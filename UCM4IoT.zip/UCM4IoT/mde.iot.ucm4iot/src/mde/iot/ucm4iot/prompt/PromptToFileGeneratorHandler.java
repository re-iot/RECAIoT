package mde.iot.ucm4iot.prompt;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.handlers.HandlerUtil;

import mde.iot.ucm4iot.prompt.RichTextInputDialog.IProcessingCallback;
import mde.iot.ucm4iot.prompt.RichTextInputDialog.IProcessingCallbackHandler;



public class PromptToFileGeneratorHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
        Shell shell = HandlerUtil.getActiveShell(event);
        RichTextInputDialog dialog = new RichTextInputDialog(shell, 
                "UCM4IoT Prompt", 
                "Enter your prompt for the AI:");
        
        dialog.setProcessingCallback(new IProcessingCallback() {

			@Override
			public void process(String input, IProcessingCallbackHandler handler) {
				
				try {
					IProject project= getProjectNameFromHandlerContext(event).orElseThrow();
					LangChainService.getInstance(project).generate(input, (output) -> {
						System.out.println("output: "+output);
						handler.onSuccess(output);            	
					});
				} catch (Throwable e) {
					handler.onFailure(e);
				}
			}
        	
        });

        if (dialog.open() == InputDialog.OK) {
            String proccessedResult = dialog.getProcessedResult();
            System.out.println("proccessedResult: "+ proccessedResult);
            
            String projectName = getProjectNameFromHandlerContext(event).orElseThrow().getName();
            System.out.println(projectName);
            
            
            writeToFile(proccessedResult, projectName);
            
        }

		return null;
	}
	
	public Optional<IProject> getProjectNameFromHandlerContext(ExecutionEvent event) {
        IStructuredSelection selection = (IStructuredSelection) HandlerUtil.getCurrentSelection(event);
        if (selection != null && !selection.isEmpty()) {
            Object element = selection.getFirstElement();
            if (element instanceof IResource) {
                IProject project = ((IResource) element).getProject();
                return Optional.ofNullable(project);
            }
        }
        return Optional.empty();
    }


	private void writeToFile(String output, String projectName ) {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		         
		IProject project = root.getProject(projectName);
		if (!project.exists()) {
		    System.out.println("Project does not exist: " + projectName);
		    return;
		}
		
		System.out.println("project name: "+ project.getName());
		
		System.out.println("project location: "+ project.getLocation().toString());

		IFolder srcUcmFolder = project.getFolder("src-ucm");
		if (!srcUcmFolder.exists()) {
		    try {
		        srcUcmFolder.create(true, true, null);
		    } catch (CoreException e) {
		        e.printStackTrace();
		        return;
		    }
		}
		
		String baseFileName = projectName;
	    String extension = ".ucmiot";

	    var fullPath = project.getLocation().toString() +"/src-ucm/"+baseFileName;
		
	    Path filePath = Path.of( fullPath+ extension);
	    
	    int counter = 1;
	    while (Files.exists(filePath)) {
	        filePath = Path.of(fullPath + "_" + counter + extension);
	        counter++;
	    }
	    
		
	    try {
	        Files.write(filePath, output.getBytes(StandardCharsets.UTF_8));
	        System.out.println("File written: " + filePath.toAbsolutePath());
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    
	    Display.getDefault().asyncExec(() -> {
	        try {
	            ResourcesPlugin.getWorkspace().getRoot().refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor());
	        } catch (CoreException e) {
	            e.printStackTrace();
	        }
	    });

	}
	
	
	public Optional<String> getProjectNameFromSelection() {
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
        IWorkspaceRoot root = workspace.getRoot();

        // Iterate over all open projects
        for (IProject project : root.getProjects()) {
            if (project.isOpen()) {
                return Optional.ofNullable(project.getName());
            }
        }

        return Optional.empty();
    }

}