package mde.iot.ucm4iot.prompt;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;

public class RichTextInputDialog extends Dialog {
    private String title;
    private String message;
    private String inputText;
    private StyledText styledText;
    
    // Optional callback for processing the input.
    private IProcessingCallback processingCallback;
    // This field can store the result from processing.
    private String processedResult;
    
    // New UI controls for showing progress within the dialog.
    private Composite progressComposite;
    private Label progressLabel;
    private ProgressBar progressBar;
    private Button okButton;

    public RichTextInputDialog(Shell parentShell, String title, String message) {
        super(parentShell);
        this.title = title;
        this.message = message;
        this.inputText = "";
    }

    /**
     * Set the processing callback.
     * 
     * @param processingCallback the callback that performs processing.
     */
    public void setProcessingCallback(IProcessingCallback processingCallback) {
        this.processingCallback = processingCallback;
    }

    /**
     * Get the processed result after the callback is executed.
     * 
     * @return the result produced by the processing callback.
     */
    public String getProcessedResult() {
        return processedResult;
    }

    public String getInputText() {
        return inputText;
    }


	@Override
	protected Point getInitialSize() {
		return new Point(800, 600);
	}

	@Override
    protected void configureShell(Shell shell) {
        super.configureShell(shell);
        shell.setText(title);
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite container = (Composite) super.createDialogArea(parent);
        container.setLayout(new GridLayout(1, false));

        // Add a label for the message.
        if (message != null) {
            Label label = new Label(container, SWT.WRAP);
            label.setText(message);
            GridData labelData = new GridData(SWT.FILL, SWT.CENTER, true, false);
            labelData.widthHint = 400;
            label.setLayoutData(labelData);
        }

        // Add the StyledText widget for rich text editing.
        styledText = new StyledText(container, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL);
        GridData textData = new GridData(SWT.FILL, SWT.FILL, true, true);
        textData.heightHint = 200;
        styledText.setLayoutData(textData);

        // --- Begin of integrated progress UI ---
        progressComposite = new Composite(container, SWT.NONE);
        progressComposite.setLayout(new GridLayout(1, false));
        GridData progressData = new GridData(SWT.FILL, SWT.CENTER, true, false);
        progressComposite.setLayoutData(progressData);
        progressComposite.setVisible(false); // Hidden until processing starts

        progressLabel = new Label(progressComposite, SWT.NONE);
        progressLabel.setText("Processing your input, please wait...");
        progressLabel.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false));

        progressBar = new ProgressBar(progressComposite, SWT.INDETERMINATE | SWT.SMOOTH);
        progressBar.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
        // --- End of integrated progress UI ---

        return container;
    }

    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        // Create OK and Cancel buttons as usual.
        okButton = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
        createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
    }

    @Override
    protected void okPressed() {
        // Capture the text input.
        inputText = styledText.getText();

        // If no processing callback was set, close the dialog immediately.
        if (processingCallback == null) {
            super.okPressed();
            return;
        }

        // Show the integrated progress UI.
        progressComposite.setVisible(true);
        // Disable input controls and the OK button.
        styledText.setEnabled(false);
        if (okButton != null && !okButton.isDisposed()) {
            okButton.setEnabled(false);
        }
        // Refresh layout so the progress controls appear.
        progressComposite.getParent().layout();

        // Start a background thread to execute the processing callback.
        Thread processingThread = new Thread(() -> {
            // Execute the processing callback, passing a handler to receive the result.
            processingCallback.process(inputText, new IProcessingCallbackHandler() {
                @Override
                public void onSuccess(String result) {
                    processedResult = result;
                    Display.getDefault().asyncExec(() -> {
                        RichTextInputDialog.super.okPressed();
                    });
                }

                @Override
                public void onFailure(Throwable ex) {
                    Display.getDefault().asyncExec(() -> {
                        ex.printStackTrace();
                       
                        MessageDialog.openError(
                                Display.getDefault().getActiveShell(), // Parent shell
                                "Error", // Dialog title
                                "An error occurred: " + ex.getMessage() // Error message
                            );
                        RichTextInputDialog.super.okPressed();
                    });
                }
            });
        });
        processingThread.start();
        // Note: Unlike before, we do not block with a modal loading dialog;
        // the progress controls within this dialog indicate processing is underway.
    }

    /**
     * Interface for injecting processing logic.
     * The implementer should perform the long-running work and report results via the handler.
     */
    public static interface IProcessingCallback {
        /**
         * Process the given input.
         *
         * @param input   The input text.
         * @param handler The handler to report success or failure.
         */
        void process(String input, IProcessingCallbackHandler handler);
    }

    /**
     * Interface for receiving the results of the processing.
     */
    public static interface IProcessingCallbackHandler {
        /**
         * Called when processing completes successfully.
         *
         * @param result The result of processing.
         */
        void onSuccess(String result);

        /**
         * Called if processing fails.
         *
         * @param ex The exception that occurred.
         */
        void onFailure(Throwable ex);
    }
}