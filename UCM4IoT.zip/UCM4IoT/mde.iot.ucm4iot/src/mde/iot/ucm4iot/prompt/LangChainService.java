package mde.iot.ucm4iot.prompt;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Optional;
import java.util.function.Consumer;

import org.eclipse.core.resources.IProject;

import ca.tabassum.LangChain4JConfig;
import ca.tabassum.LangChainUcm4IoTService;
import dev.langchain4j.service.SystemMessage;

public class LangChainService {

	// Configuration values extracted to constants
	private static final String API_KEY = System.getenv("OPENAI_API_KEY");

	private static final String MODEL_NAME = "gpt-4o"; // Replace with your preferred model
	private static final double TEMPERATURE = 0.1;
	private static final Duration TIMEOUT = Duration.ofMinutes(5); // Timeout in milliseconds
	private static final int MAX_TOKENS = 16_000;
	private static final double FREQUENCY_PENALTY = 0.0;
	private static final boolean LOG_REQUESTS = true;
	private static final boolean LOG_RESPONSES = true;
	private static final int MAX_MEMORY = 10;
	private static final double topP = 0.95;

	private static final String SYSTEM_MESSAGE = "You are a software engineer specializing in IoT systems with a PhD in model-driven engineering. "
			+ "You are an expert in requirements engineering and software modeling.";

	private static LangChainService langChainService;

	private LangChainUcm4IoTService service;

	private IProject project;

	private LangChainService(IProject project) {
		this.project = project;

		LangChain4JConfig config = LangChain4JConfig.builder()
				.apiKey(API_KEY).modelName(MODEL_NAME)
				.temperature(TEMPERATURE)
				.timeout(TIMEOUT)
				.maxTokens(MAX_TOKENS)
				.maxMemorySize(MAX_MEMORY)
				.logRequests(LOG_REQUESTS)
				.logResponses(LOG_RESPONSES)
				.frequencyPenalty(FREQUENCY_PENALTY)
				.topP(topP)
				.systemMessageProvider((obj) -> {
					return readSystemMessage()
					.orElse(SYSTEM_MESSAGE);
				})
				.build();

		service = new LangChainUcm4IoTService(config);
		
	}

	public void generate(String message, Consumer<String> consumer) {
		service.sendMessage(message, consumer);
	}

	public static LangChainService getInstance(IProject project) {
		if (langChainService == null)
			langChainService = new LangChainService(project);
		return langChainService;
	}

	Optional<String> readSystemMessage() {
		System.out.println("readSystemMessage () being called");
		
		
		String path = this.project.getLocation().toString() + "/src-ucm/SystemMessage.md";
		try {
			return Optional.ofNullable(Files.readString(Path.of(path)));
		} catch (IOException e) {
			e.printStackTrace();
		}

		return Optional.empty();

	}
}