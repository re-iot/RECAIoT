/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>On Device Resource</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getOnDeviceResource()
 * @model
 * @generated
 */
public interface OnDeviceResource extends Resource {
} // OnDeviceResource
