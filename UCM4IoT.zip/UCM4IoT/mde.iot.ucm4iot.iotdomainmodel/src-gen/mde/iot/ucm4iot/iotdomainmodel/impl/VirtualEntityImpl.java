/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import java.util.Collection;

import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.Resource;
import mde.iot.ucm4iot.iotdomainmodel.Service;
import mde.iot.ucm4iot.iotdomainmodel.VirtualEntity;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Virtual Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl#getRepresents <em>Represents</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl#getAssociated <em>Associated</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl#getContains <em>Contains</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl#getAssociatedResource <em>Associated Resource</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VirtualEntityImpl extends ActiveDigitalArtefactImpl implements VirtualEntity {
	/**
	 * The cached value of the '{@link #getRepresents() <em>Represents</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRepresents()
	 * @generated
	 * @ordered
	 */
	protected EList<PhysicalEntity> represents;

	/**
	 * The cached value of the '{@link #getAssociated() <em>Associated</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssociated()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> associated;

	/**
	 * The cached value of the '{@link #getContains() <em>Contains</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContains()
	 * @generated
	 * @ordered
	 */
	protected EList<VirtualEntity> contains;

	/**
	 * The cached value of the '{@link #getAssociatedResource() <em>Associated Resource</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssociatedResource()
	 * @generated
	 * @ordered
	 */
	protected Resource associatedResource;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VirtualEntityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.VIRTUAL_ENTITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PhysicalEntity> getRepresents() {
		if (represents == null) {
			represents = new EObjectResolvingEList<PhysicalEntity>(PhysicalEntity.class, this,
					IotdomainmodelPackage.VIRTUAL_ENTITY__REPRESENTS);
		}
		return represents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getAssociated() {
		if (associated == null) {
			associated = new EObjectResolvingEList<Service>(Service.class, this,
					IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED);
		}
		return associated;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VirtualEntity> getContains() {
		if (contains == null) {
			contains = new EObjectResolvingEList<VirtualEntity>(VirtualEntity.class, this,
					IotdomainmodelPackage.VIRTUAL_ENTITY__CONTAINS);
		}
		return contains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Resource getAssociatedResource() {
		if (associatedResource != null && associatedResource.eIsProxy()) {
			InternalEObject oldAssociatedResource = (InternalEObject) associatedResource;
			associatedResource = (Resource) eResolveProxy(oldAssociatedResource);
			if (associatedResource != oldAssociatedResource) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED_RESOURCE, oldAssociatedResource,
							associatedResource));
			}
		}
		return associatedResource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Resource basicGetAssociatedResource() {
		return associatedResource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAssociatedResource(Resource newAssociatedResource) {
		Resource oldAssociatedResource = associatedResource;
		associatedResource = newAssociatedResource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED_RESOURCE, oldAssociatedResource,
					associatedResource));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.VIRTUAL_ENTITY__REPRESENTS:
			return getRepresents();
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED:
			return getAssociated();
		case IotdomainmodelPackage.VIRTUAL_ENTITY__CONTAINS:
			return getContains();
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED_RESOURCE:
			if (resolve)
				return getAssociatedResource();
			return basicGetAssociatedResource();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.VIRTUAL_ENTITY__REPRESENTS:
			getRepresents().clear();
			getRepresents().addAll((Collection<? extends PhysicalEntity>) newValue);
			return;
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED:
			getAssociated().clear();
			getAssociated().addAll((Collection<? extends Service>) newValue);
			return;
		case IotdomainmodelPackage.VIRTUAL_ENTITY__CONTAINS:
			getContains().clear();
			getContains().addAll((Collection<? extends VirtualEntity>) newValue);
			return;
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED_RESOURCE:
			setAssociatedResource((Resource) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.VIRTUAL_ENTITY__REPRESENTS:
			getRepresents().clear();
			return;
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED:
			getAssociated().clear();
			return;
		case IotdomainmodelPackage.VIRTUAL_ENTITY__CONTAINS:
			getContains().clear();
			return;
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED_RESOURCE:
			setAssociatedResource((Resource) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.VIRTUAL_ENTITY__REPRESENTS:
			return represents != null && !represents.isEmpty();
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED:
			return associated != null && !associated.isEmpty();
		case IotdomainmodelPackage.VIRTUAL_ENTITY__CONTAINS:
			return contains != null && !contains.isEmpty();
		case IotdomainmodelPackage.VIRTUAL_ENTITY__ASSOCIATED_RESOURCE:
			return associatedResource != null;
		}
		return super.eIsSet(featureID);
	}

} //VirtualEntityImpl
