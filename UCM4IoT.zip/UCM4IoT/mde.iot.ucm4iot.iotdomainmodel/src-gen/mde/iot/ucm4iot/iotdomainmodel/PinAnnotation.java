/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pin Annotation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getType <em>Type</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getNumber <em>Number</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getPinAnnotation()
 * @model
 * @generated
 */
public interface PinAnnotation extends Annotation {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The default value is <code>"INPUT"</code>.
	 * The literals are from the enumeration {@link mde.iot.ucm4iot.iotdomainmodel.PinType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinType
	 * @see #setType(PinType)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getPinAnnotation_Type()
	 * @model default="INPUT"
	 * @generated
	 */
	PinType getType();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinType
	 * @see #getType()
	 * @generated
	 */
	void setType(PinType value);

	/**
	 * Returns the value of the '<em><b>Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Number</em>' attribute.
	 * @see #setNumber(int)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getPinAnnotation_Number()
	 * @model
	 * @generated
	 */
	int getNumber();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getNumber <em>Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Number</em>' attribute.
	 * @see #getNumber()
	 * @generated
	 */
	void setNumber(int value);

} // PinAnnotation
