/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Active Digital Artefact</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getActiveDigitalArtefact()
 * @model abstract="true"
 * @generated
 */
public interface ActiveDigitalArtefact extends User, DigitalArtefact {
} // ActiveDigitalArtefact
