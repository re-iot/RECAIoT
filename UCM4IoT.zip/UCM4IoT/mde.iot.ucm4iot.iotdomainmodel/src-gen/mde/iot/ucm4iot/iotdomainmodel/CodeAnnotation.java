/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Code Annotation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionName <em>Function Name</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionCode <em>Function Code</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getCodeAnnotation()
 * @model
 * @generated
 */
public interface CodeAnnotation extends Annotation {
	/**
	 * Returns the value of the '<em><b>Function Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Name</em>' attribute.
	 * @see #setFunctionName(String)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getCodeAnnotation_FunctionName()
	 * @model
	 * @generated
	 */
	String getFunctionName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionName <em>Function Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Name</em>' attribute.
	 * @see #getFunctionName()
	 * @generated
	 */
	void setFunctionName(String value);

	/**
	 * Returns the value of the '<em><b>Function Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Code</em>' attribute.
	 * @see #setFunctionCode(String)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getCodeAnnotation_FunctionCode()
	 * @model
	 * @generated
	 */
	String getFunctionCode();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionCode <em>Function Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Code</em>' attribute.
	 * @see #getFunctionCode()
	 * @generated
	 */
	void setFunctionCode(String value);

} // CodeAnnotation
