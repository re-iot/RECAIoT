/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Device</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Device#getAttachedTo <em>Attached To</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Device#getContains <em>Contains</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Device#getHosts <em>Hosts</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Device#getCodeAnnotations <em>Code Annotations</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Device#getPinannotation <em>Pinannotation</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDevice()
 * @model
 * @generated
 */
public interface Device extends PhysicalEntity {
	/**
	 * Returns the value of the '<em><b>Attached To</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attached To</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDevice_AttachedTo()
	 * @model
	 * @generated
	 */
	EList<PhysicalEntity> getAttachedTo();

	/**
	 * Returns the value of the '<em><b>Contains</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.Device}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDevice_Contains()
	 * @model
	 * @generated
	 */
	EList<Device> getContains();

	/**
	 * Returns the value of the '<em><b>Hosts</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hosts</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDevice_Hosts()
	 * @model
	 * @generated
	 */
	EList<OnDeviceResource> getHosts();

	/**
	 * Returns the value of the '<em><b>Code Annotations</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code Annotations</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDevice_CodeAnnotations()
	 * @model containment="true"
	 * @generated
	 */
	EList<CodeAnnotation> getCodeAnnotations();

	/**
	 * Returns the value of the '<em><b>Pinannotation</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pinannotation</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDevice_Pinannotation()
	 * @model containment="true"
	 * @generated
	 */
	EList<PinAnnotation> getPinannotation();

} // Device
