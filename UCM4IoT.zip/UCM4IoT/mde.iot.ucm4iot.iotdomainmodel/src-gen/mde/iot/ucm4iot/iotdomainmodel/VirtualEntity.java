/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Virtual Entity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getRepresents <em>Represents</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociated <em>Associated</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getContains <em>Contains</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociatedResource <em>Associated Resource</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getVirtualEntity()
 * @model
 * @generated
 */
public interface VirtualEntity extends ActiveDigitalArtefact, PassiveDigitalArtefact {
	/**
	 * Returns the value of the '<em><b>Represents</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Represents</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getVirtualEntity_Represents()
	 * @model required="true"
	 * @generated
	 */
	EList<PhysicalEntity> getRepresents();

	/**
	 * Returns the value of the '<em><b>Associated</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.Service}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Associated</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getVirtualEntity_Associated()
	 * @model
	 * @generated
	 */
	EList<Service> getAssociated();

	/**
	 * Returns the value of the '<em><b>Contains</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getVirtualEntity_Contains()
	 * @model
	 * @generated
	 */
	EList<VirtualEntity> getContains();

	/**
	 * Returns the value of the '<em><b>Associated Resource</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Associated Resource</em>' reference.
	 * @see #setAssociatedResource(Resource)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getVirtualEntity_AssociatedResource()
	 * @model
	 * @generated
	 */
	Resource getAssociatedResource();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociatedResource <em>Associated Resource</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Associated Resource</em>' reference.
	 * @see #getAssociatedResource()
	 * @generated
	 */
	void setAssociatedResource(Resource value);

} // VirtualEntity
