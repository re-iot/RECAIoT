/**
 */
package mde.iot.ucm4iot.iotdomainmodel.util;

import mde.iot.ucm4iot.iotdomainmodel.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage
 * @generated
 */
public class IotdomainmodelSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static IotdomainmodelPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IotdomainmodelSwitch() {
		if (modelPackage == null) {
			modelPackage = IotdomainmodelPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case IotdomainmodelPackage.USER: {
			User user = (User) theEObject;
			T result = caseUser(user);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.HUMAN_USER: {
			HumanUser humanUser = (HumanUser) theEObject;
			T result = caseHumanUser(humanUser);
			if (result == null)
				result = caseUser(humanUser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.DIGITAL_ARTEFACT: {
			DigitalArtefact digitalArtefact = (DigitalArtefact) theEObject;
			T result = caseDigitalArtefact(digitalArtefact);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.ACTIVE_DIGITAL_ARTEFACT: {
			ActiveDigitalArtefact activeDigitalArtefact = (ActiveDigitalArtefact) theEObject;
			T result = caseActiveDigitalArtefact(activeDigitalArtefact);
			if (result == null)
				result = caseUser(activeDigitalArtefact);
			if (result == null)
				result = caseDigitalArtefact(activeDigitalArtefact);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.PASSIVE_DIGITAL_ARTEFACT: {
			PassiveDigitalArtefact passiveDigitalArtefact = (PassiveDigitalArtefact) theEObject;
			T result = casePassiveDigitalArtefact(passiveDigitalArtefact);
			if (result == null)
				result = caseDigitalArtefact(passiveDigitalArtefact);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.SERVICE: {
			Service service = (Service) theEObject;
			T result = caseService(service);
			if (result == null)
				result = caseActiveDigitalArtefact(service);
			if (result == null)
				result = caseUser(service);
			if (result == null)
				result = caseDigitalArtefact(service);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.VIRTUAL_ENTITY: {
			VirtualEntity virtualEntity = (VirtualEntity) theEObject;
			T result = caseVirtualEntity(virtualEntity);
			if (result == null)
				result = caseActiveDigitalArtefact(virtualEntity);
			if (result == null)
				result = casePassiveDigitalArtefact(virtualEntity);
			if (result == null)
				result = caseUser(virtualEntity);
			if (result == null)
				result = caseDigitalArtefact(virtualEntity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.PHYSICAL_ENTITY: {
			PhysicalEntity physicalEntity = (PhysicalEntity) theEObject;
			T result = casePhysicalEntity(physicalEntity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.AUGMENTED_ENTITY: {
			AugmentedEntity augmentedEntity = (AugmentedEntity) theEObject;
			T result = caseAugmentedEntity(augmentedEntity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.RESOURCE: {
			Resource resource = (Resource) theEObject;
			T result = caseResource(resource);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.NETWORK_RESOURCE: {
			NetworkResource networkResource = (NetworkResource) theEObject;
			T result = caseNetworkResource(networkResource);
			if (result == null)
				result = caseResource(networkResource);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.ON_DEVICE_RESOURCE: {
			OnDeviceResource onDeviceResource = (OnDeviceResource) theEObject;
			T result = caseOnDeviceResource(onDeviceResource);
			if (result == null)
				result = caseResource(onDeviceResource);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.DEVICE: {
			Device device = (Device) theEObject;
			T result = caseDevice(device);
			if (result == null)
				result = casePhysicalEntity(device);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.ACTUATOR: {
			Actuator actuator = (Actuator) theEObject;
			T result = caseActuator(actuator);
			if (result == null)
				result = caseDevice(actuator);
			if (result == null)
				result = casePhysicalEntity(actuator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.TAG: {
			Tag tag = (Tag) theEObject;
			T result = caseTag(tag);
			if (result == null)
				result = caseDevice(tag);
			if (result == null)
				result = casePhysicalEntity(tag);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.SENSOR: {
			Sensor sensor = (Sensor) theEObject;
			T result = caseSensor(sensor);
			if (result == null)
				result = caseDevice(sensor);
			if (result == null)
				result = casePhysicalEntity(sensor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL: {
			IoTDomainModel ioTDomainModel = (IoTDomainModel) theEObject;
			T result = caseIoTDomainModel(ioTDomainModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.ANNOTATION: {
			Annotation annotation = (Annotation) theEObject;
			T result = caseAnnotation(annotation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.CODE_ANNOTATION: {
			CodeAnnotation codeAnnotation = (CodeAnnotation) theEObject;
			T result = caseCodeAnnotation(codeAnnotation);
			if (result == null)
				result = caseAnnotation(codeAnnotation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.NOTE_ANNOTATION: {
			NoteAnnotation noteAnnotation = (NoteAnnotation) theEObject;
			T result = caseNoteAnnotation(noteAnnotation);
			if (result == null)
				result = caseAnnotation(noteAnnotation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case IotdomainmodelPackage.PIN_ANNOTATION: {
			PinAnnotation pinAnnotation = (PinAnnotation) theEObject;
			T result = casePinAnnotation(pinAnnotation);
			if (result == null)
				result = caseAnnotation(pinAnnotation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>User</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>User</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUser(User object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Human User</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Human User</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHumanUser(HumanUser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Digital Artefact</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Digital Artefact</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDigitalArtefact(DigitalArtefact object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Active Digital Artefact</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Active Digital Artefact</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActiveDigitalArtefact(ActiveDigitalArtefact object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Passive Digital Artefact</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Passive Digital Artefact</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePassiveDigitalArtefact(PassiveDigitalArtefact object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseService(Service object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Virtual Entity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Virtual Entity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVirtualEntity(VirtualEntity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Physical Entity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Physical Entity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePhysicalEntity(PhysicalEntity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Augmented Entity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Augmented Entity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAugmentedEntity(AugmentedEntity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Resource</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Resource</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseResource(Resource object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Network Resource</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Network Resource</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNetworkResource(NetworkResource object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>On Device Resource</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>On Device Resource</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOnDeviceResource(OnDeviceResource object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Device</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Device</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDevice(Device object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Actuator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Actuator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActuator(Actuator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tag</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tag</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTag(Tag object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sensor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSensor(Sensor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Io TDomain Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Io TDomain Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIoTDomainModel(IoTDomainModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAnnotation(Annotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Code Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Code Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCodeAnnotation(CodeAnnotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Note Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Note Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNoteAnnotation(NoteAnnotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pin Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pin Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePinAnnotation(PinAnnotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //IotdomainmodelSwitch
