/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IotdomainmodelFactoryImpl extends EFactoryImpl implements IotdomainmodelFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static IotdomainmodelFactory init() {
		try {
			IotdomainmodelFactory theIotdomainmodelFactory = (IotdomainmodelFactory) EPackage.Registry.INSTANCE
					.getEFactory(IotdomainmodelPackage.eNS_URI);
			if (theIotdomainmodelFactory != null) {
				return theIotdomainmodelFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new IotdomainmodelFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IotdomainmodelFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case IotdomainmodelPackage.HUMAN_USER:
			return createHumanUser();
		case IotdomainmodelPackage.SERVICE:
			return createService();
		case IotdomainmodelPackage.VIRTUAL_ENTITY:
			return createVirtualEntity();
		case IotdomainmodelPackage.PHYSICAL_ENTITY:
			return createPhysicalEntity();
		case IotdomainmodelPackage.AUGMENTED_ENTITY:
			return createAugmentedEntity();
		case IotdomainmodelPackage.NETWORK_RESOURCE:
			return createNetworkResource();
		case IotdomainmodelPackage.ON_DEVICE_RESOURCE:
			return createOnDeviceResource();
		case IotdomainmodelPackage.DEVICE:
			return createDevice();
		case IotdomainmodelPackage.ACTUATOR:
			return createActuator();
		case IotdomainmodelPackage.TAG:
			return createTag();
		case IotdomainmodelPackage.SENSOR:
			return createSensor();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL:
			return createIoTDomainModel();
		case IotdomainmodelPackage.CODE_ANNOTATION:
			return createCodeAnnotation();
		case IotdomainmodelPackage.NOTE_ANNOTATION:
			return createNoteAnnotation();
		case IotdomainmodelPackage.PIN_ANNOTATION:
			return createPinAnnotation();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case IotdomainmodelPackage.PIN_TYPE:
			return createPinTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case IotdomainmodelPackage.PIN_TYPE:
			return convertPinTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HumanUser createHumanUser() {
		HumanUserImpl humanUser = new HumanUserImpl();
		return humanUser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Service createService() {
		ServiceImpl service = new ServiceImpl();
		return service;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VirtualEntity createVirtualEntity() {
		VirtualEntityImpl virtualEntity = new VirtualEntityImpl();
		return virtualEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntity createPhysicalEntity() {
		PhysicalEntityImpl physicalEntity = new PhysicalEntityImpl();
		return physicalEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AugmentedEntity createAugmentedEntity() {
		AugmentedEntityImpl augmentedEntity = new AugmentedEntityImpl();
		return augmentedEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkResource createNetworkResource() {
		NetworkResourceImpl networkResource = new NetworkResourceImpl();
		return networkResource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OnDeviceResource createOnDeviceResource() {
		OnDeviceResourceImpl onDeviceResource = new OnDeviceResourceImpl();
		return onDeviceResource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Device createDevice() {
		DeviceImpl device = new DeviceImpl();
		return device;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator createActuator() {
		ActuatorImpl actuator = new ActuatorImpl();
		return actuator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tag createTag() {
		TagImpl tag = new TagImpl();
		return tag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sensor createSensor() {
		SensorImpl sensor = new SensorImpl();
		return sensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IoTDomainModel createIoTDomainModel() {
		IoTDomainModelImpl ioTDomainModel = new IoTDomainModelImpl();
		return ioTDomainModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodeAnnotation createCodeAnnotation() {
		CodeAnnotationImpl codeAnnotation = new CodeAnnotationImpl();
		return codeAnnotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NoteAnnotation createNoteAnnotation() {
		NoteAnnotationImpl noteAnnotation = new NoteAnnotationImpl();
		return noteAnnotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PinAnnotation createPinAnnotation() {
		PinAnnotationImpl pinAnnotation = new PinAnnotationImpl();
		return pinAnnotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PinType createPinTypeFromString(EDataType eDataType, String initialValue) {
		PinType result = PinType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPinTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IotdomainmodelPackage getIotdomainmodelPackage() {
		return (IotdomainmodelPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static IotdomainmodelPackage getPackage() {
		return IotdomainmodelPackage.eINSTANCE;
	}

} //IotdomainmodelFactoryImpl
