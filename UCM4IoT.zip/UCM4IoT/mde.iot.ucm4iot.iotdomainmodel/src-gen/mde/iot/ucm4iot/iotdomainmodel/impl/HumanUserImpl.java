/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.HumanUser;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Human User</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class HumanUserImpl extends UserImpl implements HumanUser {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HumanUserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.HUMAN_USER;
	}

} //HumanUserImpl
