/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.ActiveDigitalArtefact;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Active Digital Artefact</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ActiveDigitalArtefactImpl extends UserImpl implements ActiveDigitalArtefact {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActiveDigitalArtefactImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.ACTIVE_DIGITAL_ARTEFACT;
	}

} //ActiveDigitalArtefactImpl
