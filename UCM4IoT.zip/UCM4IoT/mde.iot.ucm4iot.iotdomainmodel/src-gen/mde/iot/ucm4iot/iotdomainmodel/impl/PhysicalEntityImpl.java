/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import java.util.Collection;

import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Physical Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.PhysicalEntityImpl#getPhysicalEntities <em>Physical Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.PhysicalEntityImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PhysicalEntityImpl extends MinimalEObjectImpl.Container implements PhysicalEntity {
	/**
	 * The cached value of the '{@link #getPhysicalEntities() <em>Physical Entities</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhysicalEntities()
	 * @generated
	 * @ordered
	 */
	protected EList<PhysicalEntity> physicalEntities;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PhysicalEntityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.PHYSICAL_ENTITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PhysicalEntity> getPhysicalEntities() {
		if (physicalEntities == null) {
			physicalEntities = new EObjectResolvingEList<PhysicalEntity>(PhysicalEntity.class, this,
					IotdomainmodelPackage.PHYSICAL_ENTITY__PHYSICAL_ENTITIES);
		}
		return physicalEntities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.PHYSICAL_ENTITY__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.PHYSICAL_ENTITY__PHYSICAL_ENTITIES:
			return getPhysicalEntities();
		case IotdomainmodelPackage.PHYSICAL_ENTITY__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.PHYSICAL_ENTITY__PHYSICAL_ENTITIES:
			getPhysicalEntities().clear();
			getPhysicalEntities().addAll((Collection<? extends PhysicalEntity>) newValue);
			return;
		case IotdomainmodelPackage.PHYSICAL_ENTITY__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.PHYSICAL_ENTITY__PHYSICAL_ENTITIES:
			getPhysicalEntities().clear();
			return;
		case IotdomainmodelPackage.PHYSICAL_ENTITY__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.PHYSICAL_ENTITY__PHYSICAL_ENTITIES:
			return physicalEntities != null && !physicalEntities.isEmpty();
		case IotdomainmodelPackage.PHYSICAL_ENTITY__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //PhysicalEntityImpl
