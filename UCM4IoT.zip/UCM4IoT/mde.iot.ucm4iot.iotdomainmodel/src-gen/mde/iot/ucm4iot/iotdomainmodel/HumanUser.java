/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Human User</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getHumanUser()
 * @model
 * @generated
 */
public interface HumanUser extends User {
} // HumanUser
