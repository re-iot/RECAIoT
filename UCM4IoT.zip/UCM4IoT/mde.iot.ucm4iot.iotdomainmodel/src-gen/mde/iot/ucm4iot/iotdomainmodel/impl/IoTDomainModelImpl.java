/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import java.util.Collection;

import mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity;
import mde.iot.ucm4iot.iotdomainmodel.Device;
import mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.Resource;
import mde.iot.ucm4iot.iotdomainmodel.Service;
import mde.iot.ucm4iot.iotdomainmodel.User;
import mde.iot.ucm4iot.iotdomainmodel.VirtualEntity;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Io TDomain Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getUsers <em>Users</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getServices <em>Services</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getPhysicalEntities <em>Physical Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getResources <em>Resources</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getVirtualEntities <em>Virtual Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getAugmentedEntities <em>Augmented Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getDevices <em>Devices</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IoTDomainModelImpl extends MinimalEObjectImpl.Container implements IoTDomainModel {
	/**
	 * The cached value of the '{@link #getUsers() <em>Users</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsers()
	 * @generated
	 * @ordered
	 */
	protected EList<User> users;

	/**
	 * The cached value of the '{@link #getServices() <em>Services</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServices()
	 * @generated
	 * @ordered
	 */
	protected EList<Service> services;

	/**
	 * The cached value of the '{@link #getPhysicalEntities() <em>Physical Entities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhysicalEntities()
	 * @generated
	 * @ordered
	 */
	protected EList<PhysicalEntity> physicalEntities;

	/**
	 * The cached value of the '{@link #getResources() <em>Resources</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResources()
	 * @generated
	 * @ordered
	 */
	protected EList<Resource> resources;

	/**
	 * The cached value of the '{@link #getVirtualEntities() <em>Virtual Entities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVirtualEntities()
	 * @generated
	 * @ordered
	 */
	protected EList<VirtualEntity> virtualEntities;

	/**
	 * The cached value of the '{@link #getAugmentedEntities() <em>Augmented Entities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAugmentedEntities()
	 * @generated
	 * @ordered
	 */
	protected EList<AugmentedEntity> augmentedEntities;

	/**
	 * The cached value of the '{@link #getDevices() <em>Devices</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDevices()
	 * @generated
	 * @ordered
	 */
	protected EList<Device> devices;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IoTDomainModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.IO_TDOMAIN_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<User> getUsers() {
		if (users == null) {
			users = new EObjectContainmentEList<User>(User.class, this, IotdomainmodelPackage.IO_TDOMAIN_MODEL__USERS);
		}
		return users;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Service> getServices() {
		if (services == null) {
			services = new EObjectContainmentEList<Service>(Service.class, this,
					IotdomainmodelPackage.IO_TDOMAIN_MODEL__SERVICES);
		}
		return services;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PhysicalEntity> getPhysicalEntities() {
		if (physicalEntities == null) {
			physicalEntities = new EObjectContainmentEList<PhysicalEntity>(PhysicalEntity.class, this,
					IotdomainmodelPackage.IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES);
		}
		return physicalEntities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Resource> getResources() {
		if (resources == null) {
			resources = new EObjectContainmentEList<Resource>(Resource.class, this,
					IotdomainmodelPackage.IO_TDOMAIN_MODEL__RESOURCES);
		}
		return resources;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VirtualEntity> getVirtualEntities() {
		if (virtualEntities == null) {
			virtualEntities = new EObjectContainmentEList<VirtualEntity>(VirtualEntity.class, this,
					IotdomainmodelPackage.IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES);
		}
		return virtualEntities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AugmentedEntity> getAugmentedEntities() {
		if (augmentedEntities == null) {
			augmentedEntities = new EObjectContainmentEList<AugmentedEntity>(AugmentedEntity.class, this,
					IotdomainmodelPackage.IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES);
		}
		return augmentedEntities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Device> getDevices() {
		if (devices == null) {
			devices = new EObjectContainmentEList<Device>(Device.class, this,
					IotdomainmodelPackage.IO_TDOMAIN_MODEL__DEVICES);
		}
		return devices;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.IO_TDOMAIN_MODEL__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__USERS:
			return ((InternalEList<?>) getUsers()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__SERVICES:
			return ((InternalEList<?>) getServices()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES:
			return ((InternalEList<?>) getPhysicalEntities()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__RESOURCES:
			return ((InternalEList<?>) getResources()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES:
			return ((InternalEList<?>) getVirtualEntities()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES:
			return ((InternalEList<?>) getAugmentedEntities()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__DEVICES:
			return ((InternalEList<?>) getDevices()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__USERS:
			return getUsers();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__SERVICES:
			return getServices();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES:
			return getPhysicalEntities();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__RESOURCES:
			return getResources();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES:
			return getVirtualEntities();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES:
			return getAugmentedEntities();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__DEVICES:
			return getDevices();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__USERS:
			getUsers().clear();
			getUsers().addAll((Collection<? extends User>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__SERVICES:
			getServices().clear();
			getServices().addAll((Collection<? extends Service>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES:
			getPhysicalEntities().clear();
			getPhysicalEntities().addAll((Collection<? extends PhysicalEntity>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__RESOURCES:
			getResources().clear();
			getResources().addAll((Collection<? extends Resource>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES:
			getVirtualEntities().clear();
			getVirtualEntities().addAll((Collection<? extends VirtualEntity>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES:
			getAugmentedEntities().clear();
			getAugmentedEntities().addAll((Collection<? extends AugmentedEntity>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__DEVICES:
			getDevices().clear();
			getDevices().addAll((Collection<? extends Device>) newValue);
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__USERS:
			getUsers().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__SERVICES:
			getServices().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES:
			getPhysicalEntities().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__RESOURCES:
			getResources().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES:
			getVirtualEntities().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES:
			getAugmentedEntities().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__DEVICES:
			getDevices().clear();
			return;
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__USERS:
			return users != null && !users.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__SERVICES:
			return services != null && !services.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES:
			return physicalEntities != null && !physicalEntities.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__RESOURCES:
			return resources != null && !resources.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES:
			return virtualEntities != null && !virtualEntities.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES:
			return augmentedEntities != null && !augmentedEntities.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__DEVICES:
			return devices != null && !devices.isEmpty();
		case IotdomainmodelPackage.IO_TDOMAIN_MODEL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //IoTDomainModelImpl
