/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Tag#getIdentifies <em>Identifies</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getTag()
 * @model
 * @generated
 */
public interface Tag extends Device {
	/**
	 * Returns the value of the '<em><b>Identifies</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifies</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getTag_Identifies()
	 * @model
	 * @generated
	 */
	EList<PhysicalEntity> getIdentifies();

} // Tag
