/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import java.util.Collection;

import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.Sensor;
import mde.iot.ucm4iot.iotdomainmodel.Tag;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.SensorImpl#getMonitors <em>Monitors</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.SensorImpl#getReads <em>Reads</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SensorImpl extends DeviceImpl implements Sensor {
	/**
	 * The cached value of the '{@link #getMonitors() <em>Monitors</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitors()
	 * @generated
	 * @ordered
	 */
	protected EList<PhysicalEntity> monitors;

	/**
	 * The cached value of the '{@link #getReads() <em>Reads</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReads()
	 * @generated
	 * @ordered
	 */
	protected EList<Tag> reads;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PhysicalEntity> getMonitors() {
		if (monitors == null) {
			monitors = new EObjectResolvingEList<PhysicalEntity>(PhysicalEntity.class, this,
					IotdomainmodelPackage.SENSOR__MONITORS);
		}
		return monitors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tag> getReads() {
		if (reads == null) {
			reads = new EObjectResolvingEList<Tag>(Tag.class, this, IotdomainmodelPackage.SENSOR__READS);
		}
		return reads;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.SENSOR__MONITORS:
			return getMonitors();
		case IotdomainmodelPackage.SENSOR__READS:
			return getReads();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.SENSOR__MONITORS:
			getMonitors().clear();
			getMonitors().addAll((Collection<? extends PhysicalEntity>) newValue);
			return;
		case IotdomainmodelPackage.SENSOR__READS:
			getReads().clear();
			getReads().addAll((Collection<? extends Tag>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.SENSOR__MONITORS:
			getMonitors().clear();
			return;
		case IotdomainmodelPackage.SENSOR__READS:
			getReads().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.SENSOR__MONITORS:
			return monitors != null && !monitors.isEmpty();
		case IotdomainmodelPackage.SENSOR__READS:
			return reads != null && !reads.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //SensorImpl
