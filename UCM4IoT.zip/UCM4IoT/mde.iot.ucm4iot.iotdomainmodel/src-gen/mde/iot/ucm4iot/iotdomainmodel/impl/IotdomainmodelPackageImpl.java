/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.ActiveDigitalArtefact;
import mde.iot.ucm4iot.iotdomainmodel.Actuator;
import mde.iot.ucm4iot.iotdomainmodel.Annotation;
import mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity;
import mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation;
import mde.iot.ucm4iot.iotdomainmodel.Device;
import mde.iot.ucm4iot.iotdomainmodel.DigitalArtefact;
import mde.iot.ucm4iot.iotdomainmodel.HumanUser;
import mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelFactory;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.NetworkResource;
import mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation;
import mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource;
import mde.iot.ucm4iot.iotdomainmodel.PassiveDigitalArtefact;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.PinAnnotation;
import mde.iot.ucm4iot.iotdomainmodel.PinType;
import mde.iot.ucm4iot.iotdomainmodel.Resource;
import mde.iot.ucm4iot.iotdomainmodel.Sensor;
import mde.iot.ucm4iot.iotdomainmodel.Service;
import mde.iot.ucm4iot.iotdomainmodel.Tag;
import mde.iot.ucm4iot.iotdomainmodel.User;
import mde.iot.ucm4iot.iotdomainmodel.VirtualEntity;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IotdomainmodelPackageImpl extends EPackageImpl implements IotdomainmodelPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass userEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass humanUserEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass digitalArtefactEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass activeDigitalArtefactEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass passiveDigitalArtefactEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass virtualEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass physicalEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass augmentedEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass networkResourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass onDeviceResourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass actuatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tagEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ioTDomainModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass annotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass codeAnnotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass noteAnnotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pinAnnotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum pinTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private IotdomainmodelPackageImpl() {
		super(eNS_URI, IotdomainmodelFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link IotdomainmodelPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static IotdomainmodelPackage init() {
		if (isInited)
			return (IotdomainmodelPackage) EPackage.Registry.INSTANCE.getEPackage(IotdomainmodelPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredIotdomainmodelPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		IotdomainmodelPackageImpl theIotdomainmodelPackage = registeredIotdomainmodelPackage instanceof IotdomainmodelPackageImpl
				? (IotdomainmodelPackageImpl) registeredIotdomainmodelPackage
				: new IotdomainmodelPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theIotdomainmodelPackage.createPackageContents();

		// Initialize created meta-data
		theIotdomainmodelPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theIotdomainmodelPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(IotdomainmodelPackage.eNS_URI, theIotdomainmodelPackage);
		return theIotdomainmodelPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUser() {
		return userEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getUser_Invokes() {
		return (EReference) userEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getUser_InteractsWith() {
		return (EReference) userEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUser_Name() {
		return (EAttribute) userEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHumanUser() {
		return humanUserEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDigitalArtefact() {
		return digitalArtefactEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getActiveDigitalArtefact() {
		return activeDigitalArtefactEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPassiveDigitalArtefact() {
		return passiveDigitalArtefactEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getService() {
		return serviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getService_Exposes() {
		return (EReference) serviceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVirtualEntity() {
		return virtualEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVirtualEntity_Represents() {
		return (EReference) virtualEntityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVirtualEntity_Associated() {
		return (EReference) virtualEntityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVirtualEntity_Contains() {
		return (EReference) virtualEntityEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVirtualEntity_AssociatedResource() {
		return (EReference) virtualEntityEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPhysicalEntity() {
		return physicalEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPhysicalEntity_PhysicalEntities() {
		return (EReference) physicalEntityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhysicalEntity_Name() {
		return (EAttribute) physicalEntityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAugmentedEntity() {
		return augmentedEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAugmentedEntity_Physicalentity() {
		return (EReference) augmentedEntityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAugmentedEntity_Virtualentity() {
		return (EReference) augmentedEntityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAugmentedEntity_Contains() {
		return (EReference) augmentedEntityEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAugmentedEntity_Name() {
		return (EAttribute) augmentedEntityEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getResource() {
		return resourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getResource_ActsOn() {
		return (EReference) resourceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getResource_HasInformationOn() {
		return (EReference) resourceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getResource_Name() {
		return (EAttribute) resourceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNetworkResource() {
		return networkResourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOnDeviceResource() {
		return onDeviceResourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDevice() {
		return deviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDevice_AttachedTo() {
		return (EReference) deviceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDevice_Contains() {
		return (EReference) deviceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDevice_Hosts() {
		return (EReference) deviceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDevice_CodeAnnotations() {
		return (EReference) deviceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDevice_Pinannotation() {
		return (EReference) deviceEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getActuator() {
		return actuatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getActuator_ActsOn() {
		return (EReference) actuatorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTag() {
		return tagEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTag_Identifies() {
		return (EReference) tagEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSensor() {
		return sensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSensor_Monitors() {
		return (EReference) sensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSensor_Reads() {
		return (EReference) sensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIoTDomainModel() {
		return ioTDomainModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_Users() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_Services() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_PhysicalEntities() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_Resources() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_VirtualEntities() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_AugmentedEntities() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIoTDomainModel_Devices() {
		return (EReference) ioTDomainModelEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIoTDomainModel_Name() {
		return (EAttribute) ioTDomainModelEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAnnotation() {
		return annotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCodeAnnotation() {
		return codeAnnotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodeAnnotation_FunctionName() {
		return (EAttribute) codeAnnotationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodeAnnotation_FunctionCode() {
		return (EAttribute) codeAnnotationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNoteAnnotation() {
		return noteAnnotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNoteAnnotation_Note() {
		return (EAttribute) noteAnnotationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPinAnnotation() {
		return pinAnnotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPinAnnotation_Type() {
		return (EAttribute) pinAnnotationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPinAnnotation_Number() {
		return (EAttribute) pinAnnotationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPinType() {
		return pinTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IotdomainmodelFactory getIotdomainmodelFactory() {
		return (IotdomainmodelFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		userEClass = createEClass(USER);
		createEReference(userEClass, USER__INVOKES);
		createEReference(userEClass, USER__INTERACTS_WITH);
		createEAttribute(userEClass, USER__NAME);

		humanUserEClass = createEClass(HUMAN_USER);

		digitalArtefactEClass = createEClass(DIGITAL_ARTEFACT);

		activeDigitalArtefactEClass = createEClass(ACTIVE_DIGITAL_ARTEFACT);

		passiveDigitalArtefactEClass = createEClass(PASSIVE_DIGITAL_ARTEFACT);

		serviceEClass = createEClass(SERVICE);
		createEReference(serviceEClass, SERVICE__EXPOSES);

		virtualEntityEClass = createEClass(VIRTUAL_ENTITY);
		createEReference(virtualEntityEClass, VIRTUAL_ENTITY__REPRESENTS);
		createEReference(virtualEntityEClass, VIRTUAL_ENTITY__ASSOCIATED);
		createEReference(virtualEntityEClass, VIRTUAL_ENTITY__CONTAINS);
		createEReference(virtualEntityEClass, VIRTUAL_ENTITY__ASSOCIATED_RESOURCE);

		physicalEntityEClass = createEClass(PHYSICAL_ENTITY);
		createEReference(physicalEntityEClass, PHYSICAL_ENTITY__PHYSICAL_ENTITIES);
		createEAttribute(physicalEntityEClass, PHYSICAL_ENTITY__NAME);

		augmentedEntityEClass = createEClass(AUGMENTED_ENTITY);
		createEReference(augmentedEntityEClass, AUGMENTED_ENTITY__PHYSICALENTITY);
		createEReference(augmentedEntityEClass, AUGMENTED_ENTITY__VIRTUALENTITY);
		createEReference(augmentedEntityEClass, AUGMENTED_ENTITY__CONTAINS);
		createEAttribute(augmentedEntityEClass, AUGMENTED_ENTITY__NAME);

		resourceEClass = createEClass(RESOURCE);
		createEReference(resourceEClass, RESOURCE__ACTS_ON);
		createEReference(resourceEClass, RESOURCE__HAS_INFORMATION_ON);
		createEAttribute(resourceEClass, RESOURCE__NAME);

		networkResourceEClass = createEClass(NETWORK_RESOURCE);

		onDeviceResourceEClass = createEClass(ON_DEVICE_RESOURCE);

		deviceEClass = createEClass(DEVICE);
		createEReference(deviceEClass, DEVICE__ATTACHED_TO);
		createEReference(deviceEClass, DEVICE__CONTAINS);
		createEReference(deviceEClass, DEVICE__HOSTS);
		createEReference(deviceEClass, DEVICE__CODE_ANNOTATIONS);
		createEReference(deviceEClass, DEVICE__PINANNOTATION);

		actuatorEClass = createEClass(ACTUATOR);
		createEReference(actuatorEClass, ACTUATOR__ACTS_ON);

		tagEClass = createEClass(TAG);
		createEReference(tagEClass, TAG__IDENTIFIES);

		sensorEClass = createEClass(SENSOR);
		createEReference(sensorEClass, SENSOR__MONITORS);
		createEReference(sensorEClass, SENSOR__READS);

		ioTDomainModelEClass = createEClass(IO_TDOMAIN_MODEL);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__USERS);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__SERVICES);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__RESOURCES);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES);
		createEReference(ioTDomainModelEClass, IO_TDOMAIN_MODEL__DEVICES);
		createEAttribute(ioTDomainModelEClass, IO_TDOMAIN_MODEL__NAME);

		annotationEClass = createEClass(ANNOTATION);

		codeAnnotationEClass = createEClass(CODE_ANNOTATION);
		createEAttribute(codeAnnotationEClass, CODE_ANNOTATION__FUNCTION_NAME);
		createEAttribute(codeAnnotationEClass, CODE_ANNOTATION__FUNCTION_CODE);

		noteAnnotationEClass = createEClass(NOTE_ANNOTATION);
		createEAttribute(noteAnnotationEClass, NOTE_ANNOTATION__NOTE);

		pinAnnotationEClass = createEClass(PIN_ANNOTATION);
		createEAttribute(pinAnnotationEClass, PIN_ANNOTATION__TYPE);
		createEAttribute(pinAnnotationEClass, PIN_ANNOTATION__NUMBER);

		// Create enums
		pinTypeEEnum = createEEnum(PIN_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		humanUserEClass.getESuperTypes().add(this.getUser());
		activeDigitalArtefactEClass.getESuperTypes().add(this.getUser());
		activeDigitalArtefactEClass.getESuperTypes().add(this.getDigitalArtefact());
		passiveDigitalArtefactEClass.getESuperTypes().add(this.getDigitalArtefact());
		serviceEClass.getESuperTypes().add(this.getActiveDigitalArtefact());
		virtualEntityEClass.getESuperTypes().add(this.getActiveDigitalArtefact());
		virtualEntityEClass.getESuperTypes().add(this.getPassiveDigitalArtefact());
		networkResourceEClass.getESuperTypes().add(this.getResource());
		onDeviceResourceEClass.getESuperTypes().add(this.getResource());
		deviceEClass.getESuperTypes().add(this.getPhysicalEntity());
		actuatorEClass.getESuperTypes().add(this.getDevice());
		tagEClass.getESuperTypes().add(this.getDevice());
		sensorEClass.getESuperTypes().add(this.getDevice());
		codeAnnotationEClass.getESuperTypes().add(this.getAnnotation());
		noteAnnotationEClass.getESuperTypes().add(this.getAnnotation());
		pinAnnotationEClass.getESuperTypes().add(this.getAnnotation());

		// Initialize classes, features, and operations; add parameters
		initEClass(userEClass, User.class, "User", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getUser_Invokes(), this.getService(), null, "invokes", null, 0, -1, User.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getUser_InteractsWith(), this.getPhysicalEntity(), null, "interactsWith", null, 0, -1,
				User.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getUser_Name(), ecorePackage.getEString(), "name", null, 0, 1, User.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(humanUserEClass, HumanUser.class, "HumanUser", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(digitalArtefactEClass, DigitalArtefact.class, "DigitalArtefact", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(activeDigitalArtefactEClass, ActiveDigitalArtefact.class, "ActiveDigitalArtefact", IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(passiveDigitalArtefactEClass, PassiveDigitalArtefact.class, "PassiveDigitalArtefact", IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(serviceEClass, Service.class, "Service", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getService_Exposes(), this.getResource(), null, "exposes", null, 0, -1, Service.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(virtualEntityEClass, VirtualEntity.class, "VirtualEntity", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVirtualEntity_Represents(), this.getPhysicalEntity(), null, "represents", null, 1, -1,
				VirtualEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVirtualEntity_Associated(), this.getService(), null, "associated", null, 0, -1,
				VirtualEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVirtualEntity_Contains(), this.getVirtualEntity(), null, "contains", null, 0, -1,
				VirtualEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVirtualEntity_AssociatedResource(), this.getResource(), null, "associatedResource", null, 0,
				1, VirtualEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(physicalEntityEClass, PhysicalEntity.class, "PhysicalEntity", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPhysicalEntity_PhysicalEntities(), this.getPhysicalEntity(), null, "physicalEntities", null,
				0, -1, PhysicalEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPhysicalEntity_Name(), ecorePackage.getEString(), "name", null, 0, 1, PhysicalEntity.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(augmentedEntityEClass, AugmentedEntity.class, "AugmentedEntity", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAugmentedEntity_Physicalentity(), this.getPhysicalEntity(), null, "physicalentity", null, 1,
				1, AugmentedEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAugmentedEntity_Virtualentity(), this.getVirtualEntity(), null, "virtualentity", null, 1, 1,
				AugmentedEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAugmentedEntity_Contains(), this.getAugmentedEntity(), null, "contains", null, 0, -1,
				AugmentedEntity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAugmentedEntity_Name(), ecorePackage.getEString(), "name", null, 0, 1, AugmentedEntity.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(resourceEClass, Resource.class, "Resource", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getResource_ActsOn(), this.getPhysicalEntity(), null, "actsOn", null, 0, 1, Resource.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getResource_HasInformationOn(), this.getPhysicalEntity(), null, "hasInformationOn", null, 0, 1,
				Resource.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getResource_Name(), ecorePackage.getEString(), "name", null, 0, 1, Resource.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(networkResourceEClass, NetworkResource.class, "NetworkResource", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(onDeviceResourceEClass, OnDeviceResource.class, "OnDeviceResource", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(deviceEClass, Device.class, "Device", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDevice_AttachedTo(), this.getPhysicalEntity(), null, "attachedTo", null, 0, -1, Device.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDevice_Contains(), this.getDevice(), null, "contains", null, 0, -1, Device.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDevice_Hosts(), this.getOnDeviceResource(), null, "hosts", null, 0, -1, Device.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDevice_CodeAnnotations(), this.getCodeAnnotation(), null, "codeAnnotations", null, 0, -1,
				Device.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDevice_Pinannotation(), this.getPinAnnotation(), null, "pinannotation", null, 0, -1,
				Device.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(actuatorEClass, Actuator.class, "Actuator", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getActuator_ActsOn(), this.getPhysicalEntity(), null, "actsOn", null, 0, -1, Actuator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tagEClass, Tag.class, "Tag", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTag_Identifies(), this.getPhysicalEntity(), null, "identifies", null, 0, -1, Tag.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sensorEClass, Sensor.class, "Sensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSensor_Monitors(), this.getPhysicalEntity(), null, "monitors", null, 0, -1, Sensor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSensor_Reads(), this.getTag(), null, "reads", null, 0, -1, Sensor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(ioTDomainModelEClass, IoTDomainModel.class, "IoTDomainModel", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getIoTDomainModel_Users(), this.getUser(), null, "users", null, 0, -1, IoTDomainModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIoTDomainModel_Services(), this.getService(), null, "services", null, 0, -1,
				IoTDomainModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIoTDomainModel_PhysicalEntities(), this.getPhysicalEntity(), null, "physicalEntities", null,
				0, -1, IoTDomainModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIoTDomainModel_Resources(), this.getResource(), null, "resources", null, 0, -1,
				IoTDomainModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIoTDomainModel_VirtualEntities(), this.getVirtualEntity(), null, "virtualEntities", null, 0,
				-1, IoTDomainModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIoTDomainModel_AugmentedEntities(), this.getAugmentedEntity(), null, "augmentedEntities",
				null, 0, -1, IoTDomainModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIoTDomainModel_Devices(), this.getDevice(), null, "devices", null, 0, -1,
				IoTDomainModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getIoTDomainModel_Name(), ecorePackage.getEString(), "name", null, 0, 1, IoTDomainModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(annotationEClass, Annotation.class, "Annotation", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(codeAnnotationEClass, CodeAnnotation.class, "CodeAnnotation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCodeAnnotation_FunctionName(), ecorePackage.getEString(), "functionName", null, 0, 1,
				CodeAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodeAnnotation_FunctionCode(), ecorePackage.getEString(), "functionCode", null, 0, 1,
				CodeAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(noteAnnotationEClass, NoteAnnotation.class, "NoteAnnotation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNoteAnnotation_Note(), ecorePackage.getEString(), "note", null, 0, 1, NoteAnnotation.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(pinAnnotationEClass, PinAnnotation.class, "PinAnnotation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPinAnnotation_Type(), this.getPinType(), "type", "INPUT", 0, 1, PinAnnotation.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPinAnnotation_Number(), ecorePackage.getEInt(), "number", null, 0, 1, PinAnnotation.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(pinTypeEEnum, PinType.class, "PinType");
		addEEnumLiteral(pinTypeEEnum, PinType.INPUT);
		addEEnumLiteral(pinTypeEEnum, PinType.OUTPUT);

		// Create resource
		createResource(eNS_URI);
	}

} //IotdomainmodelPackageImpl
