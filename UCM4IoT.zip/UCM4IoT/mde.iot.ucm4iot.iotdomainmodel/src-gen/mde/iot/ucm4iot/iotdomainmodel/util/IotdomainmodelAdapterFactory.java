/**
 */
package mde.iot.ucm4iot.iotdomainmodel.util;

import mde.iot.ucm4iot.iotdomainmodel.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage
 * @generated
 */
public class IotdomainmodelAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static IotdomainmodelPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IotdomainmodelAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = IotdomainmodelPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IotdomainmodelSwitch<Adapter> modelSwitch = new IotdomainmodelSwitch<Adapter>() {
		@Override
		public Adapter caseUser(User object) {
			return createUserAdapter();
		}

		@Override
		public Adapter caseHumanUser(HumanUser object) {
			return createHumanUserAdapter();
		}

		@Override
		public Adapter caseDigitalArtefact(DigitalArtefact object) {
			return createDigitalArtefactAdapter();
		}

		@Override
		public Adapter caseActiveDigitalArtefact(ActiveDigitalArtefact object) {
			return createActiveDigitalArtefactAdapter();
		}

		@Override
		public Adapter casePassiveDigitalArtefact(PassiveDigitalArtefact object) {
			return createPassiveDigitalArtefactAdapter();
		}

		@Override
		public Adapter caseService(Service object) {
			return createServiceAdapter();
		}

		@Override
		public Adapter caseVirtualEntity(VirtualEntity object) {
			return createVirtualEntityAdapter();
		}

		@Override
		public Adapter casePhysicalEntity(PhysicalEntity object) {
			return createPhysicalEntityAdapter();
		}

		@Override
		public Adapter caseAugmentedEntity(AugmentedEntity object) {
			return createAugmentedEntityAdapter();
		}

		@Override
		public Adapter caseResource(Resource object) {
			return createResourceAdapter();
		}

		@Override
		public Adapter caseNetworkResource(NetworkResource object) {
			return createNetworkResourceAdapter();
		}

		@Override
		public Adapter caseOnDeviceResource(OnDeviceResource object) {
			return createOnDeviceResourceAdapter();
		}

		@Override
		public Adapter caseDevice(Device object) {
			return createDeviceAdapter();
		}

		@Override
		public Adapter caseActuator(Actuator object) {
			return createActuatorAdapter();
		}

		@Override
		public Adapter caseTag(Tag object) {
			return createTagAdapter();
		}

		@Override
		public Adapter caseSensor(Sensor object) {
			return createSensorAdapter();
		}

		@Override
		public Adapter caseIoTDomainModel(IoTDomainModel object) {
			return createIoTDomainModelAdapter();
		}

		@Override
		public Adapter caseAnnotation(Annotation object) {
			return createAnnotationAdapter();
		}

		@Override
		public Adapter caseCodeAnnotation(CodeAnnotation object) {
			return createCodeAnnotationAdapter();
		}

		@Override
		public Adapter caseNoteAnnotation(NoteAnnotation object) {
			return createNoteAnnotationAdapter();
		}

		@Override
		public Adapter casePinAnnotation(PinAnnotation object) {
			return createPinAnnotationAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.User <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.User
	 * @generated
	 */
	public Adapter createUserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.HumanUser <em>Human User</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.HumanUser
	 * @generated
	 */
	public Adapter createHumanUserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.DigitalArtefact <em>Digital Artefact</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.DigitalArtefact
	 * @generated
	 */
	public Adapter createDigitalArtefactAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.ActiveDigitalArtefact <em>Active Digital Artefact</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.ActiveDigitalArtefact
	 * @generated
	 */
	public Adapter createActiveDigitalArtefactAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.PassiveDigitalArtefact <em>Passive Digital Artefact</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PassiveDigitalArtefact
	 * @generated
	 */
	public Adapter createPassiveDigitalArtefactAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Service <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Service
	 * @generated
	 */
	public Adapter createServiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity <em>Virtual Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.VirtualEntity
	 * @generated
	 */
	public Adapter createVirtualEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity <em>Physical Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity
	 * @generated
	 */
	public Adapter createPhysicalEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity <em>Augmented Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity
	 * @generated
	 */
	public Adapter createAugmentedEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Resource <em>Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Resource
	 * @generated
	 */
	public Adapter createResourceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.NetworkResource <em>Network Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.NetworkResource
	 * @generated
	 */
	public Adapter createNetworkResourceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource <em>On Device Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource
	 * @generated
	 */
	public Adapter createOnDeviceResourceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Device <em>Device</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device
	 * @generated
	 */
	public Adapter createDeviceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Actuator <em>Actuator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Actuator
	 * @generated
	 */
	public Adapter createActuatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Tag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Tag
	 * @generated
	 */
	public Adapter createTagAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Sensor
	 * @generated
	 */
	public Adapter createSensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel <em>Io TDomain Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel
	 * @generated
	 */
	public Adapter createIoTDomainModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.Annotation <em>Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Annotation
	 * @generated
	 */
	public Adapter createAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation <em>Code Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation
	 * @generated
	 */
	public Adapter createCodeAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation <em>Note Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation
	 * @generated
	 */
	public Adapter createNoteAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation <em>Pin Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinAnnotation
	 * @generated
	 */
	public Adapter createPinAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //IotdomainmodelAdapterFactory
