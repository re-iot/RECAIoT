/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Code Annotation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.CodeAnnotationImpl#getFunctionName <em>Function Name</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.CodeAnnotationImpl#getFunctionCode <em>Function Code</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CodeAnnotationImpl extends AnnotationImpl implements CodeAnnotation {
	/**
	 * The default value of the '{@link #getFunctionName() <em>Function Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionName()
	 * @generated
	 * @ordered
	 */
	protected static final String FUNCTION_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFunctionName() <em>Function Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionName()
	 * @generated
	 * @ordered
	 */
	protected String functionName = FUNCTION_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFunctionCode() <em>Function Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionCode()
	 * @generated
	 * @ordered
	 */
	protected static final String FUNCTION_CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFunctionCode() <em>Function Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionCode()
	 * @generated
	 * @ordered
	 */
	protected String functionCode = FUNCTION_CODE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CodeAnnotationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.CODE_ANNOTATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFunctionName() {
		return functionName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunctionName(String newFunctionName) {
		String oldFunctionName = functionName;
		functionName = newFunctionName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_NAME,
					oldFunctionName, functionName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunctionCode(String newFunctionCode) {
		String oldFunctionCode = functionCode;
		functionCode = newFunctionCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_CODE,
					oldFunctionCode, functionCode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_NAME:
			return getFunctionName();
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_CODE:
			return getFunctionCode();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_NAME:
			setFunctionName((String) newValue);
			return;
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_CODE:
			setFunctionCode((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_NAME:
			setFunctionName(FUNCTION_NAME_EDEFAULT);
			return;
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_CODE:
			setFunctionCode(FUNCTION_CODE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_NAME:
			return FUNCTION_NAME_EDEFAULT == null ? functionName != null : !FUNCTION_NAME_EDEFAULT.equals(functionName);
		case IotdomainmodelPackage.CODE_ANNOTATION__FUNCTION_CODE:
			return FUNCTION_CODE_EDEFAULT == null ? functionCode != null : !FUNCTION_CODE_EDEFAULT.equals(functionCode);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (functionName: ");
		result.append(functionName);
		result.append(", functionCode: ");
		result.append(functionCode);
		result.append(')');
		return result.toString();
	}

} //CodeAnnotationImpl
