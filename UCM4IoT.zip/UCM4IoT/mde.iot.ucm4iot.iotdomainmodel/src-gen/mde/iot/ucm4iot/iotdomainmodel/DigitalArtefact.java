/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Digital Artefact</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getDigitalArtefact()
 * @model abstract="true"
 * @generated
 */
public interface DigitalArtefact extends EObject {
} // DigitalArtefact
