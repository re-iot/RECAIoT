/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.NetworkResource;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Network Resource</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NetworkResourceImpl extends ResourceImpl implements NetworkResource {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkResourceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.NETWORK_RESOURCE;
	}

} //NetworkResourceImpl
