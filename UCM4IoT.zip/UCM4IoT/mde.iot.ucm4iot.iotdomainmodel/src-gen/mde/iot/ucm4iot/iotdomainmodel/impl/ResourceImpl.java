/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.Resource;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Resource</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl#getActsOn <em>Acts On</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl#getHasInformationOn <em>Has Information On</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ResourceImpl extends MinimalEObjectImpl.Container implements Resource {
	/**
	 * The cached value of the '{@link #getActsOn() <em>Acts On</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActsOn()
	 * @generated
	 * @ordered
	 */
	protected PhysicalEntity actsOn;

	/**
	 * The cached value of the '{@link #getHasInformationOn() <em>Has Information On</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHasInformationOn()
	 * @generated
	 * @ordered
	 */
	protected PhysicalEntity hasInformationOn;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ResourceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.RESOURCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntity getActsOn() {
		if (actsOn != null && actsOn.eIsProxy()) {
			InternalEObject oldActsOn = (InternalEObject) actsOn;
			actsOn = (PhysicalEntity) eResolveProxy(oldActsOn);
			if (actsOn != oldActsOn) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IotdomainmodelPackage.RESOURCE__ACTS_ON,
							oldActsOn, actsOn));
			}
		}
		return actsOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntity basicGetActsOn() {
		return actsOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActsOn(PhysicalEntity newActsOn) {
		PhysicalEntity oldActsOn = actsOn;
		actsOn = newActsOn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.RESOURCE__ACTS_ON, oldActsOn,
					actsOn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntity getHasInformationOn() {
		if (hasInformationOn != null && hasInformationOn.eIsProxy()) {
			InternalEObject oldHasInformationOn = (InternalEObject) hasInformationOn;
			hasInformationOn = (PhysicalEntity) eResolveProxy(oldHasInformationOn);
			if (hasInformationOn != oldHasInformationOn) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							IotdomainmodelPackage.RESOURCE__HAS_INFORMATION_ON, oldHasInformationOn, hasInformationOn));
			}
		}
		return hasInformationOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntity basicGetHasInformationOn() {
		return hasInformationOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHasInformationOn(PhysicalEntity newHasInformationOn) {
		PhysicalEntity oldHasInformationOn = hasInformationOn;
		hasInformationOn = newHasInformationOn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.RESOURCE__HAS_INFORMATION_ON,
					oldHasInformationOn, hasInformationOn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.RESOURCE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.RESOURCE__ACTS_ON:
			if (resolve)
				return getActsOn();
			return basicGetActsOn();
		case IotdomainmodelPackage.RESOURCE__HAS_INFORMATION_ON:
			if (resolve)
				return getHasInformationOn();
			return basicGetHasInformationOn();
		case IotdomainmodelPackage.RESOURCE__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.RESOURCE__ACTS_ON:
			setActsOn((PhysicalEntity) newValue);
			return;
		case IotdomainmodelPackage.RESOURCE__HAS_INFORMATION_ON:
			setHasInformationOn((PhysicalEntity) newValue);
			return;
		case IotdomainmodelPackage.RESOURCE__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.RESOURCE__ACTS_ON:
			setActsOn((PhysicalEntity) null);
			return;
		case IotdomainmodelPackage.RESOURCE__HAS_INFORMATION_ON:
			setHasInformationOn((PhysicalEntity) null);
			return;
		case IotdomainmodelPackage.RESOURCE__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.RESOURCE__ACTS_ON:
			return actsOn != null;
		case IotdomainmodelPackage.RESOURCE__HAS_INFORMATION_ON:
			return hasInformationOn != null;
		case IotdomainmodelPackage.RESOURCE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ResourceImpl
