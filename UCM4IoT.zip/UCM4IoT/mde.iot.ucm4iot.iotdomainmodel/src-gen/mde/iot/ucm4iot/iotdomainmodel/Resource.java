/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Resource</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getActsOn <em>Acts On</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getHasInformationOn <em>Has Information On</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getResource()
 * @model abstract="true"
 * @generated
 */
public interface Resource extends EObject {
	/**
	 * Returns the value of the '<em><b>Acts On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Acts On</em>' reference.
	 * @see #setActsOn(PhysicalEntity)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getResource_ActsOn()
	 * @model
	 * @generated
	 */
	PhysicalEntity getActsOn();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getActsOn <em>Acts On</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Acts On</em>' reference.
	 * @see #getActsOn()
	 * @generated
	 */
	void setActsOn(PhysicalEntity value);

	/**
	 * Returns the value of the '<em><b>Has Information On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has Information On</em>' reference.
	 * @see #setHasInformationOn(PhysicalEntity)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getResource_HasInformationOn()
	 * @model
	 * @generated
	 */
	PhysicalEntity getHasInformationOn();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getHasInformationOn <em>Has Information On</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Has Information On</em>' reference.
	 * @see #getHasInformationOn()
	 * @generated
	 */
	void setHasInformationOn(PhysicalEntity value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getResource_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Resource
