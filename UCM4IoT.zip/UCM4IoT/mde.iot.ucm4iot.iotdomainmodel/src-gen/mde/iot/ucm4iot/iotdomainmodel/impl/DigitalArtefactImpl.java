/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.DigitalArtefact;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Digital Artefact</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class DigitalArtefactImpl extends MinimalEObjectImpl.Container implements DigitalArtefact {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DigitalArtefactImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.DIGITAL_ARTEFACT;
	}

} //DigitalArtefactImpl
