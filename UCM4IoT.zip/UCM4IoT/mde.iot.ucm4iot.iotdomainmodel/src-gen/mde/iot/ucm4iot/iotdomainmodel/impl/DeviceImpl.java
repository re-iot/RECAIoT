/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import java.util.Collection;

import mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation;
import mde.iot.ucm4iot.iotdomainmodel.Device;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.PinAnnotation;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Device</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl#getAttachedTo <em>Attached To</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl#getContains <em>Contains</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl#getHosts <em>Hosts</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl#getCodeAnnotations <em>Code Annotations</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl#getPinannotation <em>Pinannotation</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DeviceImpl extends PhysicalEntityImpl implements Device {
	/**
	 * The cached value of the '{@link #getAttachedTo() <em>Attached To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachedTo()
	 * @generated
	 * @ordered
	 */
	protected EList<PhysicalEntity> attachedTo;

	/**
	 * The cached value of the '{@link #getContains() <em>Contains</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContains()
	 * @generated
	 * @ordered
	 */
	protected EList<Device> contains;

	/**
	 * The cached value of the '{@link #getHosts() <em>Hosts</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHosts()
	 * @generated
	 * @ordered
	 */
	protected EList<OnDeviceResource> hosts;

	/**
	 * The cached value of the '{@link #getCodeAnnotations() <em>Code Annotations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodeAnnotations()
	 * @generated
	 * @ordered
	 */
	protected EList<CodeAnnotation> codeAnnotations;

	/**
	 * The cached value of the '{@link #getPinannotation() <em>Pinannotation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPinannotation()
	 * @generated
	 * @ordered
	 */
	protected EList<PinAnnotation> pinannotation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeviceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.DEVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PhysicalEntity> getAttachedTo() {
		if (attachedTo == null) {
			attachedTo = new EObjectResolvingEList<PhysicalEntity>(PhysicalEntity.class, this,
					IotdomainmodelPackage.DEVICE__ATTACHED_TO);
		}
		return attachedTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Device> getContains() {
		if (contains == null) {
			contains = new EObjectResolvingEList<Device>(Device.class, this, IotdomainmodelPackage.DEVICE__CONTAINS);
		}
		return contains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<OnDeviceResource> getHosts() {
		if (hosts == null) {
			hosts = new EObjectResolvingEList<OnDeviceResource>(OnDeviceResource.class, this,
					IotdomainmodelPackage.DEVICE__HOSTS);
		}
		return hosts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CodeAnnotation> getCodeAnnotations() {
		if (codeAnnotations == null) {
			codeAnnotations = new EObjectContainmentEList<CodeAnnotation>(CodeAnnotation.class, this,
					IotdomainmodelPackage.DEVICE__CODE_ANNOTATIONS);
		}
		return codeAnnotations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PinAnnotation> getPinannotation() {
		if (pinannotation == null) {
			pinannotation = new EObjectContainmentEList<PinAnnotation>(PinAnnotation.class, this,
					IotdomainmodelPackage.DEVICE__PINANNOTATION);
		}
		return pinannotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case IotdomainmodelPackage.DEVICE__CODE_ANNOTATIONS:
			return ((InternalEList<?>) getCodeAnnotations()).basicRemove(otherEnd, msgs);
		case IotdomainmodelPackage.DEVICE__PINANNOTATION:
			return ((InternalEList<?>) getPinannotation()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.DEVICE__ATTACHED_TO:
			return getAttachedTo();
		case IotdomainmodelPackage.DEVICE__CONTAINS:
			return getContains();
		case IotdomainmodelPackage.DEVICE__HOSTS:
			return getHosts();
		case IotdomainmodelPackage.DEVICE__CODE_ANNOTATIONS:
			return getCodeAnnotations();
		case IotdomainmodelPackage.DEVICE__PINANNOTATION:
			return getPinannotation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.DEVICE__ATTACHED_TO:
			getAttachedTo().clear();
			getAttachedTo().addAll((Collection<? extends PhysicalEntity>) newValue);
			return;
		case IotdomainmodelPackage.DEVICE__CONTAINS:
			getContains().clear();
			getContains().addAll((Collection<? extends Device>) newValue);
			return;
		case IotdomainmodelPackage.DEVICE__HOSTS:
			getHosts().clear();
			getHosts().addAll((Collection<? extends OnDeviceResource>) newValue);
			return;
		case IotdomainmodelPackage.DEVICE__CODE_ANNOTATIONS:
			getCodeAnnotations().clear();
			getCodeAnnotations().addAll((Collection<? extends CodeAnnotation>) newValue);
			return;
		case IotdomainmodelPackage.DEVICE__PINANNOTATION:
			getPinannotation().clear();
			getPinannotation().addAll((Collection<? extends PinAnnotation>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.DEVICE__ATTACHED_TO:
			getAttachedTo().clear();
			return;
		case IotdomainmodelPackage.DEVICE__CONTAINS:
			getContains().clear();
			return;
		case IotdomainmodelPackage.DEVICE__HOSTS:
			getHosts().clear();
			return;
		case IotdomainmodelPackage.DEVICE__CODE_ANNOTATIONS:
			getCodeAnnotations().clear();
			return;
		case IotdomainmodelPackage.DEVICE__PINANNOTATION:
			getPinannotation().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.DEVICE__ATTACHED_TO:
			return attachedTo != null && !attachedTo.isEmpty();
		case IotdomainmodelPackage.DEVICE__CONTAINS:
			return contains != null && !contains.isEmpty();
		case IotdomainmodelPackage.DEVICE__HOSTS:
			return hosts != null && !hosts.isEmpty();
		case IotdomainmodelPackage.DEVICE__CODE_ANNOTATIONS:
			return codeAnnotations != null && !codeAnnotations.isEmpty();
		case IotdomainmodelPackage.DEVICE__PINANNOTATION:
			return pinannotation != null && !pinannotation.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DeviceImpl
