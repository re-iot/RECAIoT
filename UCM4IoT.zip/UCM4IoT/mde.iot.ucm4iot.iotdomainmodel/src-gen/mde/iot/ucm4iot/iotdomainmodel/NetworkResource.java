/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network Resource</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getNetworkResource()
 * @model
 * @generated
 */
public interface NetworkResource extends Resource {
} // NetworkResource
