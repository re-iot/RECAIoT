/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage
 * @generated
 */
public interface IotdomainmodelFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IotdomainmodelFactory eINSTANCE = mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Human User</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Human User</em>'.
	 * @generated
	 */
	HumanUser createHumanUser();

	/**
	 * Returns a new object of class '<em>Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Service</em>'.
	 * @generated
	 */
	Service createService();

	/**
	 * Returns a new object of class '<em>Virtual Entity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Virtual Entity</em>'.
	 * @generated
	 */
	VirtualEntity createVirtualEntity();

	/**
	 * Returns a new object of class '<em>Physical Entity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Physical Entity</em>'.
	 * @generated
	 */
	PhysicalEntity createPhysicalEntity();

	/**
	 * Returns a new object of class '<em>Augmented Entity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Augmented Entity</em>'.
	 * @generated
	 */
	AugmentedEntity createAugmentedEntity();

	/**
	 * Returns a new object of class '<em>Network Resource</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Network Resource</em>'.
	 * @generated
	 */
	NetworkResource createNetworkResource();

	/**
	 * Returns a new object of class '<em>On Device Resource</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>On Device Resource</em>'.
	 * @generated
	 */
	OnDeviceResource createOnDeviceResource();

	/**
	 * Returns a new object of class '<em>Device</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Device</em>'.
	 * @generated
	 */
	Device createDevice();

	/**
	 * Returns a new object of class '<em>Actuator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Actuator</em>'.
	 * @generated
	 */
	Actuator createActuator();

	/**
	 * Returns a new object of class '<em>Tag</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tag</em>'.
	 * @generated
	 */
	Tag createTag();

	/**
	 * Returns a new object of class '<em>Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sensor</em>'.
	 * @generated
	 */
	Sensor createSensor();

	/**
	 * Returns a new object of class '<em>Io TDomain Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Io TDomain Model</em>'.
	 * @generated
	 */
	IoTDomainModel createIoTDomainModel();

	/**
	 * Returns a new object of class '<em>Code Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Code Annotation</em>'.
	 * @generated
	 */
	CodeAnnotation createCodeAnnotation();

	/**
	 * Returns a new object of class '<em>Note Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Note Annotation</em>'.
	 * @generated
	 */
	NoteAnnotation createNoteAnnotation();

	/**
	 * Returns a new object of class '<em>Pin Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pin Annotation</em>'.
	 * @generated
	 */
	PinAnnotation createPinAnnotation();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	IotdomainmodelPackage getIotdomainmodelPackage();

} //IotdomainmodelFactory
