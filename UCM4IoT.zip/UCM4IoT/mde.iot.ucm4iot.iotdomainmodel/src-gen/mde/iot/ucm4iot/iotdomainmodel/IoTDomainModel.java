/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Io TDomain Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getUsers <em>Users</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getServices <em>Services</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getPhysicalEntities <em>Physical Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getResources <em>Resources</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getVirtualEntities <em>Virtual Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getAugmentedEntities <em>Augmented Entities</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getDevices <em>Devices</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel()
 * @model
 * @generated
 */
public interface IoTDomainModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Users</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.User}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Users</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_Users()
	 * @model containment="true"
	 * @generated
	 */
	EList<User> getUsers();

	/**
	 * Returns the value of the '<em><b>Services</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.Service}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Services</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_Services()
	 * @model containment="true"
	 * @generated
	 */
	EList<Service> getServices();

	/**
	 * Returns the value of the '<em><b>Physical Entities</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Physical Entities</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_PhysicalEntities()
	 * @model containment="true"
	 * @generated
	 */
	EList<PhysicalEntity> getPhysicalEntities();

	/**
	 * Returns the value of the '<em><b>Resources</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.Resource}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resources</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_Resources()
	 * @model containment="true"
	 * @generated
	 */
	EList<Resource> getResources();

	/**
	 * Returns the value of the '<em><b>Virtual Entities</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Virtual Entities</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_VirtualEntities()
	 * @model containment="true"
	 * @generated
	 */
	EList<VirtualEntity> getVirtualEntities();

	/**
	 * Returns the value of the '<em><b>Augmented Entities</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Augmented Entities</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_AugmentedEntities()
	 * @model containment="true"
	 * @generated
	 */
	EList<AugmentedEntity> getAugmentedEntities();

	/**
	 * Returns the value of the '<em><b>Devices</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.Device}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Devices</em>' containment reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_Devices()
	 * @model containment="true"
	 * @generated
	 */
	EList<Device> getDevices();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getIoTDomainModel_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // IoTDomainModel
