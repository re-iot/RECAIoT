/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelFactory
 * @model kind="package"
 * @generated
 */
public interface IotdomainmodelPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "iotdomainmodel";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.ucm4iot.org/mde/iot/iotdomainmodel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "iotdomainmodel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IotdomainmodelPackage eINSTANCE = mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl.init();

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.UserImpl <em>User</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.UserImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getUser()
	 * @generated
	 */
	int USER = 0;

	/**
	 * The feature id for the '<em><b>Invokes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__INVOKES = 0;

	/**
	 * The feature id for the '<em><b>Interacts With</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__INTERACTS_WITH = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__NAME = 2;

	/**
	 * The number of structural features of the '<em>User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.HumanUserImpl <em>Human User</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.HumanUserImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getHumanUser()
	 * @generated
	 */
	int HUMAN_USER = 1;

	/**
	 * The feature id for the '<em><b>Invokes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_USER__INVOKES = USER__INVOKES;

	/**
	 * The feature id for the '<em><b>Interacts With</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_USER__INTERACTS_WITH = USER__INTERACTS_WITH;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_USER__NAME = USER__NAME;

	/**
	 * The number of structural features of the '<em>Human User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_USER_FEATURE_COUNT = USER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Human User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_USER_OPERATION_COUNT = USER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.DigitalArtefactImpl <em>Digital Artefact</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.DigitalArtefactImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getDigitalArtefact()
	 * @generated
	 */
	int DIGITAL_ARTEFACT = 2;

	/**
	 * The number of structural features of the '<em>Digital Artefact</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_ARTEFACT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Digital Artefact</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIGITAL_ARTEFACT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ActiveDigitalArtefactImpl <em>Active Digital Artefact</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ActiveDigitalArtefactImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getActiveDigitalArtefact()
	 * @generated
	 */
	int ACTIVE_DIGITAL_ARTEFACT = 3;

	/**
	 * The feature id for the '<em><b>Invokes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVE_DIGITAL_ARTEFACT__INVOKES = USER__INVOKES;

	/**
	 * The feature id for the '<em><b>Interacts With</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVE_DIGITAL_ARTEFACT__INTERACTS_WITH = USER__INTERACTS_WITH;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVE_DIGITAL_ARTEFACT__NAME = USER__NAME;

	/**
	 * The number of structural features of the '<em>Active Digital Artefact</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT = USER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Active Digital Artefact</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVE_DIGITAL_ARTEFACT_OPERATION_COUNT = USER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.PassiveDigitalArtefactImpl <em>Passive Digital Artefact</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.PassiveDigitalArtefactImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPassiveDigitalArtefact()
	 * @generated
	 */
	int PASSIVE_DIGITAL_ARTEFACT = 4;

	/**
	 * The number of structural features of the '<em>Passive Digital Artefact</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PASSIVE_DIGITAL_ARTEFACT_FEATURE_COUNT = DIGITAL_ARTEFACT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Passive Digital Artefact</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PASSIVE_DIGITAL_ARTEFACT_OPERATION_COUNT = DIGITAL_ARTEFACT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ServiceImpl <em>Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ServiceImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getService()
	 * @generated
	 */
	int SERVICE = 5;

	/**
	 * The feature id for the '<em><b>Invokes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__INVOKES = ACTIVE_DIGITAL_ARTEFACT__INVOKES;

	/**
	 * The feature id for the '<em><b>Interacts With</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__INTERACTS_WITH = ACTIVE_DIGITAL_ARTEFACT__INTERACTS_WITH;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__NAME = ACTIVE_DIGITAL_ARTEFACT__NAME;

	/**
	 * The feature id for the '<em><b>Exposes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE__EXPOSES = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FEATURE_COUNT = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_OPERATION_COUNT = ACTIVE_DIGITAL_ARTEFACT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl <em>Virtual Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getVirtualEntity()
	 * @generated
	 */
	int VIRTUAL_ENTITY = 6;

	/**
	 * The feature id for the '<em><b>Invokes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__INVOKES = ACTIVE_DIGITAL_ARTEFACT__INVOKES;

	/**
	 * The feature id for the '<em><b>Interacts With</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__INTERACTS_WITH = ACTIVE_DIGITAL_ARTEFACT__INTERACTS_WITH;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__NAME = ACTIVE_DIGITAL_ARTEFACT__NAME;

	/**
	 * The feature id for the '<em><b>Represents</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__REPRESENTS = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Associated</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__ASSOCIATED = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__CONTAINS = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Associated Resource</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY__ASSOCIATED_RESOURCE = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Virtual Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY_FEATURE_COUNT = ACTIVE_DIGITAL_ARTEFACT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Virtual Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIRTUAL_ENTITY_OPERATION_COUNT = ACTIVE_DIGITAL_ARTEFACT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.PhysicalEntityImpl <em>Physical Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.PhysicalEntityImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPhysicalEntity()
	 * @generated
	 */
	int PHYSICAL_ENTITY = 7;

	/**
	 * The feature id for the '<em><b>Physical Entities</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY__PHYSICAL_ENTITIES = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY__NAME = 1;

	/**
	 * The number of structural features of the '<em>Physical Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Physical Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl <em>Augmented Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getAugmentedEntity()
	 * @generated
	 */
	int AUGMENTED_ENTITY = 8;

	/**
	 * The feature id for the '<em><b>Physicalentity</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUGMENTED_ENTITY__PHYSICALENTITY = 0;

	/**
	 * The feature id for the '<em><b>Virtualentity</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUGMENTED_ENTITY__VIRTUALENTITY = 1;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUGMENTED_ENTITY__CONTAINS = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUGMENTED_ENTITY__NAME = 3;

	/**
	 * The number of structural features of the '<em>Augmented Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUGMENTED_ENTITY_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Augmented Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUGMENTED_ENTITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl <em>Resource</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getResource()
	 * @generated
	 */
	int RESOURCE = 9;

	/**
	 * The feature id for the '<em><b>Acts On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCE__ACTS_ON = 0;

	/**
	 * The feature id for the '<em><b>Has Information On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCE__HAS_INFORMATION_ON = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESOURCE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.NetworkResourceImpl <em>Network Resource</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.NetworkResourceImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getNetworkResource()
	 * @generated
	 */
	int NETWORK_RESOURCE = 10;

	/**
	 * The feature id for the '<em><b>Acts On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_RESOURCE__ACTS_ON = RESOURCE__ACTS_ON;

	/**
	 * The feature id for the '<em><b>Has Information On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_RESOURCE__HAS_INFORMATION_ON = RESOURCE__HAS_INFORMATION_ON;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_RESOURCE__NAME = RESOURCE__NAME;

	/**
	 * The number of structural features of the '<em>Network Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_RESOURCE_FEATURE_COUNT = RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Network Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_RESOURCE_OPERATION_COUNT = RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.OnDeviceResourceImpl <em>On Device Resource</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.OnDeviceResourceImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getOnDeviceResource()
	 * @generated
	 */
	int ON_DEVICE_RESOURCE = 11;

	/**
	 * The feature id for the '<em><b>Acts On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ON_DEVICE_RESOURCE__ACTS_ON = RESOURCE__ACTS_ON;

	/**
	 * The feature id for the '<em><b>Has Information On</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ON_DEVICE_RESOURCE__HAS_INFORMATION_ON = RESOURCE__HAS_INFORMATION_ON;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ON_DEVICE_RESOURCE__NAME = RESOURCE__NAME;

	/**
	 * The number of structural features of the '<em>On Device Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ON_DEVICE_RESOURCE_FEATURE_COUNT = RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>On Device Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ON_DEVICE_RESOURCE_OPERATION_COUNT = RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl <em>Device</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getDevice()
	 * @generated
	 */
	int DEVICE = 12;

	/**
	 * The feature id for the '<em><b>Physical Entities</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__PHYSICAL_ENTITIES = PHYSICAL_ENTITY__PHYSICAL_ENTITIES;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__NAME = PHYSICAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Attached To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__ATTACHED_TO = PHYSICAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__CONTAINS = PHYSICAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Hosts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__HOSTS = PHYSICAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Code Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__CODE_ANNOTATIONS = PHYSICAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Pinannotation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE__PINANNOTATION = PHYSICAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Device</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_FEATURE_COUNT = PHYSICAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Device</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_OPERATION_COUNT = PHYSICAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ActuatorImpl <em>Actuator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ActuatorImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getActuator()
	 * @generated
	 */
	int ACTUATOR = 13;

	/**
	 * The feature id for the '<em><b>Physical Entities</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__PHYSICAL_ENTITIES = DEVICE__PHYSICAL_ENTITIES;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__NAME = DEVICE__NAME;

	/**
	 * The feature id for the '<em><b>Attached To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__ATTACHED_TO = DEVICE__ATTACHED_TO;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__CONTAINS = DEVICE__CONTAINS;

	/**
	 * The feature id for the '<em><b>Hosts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__HOSTS = DEVICE__HOSTS;

	/**
	 * The feature id for the '<em><b>Code Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__CODE_ANNOTATIONS = DEVICE__CODE_ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Pinannotation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__PINANNOTATION = DEVICE__PINANNOTATION;

	/**
	 * The feature id for the '<em><b>Acts On</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__ACTS_ON = DEVICE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Actuator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR_FEATURE_COUNT = DEVICE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Actuator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR_OPERATION_COUNT = DEVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.TagImpl <em>Tag</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.TagImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getTag()
	 * @generated
	 */
	int TAG = 14;

	/**
	 * The feature id for the '<em><b>Physical Entities</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__PHYSICAL_ENTITIES = DEVICE__PHYSICAL_ENTITIES;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__NAME = DEVICE__NAME;

	/**
	 * The feature id for the '<em><b>Attached To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__ATTACHED_TO = DEVICE__ATTACHED_TO;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__CONTAINS = DEVICE__CONTAINS;

	/**
	 * The feature id for the '<em><b>Hosts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__HOSTS = DEVICE__HOSTS;

	/**
	 * The feature id for the '<em><b>Code Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__CODE_ANNOTATIONS = DEVICE__CODE_ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Pinannotation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__PINANNOTATION = DEVICE__PINANNOTATION;

	/**
	 * The feature id for the '<em><b>Identifies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG__IDENTIFIES = DEVICE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Tag</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG_FEATURE_COUNT = DEVICE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Tag</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAG_OPERATION_COUNT = DEVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.SensorImpl <em>Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.SensorImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getSensor()
	 * @generated
	 */
	int SENSOR = 15;

	/**
	 * The feature id for the '<em><b>Physical Entities</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__PHYSICAL_ENTITIES = DEVICE__PHYSICAL_ENTITIES;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__NAME = DEVICE__NAME;

	/**
	 * The feature id for the '<em><b>Attached To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__ATTACHED_TO = DEVICE__ATTACHED_TO;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__CONTAINS = DEVICE__CONTAINS;

	/**
	 * The feature id for the '<em><b>Hosts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__HOSTS = DEVICE__HOSTS;

	/**
	 * The feature id for the '<em><b>Code Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__CODE_ANNOTATIONS = DEVICE__CODE_ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Pinannotation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__PINANNOTATION = DEVICE__PINANNOTATION;

	/**
	 * The feature id for the '<em><b>Monitors</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__MONITORS = DEVICE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Reads</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__READS = DEVICE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_FEATURE_COUNT = DEVICE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_OPERATION_COUNT = DEVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl <em>Io TDomain Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getIoTDomainModel()
	 * @generated
	 */
	int IO_TDOMAIN_MODEL = 16;

	/**
	 * The feature id for the '<em><b>Users</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__USERS = 0;

	/**
	 * The feature id for the '<em><b>Services</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__SERVICES = 1;

	/**
	 * The feature id for the '<em><b>Physical Entities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES = 2;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__RESOURCES = 3;

	/**
	 * The feature id for the '<em><b>Virtual Entities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES = 4;

	/**
	 * The feature id for the '<em><b>Augmented Entities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES = 5;

	/**
	 * The feature id for the '<em><b>Devices</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__DEVICES = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL__NAME = 7;

	/**
	 * The number of structural features of the '<em>Io TDomain Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Io TDomain Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IO_TDOMAIN_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.AnnotationImpl <em>Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.AnnotationImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getAnnotation()
	 * @generated
	 */
	int ANNOTATION = 17;

	/**
	 * The number of structural features of the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.CodeAnnotationImpl <em>Code Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.CodeAnnotationImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getCodeAnnotation()
	 * @generated
	 */
	int CODE_ANNOTATION = 18;

	/**
	 * The feature id for the '<em><b>Function Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODE_ANNOTATION__FUNCTION_NAME = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Function Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODE_ANNOTATION__FUNCTION_CODE = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Code Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODE_ANNOTATION_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Code Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODE_ANNOTATION_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.NoteAnnotationImpl <em>Note Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.NoteAnnotationImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getNoteAnnotation()
	 * @generated
	 */
	int NOTE_ANNOTATION = 19;

	/**
	 * The feature id for the '<em><b>Note</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTE_ANNOTATION__NOTE = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Note Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTE_ANNOTATION_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Note Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NOTE_ANNOTATION_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.PinAnnotationImpl <em>Pin Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.PinAnnotationImpl
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPinAnnotation()
	 * @generated
	 */
	int PIN_ANNOTATION = 20;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIN_ANNOTATION__TYPE = ANNOTATION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIN_ANNOTATION__NUMBER = ANNOTATION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Pin Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIN_ANNOTATION_FEATURE_COUNT = ANNOTATION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Pin Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PIN_ANNOTATION_OPERATION_COUNT = ANNOTATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.iotdomainmodel.PinType <em>Pin Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinType
	 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPinType()
	 * @generated
	 */
	int PIN_TYPE = 21;

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.User <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>User</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.User
	 * @generated
	 */
	EClass getUser();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.User#getInvokes <em>Invokes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Invokes</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.User#getInvokes()
	 * @see #getUser()
	 * @generated
	 */
	EReference getUser_Invokes();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.User#getInteractsWith <em>Interacts With</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Interacts With</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.User#getInteractsWith()
	 * @see #getUser()
	 * @generated
	 */
	EReference getUser_InteractsWith();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.User#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.User#getName()
	 * @see #getUser()
	 * @generated
	 */
	EAttribute getUser_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.HumanUser <em>Human User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Human User</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.HumanUser
	 * @generated
	 */
	EClass getHumanUser();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.DigitalArtefact <em>Digital Artefact</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Digital Artefact</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.DigitalArtefact
	 * @generated
	 */
	EClass getDigitalArtefact();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.ActiveDigitalArtefact <em>Active Digital Artefact</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Active Digital Artefact</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.ActiveDigitalArtefact
	 * @generated
	 */
	EClass getActiveDigitalArtefact();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.PassiveDigitalArtefact <em>Passive Digital Artefact</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Passive Digital Artefact</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PassiveDigitalArtefact
	 * @generated
	 */
	EClass getPassiveDigitalArtefact();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Service <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Service
	 * @generated
	 */
	EClass getService();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Service#getExposes <em>Exposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Exposes</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Service#getExposes()
	 * @see #getService()
	 * @generated
	 */
	EReference getService_Exposes();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity <em>Virtual Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Virtual Entity</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.VirtualEntity
	 * @generated
	 */
	EClass getVirtualEntity();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getRepresents <em>Represents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Represents</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getRepresents()
	 * @see #getVirtualEntity()
	 * @generated
	 */
	EReference getVirtualEntity_Represents();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociated <em>Associated</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Associated</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociated()
	 * @see #getVirtualEntity()
	 * @generated
	 */
	EReference getVirtualEntity_Associated();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Contains</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getContains()
	 * @see #getVirtualEntity()
	 * @generated
	 */
	EReference getVirtualEntity_Contains();

	/**
	 * Returns the meta object for the reference '{@link mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociatedResource <em>Associated Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Associated Resource</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.VirtualEntity#getAssociatedResource()
	 * @see #getVirtualEntity()
	 * @generated
	 */
	EReference getVirtualEntity_AssociatedResource();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity <em>Physical Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Physical Entity</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity
	 * @generated
	 */
	EClass getPhysicalEntity();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity#getPhysicalEntities <em>Physical Entities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Physical Entities</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity#getPhysicalEntities()
	 * @see #getPhysicalEntity()
	 * @generated
	 */
	EReference getPhysicalEntity_PhysicalEntities();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity#getName()
	 * @see #getPhysicalEntity()
	 * @generated
	 */
	EAttribute getPhysicalEntity_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity <em>Augmented Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Augmented Entity</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity
	 * @generated
	 */
	EClass getAugmentedEntity();

	/**
	 * Returns the meta object for the containment reference '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getPhysicalentity <em>Physicalentity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Physicalentity</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getPhysicalentity()
	 * @see #getAugmentedEntity()
	 * @generated
	 */
	EReference getAugmentedEntity_Physicalentity();

	/**
	 * Returns the meta object for the containment reference '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getVirtualentity <em>Virtualentity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Virtualentity</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getVirtualentity()
	 * @see #getAugmentedEntity()
	 * @generated
	 */
	EReference getAugmentedEntity_Virtualentity();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Contains</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getContains()
	 * @see #getAugmentedEntity()
	 * @generated
	 */
	EReference getAugmentedEntity_Contains();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getName()
	 * @see #getAugmentedEntity()
	 * @generated
	 */
	EAttribute getAugmentedEntity_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Resource <em>Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Resource</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Resource
	 * @generated
	 */
	EClass getResource();

	/**
	 * Returns the meta object for the reference '{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getActsOn <em>Acts On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Acts On</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Resource#getActsOn()
	 * @see #getResource()
	 * @generated
	 */
	EReference getResource_ActsOn();

	/**
	 * Returns the meta object for the reference '{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getHasInformationOn <em>Has Information On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Has Information On</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Resource#getHasInformationOn()
	 * @see #getResource()
	 * @generated
	 */
	EReference getResource_HasInformationOn();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.Resource#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Resource#getName()
	 * @see #getResource()
	 * @generated
	 */
	EAttribute getResource_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.NetworkResource <em>Network Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Network Resource</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.NetworkResource
	 * @generated
	 */
	EClass getNetworkResource();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource <em>On Device Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>On Device Resource</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.OnDeviceResource
	 * @generated
	 */
	EClass getOnDeviceResource();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Device <em>Device</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Device</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device
	 * @generated
	 */
	EClass getDevice();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Device#getAttachedTo <em>Attached To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Attached To</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device#getAttachedTo()
	 * @see #getDevice()
	 * @generated
	 */
	EReference getDevice_AttachedTo();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Device#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Contains</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device#getContains()
	 * @see #getDevice()
	 * @generated
	 */
	EReference getDevice_Contains();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Device#getHosts <em>Hosts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Hosts</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device#getHosts()
	 * @see #getDevice()
	 * @generated
	 */
	EReference getDevice_Hosts();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Device#getCodeAnnotations <em>Code Annotations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Code Annotations</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device#getCodeAnnotations()
	 * @see #getDevice()
	 * @generated
	 */
	EReference getDevice_CodeAnnotations();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Device#getPinannotation <em>Pinannotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pinannotation</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Device#getPinannotation()
	 * @see #getDevice()
	 * @generated
	 */
	EReference getDevice_Pinannotation();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Actuator <em>Actuator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Actuator</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Actuator
	 * @generated
	 */
	EClass getActuator();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Actuator#getActsOn <em>Acts On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Acts On</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Actuator#getActsOn()
	 * @see #getActuator()
	 * @generated
	 */
	EReference getActuator_ActsOn();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Tag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tag</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Tag
	 * @generated
	 */
	EClass getTag();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Tag#getIdentifies <em>Identifies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Identifies</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Tag#getIdentifies()
	 * @see #getTag()
	 * @generated
	 */
	EReference getTag_Identifies();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sensor</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Sensor
	 * @generated
	 */
	EClass getSensor();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Sensor#getMonitors <em>Monitors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Monitors</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Sensor#getMonitors()
	 * @see #getSensor()
	 * @generated
	 */
	EReference getSensor_Monitors();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.iotdomainmodel.Sensor#getReads <em>Reads</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Reads</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Sensor#getReads()
	 * @see #getSensor()
	 * @generated
	 */
	EReference getSensor_Reads();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel <em>Io TDomain Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Io TDomain Model</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel
	 * @generated
	 */
	EClass getIoTDomainModel();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getUsers <em>Users</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Users</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getUsers()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_Users();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getServices <em>Services</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Services</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getServices()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_Services();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getPhysicalEntities <em>Physical Entities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Physical Entities</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getPhysicalEntities()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_PhysicalEntities();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Resources</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getResources()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_Resources();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getVirtualEntities <em>Virtual Entities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Virtual Entities</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getVirtualEntities()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_VirtualEntities();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getAugmentedEntities <em>Augmented Entities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Augmented Entities</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getAugmentedEntities()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_AugmentedEntities();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getDevices <em>Devices</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Devices</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getDevices()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EReference getIoTDomainModel_Devices();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IoTDomainModel#getName()
	 * @see #getIoTDomainModel()
	 * @generated
	 */
	EAttribute getIoTDomainModel_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.Annotation <em>Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Annotation</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.Annotation
	 * @generated
	 */
	EClass getAnnotation();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation <em>Code Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Code Annotation</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation
	 * @generated
	 */
	EClass getCodeAnnotation();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionName <em>Function Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Function Name</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionName()
	 * @see #getCodeAnnotation()
	 * @generated
	 */
	EAttribute getCodeAnnotation_FunctionName();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionCode <em>Function Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Function Code</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.CodeAnnotation#getFunctionCode()
	 * @see #getCodeAnnotation()
	 * @generated
	 */
	EAttribute getCodeAnnotation_FunctionCode();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation <em>Note Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Note Annotation</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation
	 * @generated
	 */
	EClass getNoteAnnotation();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation#getNote <em>Note</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Note</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.NoteAnnotation#getNote()
	 * @see #getNoteAnnotation()
	 * @generated
	 */
	EAttribute getNoteAnnotation_Note();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation <em>Pin Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pin Annotation</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinAnnotation
	 * @generated
	 */
	EClass getPinAnnotation();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getType()
	 * @see #getPinAnnotation()
	 * @generated
	 */
	EAttribute getPinAnnotation_Type();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getNumber <em>Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Number</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinAnnotation#getNumber()
	 * @see #getPinAnnotation()
	 * @generated
	 */
	EAttribute getPinAnnotation_Number();

	/**
	 * Returns the meta object for enum '{@link mde.iot.ucm4iot.iotdomainmodel.PinType <em>Pin Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Pin Type</em>'.
	 * @see mde.iot.ucm4iot.iotdomainmodel.PinType
	 * @generated
	 */
	EEnum getPinType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	IotdomainmodelFactory getIotdomainmodelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.UserImpl <em>User</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.UserImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getUser()
		 * @generated
		 */
		EClass USER = eINSTANCE.getUser();

		/**
		 * The meta object literal for the '<em><b>Invokes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER__INVOKES = eINSTANCE.getUser_Invokes();

		/**
		 * The meta object literal for the '<em><b>Interacts With</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER__INTERACTS_WITH = eINSTANCE.getUser_InteractsWith();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER__NAME = eINSTANCE.getUser_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.HumanUserImpl <em>Human User</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.HumanUserImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getHumanUser()
		 * @generated
		 */
		EClass HUMAN_USER = eINSTANCE.getHumanUser();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.DigitalArtefactImpl <em>Digital Artefact</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.DigitalArtefactImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getDigitalArtefact()
		 * @generated
		 */
		EClass DIGITAL_ARTEFACT = eINSTANCE.getDigitalArtefact();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ActiveDigitalArtefactImpl <em>Active Digital Artefact</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ActiveDigitalArtefactImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getActiveDigitalArtefact()
		 * @generated
		 */
		EClass ACTIVE_DIGITAL_ARTEFACT = eINSTANCE.getActiveDigitalArtefact();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.PassiveDigitalArtefactImpl <em>Passive Digital Artefact</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.PassiveDigitalArtefactImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPassiveDigitalArtefact()
		 * @generated
		 */
		EClass PASSIVE_DIGITAL_ARTEFACT = eINSTANCE.getPassiveDigitalArtefact();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ServiceImpl <em>Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ServiceImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getService()
		 * @generated
		 */
		EClass SERVICE = eINSTANCE.getService();

		/**
		 * The meta object literal for the '<em><b>Exposes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE__EXPOSES = eINSTANCE.getService_Exposes();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl <em>Virtual Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.VirtualEntityImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getVirtualEntity()
		 * @generated
		 */
		EClass VIRTUAL_ENTITY = eINSTANCE.getVirtualEntity();

		/**
		 * The meta object literal for the '<em><b>Represents</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIRTUAL_ENTITY__REPRESENTS = eINSTANCE.getVirtualEntity_Represents();

		/**
		 * The meta object literal for the '<em><b>Associated</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIRTUAL_ENTITY__ASSOCIATED = eINSTANCE.getVirtualEntity_Associated();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIRTUAL_ENTITY__CONTAINS = eINSTANCE.getVirtualEntity_Contains();

		/**
		 * The meta object literal for the '<em><b>Associated Resource</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIRTUAL_ENTITY__ASSOCIATED_RESOURCE = eINSTANCE.getVirtualEntity_AssociatedResource();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.PhysicalEntityImpl <em>Physical Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.PhysicalEntityImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPhysicalEntity()
		 * @generated
		 */
		EClass PHYSICAL_ENTITY = eINSTANCE.getPhysicalEntity();

		/**
		 * The meta object literal for the '<em><b>Physical Entities</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHYSICAL_ENTITY__PHYSICAL_ENTITIES = eINSTANCE.getPhysicalEntity_PhysicalEntities();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHYSICAL_ENTITY__NAME = eINSTANCE.getPhysicalEntity_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl <em>Augmented Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getAugmentedEntity()
		 * @generated
		 */
		EClass AUGMENTED_ENTITY = eINSTANCE.getAugmentedEntity();

		/**
		 * The meta object literal for the '<em><b>Physicalentity</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUGMENTED_ENTITY__PHYSICALENTITY = eINSTANCE.getAugmentedEntity_Physicalentity();

		/**
		 * The meta object literal for the '<em><b>Virtualentity</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUGMENTED_ENTITY__VIRTUALENTITY = eINSTANCE.getAugmentedEntity_Virtualentity();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUGMENTED_ENTITY__CONTAINS = eINSTANCE.getAugmentedEntity_Contains();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUGMENTED_ENTITY__NAME = eINSTANCE.getAugmentedEntity_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl <em>Resource</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ResourceImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getResource()
		 * @generated
		 */
		EClass RESOURCE = eINSTANCE.getResource();

		/**
		 * The meta object literal for the '<em><b>Acts On</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESOURCE__ACTS_ON = eINSTANCE.getResource_ActsOn();

		/**
		 * The meta object literal for the '<em><b>Has Information On</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESOURCE__HAS_INFORMATION_ON = eINSTANCE.getResource_HasInformationOn();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESOURCE__NAME = eINSTANCE.getResource_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.NetworkResourceImpl <em>Network Resource</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.NetworkResourceImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getNetworkResource()
		 * @generated
		 */
		EClass NETWORK_RESOURCE = eINSTANCE.getNetworkResource();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.OnDeviceResourceImpl <em>On Device Resource</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.OnDeviceResourceImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getOnDeviceResource()
		 * @generated
		 */
		EClass ON_DEVICE_RESOURCE = eINSTANCE.getOnDeviceResource();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl <em>Device</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.DeviceImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getDevice()
		 * @generated
		 */
		EClass DEVICE = eINSTANCE.getDevice();

		/**
		 * The meta object literal for the '<em><b>Attached To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE__ATTACHED_TO = eINSTANCE.getDevice_AttachedTo();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE__CONTAINS = eINSTANCE.getDevice_Contains();

		/**
		 * The meta object literal for the '<em><b>Hosts</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE__HOSTS = eINSTANCE.getDevice_Hosts();

		/**
		 * The meta object literal for the '<em><b>Code Annotations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE__CODE_ANNOTATIONS = eINSTANCE.getDevice_CodeAnnotations();

		/**
		 * The meta object literal for the '<em><b>Pinannotation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE__PINANNOTATION = eINSTANCE.getDevice_Pinannotation();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.ActuatorImpl <em>Actuator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.ActuatorImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getActuator()
		 * @generated
		 */
		EClass ACTUATOR = eINSTANCE.getActuator();

		/**
		 * The meta object literal for the '<em><b>Acts On</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTUATOR__ACTS_ON = eINSTANCE.getActuator_ActsOn();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.TagImpl <em>Tag</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.TagImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getTag()
		 * @generated
		 */
		EClass TAG = eINSTANCE.getTag();

		/**
		 * The meta object literal for the '<em><b>Identifies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAG__IDENTIFIES = eINSTANCE.getTag_Identifies();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.SensorImpl <em>Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.SensorImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getSensor()
		 * @generated
		 */
		EClass SENSOR = eINSTANCE.getSensor();

		/**
		 * The meta object literal for the '<em><b>Monitors</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENSOR__MONITORS = eINSTANCE.getSensor_Monitors();

		/**
		 * The meta object literal for the '<em><b>Reads</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENSOR__READS = eINSTANCE.getSensor_Reads();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl <em>Io TDomain Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IoTDomainModelImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getIoTDomainModel()
		 * @generated
		 */
		EClass IO_TDOMAIN_MODEL = eINSTANCE.getIoTDomainModel();

		/**
		 * The meta object literal for the '<em><b>Users</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__USERS = eINSTANCE.getIoTDomainModel_Users();

		/**
		 * The meta object literal for the '<em><b>Services</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__SERVICES = eINSTANCE.getIoTDomainModel_Services();

		/**
		 * The meta object literal for the '<em><b>Physical Entities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__PHYSICAL_ENTITIES = eINSTANCE.getIoTDomainModel_PhysicalEntities();

		/**
		 * The meta object literal for the '<em><b>Resources</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__RESOURCES = eINSTANCE.getIoTDomainModel_Resources();

		/**
		 * The meta object literal for the '<em><b>Virtual Entities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__VIRTUAL_ENTITIES = eINSTANCE.getIoTDomainModel_VirtualEntities();

		/**
		 * The meta object literal for the '<em><b>Augmented Entities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__AUGMENTED_ENTITIES = eINSTANCE.getIoTDomainModel_AugmentedEntities();

		/**
		 * The meta object literal for the '<em><b>Devices</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IO_TDOMAIN_MODEL__DEVICES = eINSTANCE.getIoTDomainModel_Devices();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IO_TDOMAIN_MODEL__NAME = eINSTANCE.getIoTDomainModel_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.AnnotationImpl <em>Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.AnnotationImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getAnnotation()
		 * @generated
		 */
		EClass ANNOTATION = eINSTANCE.getAnnotation();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.CodeAnnotationImpl <em>Code Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.CodeAnnotationImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getCodeAnnotation()
		 * @generated
		 */
		EClass CODE_ANNOTATION = eINSTANCE.getCodeAnnotation();

		/**
		 * The meta object literal for the '<em><b>Function Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODE_ANNOTATION__FUNCTION_NAME = eINSTANCE.getCodeAnnotation_FunctionName();

		/**
		 * The meta object literal for the '<em><b>Function Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODE_ANNOTATION__FUNCTION_CODE = eINSTANCE.getCodeAnnotation_FunctionCode();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.NoteAnnotationImpl <em>Note Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.NoteAnnotationImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getNoteAnnotation()
		 * @generated
		 */
		EClass NOTE_ANNOTATION = eINSTANCE.getNoteAnnotation();

		/**
		 * The meta object literal for the '<em><b>Note</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NOTE_ANNOTATION__NOTE = eINSTANCE.getNoteAnnotation_Note();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.impl.PinAnnotationImpl <em>Pin Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.PinAnnotationImpl
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPinAnnotation()
		 * @generated
		 */
		EClass PIN_ANNOTATION = eINSTANCE.getPinAnnotation();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIN_ANNOTATION__TYPE = eINSTANCE.getPinAnnotation_Type();

		/**
		 * The meta object literal for the '<em><b>Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PIN_ANNOTATION__NUMBER = eINSTANCE.getPinAnnotation_Number();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.iotdomainmodel.PinType <em>Pin Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.iotdomainmodel.PinType
		 * @see mde.iot.ucm4iot.iotdomainmodel.impl.IotdomainmodelPackageImpl#getPinType()
		 * @generated
		 */
		EEnum PIN_TYPE = eINSTANCE.getPinType();

	}

} //IotdomainmodelPackage
