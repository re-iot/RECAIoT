/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PassiveDigitalArtefact;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Passive Digital Artefact</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class PassiveDigitalArtefactImpl extends DigitalArtefactImpl implements PassiveDigitalArtefact {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PassiveDigitalArtefactImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.PASSIVE_DIGITAL_ARTEFACT;
	}

} //PassiveDigitalArtefactImpl
