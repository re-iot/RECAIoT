/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Augmented Entity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getPhysicalentity <em>Physicalentity</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getVirtualentity <em>Virtualentity</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getContains <em>Contains</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getAugmentedEntity()
 * @model
 * @generated
 */
public interface AugmentedEntity extends EObject {
	/**
	 * Returns the value of the '<em><b>Physicalentity</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Physicalentity</em>' containment reference.
	 * @see #setPhysicalentity(PhysicalEntity)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getAugmentedEntity_Physicalentity()
	 * @model containment="true" required="true"
	 * @generated
	 */
	PhysicalEntity getPhysicalentity();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getPhysicalentity <em>Physicalentity</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Physicalentity</em>' containment reference.
	 * @see #getPhysicalentity()
	 * @generated
	 */
	void setPhysicalentity(PhysicalEntity value);

	/**
	 * Returns the value of the '<em><b>Virtualentity</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Virtualentity</em>' containment reference.
	 * @see #setVirtualentity(VirtualEntity)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getAugmentedEntity_Virtualentity()
	 * @model containment="true" required="true"
	 * @generated
	 */
	VirtualEntity getVirtualentity();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getVirtualentity <em>Virtualentity</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Virtualentity</em>' containment reference.
	 * @see #getVirtualentity()
	 * @generated
	 */
	void setVirtualentity(VirtualEntity value);

	/**
	 * Returns the value of the '<em><b>Contains</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getAugmentedEntity_Contains()
	 * @model
	 * @generated
	 */
	EList<AugmentedEntity> getContains();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getAugmentedEntity_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // AugmentedEntity
