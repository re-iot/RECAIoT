/**
 */
package mde.iot.ucm4iot.iotdomainmodel.impl;

import java.util.Collection;

import mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;
import mde.iot.ucm4iot.iotdomainmodel.PhysicalEntity;
import mde.iot.ucm4iot.iotdomainmodel.VirtualEntity;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Augmented Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl#getPhysicalentity <em>Physicalentity</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl#getVirtualentity <em>Virtualentity</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl#getContains <em>Contains</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.impl.AugmentedEntityImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AugmentedEntityImpl extends MinimalEObjectImpl.Container implements AugmentedEntity {
	/**
	 * The cached value of the '{@link #getPhysicalentity() <em>Physicalentity</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhysicalentity()
	 * @generated
	 * @ordered
	 */
	protected PhysicalEntity physicalentity;

	/**
	 * The cached value of the '{@link #getVirtualentity() <em>Virtualentity</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVirtualentity()
	 * @generated
	 * @ordered
	 */
	protected VirtualEntity virtualentity;

	/**
	 * The cached value of the '{@link #getContains() <em>Contains</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContains()
	 * @generated
	 * @ordered
	 */
	protected EList<AugmentedEntity> contains;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AugmentedEntityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return IotdomainmodelPackage.Literals.AUGMENTED_ENTITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntity getPhysicalentity() {
		return physicalentity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPhysicalentity(PhysicalEntity newPhysicalentity, NotificationChain msgs) {
		PhysicalEntity oldPhysicalentity = physicalentity;
		physicalentity = newPhysicalentity;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY, oldPhysicalentity, newPhysicalentity);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhysicalentity(PhysicalEntity newPhysicalentity) {
		if (newPhysicalentity != physicalentity) {
			NotificationChain msgs = null;
			if (physicalentity != null)
				msgs = ((InternalEObject) physicalentity).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY, null, msgs);
			if (newPhysicalentity != null)
				msgs = ((InternalEObject) newPhysicalentity).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY, null, msgs);
			msgs = basicSetPhysicalentity(newPhysicalentity, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY, newPhysicalentity, newPhysicalentity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VirtualEntity getVirtualentity() {
		return virtualentity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVirtualentity(VirtualEntity newVirtualentity, NotificationChain msgs) {
		VirtualEntity oldVirtualentity = virtualentity;
		virtualentity = newVirtualentity;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY, oldVirtualentity, newVirtualentity);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVirtualentity(VirtualEntity newVirtualentity) {
		if (newVirtualentity != virtualentity) {
			NotificationChain msgs = null;
			if (virtualentity != null)
				msgs = ((InternalEObject) virtualentity).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY, null, msgs);
			if (newVirtualentity != null)
				msgs = ((InternalEObject) newVirtualentity).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY, null, msgs);
			msgs = basicSetVirtualentity(newVirtualentity, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY,
					newVirtualentity, newVirtualentity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AugmentedEntity> getContains() {
		if (contains == null) {
			contains = new EObjectResolvingEList<AugmentedEntity>(AugmentedEntity.class, this,
					IotdomainmodelPackage.AUGMENTED_ENTITY__CONTAINS);
		}
		return contains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IotdomainmodelPackage.AUGMENTED_ENTITY__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY:
			return basicSetPhysicalentity(null, msgs);
		case IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY:
			return basicSetVirtualentity(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY:
			return getPhysicalentity();
		case IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY:
			return getVirtualentity();
		case IotdomainmodelPackage.AUGMENTED_ENTITY__CONTAINS:
			return getContains();
		case IotdomainmodelPackage.AUGMENTED_ENTITY__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY:
			setPhysicalentity((PhysicalEntity) newValue);
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY:
			setVirtualentity((VirtualEntity) newValue);
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__CONTAINS:
			getContains().clear();
			getContains().addAll((Collection<? extends AugmentedEntity>) newValue);
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY:
			setPhysicalentity((PhysicalEntity) null);
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY:
			setVirtualentity((VirtualEntity) null);
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__CONTAINS:
			getContains().clear();
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY:
			return physicalentity != null;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY:
			return virtualentity != null;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__CONTAINS:
			return contains != null && !contains.isEmpty();
		case IotdomainmodelPackage.AUGMENTED_ENTITY__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //AugmentedEntityImpl
