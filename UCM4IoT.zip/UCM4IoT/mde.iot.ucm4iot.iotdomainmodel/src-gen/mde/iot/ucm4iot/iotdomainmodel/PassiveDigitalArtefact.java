/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Passive Digital Artefact</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getPassiveDigitalArtefact()
 * @model abstract="true"
 * @generated
 */
public interface PassiveDigitalArtefact extends DigitalArtefact {
} // PassiveDigitalArtefact
