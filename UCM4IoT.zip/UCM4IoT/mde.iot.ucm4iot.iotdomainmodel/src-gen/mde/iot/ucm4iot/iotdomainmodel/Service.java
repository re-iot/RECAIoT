/**
 */
package mde.iot.ucm4iot.iotdomainmodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.iotdomainmodel.Service#getExposes <em>Exposes</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getService()
 * @model
 * @generated
 */
public interface Service extends ActiveDigitalArtefact {
	/**
	 * Returns the value of the '<em><b>Exposes</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.iotdomainmodel.Resource}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exposes</em>' reference list.
	 * @see mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage#getService_Exposes()
	 * @model
	 * @generated
	 */
	EList<Resource> getExposes();

} // Service
