/**
 */
package mde.iot.ucm4iot.iotdomainmodel.provider;

import java.util.Collection;
import java.util.List;

import mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelFactory;
import mde.iot.ucm4iot.iotdomainmodel.IotdomainmodelPackage;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link mde.iot.ucm4iot.iotdomainmodel.AugmentedEntity} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class AugmentedEntityItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AugmentedEntityItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addContainsPropertyDescriptor(object);
			addNamePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Contains feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addContainsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_AugmentedEntity_contains_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_AugmentedEntity_contains_feature",
								"_UI_AugmentedEntity_type"),
						IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__CONTAINS, true, false, true, null, null,
						null));
	}

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_AugmentedEntity_name_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_AugmentedEntity_name_feature",
								"_UI_AugmentedEntity_type"),
						IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__PHYSICALENTITY);
			childrenFeatures.add(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__VIRTUALENTITY);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns AugmentedEntity.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/AugmentedEntity"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((AugmentedEntity) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_AugmentedEntity_type")
				: getString("_UI_AugmentedEntity_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(AugmentedEntity.class)) {
		case IotdomainmodelPackage.AUGMENTED_ENTITY__NAME:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case IotdomainmodelPackage.AUGMENTED_ENTITY__PHYSICALENTITY:
		case IotdomainmodelPackage.AUGMENTED_ENTITY__VIRTUALENTITY:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__PHYSICALENTITY,
				IotdomainmodelFactory.eINSTANCE.createPhysicalEntity()));

		newChildDescriptors.add(createChildParameter(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__PHYSICALENTITY,
				IotdomainmodelFactory.eINSTANCE.createDevice()));

		newChildDescriptors.add(createChildParameter(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__PHYSICALENTITY,
				IotdomainmodelFactory.eINSTANCE.createActuator()));

		newChildDescriptors.add(createChildParameter(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__PHYSICALENTITY,
				IotdomainmodelFactory.eINSTANCE.createTag()));

		newChildDescriptors.add(createChildParameter(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__PHYSICALENTITY,
				IotdomainmodelFactory.eINSTANCE.createSensor()));

		newChildDescriptors.add(createChildParameter(IotdomainmodelPackage.Literals.AUGMENTED_ENTITY__VIRTUALENTITY,
				IotdomainmodelFactory.eINSTANCE.createVirtualEntity()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return IotdomainmodelEditPlugin.INSTANCE;
	}

}
