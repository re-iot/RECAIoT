/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Handler Use Case</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.HandlerUseCase#getInterrupts <em>Interrupts</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getHandlerUseCase()
 * @model
 * @generated
 */
public interface HandlerUseCase extends UseCase {

	/**
	 * Returns the value of the '<em><b>Interrupts</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.Interrupt}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interrupts</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getHandlerUseCase_Interrupts()
	 * @model containment="true"
	 * @generated
	 */
	EList<Interrupt> getInterrupts();
} // HandlerUseCase
