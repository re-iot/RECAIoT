/**
 */
package mde.iot.ucm4iot.usecasediagram.util;

import mde.iot.ucm4iot.usecasediagram.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage
 * @generated
 */
public class UsecasediagramSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static UsecasediagramPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UsecasediagramSwitch() {
		if (modelPackage == null) {
			modelPackage = UsecasediagramPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case UsecasediagramPackage.HUMAN_ACTOR: {
			HumanActor humanActor = (HumanActor) theEObject;
			T result = caseHumanActor(humanActor);
			if (result == null)
				result = caseActor(humanActor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.SOFTWARE_ACTOR: {
			SoftwareActor softwareActor = (SoftwareActor) theEObject;
			T result = caseSoftwareActor(softwareActor);
			if (result == null)
				result = caseActor(softwareActor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.USE_CASE: {
			UseCase useCase = (UseCase) theEObject;
			T result = caseUseCase(useCase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.DEVICE_ACTOR: {
			DeviceActor deviceActor = (DeviceActor) theEObject;
			T result = caseDeviceActor(deviceActor);
			if (result == null)
				result = casePhysicalEntityActor(deviceActor);
			if (result == null)
				result = caseActor(deviceActor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.PHYSICAL_ENTITY_ACTOR: {
			PhysicalEntityActor physicalEntityActor = (PhysicalEntityActor) theEObject;
			T result = casePhysicalEntityActor(physicalEntityActor);
			if (result == null)
				result = caseActor(physicalEntityActor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.ACTOR: {
			Actor actor = (Actor) theEObject;
			T result = caseActor(actor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.INCLUDE: {
			Include include = (Include) theEObject;
			T result = caseInclude(include);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.SCOPE: {
			Scope scope = (Scope) theEObject;
			T result = caseScope(scope);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.EXTEND: {
			Extend extend = (Extend) theEObject;
			T result = caseExtend(extend);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.USE_CASE_DIAGRAM: {
			UseCaseDiagram useCaseDiagram = (UseCaseDiagram) theEObject;
			T result = caseUseCaseDiagram(useCaseDiagram);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.HANDLER_USE_CASE: {
			HandlerUseCase handlerUseCase = (HandlerUseCase) theEObject;
			T result = caseHandlerUseCase(handlerUseCase);
			if (result == null)
				result = caseUseCase(handlerUseCase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.STANDARD_USE_CASE: {
			StandardUseCase standardUseCase = (StandardUseCase) theEObject;
			T result = caseStandardUseCase(standardUseCase);
			if (result == null)
				result = caseUseCase(standardUseCase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.INTERRUPT: {
			Interrupt interrupt = (Interrupt) theEObject;
			T result = caseInterrupt(interrupt);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.INTERRUPT_AND_FAIL: {
			InterruptAndFail interruptAndFail = (InterruptAndFail) theEObject;
			T result = caseInterruptAndFail(interruptAndFail);
			if (result == null)
				result = caseInterrupt(interruptAndFail);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.INTERRUPT_AND_CONTINUE: {
			InterruptAndContinue interruptAndContinue = (InterruptAndContinue) theEObject;
			T result = caseInterruptAndContinue(interruptAndContinue);
			if (result == null)
				result = caseInterrupt(interruptAndContinue);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.UCM4_IO_TEXCEPTION: {
			UCM4IoTException ucm4IoTException = (UCM4IoTException) theEObject;
			T result = caseUCM4IoTException(ucm4IoTException);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.HARDWARE_EXCEPTION: {
			HardwareException hardwareException = (HardwareException) theEObject;
			T result = caseHardwareException(hardwareException);
			if (result == null)
				result = caseUCM4IoTException(hardwareException);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.SOFTWARE_EXCEPTION: {
			SoftwareException softwareException = (SoftwareException) theEObject;
			T result = caseSoftwareException(softwareException);
			if (result == null)
				result = caseUCM4IoTException(softwareException);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.ENVIRONMENT_EXCEPTION: {
			EnvironmentException environmentException = (EnvironmentException) theEObject;
			T result = caseEnvironmentException(environmentException);
			if (result == null)
				result = caseUCM4IoTException(environmentException);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.NETWORK_EXCEPTION: {
			NetworkException networkException = (NetworkException) theEObject;
			T result = caseNetworkException(networkException);
			if (result == null)
				result = caseUCM4IoTException(networkException);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.DYNAMIC_GOAL_REF: {
			DynamicGoalRef dynamicGoalRef = (DynamicGoalRef) theEObject;
			T result = caseDynamicGoalRef(dynamicGoalRef);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UsecasediagramPackage.CONTEXT_REQUIREMENT: {
			ContextRequirement contextRequirement = (ContextRequirement) theEObject;
			T result = caseContextRequirement(contextRequirement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Human Actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Human Actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHumanActor(HumanActor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Software Actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Software Actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSoftwareActor(SoftwareActor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Use Case</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Use Case</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUseCase(UseCase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Device Actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Device Actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDeviceActor(DeviceActor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Physical Entity Actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Physical Entity Actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePhysicalEntityActor(PhysicalEntityActor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActor(Actor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Include</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Include</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInclude(Include object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Scope</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Scope</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseScope(Scope object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Extend</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Extend</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExtend(Extend object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Use Case Diagram</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Use Case Diagram</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUseCaseDiagram(UseCaseDiagram object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Handler Use Case</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Handler Use Case</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHandlerUseCase(HandlerUseCase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Standard Use Case</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Standard Use Case</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStandardUseCase(StandardUseCase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interrupt</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interrupt</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterrupt(Interrupt object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interrupt And Fail</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interrupt And Fail</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterruptAndFail(InterruptAndFail object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interrupt And Continue</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interrupt And Continue</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterruptAndContinue(InterruptAndContinue object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>UCM4 Io TException</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>UCM4 Io TException</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUCM4IoTException(UCM4IoTException object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Hardware Exception</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Hardware Exception</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHardwareException(HardwareException object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Software Exception</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Software Exception</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSoftwareException(SoftwareException object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Environment Exception</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Environment Exception</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnvironmentException(EnvironmentException object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Network Exception</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Network Exception</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNetworkException(NetworkException object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dynamic Goal Ref</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dynamic Goal Ref</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDynamicGoalRef(DynamicGoalRef object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Context Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Context Requirement</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContextRequirement(ContextRequirement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //UsecasediagramSwitch
