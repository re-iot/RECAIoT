/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import mde.iot.ucm4iot.usecasediagram.SoftwareException;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Software Exception</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SoftwareExceptionImpl extends UCM4IoTExceptionImpl implements SoftwareException {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SoftwareExceptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.SOFTWARE_EXCEPTION;
	}

} //SoftwareExceptionImpl
