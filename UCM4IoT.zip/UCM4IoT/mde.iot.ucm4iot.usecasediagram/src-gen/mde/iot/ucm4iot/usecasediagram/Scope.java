/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scope</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Scope#getName <em>Name</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Scope#getUsecases <em>Usecases</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Scope#getExceptions <em>Exceptions</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getScope()
 * @model
 * @generated
 */
public interface Scope extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getScope_Name()
	 * @model default=""
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Scope#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Usecases</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.UseCase}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usecases</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getScope_Usecases()
	 * @model containment="true"
	 * @generated
	 */
	EList<UseCase> getUsecases();

	/**
	 * Returns the value of the '<em><b>Exceptions</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.UCM4IoTException}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exceptions</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getScope_Exceptions()
	 * @model containment="true"
	 * @generated
	 */
	EList<UCM4IoTException> getExceptions();

} // Scope
