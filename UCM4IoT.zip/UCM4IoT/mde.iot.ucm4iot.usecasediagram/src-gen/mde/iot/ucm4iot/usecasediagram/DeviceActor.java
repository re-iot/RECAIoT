/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Device Actor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getDeviceActor()
 * @model
 * @generated
 */
public interface DeviceActor extends PhysicalEntityActor {
} // DeviceActor
