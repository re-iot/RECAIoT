/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Actor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Actor#getUsecase <em>Usecase</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Actor#getName <em>Name</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Actor#getLowerBound <em>Lower Bound</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Actor#getUpperBound <em>Upper Bound</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getActor()
 * @model
 * @generated
 */
public interface Actor extends EObject {
	/**
	 * Returns the value of the '<em><b>Usecase</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.UseCase}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usecase</em>' reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getActor_Usecase()
	 * @model required="true"
	 * @generated
	 */
	EList<UseCase> getUsecase();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getActor_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Actor#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Lower Bound</b></em>' attribute.
	 * The default value is <code>"-1"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lower Bound</em>' attribute.
	 * @see #setLowerBound(int)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getActor_LowerBound()
	 * @model default="-1"
	 * @generated
	 */
	int getLowerBound();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Actor#getLowerBound <em>Lower Bound</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lower Bound</em>' attribute.
	 * @see #getLowerBound()
	 * @generated
	 */
	void setLowerBound(int value);

	/**
	 * Returns the value of the '<em><b>Upper Bound</b></em>' attribute.
	 * The default value is <code>"-1"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper Bound</em>' attribute.
	 * @see #setUpperBound(int)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getActor_UpperBound()
	 * @model default="-1"
	 * @generated
	 */
	int getUpperBound();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Actor#getUpperBound <em>Upper Bound</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper Bound</em>' attribute.
	 * @see #getUpperBound()
	 * @generated
	 */
	void setUpperBound(int value);

} // Actor
