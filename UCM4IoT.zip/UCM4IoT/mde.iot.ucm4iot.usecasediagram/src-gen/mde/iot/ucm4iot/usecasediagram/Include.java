/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Include</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Include#getIncludedCase <em>Included Case</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInclude()
 * @model
 * @generated
 */
public interface Include extends EObject {
	/**
	 * Returns the value of the '<em><b>Included Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Included Case</em>' reference.
	 * @see #setIncludedCase(UseCase)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInclude_IncludedCase()
	 * @model
	 * @generated
	 */
	UseCase getIncludedCase();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Include#getIncludedCase <em>Included Case</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Included Case</em>' reference.
	 * @see #getIncludedCase()
	 * @generated
	 */
	void setIncludedCase(UseCase value);

} // Include
