/**
 */
package mde.iot.ucm4iot.usecasediagram.util;

import mde.iot.ucm4iot.usecasediagram.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage
 * @generated
 */
public class UsecasediagramAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static UsecasediagramPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UsecasediagramAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = UsecasediagramPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UsecasediagramSwitch<Adapter> modelSwitch = new UsecasediagramSwitch<Adapter>() {
		@Override
		public Adapter caseHumanActor(HumanActor object) {
			return createHumanActorAdapter();
		}

		@Override
		public Adapter caseSoftwareActor(SoftwareActor object) {
			return createSoftwareActorAdapter();
		}

		@Override
		public Adapter caseUseCase(UseCase object) {
			return createUseCaseAdapter();
		}

		@Override
		public Adapter caseDeviceActor(DeviceActor object) {
			return createDeviceActorAdapter();
		}

		@Override
		public Adapter casePhysicalEntityActor(PhysicalEntityActor object) {
			return createPhysicalEntityActorAdapter();
		}

		@Override
		public Adapter caseActor(Actor object) {
			return createActorAdapter();
		}

		@Override
		public Adapter caseInclude(Include object) {
			return createIncludeAdapter();
		}

		@Override
		public Adapter caseScope(Scope object) {
			return createScopeAdapter();
		}

		@Override
		public Adapter caseExtend(Extend object) {
			return createExtendAdapter();
		}

		@Override
		public Adapter caseUseCaseDiagram(UseCaseDiagram object) {
			return createUseCaseDiagramAdapter();
		}

		@Override
		public Adapter caseHandlerUseCase(HandlerUseCase object) {
			return createHandlerUseCaseAdapter();
		}

		@Override
		public Adapter caseStandardUseCase(StandardUseCase object) {
			return createStandardUseCaseAdapter();
		}

		@Override
		public Adapter caseInterrupt(Interrupt object) {
			return createInterruptAdapter();
		}

		@Override
		public Adapter caseInterruptAndFail(InterruptAndFail object) {
			return createInterruptAndFailAdapter();
		}

		@Override
		public Adapter caseInterruptAndContinue(InterruptAndContinue object) {
			return createInterruptAndContinueAdapter();
		}

		@Override
		public Adapter caseUCM4IoTException(UCM4IoTException object) {
			return createUCM4IoTExceptionAdapter();
		}

		@Override
		public Adapter caseHardwareException(HardwareException object) {
			return createHardwareExceptionAdapter();
		}

		@Override
		public Adapter caseSoftwareException(SoftwareException object) {
			return createSoftwareExceptionAdapter();
		}

		@Override
		public Adapter caseEnvironmentException(EnvironmentException object) {
			return createEnvironmentExceptionAdapter();
		}

		@Override
		public Adapter caseNetworkException(NetworkException object) {
			return createNetworkExceptionAdapter();
		}

		@Override
		public Adapter caseDynamicGoalRef(DynamicGoalRef object) {
			return createDynamicGoalRefAdapter();
		}

		@Override
		public Adapter caseContextRequirement(ContextRequirement object) {
			return createContextRequirementAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.HumanActor <em>Human Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.HumanActor
	 * @generated
	 */
	public Adapter createHumanActorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.SoftwareActor <em>Software Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.SoftwareActor
	 * @generated
	 */
	public Adapter createSoftwareActorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.UseCase <em>Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase
	 * @generated
	 */
	public Adapter createUseCaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.DeviceActor <em>Device Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.DeviceActor
	 * @generated
	 */
	public Adapter createDeviceActorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.PhysicalEntityActor <em>Physical Entity Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.PhysicalEntityActor
	 * @generated
	 */
	public Adapter createPhysicalEntityActorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.Actor <em>Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.Actor
	 * @generated
	 */
	public Adapter createActorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.Include <em>Include</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.Include
	 * @generated
	 */
	public Adapter createIncludeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.Scope <em>Scope</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.Scope
	 * @generated
	 */
	public Adapter createScopeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.Extend <em>Extend</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.Extend
	 * @generated
	 */
	public Adapter createExtendAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.UseCaseDiagram <em>Use Case Diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCaseDiagram
	 * @generated
	 */
	public Adapter createUseCaseDiagramAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.HandlerUseCase <em>Handler Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.HandlerUseCase
	 * @generated
	 */
	public Adapter createHandlerUseCaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.StandardUseCase <em>Standard Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.StandardUseCase
	 * @generated
	 */
	public Adapter createStandardUseCaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.Interrupt <em>Interrupt</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.Interrupt
	 * @generated
	 */
	public Adapter createInterruptAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.InterruptAndFail <em>Interrupt And Fail</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.InterruptAndFail
	 * @generated
	 */
	public Adapter createInterruptAndFailAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.InterruptAndContinue <em>Interrupt And Continue</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.InterruptAndContinue
	 * @generated
	 */
	public Adapter createInterruptAndContinueAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.UCM4IoTException <em>UCM4 Io TException</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.UCM4IoTException
	 * @generated
	 */
	public Adapter createUCM4IoTExceptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.HardwareException <em>Hardware Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.HardwareException
	 * @generated
	 */
	public Adapter createHardwareExceptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.SoftwareException <em>Software Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.SoftwareException
	 * @generated
	 */
	public Adapter createSoftwareExceptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.EnvironmentException <em>Environment Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.EnvironmentException
	 * @generated
	 */
	public Adapter createEnvironmentExceptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.NetworkException <em>Network Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.NetworkException
	 * @generated
	 */
	public Adapter createNetworkExceptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.DynamicGoalRef <em>Dynamic Goal Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.DynamicGoalRef
	 * @generated
	 */
	public Adapter createDynamicGoalRefAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mde.iot.ucm4iot.usecasediagram.ContextRequirement <em>Context Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mde.iot.ucm4iot.usecasediagram.ContextRequirement
	 * @generated
	 */
	public Adapter createContextRequirementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //UsecasediagramAdapterFactory
