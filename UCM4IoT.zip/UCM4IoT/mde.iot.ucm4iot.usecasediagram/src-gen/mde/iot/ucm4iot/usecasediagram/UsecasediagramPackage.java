/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramFactory
 * @model kind="package"
 * @generated
 */
public interface UsecasediagramPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "usecasediagram";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.ucm4iot.org/mde/iot/usecasediagram";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "usecasediagram";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UsecasediagramPackage eINSTANCE = mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl.init();

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ActorImpl <em>Actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.ActorImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getActor()
	 * @generated
	 */
	int ACTOR = 5;

	/**
	 * The feature id for the '<em><b>Usecase</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__USECASE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__NAME = 1;

	/**
	 * The feature id for the '<em><b>Lower Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__LOWER_BOUND = 2;

	/**
	 * The feature id for the '<em><b>Upper Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__UPPER_BOUND = 3;

	/**
	 * The number of structural features of the '<em>Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.HumanActorImpl <em>Human Actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.HumanActorImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getHumanActor()
	 * @generated
	 */
	int HUMAN_ACTOR = 0;

	/**
	 * The feature id for the '<em><b>Usecase</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_ACTOR__USECASE = ACTOR__USECASE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_ACTOR__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Lower Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_ACTOR__LOWER_BOUND = ACTOR__LOWER_BOUND;

	/**
	 * The feature id for the '<em><b>Upper Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_ACTOR__UPPER_BOUND = ACTOR__UPPER_BOUND;

	/**
	 * The number of structural features of the '<em>Human Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_ACTOR_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Human Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMAN_ACTOR_OPERATION_COUNT = ACTOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.SoftwareActorImpl <em>Software Actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.SoftwareActorImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getSoftwareActor()
	 * @generated
	 */
	int SOFTWARE_ACTOR = 1;

	/**
	 * The feature id for the '<em><b>Usecase</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_ACTOR__USECASE = ACTOR__USECASE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_ACTOR__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Lower Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_ACTOR__LOWER_BOUND = ACTOR__LOWER_BOUND;

	/**
	 * The feature id for the '<em><b>Upper Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_ACTOR__UPPER_BOUND = ACTOR__UPPER_BOUND;

	/**
	 * The number of structural features of the '<em>Software Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_ACTOR_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Software Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_ACTOR_OPERATION_COUNT = ACTOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl <em>Use Case</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getUseCase()
	 * @generated
	 */
	int USE_CASE = 2;

	/**
	 * The feature id for the '<em><b>Extends</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE__EXTENDS = 0;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE__INCLUDES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE__NAME = 2;

	/**
	 * The feature id for the '<em><b>Dynamic Goals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE__DYNAMIC_GOALS = 3;

	/**
	 * The feature id for the '<em><b>Context Requirements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE__CONTEXT_REQUIREMENTS = 4;

	/**
	 * The number of structural features of the '<em>Use Case</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Use Case</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.DeviceActorImpl <em>Device Actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.DeviceActorImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getDeviceActor()
	 * @generated
	 */
	int DEVICE_ACTOR = 3;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.PhysicalEntityActorImpl <em>Physical Entity Actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.PhysicalEntityActorImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getPhysicalEntityActor()
	 * @generated
	 */
	int PHYSICAL_ENTITY_ACTOR = 4;

	/**
	 * The feature id for the '<em><b>Usecase</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_ACTOR__USECASE = ACTOR__USECASE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_ACTOR__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Lower Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_ACTOR__LOWER_BOUND = ACTOR__LOWER_BOUND;

	/**
	 * The feature id for the '<em><b>Upper Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_ACTOR__UPPER_BOUND = ACTOR__UPPER_BOUND;

	/**
	 * The number of structural features of the '<em>Physical Entity Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_ACTOR_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Physical Entity Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHYSICAL_ENTITY_ACTOR_OPERATION_COUNT = ACTOR_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Usecase</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_ACTOR__USECASE = PHYSICAL_ENTITY_ACTOR__USECASE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_ACTOR__NAME = PHYSICAL_ENTITY_ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Lower Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_ACTOR__LOWER_BOUND = PHYSICAL_ENTITY_ACTOR__LOWER_BOUND;

	/**
	 * The feature id for the '<em><b>Upper Bound</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_ACTOR__UPPER_BOUND = PHYSICAL_ENTITY_ACTOR__UPPER_BOUND;

	/**
	 * The number of structural features of the '<em>Device Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_ACTOR_FEATURE_COUNT = PHYSICAL_ENTITY_ACTOR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Device Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_ACTOR_OPERATION_COUNT = PHYSICAL_ENTITY_ACTOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.IncludeImpl <em>Include</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.IncludeImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInclude()
	 * @generated
	 */
	int INCLUDE = 6;

	/**
	 * The feature id for the '<em><b>Included Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCLUDE__INCLUDED_CASE = 0;

	/**
	 * The number of structural features of the '<em>Include</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCLUDE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Include</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCLUDE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ScopeImpl <em>Scope</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.ScopeImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getScope()
	 * @generated
	 */
	int SCOPE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Usecases</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE__USECASES = 1;

	/**
	 * The feature id for the '<em><b>Exceptions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE__EXCEPTIONS = 2;

	/**
	 * The number of structural features of the '<em>Scope</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Scope</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ExtendImpl <em>Extend</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.ExtendImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getExtend()
	 * @generated
	 */
	int EXTEND = 8;

	/**
	 * The feature id for the '<em><b>Extended Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTEND__EXTENDED_CASE = 0;

	/**
	 * The number of structural features of the '<em>Extend</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTEND_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Extend</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTEND_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseDiagramImpl <em>Use Case Diagram</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UseCaseDiagramImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getUseCaseDiagram()
	 * @generated
	 */
	int USE_CASE_DIAGRAM = 9;

	/**
	 * The feature id for the '<em><b>Scopes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE_DIAGRAM__SCOPES = 0;

	/**
	 * The feature id for the '<em><b>Actors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE_DIAGRAM__ACTORS = 1;

	/**
	 * The number of structural features of the '<em>Use Case Diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE_DIAGRAM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Use Case Diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USE_CASE_DIAGRAM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.HandlerUseCaseImpl <em>Handler Use Case</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.HandlerUseCaseImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getHandlerUseCase()
	 * @generated
	 */
	int HANDLER_USE_CASE = 10;

	/**
	 * The feature id for the '<em><b>Extends</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE__EXTENDS = USE_CASE__EXTENDS;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE__INCLUDES = USE_CASE__INCLUDES;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE__NAME = USE_CASE__NAME;

	/**
	 * The feature id for the '<em><b>Dynamic Goals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE__DYNAMIC_GOALS = USE_CASE__DYNAMIC_GOALS;

	/**
	 * The feature id for the '<em><b>Context Requirements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE__CONTEXT_REQUIREMENTS = USE_CASE__CONTEXT_REQUIREMENTS;

	/**
	 * The feature id for the '<em><b>Interrupts</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE__INTERRUPTS = USE_CASE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Handler Use Case</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE_FEATURE_COUNT = USE_CASE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Handler Use Case</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HANDLER_USE_CASE_OPERATION_COUNT = USE_CASE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.StandardUseCaseImpl <em>Standard Use Case</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.StandardUseCaseImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getStandardUseCase()
	 * @generated
	 */
	int STANDARD_USE_CASE = 11;

	/**
	 * The feature id for the '<em><b>Extends</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE__EXTENDS = USE_CASE__EXTENDS;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE__INCLUDES = USE_CASE__INCLUDES;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE__NAME = USE_CASE__NAME;

	/**
	 * The feature id for the '<em><b>Dynamic Goals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE__DYNAMIC_GOALS = USE_CASE__DYNAMIC_GOALS;

	/**
	 * The feature id for the '<em><b>Context Requirements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE__CONTEXT_REQUIREMENTS = USE_CASE__CONTEXT_REQUIREMENTS;

	/**
	 * The number of structural features of the '<em>Standard Use Case</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE_FEATURE_COUNT = USE_CASE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Standard Use Case</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STANDARD_USE_CASE_OPERATION_COUNT = USE_CASE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptImpl <em>Interrupt</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.InterruptImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInterrupt()
	 * @generated
	 */
	int INTERRUPT = 12;

	/**
	 * The feature id for the '<em><b>Interrupted Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT__INTERRUPTED_CASE = 0;

	/**
	 * The feature id for the '<em><b>Exceptions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT__EXCEPTIONS = 1;

	/**
	 * The number of structural features of the '<em>Interrupt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interrupt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptAndFailImpl <em>Interrupt And Fail</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.InterruptAndFailImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInterruptAndFail()
	 * @generated
	 */
	int INTERRUPT_AND_FAIL = 13;

	/**
	 * The feature id for the '<em><b>Interrupted Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_FAIL__INTERRUPTED_CASE = INTERRUPT__INTERRUPTED_CASE;

	/**
	 * The feature id for the '<em><b>Exceptions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_FAIL__EXCEPTIONS = INTERRUPT__EXCEPTIONS;

	/**
	 * The number of structural features of the '<em>Interrupt And Fail</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_FAIL_FEATURE_COUNT = INTERRUPT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Interrupt And Fail</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_FAIL_OPERATION_COUNT = INTERRUPT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptAndContinueImpl <em>Interrupt And Continue</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.InterruptAndContinueImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInterruptAndContinue()
	 * @generated
	 */
	int INTERRUPT_AND_CONTINUE = 14;

	/**
	 * The feature id for the '<em><b>Interrupted Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_CONTINUE__INTERRUPTED_CASE = INTERRUPT__INTERRUPTED_CASE;

	/**
	 * The feature id for the '<em><b>Exceptions</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_CONTINUE__EXCEPTIONS = INTERRUPT__EXCEPTIONS;

	/**
	 * The number of structural features of the '<em>Interrupt And Continue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_CONTINUE_FEATURE_COUNT = INTERRUPT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Interrupt And Continue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERRUPT_AND_CONTINUE_OPERATION_COUNT = INTERRUPT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.UCM4IoTExceptionImpl <em>UCM4 Io TException</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UCM4IoTExceptionImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getUCM4IoTException()
	 * @generated
	 */
	int UCM4_IO_TEXCEPTION = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UCM4_IO_TEXCEPTION__NAME = 0;

	/**
	 * The number of structural features of the '<em>UCM4 Io TException</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UCM4_IO_TEXCEPTION_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>UCM4 Io TException</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UCM4_IO_TEXCEPTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.HardwareExceptionImpl <em>Hardware Exception</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.HardwareExceptionImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getHardwareException()
	 * @generated
	 */
	int HARDWARE_EXCEPTION = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HARDWARE_EXCEPTION__NAME = UCM4_IO_TEXCEPTION__NAME;

	/**
	 * The number of structural features of the '<em>Hardware Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HARDWARE_EXCEPTION_FEATURE_COUNT = UCM4_IO_TEXCEPTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Hardware Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HARDWARE_EXCEPTION_OPERATION_COUNT = UCM4_IO_TEXCEPTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.SoftwareExceptionImpl <em>Software Exception</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.SoftwareExceptionImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getSoftwareException()
	 * @generated
	 */
	int SOFTWARE_EXCEPTION = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_EXCEPTION__NAME = UCM4_IO_TEXCEPTION__NAME;

	/**
	 * The number of structural features of the '<em>Software Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_EXCEPTION_FEATURE_COUNT = UCM4_IO_TEXCEPTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Software Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTWARE_EXCEPTION_OPERATION_COUNT = UCM4_IO_TEXCEPTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.EnvironmentExceptionImpl <em>Environment Exception</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.EnvironmentExceptionImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getEnvironmentException()
	 * @generated
	 */
	int ENVIRONMENT_EXCEPTION = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_EXCEPTION__NAME = UCM4_IO_TEXCEPTION__NAME;

	/**
	 * The number of structural features of the '<em>Environment Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_EXCEPTION_FEATURE_COUNT = UCM4_IO_TEXCEPTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Environment Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_EXCEPTION_OPERATION_COUNT = UCM4_IO_TEXCEPTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.NetworkExceptionImpl <em>Network Exception</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.NetworkExceptionImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getNetworkException()
	 * @generated
	 */
	int NETWORK_EXCEPTION = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_EXCEPTION__NAME = UCM4_IO_TEXCEPTION__NAME;

	/**
	 * The number of structural features of the '<em>Network Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_EXCEPTION_FEATURE_COUNT = UCM4_IO_TEXCEPTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Network Exception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_EXCEPTION_OPERATION_COUNT = UCM4_IO_TEXCEPTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.DynamicGoalRefImpl <em>Dynamic Goal Ref</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.DynamicGoalRefImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getDynamicGoalRef()
	 * @generated
	 */
	int DYNAMIC_GOAL_REF = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DYNAMIC_GOAL_REF__NAME = 0;

	/**
	 * The number of structural features of the '<em>Dynamic Goal Ref</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DYNAMIC_GOAL_REF_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Dynamic Goal Ref</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DYNAMIC_GOAL_REF_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ContextRequirementImpl <em>Context Requirement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mde.iot.ucm4iot.usecasediagram.impl.ContextRequirementImpl
	 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getContextRequirement()
	 * @generated
	 */
	int CONTEXT_REQUIREMENT = 21;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_REQUIREMENT__ID = 0;

	/**
	 * The number of structural features of the '<em>Context Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_REQUIREMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Context Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_REQUIREMENT_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.HumanActor <em>Human Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Human Actor</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.HumanActor
	 * @generated
	 */
	EClass getHumanActor();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.SoftwareActor <em>Software Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Software Actor</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.SoftwareActor
	 * @generated
	 */
	EClass getSoftwareActor();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.UseCase <em>Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Use Case</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase
	 * @generated
	 */
	EClass getUseCase();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.UseCase#getExtends <em>Extends</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Extends</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase#getExtends()
	 * @see #getUseCase()
	 * @generated
	 */
	EReference getUseCase_Extends();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.UseCase#getIncludes <em>Includes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Includes</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase#getIncludes()
	 * @see #getUseCase()
	 * @generated
	 */
	EReference getUseCase_Includes();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.UseCase#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase#getName()
	 * @see #getUseCase()
	 * @generated
	 */
	EAttribute getUseCase_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.UseCase#getDynamicGoals <em>Dynamic Goals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dynamic Goals</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase#getDynamicGoals()
	 * @see #getUseCase()
	 * @generated
	 */
	EReference getUseCase_DynamicGoals();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.UseCase#getContextRequirements <em>Context Requirements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Context Requirements</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCase#getContextRequirements()
	 * @see #getUseCase()
	 * @generated
	 */
	EReference getUseCase_ContextRequirements();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.DeviceActor <em>Device Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Device Actor</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.DeviceActor
	 * @generated
	 */
	EClass getDeviceActor();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.PhysicalEntityActor <em>Physical Entity Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Physical Entity Actor</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.PhysicalEntityActor
	 * @generated
	 */
	EClass getPhysicalEntityActor();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.Actor <em>Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Actor</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Actor
	 * @generated
	 */
	EClass getActor();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.usecasediagram.Actor#getUsecase <em>Usecase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Usecase</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Actor#getUsecase()
	 * @see #getActor()
	 * @generated
	 */
	EReference getActor_Usecase();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.Actor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Actor#getName()
	 * @see #getActor()
	 * @generated
	 */
	EAttribute getActor_Name();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.Actor#getLowerBound <em>Lower Bound</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lower Bound</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Actor#getLowerBound()
	 * @see #getActor()
	 * @generated
	 */
	EAttribute getActor_LowerBound();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.Actor#getUpperBound <em>Upper Bound</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Upper Bound</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Actor#getUpperBound()
	 * @see #getActor()
	 * @generated
	 */
	EAttribute getActor_UpperBound();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.Include <em>Include</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Include</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Include
	 * @generated
	 */
	EClass getInclude();

	/**
	 * Returns the meta object for the reference '{@link mde.iot.ucm4iot.usecasediagram.Include#getIncludedCase <em>Included Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Included Case</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Include#getIncludedCase()
	 * @see #getInclude()
	 * @generated
	 */
	EReference getInclude_IncludedCase();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.Scope <em>Scope</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Scope</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Scope
	 * @generated
	 */
	EClass getScope();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.Scope#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Scope#getName()
	 * @see #getScope()
	 * @generated
	 */
	EAttribute getScope_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.Scope#getUsecases <em>Usecases</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Usecases</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Scope#getUsecases()
	 * @see #getScope()
	 * @generated
	 */
	EReference getScope_Usecases();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.Scope#getExceptions <em>Exceptions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Exceptions</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Scope#getExceptions()
	 * @see #getScope()
	 * @generated
	 */
	EReference getScope_Exceptions();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.Extend <em>Extend</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Extend</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Extend
	 * @generated
	 */
	EClass getExtend();

	/**
	 * Returns the meta object for the reference '{@link mde.iot.ucm4iot.usecasediagram.Extend#getExtendedCase <em>Extended Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Extended Case</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Extend#getExtendedCase()
	 * @see #getExtend()
	 * @generated
	 */
	EReference getExtend_ExtendedCase();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.UseCaseDiagram <em>Use Case Diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Use Case Diagram</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCaseDiagram
	 * @generated
	 */
	EClass getUseCaseDiagram();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.UseCaseDiagram#getScopes <em>Scopes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scopes</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCaseDiagram#getScopes()
	 * @see #getUseCaseDiagram()
	 * @generated
	 */
	EReference getUseCaseDiagram_Scopes();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.UseCaseDiagram#getActors <em>Actors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Actors</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UseCaseDiagram#getActors()
	 * @see #getUseCaseDiagram()
	 * @generated
	 */
	EReference getUseCaseDiagram_Actors();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.HandlerUseCase <em>Handler Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Handler Use Case</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.HandlerUseCase
	 * @generated
	 */
	EClass getHandlerUseCase();

	/**
	 * Returns the meta object for the containment reference list '{@link mde.iot.ucm4iot.usecasediagram.HandlerUseCase#getInterrupts <em>Interrupts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Interrupts</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.HandlerUseCase#getInterrupts()
	 * @see #getHandlerUseCase()
	 * @generated
	 */
	EReference getHandlerUseCase_Interrupts();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.StandardUseCase <em>Standard Use Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Standard Use Case</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.StandardUseCase
	 * @generated
	 */
	EClass getStandardUseCase();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.Interrupt <em>Interrupt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interrupt</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Interrupt
	 * @generated
	 */
	EClass getInterrupt();

	/**
	 * Returns the meta object for the reference '{@link mde.iot.ucm4iot.usecasediagram.Interrupt#getInterruptedCase <em>Interrupted Case</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interrupted Case</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Interrupt#getInterruptedCase()
	 * @see #getInterrupt()
	 * @generated
	 */
	EReference getInterrupt_InterruptedCase();

	/**
	 * Returns the meta object for the reference list '{@link mde.iot.ucm4iot.usecasediagram.Interrupt#getExceptions <em>Exceptions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Exceptions</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.Interrupt#getExceptions()
	 * @see #getInterrupt()
	 * @generated
	 */
	EReference getInterrupt_Exceptions();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.InterruptAndFail <em>Interrupt And Fail</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interrupt And Fail</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.InterruptAndFail
	 * @generated
	 */
	EClass getInterruptAndFail();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.InterruptAndContinue <em>Interrupt And Continue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interrupt And Continue</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.InterruptAndContinue
	 * @generated
	 */
	EClass getInterruptAndContinue();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.UCM4IoTException <em>UCM4 Io TException</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>UCM4 Io TException</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UCM4IoTException
	 * @generated
	 */
	EClass getUCM4IoTException();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.UCM4IoTException#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.UCM4IoTException#getName()
	 * @see #getUCM4IoTException()
	 * @generated
	 */
	EAttribute getUCM4IoTException_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.HardwareException <em>Hardware Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hardware Exception</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.HardwareException
	 * @generated
	 */
	EClass getHardwareException();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.SoftwareException <em>Software Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Software Exception</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.SoftwareException
	 * @generated
	 */
	EClass getSoftwareException();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.EnvironmentException <em>Environment Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Environment Exception</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.EnvironmentException
	 * @generated
	 */
	EClass getEnvironmentException();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.NetworkException <em>Network Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Network Exception</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.NetworkException
	 * @generated
	 */
	EClass getNetworkException();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.DynamicGoalRef <em>Dynamic Goal Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dynamic Goal Ref</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.DynamicGoalRef
	 * @generated
	 */
	EClass getDynamicGoalRef();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.DynamicGoalRef#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.DynamicGoalRef#getName()
	 * @see #getDynamicGoalRef()
	 * @generated
	 */
	EAttribute getDynamicGoalRef_Name();

	/**
	 * Returns the meta object for class '{@link mde.iot.ucm4iot.usecasediagram.ContextRequirement <em>Context Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Context Requirement</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.ContextRequirement
	 * @generated
	 */
	EClass getContextRequirement();

	/**
	 * Returns the meta object for the attribute '{@link mde.iot.ucm4iot.usecasediagram.ContextRequirement#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see mde.iot.ucm4iot.usecasediagram.ContextRequirement#getId()
	 * @see #getContextRequirement()
	 * @generated
	 */
	EAttribute getContextRequirement_Id();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	UsecasediagramFactory getUsecasediagramFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.HumanActorImpl <em>Human Actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.HumanActorImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getHumanActor()
		 * @generated
		 */
		EClass HUMAN_ACTOR = eINSTANCE.getHumanActor();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.SoftwareActorImpl <em>Software Actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.SoftwareActorImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getSoftwareActor()
		 * @generated
		 */
		EClass SOFTWARE_ACTOR = eINSTANCE.getSoftwareActor();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl <em>Use Case</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getUseCase()
		 * @generated
		 */
		EClass USE_CASE = eINSTANCE.getUseCase();

		/**
		 * The meta object literal for the '<em><b>Extends</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USE_CASE__EXTENDS = eINSTANCE.getUseCase_Extends();

		/**
		 * The meta object literal for the '<em><b>Includes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USE_CASE__INCLUDES = eINSTANCE.getUseCase_Includes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USE_CASE__NAME = eINSTANCE.getUseCase_Name();

		/**
		 * The meta object literal for the '<em><b>Dynamic Goals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USE_CASE__DYNAMIC_GOALS = eINSTANCE.getUseCase_DynamicGoals();

		/**
		 * The meta object literal for the '<em><b>Context Requirements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USE_CASE__CONTEXT_REQUIREMENTS = eINSTANCE.getUseCase_ContextRequirements();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.DeviceActorImpl <em>Device Actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.DeviceActorImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getDeviceActor()
		 * @generated
		 */
		EClass DEVICE_ACTOR = eINSTANCE.getDeviceActor();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.PhysicalEntityActorImpl <em>Physical Entity Actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.PhysicalEntityActorImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getPhysicalEntityActor()
		 * @generated
		 */
		EClass PHYSICAL_ENTITY_ACTOR = eINSTANCE.getPhysicalEntityActor();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ActorImpl <em>Actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.ActorImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getActor()
		 * @generated
		 */
		EClass ACTOR = eINSTANCE.getActor();

		/**
		 * The meta object literal for the '<em><b>Usecase</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__USECASE = eINSTANCE.getActor_Usecase();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__NAME = eINSTANCE.getActor_Name();

		/**
		 * The meta object literal for the '<em><b>Lower Bound</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__LOWER_BOUND = eINSTANCE.getActor_LowerBound();

		/**
		 * The meta object literal for the '<em><b>Upper Bound</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__UPPER_BOUND = eINSTANCE.getActor_UpperBound();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.IncludeImpl <em>Include</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.IncludeImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInclude()
		 * @generated
		 */
		EClass INCLUDE = eINSTANCE.getInclude();

		/**
		 * The meta object literal for the '<em><b>Included Case</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INCLUDE__INCLUDED_CASE = eINSTANCE.getInclude_IncludedCase();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ScopeImpl <em>Scope</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.ScopeImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getScope()
		 * @generated
		 */
		EClass SCOPE = eINSTANCE.getScope();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCOPE__NAME = eINSTANCE.getScope_Name();

		/**
		 * The meta object literal for the '<em><b>Usecases</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCOPE__USECASES = eINSTANCE.getScope_Usecases();

		/**
		 * The meta object literal for the '<em><b>Exceptions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCOPE__EXCEPTIONS = eINSTANCE.getScope_Exceptions();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ExtendImpl <em>Extend</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.ExtendImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getExtend()
		 * @generated
		 */
		EClass EXTEND = eINSTANCE.getExtend();

		/**
		 * The meta object literal for the '<em><b>Extended Case</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EXTEND__EXTENDED_CASE = eINSTANCE.getExtend_ExtendedCase();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseDiagramImpl <em>Use Case Diagram</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UseCaseDiagramImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getUseCaseDiagram()
		 * @generated
		 */
		EClass USE_CASE_DIAGRAM = eINSTANCE.getUseCaseDiagram();

		/**
		 * The meta object literal for the '<em><b>Scopes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USE_CASE_DIAGRAM__SCOPES = eINSTANCE.getUseCaseDiagram_Scopes();

		/**
		 * The meta object literal for the '<em><b>Actors</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USE_CASE_DIAGRAM__ACTORS = eINSTANCE.getUseCaseDiagram_Actors();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.HandlerUseCaseImpl <em>Handler Use Case</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.HandlerUseCaseImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getHandlerUseCase()
		 * @generated
		 */
		EClass HANDLER_USE_CASE = eINSTANCE.getHandlerUseCase();

		/**
		 * The meta object literal for the '<em><b>Interrupts</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HANDLER_USE_CASE__INTERRUPTS = eINSTANCE.getHandlerUseCase_Interrupts();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.StandardUseCaseImpl <em>Standard Use Case</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.StandardUseCaseImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getStandardUseCase()
		 * @generated
		 */
		EClass STANDARD_USE_CASE = eINSTANCE.getStandardUseCase();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptImpl <em>Interrupt</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.InterruptImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInterrupt()
		 * @generated
		 */
		EClass INTERRUPT = eINSTANCE.getInterrupt();

		/**
		 * The meta object literal for the '<em><b>Interrupted Case</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERRUPT__INTERRUPTED_CASE = eINSTANCE.getInterrupt_InterruptedCase();

		/**
		 * The meta object literal for the '<em><b>Exceptions</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERRUPT__EXCEPTIONS = eINSTANCE.getInterrupt_Exceptions();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptAndFailImpl <em>Interrupt And Fail</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.InterruptAndFailImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInterruptAndFail()
		 * @generated
		 */
		EClass INTERRUPT_AND_FAIL = eINSTANCE.getInterruptAndFail();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptAndContinueImpl <em>Interrupt And Continue</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.InterruptAndContinueImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getInterruptAndContinue()
		 * @generated
		 */
		EClass INTERRUPT_AND_CONTINUE = eINSTANCE.getInterruptAndContinue();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.UCM4IoTExceptionImpl <em>UCM4 Io TException</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UCM4IoTExceptionImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getUCM4IoTException()
		 * @generated
		 */
		EClass UCM4_IO_TEXCEPTION = eINSTANCE.getUCM4IoTException();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UCM4_IO_TEXCEPTION__NAME = eINSTANCE.getUCM4IoTException_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.HardwareExceptionImpl <em>Hardware Exception</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.HardwareExceptionImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getHardwareException()
		 * @generated
		 */
		EClass HARDWARE_EXCEPTION = eINSTANCE.getHardwareException();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.SoftwareExceptionImpl <em>Software Exception</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.SoftwareExceptionImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getSoftwareException()
		 * @generated
		 */
		EClass SOFTWARE_EXCEPTION = eINSTANCE.getSoftwareException();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.EnvironmentExceptionImpl <em>Environment Exception</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.EnvironmentExceptionImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getEnvironmentException()
		 * @generated
		 */
		EClass ENVIRONMENT_EXCEPTION = eINSTANCE.getEnvironmentException();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.NetworkExceptionImpl <em>Network Exception</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.NetworkExceptionImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getNetworkException()
		 * @generated
		 */
		EClass NETWORK_EXCEPTION = eINSTANCE.getNetworkException();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.DynamicGoalRefImpl <em>Dynamic Goal Ref</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.DynamicGoalRefImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getDynamicGoalRef()
		 * @generated
		 */
		EClass DYNAMIC_GOAL_REF = eINSTANCE.getDynamicGoalRef();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DYNAMIC_GOAL_REF__NAME = eINSTANCE.getDynamicGoalRef_Name();

		/**
		 * The meta object literal for the '{@link mde.iot.ucm4iot.usecasediagram.impl.ContextRequirementImpl <em>Context Requirement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mde.iot.ucm4iot.usecasediagram.impl.ContextRequirementImpl
		 * @see mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramPackageImpl#getContextRequirement()
		 * @generated
		 */
		EClass CONTEXT_REQUIREMENT = eINSTANCE.getContextRequirement();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTEXT_REQUIREMENT__ID = eINSTANCE.getContextRequirement_Id();

	}

} //UsecasediagramPackage
