/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage
 * @generated
 */
public interface UsecasediagramFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UsecasediagramFactory eINSTANCE = mde.iot.ucm4iot.usecasediagram.impl.UsecasediagramFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Human Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Human Actor</em>'.
	 * @generated
	 */
	HumanActor createHumanActor();

	/**
	 * Returns a new object of class '<em>Software Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Software Actor</em>'.
	 * @generated
	 */
	SoftwareActor createSoftwareActor();

	/**
	 * Returns a new object of class '<em>Device Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Device Actor</em>'.
	 * @generated
	 */
	DeviceActor createDeviceActor();

	/**
	 * Returns a new object of class '<em>Physical Entity Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Physical Entity Actor</em>'.
	 * @generated
	 */
	PhysicalEntityActor createPhysicalEntityActor();

	/**
	 * Returns a new object of class '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Actor</em>'.
	 * @generated
	 */
	Actor createActor();

	/**
	 * Returns a new object of class '<em>Include</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Include</em>'.
	 * @generated
	 */
	Include createInclude();

	/**
	 * Returns a new object of class '<em>Scope</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Scope</em>'.
	 * @generated
	 */
	Scope createScope();

	/**
	 * Returns a new object of class '<em>Extend</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Extend</em>'.
	 * @generated
	 */
	Extend createExtend();

	/**
	 * Returns a new object of class '<em>Use Case Diagram</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Use Case Diagram</em>'.
	 * @generated
	 */
	UseCaseDiagram createUseCaseDiagram();

	/**
	 * Returns a new object of class '<em>Handler Use Case</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Handler Use Case</em>'.
	 * @generated
	 */
	HandlerUseCase createHandlerUseCase();

	/**
	 * Returns a new object of class '<em>Standard Use Case</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Standard Use Case</em>'.
	 * @generated
	 */
	StandardUseCase createStandardUseCase();

	/**
	 * Returns a new object of class '<em>Interrupt And Fail</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interrupt And Fail</em>'.
	 * @generated
	 */
	InterruptAndFail createInterruptAndFail();

	/**
	 * Returns a new object of class '<em>Interrupt And Continue</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interrupt And Continue</em>'.
	 * @generated
	 */
	InterruptAndContinue createInterruptAndContinue();

	/**
	 * Returns a new object of class '<em>Hardware Exception</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Exception</em>'.
	 * @generated
	 */
	HardwareException createHardwareException();

	/**
	 * Returns a new object of class '<em>Software Exception</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Software Exception</em>'.
	 * @generated
	 */
	SoftwareException createSoftwareException();

	/**
	 * Returns a new object of class '<em>Environment Exception</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Environment Exception</em>'.
	 * @generated
	 */
	EnvironmentException createEnvironmentException();

	/**
	 * Returns a new object of class '<em>Network Exception</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Network Exception</em>'.
	 * @generated
	 */
	NetworkException createNetworkException();

	/**
	 * Returns a new object of class '<em>Dynamic Goal Ref</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dynamic Goal Ref</em>'.
	 * @generated
	 */
	DynamicGoalRef createDynamicGoalRef();

	/**
	 * Returns a new object of class '<em>Context Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Context Requirement</em>'.
	 * @generated
	 */
	ContextRequirement createContextRequirement();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	UsecasediagramPackage getUsecasediagramPackage();

} //UsecasediagramFactory
