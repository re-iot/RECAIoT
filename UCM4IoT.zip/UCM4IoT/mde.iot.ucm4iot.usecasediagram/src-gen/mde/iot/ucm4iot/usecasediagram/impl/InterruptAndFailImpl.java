/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import mde.iot.ucm4iot.usecasediagram.InterruptAndFail;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interrupt And Fail</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InterruptAndFailImpl extends InterruptImpl implements InterruptAndFail {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterruptAndFailImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.INTERRUPT_AND_FAIL;
	}

} //InterruptAndFailImpl
