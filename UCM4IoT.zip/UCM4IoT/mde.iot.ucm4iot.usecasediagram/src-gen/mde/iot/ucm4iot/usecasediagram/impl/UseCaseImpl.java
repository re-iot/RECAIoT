/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import java.util.Collection;

import mde.iot.ucm4iot.usecasediagram.ContextRequirement;
import mde.iot.ucm4iot.usecasediagram.DynamicGoalRef;
import mde.iot.ucm4iot.usecasediagram.Extend;
import mde.iot.ucm4iot.usecasediagram.Include;
import mde.iot.ucm4iot.usecasediagram.UseCase;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Use Case</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl#getExtends <em>Extends</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl#getIncludes <em>Includes</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl#getName <em>Name</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl#getDynamicGoals <em>Dynamic Goals</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseImpl#getContextRequirements <em>Context Requirements</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class UseCaseImpl extends MinimalEObjectImpl.Container implements UseCase {
	/**
	 * The cached value of the '{@link #getExtends() <em>Extends</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtends()
	 * @generated
	 * @ordered
	 */
	protected EList<Extend> extends_;

	/**
	 * The cached value of the '{@link #getIncludes() <em>Includes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncludes()
	 * @generated
	 * @ordered
	 */
	protected EList<Include> includes;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDynamicGoals() <em>Dynamic Goals</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDynamicGoals()
	 * @generated
	 * @ordered
	 */
	protected EList<DynamicGoalRef> dynamicGoals;

	/**
	 * The cached value of the '{@link #getContextRequirements() <em>Context Requirements</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContextRequirements()
	 * @generated
	 * @ordered
	 */
	protected EList<ContextRequirement> contextRequirements;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UseCaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.USE_CASE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Extend> getExtends() {
		if (extends_ == null) {
			extends_ = new EObjectContainmentEList<Extend>(Extend.class, this, UsecasediagramPackage.USE_CASE__EXTENDS);
		}
		return extends_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Include> getIncludes() {
		if (includes == null) {
			includes = new EObjectContainmentEList<Include>(Include.class, this,
					UsecasediagramPackage.USE_CASE__INCLUDES);
		}
		return includes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UsecasediagramPackage.USE_CASE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DynamicGoalRef> getDynamicGoals() {
		if (dynamicGoals == null) {
			dynamicGoals = new EObjectContainmentEList<DynamicGoalRef>(DynamicGoalRef.class, this,
					UsecasediagramPackage.USE_CASE__DYNAMIC_GOALS);
		}
		return dynamicGoals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ContextRequirement> getContextRequirements() {
		if (contextRequirements == null) {
			contextRequirements = new EObjectContainmentEList<ContextRequirement>(ContextRequirement.class, this,
					UsecasediagramPackage.USE_CASE__CONTEXT_REQUIREMENTS);
		}
		return contextRequirements;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE__EXTENDS:
			return ((InternalEList<?>) getExtends()).basicRemove(otherEnd, msgs);
		case UsecasediagramPackage.USE_CASE__INCLUDES:
			return ((InternalEList<?>) getIncludes()).basicRemove(otherEnd, msgs);
		case UsecasediagramPackage.USE_CASE__DYNAMIC_GOALS:
			return ((InternalEList<?>) getDynamicGoals()).basicRemove(otherEnd, msgs);
		case UsecasediagramPackage.USE_CASE__CONTEXT_REQUIREMENTS:
			return ((InternalEList<?>) getContextRequirements()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE__EXTENDS:
			return getExtends();
		case UsecasediagramPackage.USE_CASE__INCLUDES:
			return getIncludes();
		case UsecasediagramPackage.USE_CASE__NAME:
			return getName();
		case UsecasediagramPackage.USE_CASE__DYNAMIC_GOALS:
			return getDynamicGoals();
		case UsecasediagramPackage.USE_CASE__CONTEXT_REQUIREMENTS:
			return getContextRequirements();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE__EXTENDS:
			getExtends().clear();
			getExtends().addAll((Collection<? extends Extend>) newValue);
			return;
		case UsecasediagramPackage.USE_CASE__INCLUDES:
			getIncludes().clear();
			getIncludes().addAll((Collection<? extends Include>) newValue);
			return;
		case UsecasediagramPackage.USE_CASE__NAME:
			setName((String) newValue);
			return;
		case UsecasediagramPackage.USE_CASE__DYNAMIC_GOALS:
			getDynamicGoals().clear();
			getDynamicGoals().addAll((Collection<? extends DynamicGoalRef>) newValue);
			return;
		case UsecasediagramPackage.USE_CASE__CONTEXT_REQUIREMENTS:
			getContextRequirements().clear();
			getContextRequirements().addAll((Collection<? extends ContextRequirement>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE__EXTENDS:
			getExtends().clear();
			return;
		case UsecasediagramPackage.USE_CASE__INCLUDES:
			getIncludes().clear();
			return;
		case UsecasediagramPackage.USE_CASE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case UsecasediagramPackage.USE_CASE__DYNAMIC_GOALS:
			getDynamicGoals().clear();
			return;
		case UsecasediagramPackage.USE_CASE__CONTEXT_REQUIREMENTS:
			getContextRequirements().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE__EXTENDS:
			return extends_ != null && !extends_.isEmpty();
		case UsecasediagramPackage.USE_CASE__INCLUDES:
			return includes != null && !includes.isEmpty();
		case UsecasediagramPackage.USE_CASE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case UsecasediagramPackage.USE_CASE__DYNAMIC_GOALS:
			return dynamicGoals != null && !dynamicGoals.isEmpty();
		case UsecasediagramPackage.USE_CASE__CONTEXT_REQUIREMENTS:
			return contextRequirements != null && !contextRequirements.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //UseCaseImpl
