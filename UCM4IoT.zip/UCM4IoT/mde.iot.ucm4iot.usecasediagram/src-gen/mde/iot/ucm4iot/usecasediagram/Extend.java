/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extend</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Extend#getExtendedCase <em>Extended Case</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getExtend()
 * @model
 * @generated
 */
public interface Extend extends EObject {
	/**
	 * Returns the value of the '<em><b>Extended Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extended Case</em>' reference.
	 * @see #setExtendedCase(UseCase)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getExtend_ExtendedCase()
	 * @model
	 * @generated
	 */
	UseCase getExtendedCase();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Extend#getExtendedCase <em>Extended Case</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Extended Case</em>' reference.
	 * @see #getExtendedCase()
	 * @generated
	 */
	void setExtendedCase(UseCase value);

} // Extend
