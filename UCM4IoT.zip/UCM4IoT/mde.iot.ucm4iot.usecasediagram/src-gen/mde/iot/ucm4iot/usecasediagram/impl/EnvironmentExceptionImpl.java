/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import mde.iot.ucm4iot.usecasediagram.EnvironmentException;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Environment Exception</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EnvironmentExceptionImpl extends UCM4IoTExceptionImpl implements EnvironmentException {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EnvironmentExceptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.ENVIRONMENT_EXCEPTION;
	}

} //EnvironmentExceptionImpl
