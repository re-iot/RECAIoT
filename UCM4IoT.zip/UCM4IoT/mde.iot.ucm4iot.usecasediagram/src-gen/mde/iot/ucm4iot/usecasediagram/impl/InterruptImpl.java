/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import java.util.Collection;
import mde.iot.ucm4iot.usecasediagram.Interrupt;
import mde.iot.ucm4iot.usecasediagram.UCM4IoTException;
import mde.iot.ucm4iot.usecasediagram.UseCase;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interrupt</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptImpl#getInterruptedCase <em>Interrupted Case</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.InterruptImpl#getExceptions <em>Exceptions</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class InterruptImpl extends MinimalEObjectImpl.Container implements Interrupt {
	/**
	 * The cached value of the '{@link #getInterruptedCase() <em>Interrupted Case</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterruptedCase()
	 * @generated
	 * @ordered
	 */
	protected UseCase interruptedCase;

	/**
	 * The cached value of the '{@link #getExceptions() <em>Exceptions</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExceptions()
	 * @generated
	 * @ordered
	 */
	protected EList<UCM4IoTException> exceptions;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterruptImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.INTERRUPT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UseCase getInterruptedCase() {
		if (interruptedCase != null && interruptedCase.eIsProxy()) {
			InternalEObject oldInterruptedCase = (InternalEObject) interruptedCase;
			interruptedCase = (UseCase) eResolveProxy(oldInterruptedCase);
			if (interruptedCase != oldInterruptedCase) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							UsecasediagramPackage.INTERRUPT__INTERRUPTED_CASE, oldInterruptedCase, interruptedCase));
			}
		}
		return interruptedCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UseCase basicGetInterruptedCase() {
		return interruptedCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInterruptedCase(UseCase newInterruptedCase) {
		UseCase oldInterruptedCase = interruptedCase;
		interruptedCase = newInterruptedCase;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UsecasediagramPackage.INTERRUPT__INTERRUPTED_CASE,
					oldInterruptedCase, interruptedCase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UCM4IoTException> getExceptions() {
		if (exceptions == null) {
			exceptions = new EObjectResolvingEList<UCM4IoTException>(UCM4IoTException.class, this,
					UsecasediagramPackage.INTERRUPT__EXCEPTIONS);
		}
		return exceptions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UsecasediagramPackage.INTERRUPT__INTERRUPTED_CASE:
			if (resolve)
				return getInterruptedCase();
			return basicGetInterruptedCase();
		case UsecasediagramPackage.INTERRUPT__EXCEPTIONS:
			return getExceptions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UsecasediagramPackage.INTERRUPT__INTERRUPTED_CASE:
			setInterruptedCase((UseCase) newValue);
			return;
		case UsecasediagramPackage.INTERRUPT__EXCEPTIONS:
			getExceptions().clear();
			getExceptions().addAll((Collection<? extends UCM4IoTException>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.INTERRUPT__INTERRUPTED_CASE:
			setInterruptedCase((UseCase) null);
			return;
		case UsecasediagramPackage.INTERRUPT__EXCEPTIONS:
			getExceptions().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.INTERRUPT__INTERRUPTED_CASE:
			return interruptedCase != null;
		case UsecasediagramPackage.INTERRUPT__EXCEPTIONS:
			return exceptions != null && !exceptions.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //InterruptImpl
