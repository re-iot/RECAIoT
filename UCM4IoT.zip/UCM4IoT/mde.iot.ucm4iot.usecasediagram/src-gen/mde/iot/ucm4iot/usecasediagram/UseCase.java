/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Use Case</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCase#getExtends <em>Extends</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCase#getIncludes <em>Includes</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCase#getName <em>Name</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCase#getDynamicGoals <em>Dynamic Goals</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCase#getContextRequirements <em>Context Requirements</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCase()
 * @model abstract="true"
 * @generated
 */
public interface UseCase extends EObject {
	/**
	 * Returns the value of the '<em><b>Extends</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.Extend}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extends</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCase_Extends()
	 * @model containment="true"
	 * @generated
	 */
	EList<Extend> getExtends();

	/**
	 * Returns the value of the '<em><b>Includes</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.Include}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Includes</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCase_Includes()
	 * @model containment="true"
	 * @generated
	 */
	EList<Include> getIncludes();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCase_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.UseCase#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Dynamic Goals</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.DynamicGoalRef}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dynamic Goals</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCase_DynamicGoals()
	 * @model containment="true"
	 * @generated
	 */
	EList<DynamicGoalRef> getDynamicGoals();

	/**
	 * Returns the value of the '<em><b>Context Requirements</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.ContextRequirement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Context Requirements</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCase_ContextRequirements()
	 * @model containment="true"
	 * @generated
	 */
	EList<ContextRequirement> getContextRequirements();

} // UseCase
