/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Standard Use Case</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getStandardUseCase()
 * @model
 * @generated
 */
public interface StandardUseCase extends UseCase {
} // StandardUseCase
