/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Software Exception</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getSoftwareException()
 * @model
 * @generated
 */
public interface SoftwareException extends UCM4IoTException {
} // SoftwareException
