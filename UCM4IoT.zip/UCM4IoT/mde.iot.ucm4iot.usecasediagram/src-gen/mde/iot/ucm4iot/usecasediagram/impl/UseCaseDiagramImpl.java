/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import java.util.Collection;

import mde.iot.ucm4iot.usecasediagram.Actor;
import mde.iot.ucm4iot.usecasediagram.Scope;
import mde.iot.ucm4iot.usecasediagram.UseCaseDiagram;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Use Case Diagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseDiagramImpl#getScopes <em>Scopes</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.UseCaseDiagramImpl#getActors <em>Actors</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UseCaseDiagramImpl extends MinimalEObjectImpl.Container implements UseCaseDiagram {
	/**
	 * The cached value of the '{@link #getScopes() <em>Scopes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScopes()
	 * @generated
	 * @ordered
	 */
	protected EList<Scope> scopes;

	/**
	 * The cached value of the '{@link #getActors() <em>Actors</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActors()
	 * @generated
	 * @ordered
	 */
	protected EList<Actor> actors;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UseCaseDiagramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.USE_CASE_DIAGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Scope> getScopes() {
		if (scopes == null) {
			scopes = new EObjectContainmentEList<Scope>(Scope.class, this,
					UsecasediagramPackage.USE_CASE_DIAGRAM__SCOPES);
		}
		return scopes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Actor> getActors() {
		if (actors == null) {
			actors = new EObjectContainmentEList<Actor>(Actor.class, this,
					UsecasediagramPackage.USE_CASE_DIAGRAM__ACTORS);
		}
		return actors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE_DIAGRAM__SCOPES:
			return ((InternalEList<?>) getScopes()).basicRemove(otherEnd, msgs);
		case UsecasediagramPackage.USE_CASE_DIAGRAM__ACTORS:
			return ((InternalEList<?>) getActors()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE_DIAGRAM__SCOPES:
			return getScopes();
		case UsecasediagramPackage.USE_CASE_DIAGRAM__ACTORS:
			return getActors();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE_DIAGRAM__SCOPES:
			getScopes().clear();
			getScopes().addAll((Collection<? extends Scope>) newValue);
			return;
		case UsecasediagramPackage.USE_CASE_DIAGRAM__ACTORS:
			getActors().clear();
			getActors().addAll((Collection<? extends Actor>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE_DIAGRAM__SCOPES:
			getScopes().clear();
			return;
		case UsecasediagramPackage.USE_CASE_DIAGRAM__ACTORS:
			getActors().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.USE_CASE_DIAGRAM__SCOPES:
			return scopes != null && !scopes.isEmpty();
		case UsecasediagramPackage.USE_CASE_DIAGRAM__ACTORS:
			return actors != null && !actors.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //UseCaseDiagramImpl
