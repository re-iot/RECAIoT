/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interrupt And Fail</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInterruptAndFail()
 * @model
 * @generated
 */
public interface InterruptAndFail extends Interrupt {
} // InterruptAndFail
