/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import mde.iot.ucm4iot.usecasediagram.DeviceActor;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Device Actor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DeviceActorImpl extends PhysicalEntityActorImpl implements DeviceActor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeviceActorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.DEVICE_ACTOR;
	}

} //DeviceActorImpl
