/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Use Case Diagram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCaseDiagram#getScopes <em>Scopes</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.UseCaseDiagram#getActors <em>Actors</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCaseDiagram()
 * @model
 * @generated
 */
public interface UseCaseDiagram extends EObject {
	/**
	 * Returns the value of the '<em><b>Scopes</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.Scope}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scopes</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCaseDiagram_Scopes()
	 * @model containment="true"
	 * @generated
	 */
	EList<Scope> getScopes();

	/**
	 * Returns the value of the '<em><b>Actors</b></em>' containment reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.Actor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actors</em>' containment reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getUseCaseDiagram_Actors()
	 * @model containment="true"
	 * @generated
	 */
	EList<Actor> getActors();

} // UseCaseDiagram
