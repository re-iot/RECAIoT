/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import java.util.Collection;
import mde.iot.ucm4iot.usecasediagram.HandlerUseCase;
import mde.iot.ucm4iot.usecasediagram.Interrupt;
import mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Handler Use Case</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.impl.HandlerUseCaseImpl#getInterrupts <em>Interrupts</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HandlerUseCaseImpl extends UseCaseImpl implements HandlerUseCase {
	/**
	 * The cached value of the '{@link #getInterrupts() <em>Interrupts</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterrupts()
	 * @generated
	 * @ordered
	 */
	protected EList<Interrupt> interrupts;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HandlerUseCaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UsecasediagramPackage.Literals.HANDLER_USE_CASE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Interrupt> getInterrupts() {
		if (interrupts == null) {
			interrupts = new EObjectContainmentEList<Interrupt>(Interrupt.class, this,
					UsecasediagramPackage.HANDLER_USE_CASE__INTERRUPTS);
		}
		return interrupts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UsecasediagramPackage.HANDLER_USE_CASE__INTERRUPTS:
			return ((InternalEList<?>) getInterrupts()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UsecasediagramPackage.HANDLER_USE_CASE__INTERRUPTS:
			return getInterrupts();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UsecasediagramPackage.HANDLER_USE_CASE__INTERRUPTS:
			getInterrupts().clear();
			getInterrupts().addAll((Collection<? extends Interrupt>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.HANDLER_USE_CASE__INTERRUPTS:
			getInterrupts().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UsecasediagramPackage.HANDLER_USE_CASE__INTERRUPTS:
			return interrupts != null && !interrupts.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //HandlerUseCaseImpl
