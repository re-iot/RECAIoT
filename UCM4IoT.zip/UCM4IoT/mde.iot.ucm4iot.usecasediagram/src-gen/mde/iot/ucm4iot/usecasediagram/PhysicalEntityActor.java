/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Physical Entity Actor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getPhysicalEntityActor()
 * @model
 * @generated
 */
public interface PhysicalEntityActor extends Actor {
} // PhysicalEntityActor
