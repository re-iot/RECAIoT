/**
 */
package mde.iot.ucm4iot.usecasediagram.impl;

import mde.iot.ucm4iot.usecasediagram.*;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class UsecasediagramFactoryImpl extends EFactoryImpl implements UsecasediagramFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static UsecasediagramFactory init() {
		try {
			UsecasediagramFactory theUsecasediagramFactory = (UsecasediagramFactory) EPackage.Registry.INSTANCE
					.getEFactory(UsecasediagramPackage.eNS_URI);
			if (theUsecasediagramFactory != null) {
				return theUsecasediagramFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new UsecasediagramFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UsecasediagramFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case UsecasediagramPackage.HUMAN_ACTOR:
			return createHumanActor();
		case UsecasediagramPackage.SOFTWARE_ACTOR:
			return createSoftwareActor();
		case UsecasediagramPackage.DEVICE_ACTOR:
			return createDeviceActor();
		case UsecasediagramPackage.PHYSICAL_ENTITY_ACTOR:
			return createPhysicalEntityActor();
		case UsecasediagramPackage.ACTOR:
			return createActor();
		case UsecasediagramPackage.INCLUDE:
			return createInclude();
		case UsecasediagramPackage.SCOPE:
			return createScope();
		case UsecasediagramPackage.EXTEND:
			return createExtend();
		case UsecasediagramPackage.USE_CASE_DIAGRAM:
			return createUseCaseDiagram();
		case UsecasediagramPackage.HANDLER_USE_CASE:
			return createHandlerUseCase();
		case UsecasediagramPackage.STANDARD_USE_CASE:
			return createStandardUseCase();
		case UsecasediagramPackage.INTERRUPT_AND_FAIL:
			return createInterruptAndFail();
		case UsecasediagramPackage.INTERRUPT_AND_CONTINUE:
			return createInterruptAndContinue();
		case UsecasediagramPackage.HARDWARE_EXCEPTION:
			return createHardwareException();
		case UsecasediagramPackage.SOFTWARE_EXCEPTION:
			return createSoftwareException();
		case UsecasediagramPackage.ENVIRONMENT_EXCEPTION:
			return createEnvironmentException();
		case UsecasediagramPackage.NETWORK_EXCEPTION:
			return createNetworkException();
		case UsecasediagramPackage.DYNAMIC_GOAL_REF:
			return createDynamicGoalRef();
		case UsecasediagramPackage.CONTEXT_REQUIREMENT:
			return createContextRequirement();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HumanActor createHumanActor() {
		HumanActorImpl humanActor = new HumanActorImpl();
		return humanActor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SoftwareActor createSoftwareActor() {
		SoftwareActorImpl softwareActor = new SoftwareActorImpl();
		return softwareActor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeviceActor createDeviceActor() {
		DeviceActorImpl deviceActor = new DeviceActorImpl();
		return deviceActor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PhysicalEntityActor createPhysicalEntityActor() {
		PhysicalEntityActorImpl physicalEntityActor = new PhysicalEntityActorImpl();
		return physicalEntityActor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actor createActor() {
		ActorImpl actor = new ActorImpl();
		return actor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Include createInclude() {
		IncludeImpl include = new IncludeImpl();
		return include;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Scope createScope() {
		ScopeImpl scope = new ScopeImpl();
		return scope;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Extend createExtend() {
		ExtendImpl extend = new ExtendImpl();
		return extend;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UseCaseDiagram createUseCaseDiagram() {
		UseCaseDiagramImpl useCaseDiagram = new UseCaseDiagramImpl();
		return useCaseDiagram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HandlerUseCase createHandlerUseCase() {
		HandlerUseCaseImpl handlerUseCase = new HandlerUseCaseImpl();
		return handlerUseCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StandardUseCase createStandardUseCase() {
		StandardUseCaseImpl standardUseCase = new StandardUseCaseImpl();
		return standardUseCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterruptAndFail createInterruptAndFail() {
		InterruptAndFailImpl interruptAndFail = new InterruptAndFailImpl();
		return interruptAndFail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterruptAndContinue createInterruptAndContinue() {
		InterruptAndContinueImpl interruptAndContinue = new InterruptAndContinueImpl();
		return interruptAndContinue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HardwareException createHardwareException() {
		HardwareExceptionImpl hardwareException = new HardwareExceptionImpl();
		return hardwareException;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SoftwareException createSoftwareException() {
		SoftwareExceptionImpl softwareException = new SoftwareExceptionImpl();
		return softwareException;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnvironmentException createEnvironmentException() {
		EnvironmentExceptionImpl environmentException = new EnvironmentExceptionImpl();
		return environmentException;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkException createNetworkException() {
		NetworkExceptionImpl networkException = new NetworkExceptionImpl();
		return networkException;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DynamicGoalRef createDynamicGoalRef() {
		DynamicGoalRefImpl dynamicGoalRef = new DynamicGoalRefImpl();
		return dynamicGoalRef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContextRequirement createContextRequirement() {
		ContextRequirementImpl contextRequirement = new ContextRequirementImpl();
		return contextRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UsecasediagramPackage getUsecasediagramPackage() {
		return (UsecasediagramPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static UsecasediagramPackage getPackage() {
		return UsecasediagramPackage.eINSTANCE;
	}

} //UsecasediagramFactoryImpl
