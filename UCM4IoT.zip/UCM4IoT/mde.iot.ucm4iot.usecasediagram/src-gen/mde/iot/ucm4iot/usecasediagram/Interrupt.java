/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interrupt</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Interrupt#getInterruptedCase <em>Interrupted Case</em>}</li>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.Interrupt#getExceptions <em>Exceptions</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInterrupt()
 * @model abstract="true"
 * @generated
 */
public interface Interrupt extends EObject {
	/**
	 * Returns the value of the '<em><b>Interrupted Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interrupted Case</em>' reference.
	 * @see #setInterruptedCase(UseCase)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInterrupt_InterruptedCase()
	 * @model required="true"
	 * @generated
	 */
	UseCase getInterruptedCase();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.Interrupt#getInterruptedCase <em>Interrupted Case</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interrupted Case</em>' reference.
	 * @see #getInterruptedCase()
	 * @generated
	 */
	void setInterruptedCase(UseCase value);

	/**
	 * Returns the value of the '<em><b>Exceptions</b></em>' reference list.
	 * The list contents are of type {@link mde.iot.ucm4iot.usecasediagram.UCM4IoTException}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exceptions</em>' reference list.
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInterrupt_Exceptions()
	 * @model required="true"
	 * @generated
	 */
	EList<UCM4IoTException> getExceptions();

} // Interrupt
