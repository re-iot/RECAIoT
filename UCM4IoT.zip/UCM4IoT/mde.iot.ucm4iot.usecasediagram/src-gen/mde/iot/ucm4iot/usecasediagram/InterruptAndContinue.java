/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interrupt And Continue</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getInterruptAndContinue()
 * @model
 * @generated
 */
public interface InterruptAndContinue extends Interrupt {
} // InterruptAndContinue
