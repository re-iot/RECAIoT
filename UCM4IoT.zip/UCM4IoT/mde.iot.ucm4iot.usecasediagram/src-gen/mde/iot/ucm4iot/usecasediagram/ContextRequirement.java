/**
 */
package mde.iot.ucm4iot.usecasediagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Context Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mde.iot.ucm4iot.usecasediagram.ContextRequirement#getId <em>Id</em>}</li>
 * </ul>
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getContextRequirement()
 * @model
 * @generated
 */
public interface ContextRequirement extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getContextRequirement_Id()
	 * @model
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link mde.iot.ucm4iot.usecasediagram.ContextRequirement#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

} // ContextRequirement
