/**
 */
package mde.iot.ucm4iot.usecasediagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Environment Exception</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mde.iot.ucm4iot.usecasediagram.UsecasediagramPackage#getEnvironmentException()
 * @model
 * @generated
 */
public interface EnvironmentException extends UCM4IoTException {
} // EnvironmentException
