package mde.iot.ucm4iot.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

/**
 * Interface: IUcm4iotGenerator
 * ----------------------------
 * Interface for Ucm4iot Generators.
 */
interface IUcm4iotGenerator {
	// Generator interface.
	def void generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context);
	def void generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder);
	
	// File creation interface.
	def String createFileName(String name, String ext);
	def void createFile(IFileSystemAccess2 fsa, String path, String file, String data);
}
