package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.Collections
import java.util.HashMap
import java.util.HashSet
import java.util.List
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.InteractionStep
import mde.iot.ucm4iot.ucm4iot.InternalStep
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.OutcomeEndings
import mde.iot.ucm4iot.ucm4iot.OutcomeEnds
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.Step
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

/**
 * Class: ExceptionSummaryTableGenerator
 * -------------------------------------
 * Generates Exception Summary Table.
 */
class ExceptionSummaryTableGenerator extends IUcm4iotGeneratorImpl {
	
	/**
	 * generate(..)
	 * ------------
	 * Generates the exception summary table for all exceptions found within a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	/**
	 * generate(..)
	 * ------------
	 * Generates the exception summary table for all exceptions found within a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		val useCases = StreamSupport.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
  			.collect(Collectors.toList());
		
		val exceptions = StreamSupport.stream(resource.allContents.toIterable.filter(Exception).spliterator(), false)
  			.collect(Collectors.toList());
  		
  		var table = generateTable(useCases, exceptions);
  		createFile(fsa, folder, createFileName("exceptionSummaryTable", ".txt"), table);
	}
	
	/**
	 * generateTable(..)
	 * -----------------
	 * Generates the exception summary table.
	 */
	protected def String generateTable(List<UseCase> useCases, List<Exception> exceptions) {
		var exceptionInfo = new HashMap<Exception, HashMap<String, ArrayList<String>>>();
		
		// Finds information about each exception.
		for (ctx : exceptions) {
			var table = new HashMap<String, ArrayList<String>>();
			table.put('type',       new ArrayList<String>());
			table.put('sources',    new ArrayList<String>());
			table.put('actors',     new ArrayList<String>());
			table.put('handlers',   new ArrayList<String>());
			table.put('interrupts', new ArrayList<String>());
			table.put('paths',      new ArrayList<String>());
			
			// Gets information about the exception.
			getExceptionType(ctx, table);
			getSources      (ctx, table, useCases);
			getActors       (ctx, table, useCases);
			getHandlers     (ctx, table, useCases);
			getInterruptType(ctx, table, useCases);
			getPaths        (ctx, table, useCases);
			getGlobalPaths  (ctx, table, useCases);
			
			exceptionInfo.put(ctx, table);
		}
		
		return createExceptionSummaryTable(exceptions, exceptionInfo);
	}
	
	/**
	 * getExceptionType(..)
	 * --------------------
	 * Gets the type of the exception.
	 */
	protected def void getExceptionType(Exception ctx, HashMap<String, ArrayList<String>> table) {
		table.get('type').add(formatExceptionType(ctx));
	}
	
	/**
	 * getSources(..)
	 * --------------
	 * Get the use cases that raise the exception.
	 */
	protected def void getSources(Exception ctx, HashMap<String, ArrayList<String>> table, List<UseCase> useCases) {
		for (useCase : getUseCasesRaisingException(ctx, useCases)) {
			table.get('sources').add(useCase.name);
		}
	}
	
	/**
	 * getActors(..)
	 * -------------
	 * Get the actors that participate in the raising of the exception.
	 */
	protected def void getActors(Exception ctx, HashMap<String, ArrayList<String>> table, List<UseCase> useCases) {
		var foundActors = newArrayList;
		
		// Search for actors in use cases that raise the exception.
		for (useCase : getUseCasesRaisingException(ctx, useCases)) {
			var possibleActors = EcoreUtil2.getAllContentsOfType(useCase, Actor);
			
			// Recursively searches for actors from each exception step.
			for (step : getStepsRaisingException(ctx, useCase)) {
				var block = EcoreUtil2.getContainerOfType(step, ExtensionBlock);
				foundActors.addAll(getActors(ctx, block, possibleActors));
			}
		}
		
		// Collect unique actors.
		var formattedActors = foundActors.stream()
			.map([actor | formatActorName(actor)])
			.distinct()
			.collect(Collectors.toList());
		
		table.get('actors').addAll(formattedActors);
	}
	
	/**
	 * getActors(..)
	 * -------------
	 * Gets the actors that participate in the raising of the exception.
	 */
	private def getActors(Exception ctx, ExtensionBlock block, List<Actor> possibleActors) {
		var actors = newArrayList;
		
		// Recursively finds all references to actors in the use case.
		getActorsHelper(ctx, block.steps, possibleActors, actors);
		return actors.stream()
			.distinct()
			.collect(Collectors.toList());
	}
	
	/**
	 * getActorsHelper(..)
	 * -------------------
	 * Helper function to recursively search for actors.
	 */
	private def void getActorsHelper(Exception ctx, List<Step> steps, List<Actor> possibleActors, List<Actor> actors) {
		if (steps.size == 0) return;
		
		// Filter for steps to check that may include an actor that participated in the exception being raised.
		var candidateSteps = steps.stream()
			.filter([step | step instanceof InteractionStep || step instanceof InternalStep])
			.filter([step | !step.ignoreDescription])
			.collect(Collectors.toList());
		
		// Finds actors in the given list of steps.
		for (step : candidateSteps) {
			var foundActors = possibleActors.stream()
				.filter([actor | hasWord(step, actor.name)])
				.collect(Collectors.toList());
				
			actors.addAll(foundActors);
		}
		
		// Recursively search upwards to the parent block.
		var block = EcoreUtil2.getContainerOfType(steps.get(0), ExtensionBlock);
		if (block !== null) {
			var parentSteps = getParentSteps(block);
			getActorsHelper(ctx, parentSteps, possibleActors, actors);
		}
	}
	
	/**
	 * hasWord(..)
	 * -----------
	 * Returns true if a step has the passed word; false otherwise.
	 */
	private def boolean hasWord(Step step, String value) {
		var description = step.getDescription();
		if (description === null) {
			description = "";
		}
		
		var words = description
				.replaceAll("[^a-zA-Z0-9]", " ")
				.split("\\s+");
		
		// Check if any words match the passed String.
		for (String word : words) {
			if (value.equals(word)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * getHandlers(..)
	 * ---------------
	 * Get the handlers that handle the exception.
	 */
	protected def void getHandlers(Exception ctx, HashMap<String, ArrayList<String>> table, List<UseCase> useCases) {
		for (handler : getHandlers(useCases, ctx)) {
			table.get('handlers').add('{' + handler.name + '}');
		}
	}
	
	/**
	 * getInterruptType(..)
	 * --------------------
	 * Gets how the exception interrupts the system.
	 */
	protected def void getInterruptType(Exception ctx, HashMap<String, ArrayList<String>> table, List<UseCase> useCases) {
		var interrupts = newArrayList;
		
		// For every occurrence of the exception, determine the interrupt type.
		for (useCase : getUseCasesRaisingException(ctx, useCases)) {
			for (step : getStepsRaisingException(ctx, useCase)) {
				interrupts.add(getInterruptType(step));
			}
		}
		
		// Collect only unique values.
		var interruptTypes = interrupts.stream()
			.distinct()
			.collect(Collectors.toList());
		
		// Expecting only one interrupt type.
		if (interruptTypes.size() == 1) {
			table.get('interrupts').add(interruptTypes.get(0));
		} else if (interruptTypes.size() > 1) {
			val x = interrupts.stream().filter([type | type == "Interrupt and Continue"]).count();
			val y = interrupts.stream().filter([type | type == "Interrupt and Fail"]).count();
			val z = interrupts.stream().filter([type | type == "Cannot be Determined"]).count();
			
			table.get('interrupts').add('Interrupt and Continue (' + x + ')');
			table.get('interrupts').add('Interrupt and Fail ('      + y + ')');
			
			if (z > 0) {
				table.get('interrupts').add('Cannot be Determined (' + z + ')');
			}
		} else {
			table.get('interrupts').add('Error');
		}
	}
	
	/**
	 * getInterruptType(..)
	 * --------------------
	 * Gets how the exception interrupts the system.
	 */
	protected def getInterruptType(ExceptionStep step) {
		var block = EcoreUtil2.getContainerOfType(step, ExtensionBlock);
				
		// If outcome continues, then interrupt and continues; otherwise, if outcome fails, then interrupt and fail.
		if (block.outcome instanceof OutcomeContinues) {
			return 'Interrupt and Continue';
		} else {
			var outcome = block.outcome as OutcomeEnds;
			
			if (outcome.type == OutcomeEndings.FAILURE) {
				return 'Interrupt and Fail';
			} else {
				return 'Cannot be Determined';
			}
		}
	}
	
	/**
	 * getPath(..)
	 * -----------
	 * Get the paths that lead to the exception being raised, and handled.
	 */
	protected def void getPaths(Exception ctx, HashMap<String, ArrayList<String>> table, List<UseCase> useCases) {
		if (isGlobalException(ctx)) return;
		
		// Determine all paths that lead to this exception being raised.
		for (useCase : getUseCasesRaisingException(ctx, useCases)) {
			var handlers = getHandlers(useCases, useCase, ctx);
			var paths = getPaths(useCases, useCase);
			
			// Add a null value if there are no handlers.
			if (handlers.isEmpty()) {
				handlers.add(null);
			}
			
			// For each handler, print the possible handler paths.
			for (handler : handlers) {
				for (path : paths) {
					table.get('paths').add(formatPath(path, ctx, handler));
				}
			}
		} // for (usecase)
	} // getPaths(..)
	
	/**
	 * getGlobalPaths(..)
	 * ------------------
	 * Determine where global exceptions can be raised.
	 */
	protected def void getGlobalPaths(Exception ctx, HashMap<String, ArrayList<String>> table, List<UseCase> useCases) {
		if (!isGlobalException(ctx)) return;
		
		// Determine all locations a global exception can be raised.
		for (useCase : getUseCasesRaisingException(ctx, useCases)) {
			var handlers = getHandlers(useCases, useCase, ctx);
			var paths = getInvocationPaths(useCases, useCase);
			
			// Add a null value if there are no handlers.
			if (handlers.isEmpty()) {
				handlers.add(null);
			}
			
			// Find unique invoked use cases.
			var globalUseCases = paths.stream()
				.flatMap([path | path.stream()])
				.distinct()
				.collect(Collectors.toList());
			
			// For each handler, print the possible handler paths.
			for (handler : handlers) {
				for (globalUseCase : globalUseCases) {
					table.get('paths').add(formatGlobalPath(useCase, globalUseCase, ctx, handler));
				}
			}
		} // for (usecase)
	} // getGlobalPaths(..)
	
	/**
	 * getPaths(..)
	 * ------------
	 * Gets the paths that lead to this use case being called.
	 */
	protected def getPaths(List<UseCase> useCases, UseCase ctx) {
		var paths = newArrayList;
		getPathsHelper(useCases, ctx, paths, new ArrayList<UseCase>(), new HashSet<UseCase>());
		return paths;
	}
	
	/**
	 * getPathsHelper(..)
	 * ------------------
	 * Helper function that recursively searches for paths that lead to the passed use case.
	 */
	private def void getPathsHelper(List<UseCase> useCases, UseCase ctx, List<List<UseCase>> paths, List<UseCase> currentPath, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			paths.add(new ArrayList<UseCase>(currentPath));
			return;
		}
		
		visited.add(ctx);
		currentPath.add(ctx);
		
		// Find next use cases to traverse to.
		var parents = getParents(useCases, ctx);
		
		// Add the current path to the list of paths.
		if (parents.isEmpty()) {
			paths.add(new ArrayList<UseCase>(currentPath));
		}
		
		// Traverse upwards towards the use case that invokes the current use case.
		for (parent : parents) {
			getPathsHelper(useCases, parent, paths, currentPath, visited);
		}
		
		currentPath.remove(ctx);
		visited.remove(ctx);
	}
	
	/**
	 * getInvocationPaths(..)
	 * ----------------------
	 * Gets the paths of the invoked use cases.
	 */
	protected def getInvocationPaths(List<UseCase> useCases, UseCase ctx) {
		var paths = newArrayList;
		getInvocationPathsHelper(useCases, ctx, paths, new ArrayList<UseCase>(), new HashSet<UseCase>());
		return paths;
	}
	
	/**
	 * getInvocationPathsHelper(..)
	 * ----------------------------
	 * Helper function that recursively searches for invoked paths from the passed use case.
	 */
	private def void getInvocationPathsHelper(List<UseCase> useCases, UseCase ctx, List<List<UseCase>> paths, List<UseCase> currentPath, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			paths.add(new ArrayList<UseCase>(currentPath));
			return;
		}
		
		visited.add(ctx);
		currentPath.add(ctx);
		
		// Find next use cases to traverse to.
		var children = getChildren(ctx);
		
		// Add the current path to the list of paths.
		if (children.isEmpty()) {
			paths.add(new ArrayList<UseCase>(currentPath));
		}
		
		// Traverse downwards to the invoked use case in the current use case.
		for (child : children) {
			getInvocationPathsHelper(useCases, child, paths, currentPath, visited);
		}
		
		currentPath.remove(ctx);
		visited.remove(ctx);
	}
	
	/**
	 * formatPath(..)
	 * --------------
	 * Formats the given path.
	 */
	protected def formatPath(List<UseCase> path, Exception exception, HandlerUseCase handler) {
		var builder = new StringBuilder();
		
		// Reverse the given path to obtain the real path.
		var realPath = new ArrayList<UseCase>(path);
		var UseCase last = null;
		Collections.reverse(realPath);
		
		// Build the path.
		for (useCase : realPath) {
			builder.append(useCase.name + ' >> ');
			last = useCase;
		}
		
		var interrupts = newArrayList;
		for (step : getStepsRaisingException(exception, last)) {
			interrupts.add(getInterruptType(step));
		}
		
		// Formats the handler path.
		if (handler === null) {
			builder.append('{ ~ }');
		} else {
			builder.append('{' + handler.name + '}');
		}
		
		// Appends the interrupt type.
		if (interrupts.stream().distinct().count() == 1) {
			if (interrupts.get(0) == "Interrupt and Continue") {
				builder.append(' !I&C');
			} else if (interrupts.get(0) == "Interrupt and Fail") {
				builder.append(' !I&F');
			}
		}
		
		return builder.toString();
	}
	
	/**
	 * formatGlobalPath(..)
	 * --------------------
	 * Formats a global path.
	 */
	protected def formatGlobalPath(UseCase source, UseCase ctx, Exception exception, HandlerUseCase handler) {
		var interrupts = newArrayList;
		for (step : getStepsRaisingException(exception, source)) {
			interrupts.add(getInterruptType(step));
		}
		
		var String interruptType = '';
		
		// Appends the interrupt type.
		if (interrupts.stream().distinct().count() == 1) {
			if (interrupts.get(0) == "Interrupt and Continue") {
				interruptType = ' !I&C';
			} else if (interrupts.get(0) == "Interrupt and Fail") {
				interruptType = ' !I&F';
			}
		}
		
		if (source === ctx) {
			return ctx.name + ' >> {' + handler.name + '}' + interruptType;
		} else {
			return 'GLOBAL::' + ctx.name + ' >> {' + handler.name + '}' + interruptType;
		}
	}
	
	/**
	 * isGlobalException(..)
	 * ---------------------
	 * Returns true if the passed exception is a global exception.
	 */
	protected def boolean isGlobalException(Exception ctx) {
		return ctx.isGlobal;
	}
	
	/**
	 * getChildren(..)
	 * ---------------
	 * Returns a list of use cases that are invoked by the passed use case.
	 */
	protected def getChildren(UseCase useCase) {
		return EcoreUtil2.getAllContentsOfType(useCase, InvocationStep).stream()
			.map([step | step.invokedUseCase])
			.collect(Collectors.toList());
	}
	
	/**
	 * getParents(..)
	 * --------------
	 * Returns a list of use cases that invoke the passed use case.
	 */
	protected def getParents(List<UseCase> useCases, UseCase invokedUseCase) {
		var parentUseCases = newArrayList;
		
		// Checks which use cases invoke the passed use case.
		for (useCase : useCases) {
			var hasInvokedUseCase = EcoreUtil2.getAllContentsOfType(useCase, InvocationStep).stream
				.anyMatch([step | step.invokedUseCase === invokedUseCase]);
				
			if (hasInvokedUseCase) {
				parentUseCases.add(useCase)
			}
		}
		
		return parentUseCases;
	}
	
	/**
	 * getUseCasesRaisingException(..)
	 * -------------------------------
	 * Get the use cases that raise the exception.
	 */
	protected def getUseCasesRaisingException(Exception exception, List<UseCase> useCases) {
		var sourceUseCases = newArrayList;
		
		// Checks which use cases raise an exception.
		for (useCase : useCases) {
			var useCaseExceptions = EcoreUtil2.getAllContentsOfType(useCase, ExceptionStep).stream()
				.map([step | step.refException])
				.collect(Collectors.toList());
			
			// If the passed exception is found in this use case, then add this use case to the table.
			if (useCaseExceptions.contains(exception)) {
				sourceUseCases.add(useCase);
			}
		}
		
		return sourceUseCases;
	}
	
	/**
	 * getStepsRaisingException(..)
	 * ----------------------------
	 * Gets the steps that raise an exception.
	 */
	protected def getStepsRaisingException(Exception exception, UseCase useCase) {
		return EcoreUtil2.getAllContentsOfType(useCase, ExceptionStep).stream
			.filter([step | step.refException === exception])
			.collect(Collectors.toList());
	}
	
	/**
	 * getHandlers(..)
	 * ---------------
	 * Returns a list of use cases that handle the passed use case and exception.
	 */
	protected def getHandlers(List<UseCase> useCases, Exception exception) {
		var exceptionHandlers = newArrayList;
		
		var handlers = useCases.stream()
			.filter([uc | uc instanceof HandlerUseCase])
			.map   ([uc | uc as         HandlerUseCase])
			.collect(Collectors.toList());
		
		// Checks which handlers handle the passed exception.
		for (handler : handlers) {
			var handlesException = handler.contextExceptions.stream()
				.anyMatch([cx | cx.exception === exception]);
			
			if (handlesException) {
				exceptionHandlers.add(handler);
			}
		}
		
		return exceptionHandlers;
	}
	
	/**
	 * getHandlers(..)
	 * ---------------
	 * Returns a list of use cases that handle the passed use case and exception.
	 */
	protected def getHandlers(List<UseCase> useCases, UseCase context, Exception exception) {
		var exceptionHandlers = newArrayList;
		
		var handlers = useCases.stream()
			.filter([uc | uc instanceof HandlerUseCase])
			.map   ([uc | uc as         HandlerUseCase])
			.collect(Collectors.toList());
		
		// Checks which handlers handle the passed exception and context.
		for (handler : handlers) {
			var handlesException = handler.contextExceptions.stream()
				.anyMatch([cx | cx.context === context && cx.exception === exception]);
			
			if (handlesException) {
				exceptionHandlers.add(handler);
			}
		}
		
		return exceptionHandlers;
	}
	
	/**
	 * getParentSteps(..)
	 * ------------------
	 * Returns a list of steps that are the context of an extension block.
	 */
	protected def getParentSteps(ExtensionBlock block) {
		var parentSteps = newArrayList;
		
		// Find all steps in the parent.
		var steps = newArrayList;
		
		var parent = block.eContainer();
		if (parent instanceof ExtensionBlock) {
			steps.addAll((parent as ExtensionBlock).steps);
		} else {
			var main = EcoreUtil2.getContainerOfType(block, UseCase).main;
			steps.addAll(main.steps);
		}
		
		// Search for steps that are the parent step.
		var start = steps.indexOf(block.refStep);
		var end   = start + 1;
		
		if (block.hasRangedRef) {
			end = steps.indexOf(block.endRefStep) + 1;
		}
		
		parentSteps.addAll(steps.subList(start, end));
		return parentSteps;
	}
	
	/**
	 * getActorNameAndType(..)
	 * -----------------------
	 * Formats the name of the passed actor.
	 */
	protected def String formatActorName(Actor actor) {
		var actorFormat = '%s::%s';
		
		if (actor instanceof DeviceActor) {
			return String.format(actorFormat, 'DEVICE', actor.name);
		} else if (actor instanceof PhysicalEntityActor) {
			return String.format(actorFormat, 'PHYSICAL_ENTITY', actor.name);
		} else if (actor instanceof SoftwareActor) {
			return String.format(actorFormat, 'SOFTWARE', actor.name);
		} else {
			return String.format(actorFormat, 'HUMAN', actor.name);
		}
	}
	
	/**
	 * formatExceptionType(..)
	 * -----------------------
	 * Formats the type of the passed exception.
	 */
	protected def String formatExceptionType(Exception exception) {
		var exceptionFormat = "%s";
		
		if (exception instanceof HardwareException) {
			return String.format(exceptionFormat, 'HARDWARE_EXCEPTION');
		} else if (exception instanceof SoftwareException) {
			return String.format(exceptionFormat, 'SOFTWARE_EXCEPTION');
		} else if (exception instanceof NetworkException) {
			return String.format(exceptionFormat, 'NETWORK_EXCEPTION');
		} else {
			return String.format(exceptionFormat, 'ENVIRONMENT_EXCEPTION');
		}
	}
	
	/**
	 * createExceptionTable(..)
	 * ------------------------
	 * Creates the table.
	 */
	protected def String createExceptionSummaryTable(List<Exception> exceptions, HashMap<Exception, HashMap<String, ArrayList<String>>> exceptionInfo) {
		var rows = newArrayList;
		
		// Function to convert values from the exceptionInfo hash map into a list of strings. 
		val tableToColumn = [String columnName | 
			[ HashMap<String, ArrayList<String>> table | 
				return table.get(columnName).toList();
			]
		];
		
		// Creates the format of the table.
		var columnNames = #["Exception Type", "Exception Name", "Exception Source", "Associated Actors", "Handler", "Interrupt Type", "Path"];
		var columns = #[
			fitColumnWidth(columnNames.get(0), 5, exceptionInfo, tableToColumn.apply('type')),
			fitColumnWidth(columnNames.get(1), 5, exceptions.stream().map([ex | ex.name]).collect(Collectors.toList())),
			fitColumnWidth(columnNames.get(2), 5, exceptionInfo, tableToColumn.apply('sources')),
			fitColumnWidth(columnNames.get(3), 5, exceptionInfo, tableToColumn.apply('actors')),
			fitColumnWidth(columnNames.get(4), 5, exceptionInfo, tableToColumn.apply('handlers')),
			fitColumnWidth(columnNames.get(5), 5, exceptionInfo, tableToColumn.apply('interrupts')),
			fitColumnWidth(columnNames.get(6), 4, exceptionInfo, tableToColumn.apply('paths'))
		];
		
		// Creates the format of the body of the table.
		var format = createTableFormat(columns);
		var line = String.format(format, "", "", "", "", "", "", "").replace(" ", "-").replace("|", "+");
		var partialLine = String.format(line
			.replaceFirst("-+", String.format("%%-%ds", columns.get(0)))
			.replaceFirst("\\+", "|"), ""
		);
		
		
		// Starts filling in the headers of the table.
		rows += line;
		rows += String.format(format,
			" " + columnNames.get(0),
			" " + columnNames.get(1), 
			" " + columnNames.get(2),
			" " + columnNames.get(3),
			" " + columnNames.get(4),
			" " + columnNames.get(5),
			" " + columnNames.get(6)
		);
		rows += line;
		
		// List out the results from the table.
		for (exceptionType : getExceptionTypes(exceptionInfo)) {
			var exceptionTypeStarted = false;
			
			// Prints out data related to each exception.
			for (exception : exceptions) {
				var table = exceptionInfo.get(exception);
				var type       = table.get('type').get(0);
				var sources    = table.get('sources');
				var actors     = table.get('actors');
				var handlers   = table.get('handlers');
				var interrupts = table.get('interrupts');
				var paths      = table.get('paths');
				
				// Print exception data for the current exception type group.
				if (exceptionType.equals(type)) {
					// If algorithm has not printed the exception type yet, then print it.
					var rowData = #[#[exceptionType], #[exception.name], sources, actors, handlers, interrupts, paths];
					if (exceptionTypeStarted) {
						rowData = #[#[""], #[exception.name], sources, actors, handlers, interrupts, paths];
					}
					
					// Leaves empty space when no data is found in a particular column.
					val n = maxSize(rowData);
					for (var i = 0; i < n; i++) {
						rows += String.format(format, getDataOrDefault(i, rowData));
					}
					
					rows += partialLine;
					exceptionTypeStarted = true;
				}
			} // for (exception..)
			
			// Replace the last line if the exception type was printed.
			if (exceptionTypeStarted) {
				rows.remove(rows.size - 1);
				rows += line;
			}
		}
		
		return String.join("\n", rows);
	}
	
	/**
	 * getExceptionTypes(..)
	 * ---------------------
	 * List the exception types found in exceptionInfo
	 */
	private def getExceptionTypes(HashMap<Exception, HashMap<String, ArrayList<String>>> exceptionInfo) {
		return exceptionInfo.values.stream().map([table | table.get('type')])
			.flatMap([list | list.stream()])
			.distinct()
			.sorted()
			.collect(Collectors.toList())
	}
}
