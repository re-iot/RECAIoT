package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import java.util.stream.Collectors
import java.util.stream.Stream
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.Ucm4iotUtilities
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

/**
 * Class: HandlerTableGenerator
 * ----------------------------
 * Generates Handler Summary Tables.
 */
class HandlerTableGenerator extends IUcm4iotGeneratorImpl {

	/**
	 * generate(..)
	 * ------------
	 * Generates handler tables for all use cases within a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}

	/**
	 * generate(..)
	 * ------------
	 * Generates handler tables for all use cases within a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		var handlers = StreamSupport.stream(resource.allContents.toIterable.filter(HandlerUseCase).spliterator(), false)
  			.collect(Collectors.toList());
		
	  	var table = generateTable(handlers);
  		createFile(fsa, folder, createFileName("handlerTable", ".txt"), table);
	}
	
	/**
	 * generateTable(..)
	 * -----------------
	 * Generates the handler summary table.
	 */
	protected def String generateTable(List<HandlerUseCase> handlers) {
		var handlerInfo = new HashMap<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>>();
		var dependents = new HashMap<HandlerUseCase, List<UseCase>>();
		
		// Finds information about each handler.
		for (ctx : handlers) {
			var depUseCases = getDependentUseCases(ctx);
			
			// Creates the table.
			var table = new HashMap<UseCase, HashMap<String, ArrayList<String>>>();
			for (useCase : depUseCases) {			
				var hashmap = new HashMap<String, ArrayList<String>>();
				hashmap.put('handled_exceptions',   new ArrayList<String>());
				hashmap.put('unhandled_exceptions', new ArrayList<String>());
				hashmap.put('actors',               new ArrayList<String>());
				
				table.put(useCase, hashmap);
			}
			
			// Get information about the handler.
			getHandledExceptions  (ctx, depUseCases, table);
			getUnhandledExceptions(ctx, depUseCases, table);
			getActors             (ctx, depUseCases, table);
			
			handlerInfo.put(ctx, table);
			dependents.put(ctx, depUseCases);
		}
		
		return createHandlerTable(handlers, dependents, handlerInfo);
	}
	
	/**
	 * getDependentUseCases(..)
	 * ------------------------
	 * Get the use cases that are dependent on the passed handler.
	 */
	protected def List<UseCase> getDependentUseCases(HandlerUseCase ctx) {
		return ctx.contextExceptions.stream()
			.map([ce | ce.context])
			.distinct()
			.collect(Collectors.toList());
	}
	
	/**
	 * getHandledExceptions(..)
	 * ------------------------
	 * Gets all handled exceptions.
	 */
	protected def void getHandledExceptions(HandlerUseCase ctx, List<UseCase> depUseCases, HashMap<UseCase, HashMap<String, ArrayList<String>>> table) {
		for (useCase : depUseCases) {
			var exceptions = ctx.contextExceptions.stream()
				.filter([ce | ce.context === useCase])
				.map([ce | formatExceptionName(ce.exception)])
				.collect(Collectors.toList());
			
			table.get(useCase).get('handled_exceptions').addAll(exceptions);
		}
	}
	
	/**
	 * getUnhandledExceptions(..)
	 * --------------------------
	 * Gets all exceptions from the dependent use cases that are not handled.
	 */
	protected def void getUnhandledExceptions(HandlerUseCase ctx, List<UseCase> depUseCases, HashMap<UseCase, HashMap<String, ArrayList<String>>> table) {
		for (useCase : depUseCases) {
			// ...
		}
	}
	
	/**
	 * getActors(..)
	 * -------------
	 * Gets all actors from the dependent use case and the handler use case.
	 */
	protected def void getActors(HandlerUseCase ctx, List<UseCase> depUseCases, HashMap<UseCase, HashMap<String, ArrayList<String>>> table) {
		for (useCase : depUseCases) {
			var useCaseActors = Ucm4iotUtilities.getActors(useCase);
			var handlerActors = Ucm4iotUtilities.getActors(ctx);
			
			val useCaseActorNames = useCaseActors.stream()
				.map([actor | formatActorName(actor)])
				.distinct()
				.collect(Collectors.toList());
			
			val handlerActorNames = handlerActors.stream()
				.map([actor | formatActorName(actor)])
				.map([actorName | formatExceptionalActor(useCaseActorNames, actorName)])
				.distinct()
				.collect(Collectors.toList());
				
			var actorNames = Stream.concat(useCaseActorNames.stream, handlerActorNames.stream)
				.distinct()
				.collect(Collectors.toList());
			
			table.get(useCase).get('actors').addAll(actorNames);
		}
	}
	
	/**
	 * formatExceptionalActor(..)
	 * --------------------------
	 * Formats the name of an actor with a '*' if it is an exceptional actor
	 */
	private def formatExceptionalActor(List<String> useCaseActorNames, String actorName) {
		if (useCaseActorNames.contains(actorName)) {
			return actorName;
		} else {
			return actorName + "*";
		}
	}
	
	/**
	 * formatExceptionName(..)
	 * -----------------------
	 * Formats the name of the passed exception.
	 */
	protected def String formatExceptionName(Exception exception) {
		var exceptionFormat = "%s::%s";
		
		if (exception instanceof HardwareException) {
			return String.format(exceptionFormat, 'HARDWARE_EXCEPTION', exception.name);
		} else if (exception instanceof SoftwareException) {
			return String.format(exceptionFormat, 'SOFTWARE_EXCEPTION', exception.name);
		} else if (exception instanceof NetworkException) {
			return String.format(exceptionFormat, 'NETWORK_EXCEPTION', exception.name);
		} else {
			return String.format(exceptionFormat, 'ENVIRONMENT_EXCEPTION', exception.name);
		}
	}
	
	/**
	 * getActorNameAndType(..)
	 * -----------------------
	 * Formats the name of the passed actor.
	 */
	protected def String formatActorName(Actor actor) {
		var actorFormat = '%s::%s';
		
		if (actor instanceof DeviceActor) {
			return String.format(actorFormat, 'DEVICE', actor.name);
		} else if (actor instanceof PhysicalEntityActor) {
			return String.format(actorFormat, 'PHYSICAL_ENTITY', actor.name);
		} else if (actor instanceof SoftwareActor) {
			return String.format(actorFormat, 'SOFTWARE', actor.name);
		} else {
			return String.format(actorFormat, 'HUMAN', actor.name);
		}
	}
	
	/**
	 * createHandlerTable(..)
	 * ----------------------
	 * Creates a table.
	 */
	protected def String createHandlerTable(List<HandlerUseCase> handlers, HashMap<HandlerUseCase, List<UseCase>> dependents, HashMap<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>> handlerInfo) {
		var rows = newArrayList;
		
		// Lambda function to convert a list of use cases into a list of string representations of those use cases.
		val dependentsToColumn = [ List<UseCase> useCases | 
			useCases.stream()
				.map([uc | uc.name])
				.collect(Collectors.toList())
		];
		
		// Lambda function to get a column from a table, from all use cases.
		val tableToColumn = [String columnName | 
			[ HashMap<UseCase, HashMap<String, ArrayList<String>>> table |
				val list = newArrayList;
				for (key : table.keySet()) {
					list.addAll(table.get(key).get(columnName));  // Add all columns into one list.
				}
				return list.toList();
			]
		];

		// Creates the format of the table.
		var columnNames = #["Handlers", "Dependent Use Cases", "Handled Exceptions", "Actors"];
		var columns = #[
			fitColumnWidth(columnNames.get(0), 2, handlers.stream().map[uc | uc.name].collect(Collectors.toList())),
			fitColumnWidth(columnNames.get(1), 2, dependents, dependentsToColumn),
			fitColumnWidth(columnNames.get(2), 2, handlerInfo, tableToColumn.apply('handled_exceptions')),
			fitColumnWidth(columnNames.get(3), 2, handlerInfo, tableToColumn.apply('actors'))
		];
		
		// Creates the format of the body of the table.
		var format = createTableFormat(columns);
		var line = String.format(format, "", "", "", "").replace(" ", "-").replace("|", "+");
		var partialLine = String.format(line
			.replaceFirst("-+", String.format("%%-%ds", columns.get(0)))
			.replaceFirst("\\+", "|"), ""
		);
		
		// Starts filling in the headers of the table.
		rows += line;
		rows += String.format(format, 
			" " + columnNames.get(0), 
			" " + columnNames.get(1), 
			" " + columnNames.get(2),
			" " + columnNames.get(3)
		);
		rows += line;
		
		// List out the exceptions and exceptional actors found from each handled use case.
		for (handler : handlers) {
			var handlerDependents = dependents.get(handler);
			var rowStarted = false;
			
			for (handledUseCase : handlerDependents) {
				var table = handlerInfo.get(handler).get(handledUseCase);
				var handledExceptions = table.get('handled_exceptions');
				var actors            = table.get('actors');
				
				// If algorithm has not started printing row for the current handler, then print the handler's name.
				var rowData = #[#[handler.name], #[handledUseCase.name], handledExceptions, actors];
				if (rowStarted) {
					rowData = #[#[""], #[handledUseCase.name], handledExceptions, actors];
				}
				
				// Leaves empty space when no data is found in a column.
				val n = maxSize(rowData);
				for (var i = 0; i < n; i++) {
					rows += String.format(format, getDataOrDefault(i, rowData));
				}
				
				rows += partialLine;
				rowStarted = true;
			}
			
			rows.remove(rows.size - 1);
			rows += line;
		}
		
		return String.join("\n", rows);
	}
	
} // Class HandlerTableGenerator
