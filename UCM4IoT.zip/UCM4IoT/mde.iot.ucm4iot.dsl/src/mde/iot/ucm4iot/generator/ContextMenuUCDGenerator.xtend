package mde.iot.ucm4iot.generator

import java.text.SimpleDateFormat
import java.util.Calendar
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.AbstractGenerator
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

/**
 * Class: ContextMenuUCDGenerator
 * ------------------------------
 * Generator for the context menu.
 */
class ContextMenuUCDGenerator extends AbstractGenerator {
	public static final String GEN_EXCEPTION_LIST = "exceptions/";
	public static final String GEN_HANDLER_LIST   = "handlers/";
	public static final String OUTDATED_LIST      = "outdated/";
	
	/**
	 * doGenerate(..)
	 * --------------
	 * Generates exception related artifacts from a UCM4IoT model.
	 */
	override void doGenerate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		var date = Calendar.getInstance().getTime();
        var dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss/");
        
        // Generates the various artifacts.
		var diagramGenerator = new UseCaseDiagramGenerator();
		diagramGenerator.generate(resource, fsa, context, dateFormat.format(date));
	}
}
