package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import java.util.Map
import java.util.function.Function
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.HumanActor
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

import static extension org.eclipse.xtext.EcoreUtil2.*
import mde.iot.ucm4iot.ucm4iot.Step
import mde.iot.ucm4iot.ucm4iot.DeviceType

class IoTDomainModelGenerator extends IUcm4iotGeneratorImpl {
	
	/**
	 * generate(..)
	 * ------------
	 * Generates a use case diagram for a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	/**
	 * generate(..)
	 * ------------
	 * Generates a use case diagram for a ucm4iot model.
	 */
	override void generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		var data = generateDomainModel(resource);
		createFile(fsa, folder, createFileName(resource.normalizedURI.lastSegment.replace(".ucmiot", ""), ".iotdomainmodel"), data);
	}
	
	/**
	 * createTable(..)
	 * ---------------
	 * Creates a table of information.
	 */
	protected def HashMap<String, List<EObject>> createTable(Resource resource) {
		var useCases = StreamSupport
			.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var actors = StreamSupport
			.stream(resource.allContents.toIterable.filter(Actor).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var exceptions = StreamSupport
			.stream(resource.allContents.toIterable.filter(Exception).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var table = new HashMap<String, List<EObject>>();
		table.put('use_cases',  useCases);
		table.put('actors',     actors);
		table.put('exceptions', exceptions)
		
		return table;
	}
	
	protected def generateDomainModel(Resource resource) {
		var table = createTable(resource);
		
		// Creates a use case diagram.
		var tag = "iotdomainmodel:IoTDomainModel";
		var attributes = #{
			'xmi:version'          -> '2.0',
			'xmlns:xmi'            -> 'http://www.omg.org/XMI',
			'xmlns:xsi'            -> 'http://www.w3.org/2001/XMLSchema-instance',
			'xmlns:iotdomainmodel' -> 'http://www.ucm4iot.org/mde/iot/iotdomainmodel'
		};
		
		var root = new DiagramRepresentation(null, tag, attributes);
		findUsers(table, root);
		findPhysicalEntities(table, root);
		findServices(table, root);
		addAssociations(table, root);  // TODO: FIX
		
		var data = createDiagram(root);
		return String.join("\n", data);
	}
	
	protected def findUsers(HashMap<String, List<EObject>> table, DiagramRepresentation root) {
		// Finds the names of all human actors.
		var humanUsers = table.get('actors').stream()
			.filter([actor | actor instanceof HumanActor])
			.map([actor | actor as Actor])
			.map([actor | actor.name])
			.distinct()
			.collect(Collectors.toList());
		
		// Convert each actor into a diagram element.
		for (actorName : humanUsers) {
			var tag = "users";
			var attributes = #{
				'xsi:type' -> 'iotdomainmodel:HumanUser',
				'name' -> actorName
			};
			
			var actorRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('users', #[actorRep]);
		}
		
		// Finds the names of all software actors.
		var softwareUsers = table.get('actors').stream()
			.filter([actor | actor instanceof SoftwareActor])
			.map([actor | actor as Actor])
			.map([actor | actor.name])
			.distinct()
			.collect(Collectors.toList());
			
		// Converts each software into an active digital artefact.
		for (actorName : softwareUsers) {
			var tag = "users";
			var attributes = #{
				'xsi:type' -> 'iotdomainmodel:VirtualEntity',  // TODO: consider determining if Service or Virtual Entity.
				'name' -> actorName
			};
			
			var actorRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('users', #[actorRep]);
		}
	}
	
	protected def findPhysicalEntities(HashMap<String, List<EObject>> table, DiagramRepresentation root) {
		// Finds the names of all physical entities.
		var physicalEntitiesUsers = table.get('actors').stream()
			.filter([actor | actor instanceof PhysicalEntityActor])
			.map([actor | actor as Actor])
			.map([actor | actor.name])
			.distinct()
			.collect(Collectors.toList());
		
		// Convert each physical entity into a diagram element.
		for (actorName : physicalEntitiesUsers) {
			var tag = "physicalEntities";
			var attributes = #{
				'name' -> actorName
			};
			
			var actorRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('physicalEntities', #[actorRep]);
		}
		
		// Finds the names of all sensors.
		var sensorUsers = table.get('actors').stream()
			.filter([actor | actor instanceof DeviceActor])
			.map([actor | actor as DeviceActor])
			.filter([actor | actor.getDeviceType() == DeviceType.SENSOR])
			.map([actor | actor.name])
			.distinct()
			.collect(Collectors.toList());
		
		// Convert each actor into a diagram element.
		for (actorName : sensorUsers) {
			var tag = "devices";
			var attributes = #{
				'xsi:type' -> 'iotdomainmodel:Sensor',
				'name' -> actorName
			};
			
			var actorRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('devices', #[actorRep]);
		}
		
		// Finds the names of all tags.
		var tagUsers = table.get('actors').stream()
			.filter([actor | actor instanceof DeviceActor])
			.map([actor | actor as DeviceActor])
			.filter([actor | actor.getDeviceType() == DeviceType.TAG])
			.map([actor | actor.name])
			.distinct()
			.collect(Collectors.toList());
		
		// Convert each actor into a diagram element.
		for (actorName : tagUsers) {
			var tag = "devices";
			var attributes = #{
				'xsi:type' -> 'iotdomainmodel:Tag',
				'name' -> actorName
			};
			
			var actorRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('devices', #[actorRep]);
		}
		
		// Finds the names of all actuators.
		var actuatorUsers = table.get('actors').stream()
			.filter([actor | actor instanceof DeviceActor])
			.map([actor | actor as DeviceActor])
			.filter([actor | actor.getDeviceType() == DeviceType.ACTUATOR])
			.map([actor | actor.name])
			.distinct()
			.collect(Collectors.toList());
		
		// Convert each actor into a diagram element.
		for (actorName : actuatorUsers) {
			var tag = "devices";
			var attributes = #{
				'xsi:type' -> 'iotdomainmodel:Actuator',
				'name' -> actorName
			};
			
			var actorRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('devices', #[actorRep]);
		}
	}
	
	protected def findServices(HashMap<String, List<EObject>> table, DiagramRepresentation root) {
		var useCases = table.get('use_cases').stream()
			.map([ob | ob as UseCase])
			.collect(Collectors.toList());
		
		var services = newArrayList;
		
		// Determine the services in the model.
		for (useCase : useCases) {
			var invocationSteps = EcoreUtil2.getAllContentsOfType(useCase, InvocationStep);
			var actors = EcoreUtil2.getAllContentsOfType(useCase, Actor).stream()
				.filter([actor | actor instanceof HumanActor || actor instanceof SoftwareActor])
				.collect(Collectors.toList());
			
			// Summary/User-goal level use cases invoked by a user are assumed to be services.
			for (invocationStep : invocationSteps) {
				var hasActor = actors.stream()
					.anyMatch([actor | hasWord(invocationStep, actor.name)]);
				
				// When an actor invokes a use case, then convert to a diagram element.
				if (hasActor) {
					services.add(invocationStep.invokedUseCase);
				}
			}
		}
		
		// Only look at each identified service once.
		var uniqueServices = services.stream()
			.distinct()
			.collect(Collectors.toList());
		
		// Converts each determined service into a diagram element.
		for (service : uniqueServices) {
			var tag = "users";
			var attributes = #{
				'xsi:type' -> 'iotdomainmodel:Service',
				'name' -> service.name
			};
			
			var serviceRep = new DiagramRepresentation(null, tag, attributes);			
			root.addChildren('users', #[serviceRep]);
		}
	}
	
	/**
	 * hasWord(..)
	 * -----------
	 * Returns true if a step has the passed word; false otherwise.
	 */
	private def boolean hasWord(Step step, String value) {
		var description = step.getDescription();
		if (description === null) {
			description = "";
		}
		
		var words = description
				.replaceAll("[^a-zA-Z0-9]", " ")
				.split("\\s+");
		
		// Check if any words match the passed String.
		for (String word : words) {
			if (value.equals(word)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * addAssociations(..)
	 * -------------------
	 * Add relationships between the elements in the table.
	 */
	protected def addAssociations(HashMap<String, List<EObject>> table, DiagramRepresentation root) {
		for (user : root.getChildren('users')) {
			
			
			addInteractions(table, root, user);
			addDeviceInteractions(table, root, user);
			addServiceInteractions(table, root, user);
		}
		
		for (device : root.getChildren('devices')) {
			addDeviceRelationships(table, root, device);
		}
	}
	
	protected def addInteractions(HashMap<String, List<EObject>> table, DiagramRepresentation root, DiagramRepresentation user) {
		var useCases = table.get('use_cases').stream()
			.map([ob | ob as UseCase])
			.collect(Collectors.toList());
		
		val userName = user.getAttribute('name');
		var interactedEntities = newArrayList;
		
		var physicalEntities = newArrayList;
		if (root.hasChildren('physicalEntities')) {
			physicalEntities.addAll(root.getChildren('physicalEntities'));
		}
		
		//if (root.hasChildren('devices')) {
		//	physicalEntities.addAll(root.getChildren('devices'));
		//}
		
		// Searches through all use cases to see when the user interacts with a physical entity.
		for (useCase : useCases) {
			var steps = EcoreUtil2.getAllContentsOfType(useCase, Step).stream()
				.filter([step | step.description !== null])
				.collect(Collectors.toList());
			
			var physicalEntityNames = physicalEntities.stream()
				.map([entity | entity.getAttribute('name')])
				.collect(Collectors.toList());
				
			for (step : steps) {
				for (physicalEntityName : physicalEntityNames) {
					if (hasWord(step, userName) &&  hasWord(step, physicalEntityName)) {
						interactedEntities.add(physicalEntityName);
					}
				}
			}
		}
		
		var distinctEntities = interactedEntities.stream()
			.distinct()
			.collect(Collectors.toList());
		
		val entityAssociations = newArrayList;
		for (entity : distinctEntities) {
			var index = indexMatched(physicalEntities, [rep | rep.getAttribute('name') === entity]);
			
			var association = formatAssociation(
				'physicalEntities' -> index
			);
			
			entityAssociations.add(association);
		}
		
		// Adds the association to the user.
		user.addAttribute('interactsWith', String.join(" ", entityAssociations));
	}
	
	protected def addDeviceInteractions(HashMap<String, List<EObject>> table, DiagramRepresentation root, DiagramRepresentation user) {
		var useCases = table.get('use_cases').stream()
			.map([ob | ob as UseCase])
			.collect(Collectors.toList());
		
		val userName = user.getAttribute('name');
		var interactedEntities = newArrayList;
		
		var devices = newArrayList;
		if (root.hasChildren('devices')) {
			devices.addAll(root.getChildren('devices'));
		}
		
		// Searches through all use cases to see when the user interacts with a physical entity.
		for (useCase : useCases) {
			var steps = EcoreUtil2.getAllContentsOfType(useCase, Step).stream()
				.filter([step | step.description !== null])
				.collect(Collectors.toList());
			
			var deviceNames = devices.stream()
				.map([entity | entity.getAttribute('name')])
				.collect(Collectors.toList());
				
			for (step : steps) {
				for (deviceName : deviceNames) {
					if (hasWord(step, userName) &&  hasWord(step, deviceName)) {
						interactedEntities.add(deviceName);
					}
				}
			}
		}
		
		var distinctEntities = interactedEntities.stream()
			.distinct()
			.collect(Collectors.toList());
		
		val entityAssociations = newArrayList;
		for (entity : distinctEntities) {
			var index = indexMatched(devices, [rep | rep.getAttribute('name') === entity]);
			
			var association = formatAssociation(
				'devices' -> index
			);
			
			entityAssociations.add(association);
		}
		
		// Adds the association to the user.
		user.addAttribute('interactsWith', String.join(" ", entityAssociations));
	}
	
	protected def addServiceInteractions(HashMap<String, List<EObject>> table, DiagramRepresentation root, DiagramRepresentation user) {
		var useCases = table.get('use_cases').stream()
			.map([ob | ob as UseCase])
			.collect(Collectors.toList());
		
		var invokedEntities = newArrayList;
		
		var users = newArrayList;
		var services = newArrayList;
		if (root.hasChildren('users')) {
			var userList = root.getChildren('users');
			users.addAll(userList);
			
			var serviceList = users.stream()
				.filter([dr | dr.getAttribute('xsi:type') == 'iotdomainmodel:Service'])
				.collect(Collectors.toList());
			services.addAll(serviceList);
		}
		
		// Determine interactions between services and users.
		for (useCase : useCases) {
			var invocationSteps = EcoreUtil2.getAllContentsOfType(useCase, InvocationStep);
			var actorName = user.getAttribute('name');
			
			// Select only found services from list.
			for (service : services) {
				val serviceName = service.getAttribute('name');
				
				var serviceSteps = invocationSteps.stream()
					.filter([step | step.invokedUseCase.name == serviceName])
					.collect(Collectors.toList());
				
				for (serviceStep : serviceSteps) {
					if (hasWord(serviceStep, actorName)) {
						invokedEntities.add(serviceName);
					}
				}
			} // for (services...)
		} // for (usecases...)
		
		var distinctEntities = invokedEntities.stream()
			.distinct()
			.collect(Collectors.toList());
			
		val serviceAssociations = newArrayList;
		for (service : distinctEntities) {
			var index = indexMatched(users, [rep | rep.getAttribute('name') === service]);
			
			var association = formatAssociation(
				'users' -> index
			);
			
			serviceAssociations.add(association);
		}
		
		// Adds the association to the user.
		user.addAttribute('invokes', String.join(" ", serviceAssociations));
	}
	
	protected def addDeviceRelationships(HashMap<String, List<EObject>> table, DiagramRepresentation root, DiagramRepresentation device) {
		var useCases = table.get('use_cases').stream()
			.map([ob | ob as UseCase])
			.collect(Collectors.toList());
		
		val ctxDeviceName = device.getAttribute('name');
		var containsDevices   = newArrayList;
		var containsPE        = newArrayList;
		var readDevices       = newArrayList;
		var monitorsDevices   = newArrayList;
		var identifiesDevices = newArrayList;
		var actsDevices       = newArrayList;
		
		var devices = newArrayList;
		if (root.hasChildren('devices')) {
			devices.addAll(root.getChildren('devices'));
		}
		
		var physicalEntities = newArrayList;
		if (root.hasChildren('physicalEntities')) {
			physicalEntities.addAll(root.getChildren('physicalEntities'));
		}
		
		// Searches through all use cases to see the relationships of each device.
		for (useCase : useCases) {
			var steps = EcoreUtil2.getAllContentsOfType(useCase, Step).stream()
				.filter([step | step.description !== null])
				.collect(Collectors.toList());
			
			var deviceNames = devices.stream()
				.map([entity | entity.getAttribute('name')])
				.collect(Collectors.toList());
				
			var physicalEntityNames = physicalEntities.stream()
				.map([entity | entity.getAttribute('name')])
				.collect(Collectors.toList());
			
			var ctxDeviceType = devices.stream()
				.filter([entity | entity.getAttribute('name') == ctxDeviceName])
				.map([entity | entity.getAttribute('xsi:type')])
				.findFirst()
				.orElse('')
				
			for (step : steps) {
				for (deviceName : deviceNames) {
					var deviceType = devices.stream()
						.filter([entity | entity.getAttribute('name') == deviceName])
						.map([entity | entity.getAttribute('xsi:type')])
						.findFirst()
						.orElse('')
					
					//System.out.println(ctxDeviceType + ' -> ' + deviceType);
					
					// Determine a reads relationship
					if (ctxDeviceType == 'iotdomainmodel:Sensor' && deviceType == 'iotdomainmodel:Tag' && hasInteraction(step, 'reads', ctxDeviceName, deviceName)) {
						readDevices.add(deviceName);
						//System.out.println('reads ' + deviceName);
					}
					
					if (hasInteraction(step, 'contains', ctxDeviceName, deviceName)) {
						containsDevices.add(deviceName);
						//System.out.println('contains ' + deviceName);
					}
				} // for (devices..)
				
				for (physicalEntityName : physicalEntityNames) {
					//System.out.println(ctxDeviceType + ' -> physicalEntity');
					
					// Determine a monitors relationship
					if (ctxDeviceType == 'iotdomainmodel:Sensor' && hasInteraction(step, 'monitors', ctxDeviceName, physicalEntityName)) {
						monitorsDevices.add(physicalEntityName);
						//System.out.println('monitors ' + physicalEntityName);
					}
					
					// Determine a identifies relationship
					if (ctxDeviceType == 'iotdomainmodel:Tag' && hasInteraction(step, 'identifies', ctxDeviceName, physicalEntityName)) {
						identifiesDevices.add(physicalEntityName);
						//System.out.println('identifies ' + physicalEntityName);
					}
					
					// Determine a acts on relationship
					if (ctxDeviceType == 'iotdomainmodel:Actuator' && hasInteraction(step, 'acts on', ctxDeviceName, physicalEntityName)) {
						actsDevices.add(physicalEntityName);
						//System.out.println('acts on ' + physicalEntityName);
					}
					
					// Determine a contains relationship
					if (hasInteraction(step, 'attached to', ctxDeviceName, physicalEntityName)) {
						containsPE.add(physicalEntityName);
						//System.out.println('attached to ' + physicalEntityName);
					}
				}
			} // for (steps..)
		} // for (usecases..)
		
		var distinctContainsDevices   = containsDevices.stream().distinct().collect(Collectors.toList());
		var distinctContainsPE 	      = containsPE.stream().distinct().collect(Collectors.toList());
		var distinctReadDevices       = readDevices.stream().distinct().collect(Collectors.toList());
		var distinctMonitorsDevices   = monitorsDevices.stream().distinct().collect(Collectors.toList());
		var distinctIdentifiesDevices = identifiesDevices.stream().distinct().collect(Collectors.toList());
		var distinctActsDevices       = actsDevices.stream().distinct().collect(Collectors.toList());
		
		val containDevicesAssociations = newArrayList;
		for (entity : distinctContainsDevices) {
			var index = indexMatched(devices, [rep | rep.getAttribute('name') === entity]);
			var association = formatAssociation('devices' -> index);
			containDevicesAssociations.add(association);
		}
		
		val containPEAssociations = newArrayList;
		for (entity : distinctContainsPE) {
			var index = indexMatched(physicalEntities, [rep | rep.getAttribute('name') === entity]);
			var association = formatAssociation('physicalEntities' -> index);
			containPEAssociations.add(association);
		}
		
		val readDevicesAssociations = newArrayList;
		for (entity : distinctReadDevices) {
			var index = indexMatched(devices, [rep | rep.getAttribute('name') === entity]);
			var association = formatAssociation('devices' -> index);
			readDevicesAssociations.add(association);
		}
		
		val monitorsDevicesAssociations = newArrayList;
		for (entity : distinctMonitorsDevices) {
			var index = indexMatched(physicalEntities, [rep | rep.getAttribute('name') === entity]);
			var association = formatAssociation('physicalEntities' -> index);
			monitorsDevicesAssociations.add(association);
		}
		
		val identifiesDevicesAssociations = newArrayList;
		for (entity : distinctIdentifiesDevices) {
			var index = indexMatched(physicalEntities, [rep | rep.getAttribute('name') === entity]);
			var association = formatAssociation('physicalEntities' -> index);
			identifiesDevicesAssociations.add(association);
		}
		
		val actsDevicesAssociations = newArrayList;
		for (entity : distinctActsDevices) {
			var index = indexMatched(physicalEntities, [rep | rep.getAttribute('name') === entity]);
			var association = formatAssociation('physicalEntities' -> index);
			actsDevicesAssociations.add(association);
		}
		
		// Adds the association to the user.
		if (containDevicesAssociations.size > 0) {
			device.addAttribute('contains', String.join(" ", containDevicesAssociations));
		}
		
		if (containPEAssociations.size > 0) {
			device.addAttribute('attachedTo', String.join(" ", containPEAssociations));
		}
		
		if (readDevicesAssociations.size > 0) {
			device.addAttribute('reads', String.join(" ", readDevicesAssociations));
		}
		
		if (monitorsDevicesAssociations.size > 0) {
			device.addAttribute('monitors', String.join(" ", monitorsDevicesAssociations));
		}
		
		if (identifiesDevicesAssociations.size > 0) {
			device.addAttribute('identifies', String.join(" ", identifiesDevicesAssociations));
		}
		
		if (actsDevicesAssociations.size > 0) {
			device.addAttribute('actsOn', String.join(" ", actsDevicesAssociations));
		}
		
		//System.out.println('end');
	}
	
	private def boolean hasInteraction(Step step, String action, String actor1, String actor2) {
		var description = step.getDescription();
		if (description === null) {
			description = "";
		}
		
		// The different types of sentences that may appear.
		var interactionType1 = String.format("%s %s %s", actor1, action, actor2);
		var interactionType2 = String.format("%s %s a %s", actor1, action, actor2);
		var interactionType3 = String.format("%s %s an %s", actor1, action, actor2);
		var interactionType4 = String.format("%s %s the %s", actor1, action, actor2);
		
		// Checks if the words exist within the sentence.
		if (hasWord(step, actor1) && hasWord(step, actor2)) {
			var output1 = description.contains(interactionType1);
			var output2 = description.contains(interactionType2);
			var output3 = description.contains(interactionType3);
			var output4 = description.contains(interactionType4);
			
			return output1 || output2 || output3 || output4;
		}
		
		return false;
	}
	
	/**
	 * indexMatched(..)
	 * ----------------
	 * Determines the first index the passed function returns true.
	 */
	protected def indexMatched(List<DiagramRepresentation> reps, Function<DiagramRepresentation, Boolean> match) {
		for (var i = 0; i < reps.size(); i++) {
			if (match.apply(reps.get(i))) {
				return i;
			}
		}
		
		return -1;
	}
	
	/**
	 * formatAssociation(..)
	 * ---------------------
	 * Formats an association to an existing element.
	 */
	protected def String formatAssociation(Pair<String, Integer>... indexMap) {
		var builder = new StringBuilder();
		val format = "/@%s.%s";
		
		builder.append("/");
		for (pair : indexMap) {
			builder.append(String.format(format, pair.getKey(), pair.getValue()));
		}
		
		return builder.toString();
	}
	
	/**
	 * createDiagram(..)
	 * -----------------
	 * Creates a diagram.
	 */
	protected def List<String> createDiagram(DiagramRepresentation rep) {
		var data = newArrayList;
		data += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		createDiagramHelper(rep, 0, data);
		return data;
	}
	
	/**
	 * createDiagramHelper(..)
	 * -----------------------
	 * Recursively goes through a diagram representation and outputs a diagram.
	 */
	private def void createDiagramHelper(DiagramRepresentation rep, int depth, ArrayList<String> output) {
		if (rep === null) {
			return;
		}
		
		// Gets the appropriate tag of this element.
		if (rep.hasChildren()) {
			output += createTabs(depth) + rep.getStartTag();
			
			// Recursively goes through each child.
			for (key : rep.keySet()) {
				for (child : rep.getChildren(key)) {
					createDiagramHelper(child, depth+1, output);
				}
			}
			
			output += createTabs(depth) + rep.getEndTag();
		} else {
			output += createTabs(depth) + rep.getOneLineTag();
		}
	}
	
	/**
	 * createTab(..)
	 * -------------
	 * Creates a string with the specified number of tabs.
	 */
	private def String createTabs(int indents) {
		var builder = new StringBuilder();
		builder.append("");
		
		// Repeat the number of tabs.
		for (var i = 0; i < indents; i++) {
			builder.append("\t")
		}
		
		return builder.toString();
	}
	
	/**
	 * Class: DiagramRepresentation
	 * ----------------------------
	 * Creates a representation of a diagram.
	 */
	protected static class DiagramRepresentation {
		// Ecore representation.
		EObject element;
		HashMap<String, List<DiagramRepresentation>> childrenMap;
		
		// Diagram representation.
		String tag;
		Map<String, String> attributes;
		
		/**
		 * Creates a new diagram representation.
		 */
		new (EObject element, String tag) {
			this(element, tag, new HashMap<String, String>());
		}
		
		/**
		 * Creates a new diagram representation.
		 */
		new (EObject element, String tag, Map<String, String> attributes) {
			this.element = element;
			this.tag = tag;
			
			this.attributes = new HashMap<String, String>();
			this.attributes.putAll(attributes);
			
			this.childrenMap = new HashMap<String, List<DiagramRepresentation>>();
		}
		
		/**
		 * getElement(..)
		 * --------------
		 * Gets the object this element is associated with.
		 */
		def getElement() {
			return this.element;
		}
		
		/**
		 * addChildren(..)
		 * ---------------
		 * Adds a list of children to this element.
		 */
		def void addChildren(String key, List<DiagramRepresentation> children) {			
			if (!childrenMap.containsKey(key)) {
				childrenMap.put(key, newArrayList);
			}
			childrenMap.get(key).addAll(children);
		}
		
		/**
		 * keySet(..)
		 * ----------
		 * Get the keys associated with the children.
		 */
		def keySet() {
			return childrenMap.keySet();
		}
		
		/**
		 * getChildren(..)
		 * ---------------
		 * Gets the children of this element.
		 */
		def getChildren(String key) {
			return this.childrenMap.get(key);
		}
		
		/**
		 * hasChildren(..)
		 * ---------------
		 * Returns true if this element has children of the desired type.
		 */
		def hasChildren(String key) {
			return this.childrenMap.containsKey(key);
		}
		
		/**
		 * hasChildren(..)
		 * ---------------
		 * Returns true if this element has children.
		 */
		def hasChildren() {
			return !this.childrenMap.isEmpty();
		}
		
		/**
		 * getStartTag(..)
		 * ---------------
		 * Gets the tag for the start of an element.
		 */
		def getStartTag() {
			if (attributes.isEmpty()) {
				return String.format("<%s>", tag);
			}
			
			return String.format("<%s %s>", tag, getAttributes());
		}
		
		/**
		 * getEndTag(..)
		 * -------------
		 * Gets the tag for the end of an element.
		 */
		def getEndTag() {
			return String.format("</%s>", tag);
		}
		
		/**
		 * getOneLineTag(..)
		 * -----------------
		 * Gets the tag in a one line representation.
		 */
		def getOneLineTag() {
			if (attributes.isEmpty()) {
				return String.format("<%s/>", tag);
			}
			
			return String.format("<%s %s/>", tag, getAttributes());
		}
		
		/**
		 * addAttribute(..)
		 * ----------------
		 * Adds an attribute to this element.
		 */
		def addAttribute(String key, String value) {
			this.attributes.put(key, value);
		}
		
		/**
		 * addAttributes(..)
		 * -----------------
		 * Adds many attributes to this element.
		 */
		def addAttributes(Map<String, String> attributes) {
			this.attributes.putAll(attributes);
		}
		
		/**
		 * hasAttribute(..)
		 * ----------------
		 * Returns true if the element contains the given attribute.
		 */
		def hasAttribute(String key) {
			return this.attributes.containsKey(key);
		}
		
		/**
		 * getAttribute(..)
		 * ----------------
		 * Gets an attribute from the element.
		 */
		def getAttribute(String key) {
			this.attributes.get(key);
		}
		
		/**
		 * getAttributes(..)
		 * -----------------
		 * Gets the attributes formatted into a string.
		 */
		def String getAttributes() {
			var args = newArrayList;
			
			// Create attribute-value pairs.
			for (key : attributes.keySet()) {
				args += String.format("%s=\"%s\"", key, attributes.get(key));
			}
			
			return String.join(" ", args);
		}
	}
}
