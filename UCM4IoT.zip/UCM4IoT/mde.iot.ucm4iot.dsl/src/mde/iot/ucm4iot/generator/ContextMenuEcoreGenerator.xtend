package mde.iot.ucm4iot.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.AbstractGenerator
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

class ContextMenuEcoreGenerator extends AbstractGenerator {
	
	/**
	 * doGenerate(..)
	 * --------------
	 * Generates exception related artifacts from a UCM4IoT model.
	 */
	override void doGenerate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {        
		var ecoreGenerator = new EcoreGenerator();
		ecoreGenerator.generate(resource, fsa, context);
	}
}
