package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import java.util.Map
import java.util.function.Function
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.HumanActor
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

import static extension org.eclipse.xtext.EcoreUtil2.*

import mde.iot.ucm4iot.ucm4iot.ContextAwarenessEnabledUseCase
import mde.iot.ucm4iot.ucm4iot.ContextItem
import mde.iot.ucm4iot.ucm4iot.Step
import java.util.LinkedHashSet
import java.util.regex.Pattern


class UseCaseDiagramGenerator extends IUcm4iotGeneratorImpl {
	
	/**
	 * generate(..)
	 * ------------
	 * Generates a use case diagram for a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	/**
	 * generate(..)
	 * ------------
	 * Generates a use case diagram for a ucm4iot model.
	 */
	override void generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		var data = generateDiagram(resource);
		createFile(fsa, folder, createFileName(resource.normalizedURI.lastSegment.replace(".ucmiot", ""), ".usecasediagram"), data);
	}
	
		
	/**
	 * createTable(..)
	 * ---------------
	 * Creates a table of information.
	 */
	protected def HashMap<String, List<EObject>> createTable(Resource resource) {
		var useCases = StreamSupport
			.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var actors = StreamSupport
			.stream(resource.allContents.toIterable.filter(Actor).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var exceptions = StreamSupport
			.stream(resource.allContents.toIterable.filter(Exception).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var table = new HashMap<String, List<EObject>>();
		table.put('use_cases',  useCases);
		table.put('actors',     actors);
		table.put('exceptions', exceptions)
		
		return table;
	}
	
	/**
	 * generateDiagram(..)
	 * -------------------
	 * Generates a diagram.
	 */
	protected def generateDiagram(Resource resource) {
		var table = createTable(resource);
		
		// Creates a use case diagram.
		var tag = "usecasediagram:UseCaseDiagram";
		var attributes = #{
			'xmi:version'          -> '2.0',
			'xmlns:xmi'            -> 'http://www.omg.org/XMI',
			'xmlns:xsi'            -> 'http://www.w3.org/2001/XMLSchema-instance',
			'xmlns:usecasediagram' -> 'http://www.ucm4iot.org/mde/iot/usecasediagram'
		};
		
		var root = new DiagramRepresentation(null, tag, attributes);
		linkScopes(table, root);
		linkActors(table, root);
		addAssociations(root);
		
		var data = createDiagram(root);
		return String.join("\n", data);
	}
	
	/**
	 * linkScopes(..)
	 * --------------
	 * Links each scope in the model to the root element.
	 */
	protected def linkScopes(HashMap<String, List<EObject>> table, DiagramRepresentation root) {
		var useCases = table.get('use_cases').stream()
			.map([ob | ob as UseCase])
			.collect(Collectors.toList());
		
		var scopeNames = useCases.stream()
			.map([uc | uc.scope])
			.distinct()
			.collect(Collectors.toList());
		
		// Creates a child under the root element for each scope.
		for (scopeName : scopeNames) {
			val containedUseCases = useCases.stream()
				.filter([uc | uc.scope == scopeName])
				.collect(Collectors.toList());
			
			val containedExceptions = table.get('exceptions').stream()
				.map([ob | ob as Exception])
				.filter([exception | hasExeption(containedUseCases, exception)])
				.collect(Collectors.toList());
			
			// Define the element.
			var tag = "scopes";
			var attributes = #{
				'name' -> scopeName
			};
			
			var scopeRep = new DiagramRepresentation(null, tag, attributes);
			linkUseCases(scopeRep, containedUseCases);
			linkExceptions(scopeRep, containedExceptions);
			
			root.addChildren('scopes', #[scopeRep]);
		}
	}
	
	/**
	 * hasExeption(..)
	 * ---------------
	 * There exists a use case that raises the passed exception.
	 */
	private def boolean hasExeption(List<UseCase> useCases, Exception exception) {
		return useCases.stream().anyMatch([uc |
				EcoreUtil2.getAllContentsOfType(uc, ExceptionStep).stream()
					.anyMatch([es | es.refException === exception])
		]);
	}
	
	/**
	 * linkUseCases(..)
	 * ----------------
	 * Links use cases to their respective scope.
	 */
//	protected def linkUseCases(DiagramRepresentation scopeRep, List<UseCase> containedUseCases) {
//		for (useCase : containedUseCases) {
//			var tag = "usecases";
//			var attributes = #{
//				'xsi:type' -> formatUseCaseType(useCase),
//				'name'     -> useCase.name
//			};
//			
//			var useCaseRep = new DiagramRepresentation(useCase, tag, attributes);
//			scopeRep.addChildren('use_cases', #[useCaseRep]);
//		}
//	}
	
	protected def linkUseCases(DiagramRepresentation scopeRep, List<UseCase> containedUseCases) {
    for (useCase : containedUseCases) {
        var tag = "usecases";
        var attributes = #{
            'xsi:type' -> formatUseCaseType(useCase),
            'name'     -> useCase.name
        };

        var useCaseRep = new DiagramRepresentation(useCase, tag, attributes);

        // NEW: attach dynamic-goal references and CA requirements to the use case.
        linkDynamicGoals(useCaseRep, useCase);
        linkContextRequirements(useCaseRep, useCase);

        scopeRep.addChildren('use_cases', #[useCaseRep]);
    }
}


/** Matches [DG:Name] and [RB:Name] tags embedded in step descriptions. */
static val Pattern DG_RB_PATTERN = Pattern.compile("\\[(?:DG|RB):\\s*([^\\]]+?)\\s*\\]");

/**
 * linkDynamicGoals(..)
 * --------------------
 * Adds a child element for every distinct dynamic goal referenced (via
 * [DG:...] or [RB:...]) in the steps of the use case.
 */
protected def linkDynamicGoals(DiagramRepresentation useCaseRep, UseCase useCase) {
    for (goalName : extractDynamicGoalNames(useCase)) {
        var attributes = #{ 'name' -> goalName };
        var goalRep = new DiagramRepresentation(null, "dynamicGoals", attributes);
        useCaseRep.addChildren('dynamic_goals', #[goalRep]);
    }
}

/**
 * linkContextRequirements(..)
 * ---------------------------
 * Adds a child element for every CA requirement id associated with the use case.
 */
protected def linkContextRequirements(DiagramRepresentation useCaseRep, UseCase useCase) {
    for (caId : extractContextRequirementIds(useCase)) {
        var attributes = #{ 'id' -> caId };
        var caRep = new DiagramRepresentation(null, "contextRequirements", attributes);
        useCaseRep.addChildren('context_requirements', #[caRep]);
    }
}

/**
 * extractDynamicGoalNames(..)
 * ---------------------------
 * Scans every step description of the use case for [DG:...]/[RB:...] tags and
 * returns the distinct goal names, in first-seen order.
 */
protected def LinkedHashSet<String> extractDynamicGoalNames(UseCase useCase) {
    val names = new LinkedHashSet<String>();
    for (step : EcoreUtil2.getAllContentsOfType(useCase, Step)) {
        val feature = step.eClass.getEStructuralFeature("description");
        if (feature !== null) {
            val value = step.eGet(feature);
            if (value instanceof String) {
                val matcher = DG_RB_PATTERN.matcher(value as String);
                while (matcher.find()) {
                    names.add(matcher.group(1).trim());
                }
            }
        }
    }
    return names;
}

/**
 * extractContextRequirementIds(..)
 * --------------------------------
 * Collects CA requirement ids for the use case: those defined in its
 * context-awareness block, plus those referenced by a CA-enabled use case.
 */
protected def LinkedHashSet<String> extractContextRequirementIds(UseCase useCase) {
    val ids = new LinkedHashSet<String>();

    // Defined in the use case's context-awareness block (CA006: "...").
    if (useCase.contextAwareness !== null) {
        for (ContextItem item : useCase.contextAwareness.contextItems) {
            ids.add(item.id);
        }
    }

    // Referenced by a CA-enabled use case (context: CA002, CA003, ...).
    if (useCase instanceof ContextAwarenessEnabledUseCase) {
        for (cid : (useCase as ContextAwarenessEnabledUseCase).context) {
            ids.add(cid);
        }
    }

    return ids;
}

	
	/**
	 * linkExceptions(..)
	 * ------------------
	 * Links exceptions to their respective scope.
	 */
	protected def linkExceptions(DiagramRepresentation scopeRep, List<Exception> containedExceptions) {
		for (exception : containedExceptions) {
			var tag = "exceptions";
			var attributes = #{
				'xsi:type' -> formatExceptionType(exception),
				'name'     -> exception.name
			};
			
			var exceptionRep = new DiagramRepresentation(exception, tag, attributes);
			scopeRep.addChildren('exceptions', #[exceptionRep]);
		}
	}
	
	/**
	 * linkActors(..)
	 * --------------
	 * Links each actor in the model to the root element.
	 */
	protected def linkActors(HashMap<String, List<EObject>> table, DiagramRepresentation root) {
		var actors = table.get('actors').stream()
			.map([ob | ob as Actor])
			.collect(Collectors.toList());
		
		var actorNames = actors.stream()
			.map([ac | ac.name])
			.distinct()
			.collect(Collectors.toList());
		
		for (actorName : actorNames) {
			val relevantActors = actors.stream()
				.filter([ac | ac.name == actorName])
				.collect(Collectors.toList());
			
			// Finds an arbitrary actor to reference.
			val actor = relevantActors.stream()
				.findFirst()
				.orElse(null);
			
			var tag = "actors";
			var attributes = #{
				'xsi:type'   -> formatActorType(actor),
				'name'       -> actorName,
				'lowerBound' -> formatActorMultiplicity(actor.lowerbound),
				'upperBound' -> formatActorMultiplicity(actor.upperbound)
 			};
 			
 			var actorRep = new DiagramRepresentation(null, tag, attributes);
			root.addChildren('actors', #[actorRep]);
		}
	}
	
	/**
	 * addAssociations(..)
	 * -------------------
	 * Add relationships between the elements in the table.
	 */
	protected def addAssociations(DiagramRepresentation root) {
		for (scopeRep : root.getChildren('scopes')) {
			for (useCaseRep : scopeRep.getChildren('use_cases')) {
				addIncludesAssociations(root, useCaseRep);
				
				// Adds interrupt relationships if handler.
				if (useCaseRep.element instanceof HandlerUseCase) {
					addInterruptsAssociations(root, useCaseRep);
				}
			}
		}
		
		// Adds actor associations.
		for (actorRep : root.getChildren('actors')) {
			addActorAssociations(root, actorRep);
		}
	}
	
	/**
	 * addIncludesAssociations(..)
	 * ---------------------------
	 * Adds an includes relationship for each use case element.
	 */
	protected def addIncludesAssociations(DiagramRepresentation root, DiagramRepresentation useCaseRep) {
		var scopeReps = root.getChildren('scopes');
		
		var invokedUseCases = EcoreUtil2.getAllContentsOfType(useCaseRep.element, InvocationStep).stream()
			.map([step | step.invokedUseCase])
			.distinct()
			.collect(Collectors.toList());
		
		// Iterates through every invoked use case in the given use case.
		for (invokedUseCase : invokedUseCases) {
			var scopeIndex = indexMatched(scopeReps, [scopeRep | 
				invokedUseCase.scope == scopeRep.getAttribute('name')
			]);
			
			var useCaseIndex = indexMatched(scopeReps.get(scopeIndex).getChildren('use_cases'), [ucRep |
				invokedUseCase === ucRep.element 
			]);
			
			var tag = "includes";
			var attributes = #{
				'includedCase' -> formatAssociation(
					'scopes'   -> scopeIndex,
					'usecases' -> useCaseIndex
				)
			};
			
			var includesRep = new DiagramRepresentation(null, tag, attributes);
			useCaseRep.addChildren('included_use_cases', #[includesRep]);
		}
	}
	
	/**
	 * addInterruptsAssociations(..)
	 * -----------------------------
	 * Adds an interrupts association for every handler use case.
	 */
	protected def addInterruptsAssociations(DiagramRepresentation root, DiagramRepresentation useCaseRep) {
		val scopeReps = root.getChildren('scopes');
		
		val interruptedUseCases = (useCaseRep.element as HandlerUseCase).contextExceptions.stream()
			.map([cx | cx.context])
			.distinct()
			.collect(Collectors.toList());
		
		// Iterates through every interrupted use case in the given use case.
		for (interruptedUseCase : interruptedUseCases) {
			val scopeIndex = indexMatched(scopeReps, [scopeRep |
				interruptedUseCase.scope == scopeRep.getAttribute('name')
			]);
			
			val useCaseIndex = indexMatched(scopeReps.get(scopeIndex).getChildren('use_cases'), [ucRep |
				interruptedUseCase === ucRep.element 
			]);
			
			// Groups exceptions into two categories depending on whether they interrupt and continue or fail.
			var interruptsContinues = newArrayList;
			var interruptsEnds = newArrayList;
			
			// Finds the exception.
			val exceptions = (useCaseRep.element as HandlerUseCase).contextExceptions.stream()
				.filter([cx | interruptedUseCase == cx.context])
				.map([cx | cx.exception])
				.collect(Collectors.toList());
			
			// Groups exceptions into interrupts and fails or interrupts and continues.
			for (exception : exceptions) {
				if (isInterruptsAndContinues(interruptedUseCase, exception)) {
					interruptsContinues.add(exception);
				} else {
					interruptsEnds.add(exception);
				}
			}
			
			// Create interrupt association for exceptions that interrupt and continue.
			if (!interruptsContinues.isEmpty()) {
				var interruptsRep = createInterruptElement(scopeReps, scopeIndex, interruptsContinues, useCaseIndex, true);
				useCaseRep.addChildren('interrupted_use_cases', #[interruptsRep]);
			}
			
			// Create interrupt association for exceptions that interrupt and ends.
			if (!interruptsEnds.isEmpty()) {
				var interruptsRep = createInterruptElement(scopeReps, scopeIndex, interruptsEnds, useCaseIndex, false);
				useCaseRep.addChildren('interrupted_use_cases', #[interruptsRep]);
			}
		}
	}
	
	/**
	 * createInterruptElement(..)
	 * --------------------------
	 * Helper function that creates interrupt representations.
	 */
	private def createInterruptElement(List<DiagramRepresentation> scopeReps, int scopeIndex, List<Exception> interruptsContinues, int useCaseIndex, boolean interruptsAndContinues) {
		val exceptionReps = scopeReps.get(scopeIndex).getChildren('exceptions');
		val exceptionAssociations = interruptsContinues.stream()
			.map([exception | indexMatched(exceptionReps, [exRep | exception == exRep.element])])
			.map([exceptionIndex | formatAssociation(
				'scopes'     -> scopeIndex,
				'exceptions' -> exceptionIndex
			)]).collect(Collectors.toList());
		
		// Creates the diagram representation for the interrupt tag.
		var tag = "interrupts";
		var attributes = #{
			'xsi:type' -> formatInterrupt(interruptsAndContinues),
			'interruptedCase' -> formatAssociation(
				'scopes'   -> scopeIndex,
				'usecases' -> useCaseIndex
			),
			'exceptions' -> String.join(" ", exceptionAssociations)
		}
		
		return new DiagramRepresentation(null, tag, attributes);
	}
	
	/**
	 * isInterruptsAndContinues(..)
	 * ----------------------------
	 * Function returns true if this use case interrupts and continues when the passed exception is raised.
	 */
	private def boolean isInterruptsAndContinues(UseCase useCase, Exception exception) {
		var relevantSteps = EcoreUtil2.getAllContentsOfType(useCase, ExceptionStep).stream()
			.filter([step | step.refException === exception])
			.collect(Collectors.toList());
		
		// Pick the first occurrence of the exception (arbitrarily) and determine interrupt type.
		var block = EcoreUtil2.getContainerOfType(relevantSteps.get(0), ExtensionBlock);
		if (block.outcome instanceof OutcomeContinues) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * addActorAssociations(..)
	 * ------------------------
	 * Adds an association to a use case for every actor.
	 */
	protected def addActorAssociations(DiagramRepresentation root, DiagramRepresentation actorRep) {
		val associations = newArrayList;
		
		for (scopeRep : root.getChildren('scopes')) {
			for (useCaseRep : scopeRep.getChildren('use_cases')) {
				var actor = EcoreUtil2.getAllContentsOfType(useCaseRep.element, Actor).stream()
					.filter([actor | actorRep.getAttribute('name') == actor.name])
					.findFirst().orElse(null);
				
				// If actor is in the use case, then create association.
				if (actor !== null) {
					var scopeReps = root.getChildren('scopes');
					val scopeIndex = indexMatched(scopeReps, [rep | rep === scopeRep]);
					
					var useCaseReps = scopeReps.get(scopeIndex).getChildren('use_cases');
					val useCaseIndex = indexMatched(useCaseReps, [rep | rep === useCaseRep]);
					
					var association = formatAssociation(
						'scopes'   -> scopeIndex,
						'usecases' -> useCaseIndex
					);
					
					associations.add(association);
				}
			}
		}
		
		// Adds the association to the actor directly.
		actorRep.addAttribute('usecase', String.join(" ", associations));
	}
	
	/**
	 * indexMatched(..)
	 * ----------------
	 * Determines the first index the passed function returns true.
	 */
	protected def indexMatched(List<DiagramRepresentation> reps, Function<DiagramRepresentation, Boolean> match) {
		for (var i = 0; i < reps.size(); i++) {
			if (match.apply(reps.get(i))) {
				return i;
			}
		}
		
		return -1;
	}
	
	/**
	 * formatUseCaseType(..)
	 * ---------------------
	 * Formats the type of the passed use case.
	 */
	private def String formatUseCaseType(UseCase useCase) {
		val format = "usecasediagram:%s";
		
		// Formats the type depending on the original type of the use case.
		if (useCase instanceof ExceptionalUseCase) {
			return String.format(format, "StandardUseCase");
		}
		return String.format(format, "HandlerUseCase");
	}
	
	/**
	 * formatExceptionType(..)
	 * -----------------------
	 * Formats the type of the passed exception.
	 */
	private def String formatExceptionType(Exception exception) {
		val format = "usecasediagram:%s";
		
		if (exception instanceof HardwareException) {
			return String.format(format, "HardwareException");
		} else if (exception instanceof SoftwareException) {
			return String.format(format, "SoftwareException");
		} else if (exception instanceof EnvironmentException) {
			return String.format(format, "EnvironmentException");
		} else if (exception instanceof NetworkException) {
			return String.format(format, "NetworkException");
		} else {
			return String.format(format, "Exception");
		}
	}
	
	/**
	 * formatActorType(..)
	 * -------------------
	 * Formats the type of the passed actor.
	 */
	private def String formatActorType(Actor actor) {
		val format = "usecasediagram:%s";
		
		if (actor instanceof HumanActor) {
			return String.format(format, "HumanActor");
		} else if (actor instanceof SoftwareActor) {
			return String.format(format, "SoftwareActor");
		} else if (actor instanceof DeviceActor) {
			return String.format(format, "DeviceActor");
		} else if (actor instanceof PhysicalEntityActor) {
			return String.format(format, "PhysicalEntityActor");
		} else {
			return String.format(format, "Actor");
		}
	}
	
	/**
	 * formatActorMultiplicity(..)
	 * ---------------------------
	 * Formats the multiplicity of an actor.
	 */
	private def String formatActorMultiplicity(String multiplicity) {
		if (multiplicity === null) {
			return "-1";
		} else if (multiplicity.equals("*")) {
			return "-1";
		} else {
			return multiplicity;
		}
	}
	
	/**
	 * formatInterrupt(..)
	 * -------------------
	 * Formats the interrupted use case.
	 */
	private def String formatInterrupt(boolean isInterruptContinues) {
		val format = "usecasediagram:%s";
		
		if (isInterruptContinues) {
			return String.format(format, "InterruptAndContinue");
		}
		return String.format(format, "InterruptAndFail");
	}
	
	/**
	 * formatAssociation(..)
	 * ---------------------
	 * Formats an association to an existing element.
	 */
	protected def String formatAssociation(Pair<String, Integer>... indexMap) {
		var builder = new StringBuilder();
		val format = "/@%s.%s";
		
		builder.append("/");
		for (pair : indexMap) {
			builder.append(String.format(format, pair.getKey(), pair.getValue()));
		}
		
		return builder.toString();
	}
	
	/**
	 * createDiagram(..)
	 * -----------------
	 * Creates a diagram.
	 */
	protected def List<String> createDiagram(DiagramRepresentation rep) {
		var data = newArrayList;
		data += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		createDiagramHelper(rep, 0, data);
		return data;
	}
	
	/**
	 * createDiagramHelper(..)
	 * -----------------------
	 * Recursively goes through a diagram representation and outputs a diagram.
	 */
	private def void createDiagramHelper(DiagramRepresentation rep, int depth, ArrayList<String> output) {
		if (rep === null) {
			return;
		}
		
		// Gets the appropriate tag of this element.
		if (rep.hasChildren()) {
			output += createTabs(depth) + rep.getStartTag();
			
			// Recursively goes through each child.
			for (key : rep.keySet()) {
				for (child : rep.getChildren(key)) {
					createDiagramHelper(child, depth+1, output);
				}
			}
			
			output += createTabs(depth) + rep.getEndTag();
		} else {
			output += createTabs(depth) + rep.getOneLineTag();
		}
	}
	
	/**
	 * createTab(..)
	 * -------------
	 * Creates a string with the specified number of tabs.
	 */
	private def String createTabs(int indents) {
		var builder = new StringBuilder();
		builder.append("");
		
		// Repeat the number of tabs.
		for (var i = 0; i < indents; i++) {
			builder.append("\t")
		}
		
		return builder.toString();
	}
	
	/**
	 * Class: DiagramRepresentation
	 * ----------------------------
	 * Creates a representation of a diagram.
	 */
	protected static class DiagramRepresentation {
		// Ecore representation.
		EObject element;
		HashMap<String, List<DiagramRepresentation>> childrenMap;
		
		// Diagram representation.
		String tag;
		Map<String, String> attributes;
		
		/**
		 * Creates a new diagram representation.
		 */
		new (EObject element, String tag) {
			this(element, tag, new HashMap<String, String>());
		}
		
		/**
		 * Creates a new diagram representation.
		 */
		new (EObject element, String tag, Map<String, String> attributes) {
			this.element = element;
			this.tag = tag;
			
			this.attributes = new HashMap<String, String>();
			this.attributes.putAll(attributes);
			
			this.childrenMap = new HashMap<String, List<DiagramRepresentation>>();
		}
		
		/**
		 * getElement(..)
		 * --------------
		 * Gets the object this element is associated with.
		 */
		def getElement() {
			return this.element;
		}
		
		/**
		 * addChildren(..)
		 * ---------------
		 * Adds a list of children to this element.
		 */
		def void addChildren(String key, List<DiagramRepresentation> children) {			
			if (!childrenMap.containsKey(key)) {
				childrenMap.put(key, newArrayList);
			}
			childrenMap.get(key).addAll(children);
		}
		
		/**
		 * keySet(..)
		 * ----------
		 * Get the keys associated with the children.
		 */
		def keySet() {
			return childrenMap.keySet();
		}
		
		/**
		 * getChildren(..)
		 * ---------------
		 * Gets the children of this element.
		 */
		def getChildren(String key) {
			return this.childrenMap.get(key);
		}
		
		/**
		 * hasChildren(..)
		 * ---------------
		 * Returns true if this element has children.
		 */
		def hasChildren() {
			return !this.childrenMap.isEmpty();
		}
		
		/**
		 * getStartTag(..)
		 * ---------------
		 * Gets the tag for the start of an element.
		 */
		def getStartTag() {
			if (attributes.isEmpty()) {
				return String.format("<%s>", tag);
			}
			
			return String.format("<%s %s>", tag, getAttributes());
		}
		
		/**
		 * getEndTag(..)
		 * -------------
		 * Gets the tag for the end of an element.
		 */
		def getEndTag() {
			return String.format("</%s>", tag);
		}
		
		/**
		 * getOneLineTag(..)
		 * -----------------
		 * Gets the tag in a one line representation.
		 */
		def getOneLineTag() {
			if (attributes.isEmpty()) {
				return String.format("<%s/>", tag);
			}
			
			return String.format("<%s %s/>", tag, getAttributes());
		}
		
		/**
		 * addAttribute(..)
		 * ----------------
		 * Adds an attribute to this element.
		 */
		def addAttribute(String key, String value) {
			this.attributes.put(key, value);
		}
		
		/**
		 * addAttributes(..)
		 * -----------------
		 * Adds many attributes to this element.
		 */
		def addAttributes(Map<String, String> attributes) {
			this.attributes.putAll(attributes);
		}
		
		/**
		 * getAttribute(..)
		 * ----------------
		 * Gets an attribute from the element.
		 */
		def getAttribute(String key) {
			this.attributes.get(key);
		}
		
		/**
		 * getAttributes(..)
		 * -----------------
		 * Gets the attributes formatted into a string.
		 */
		def String getAttributes() {
			var args = newArrayList;
			
			// Create attribute-value pairs.
			for (key : attributes.keySet()) {
				args += String.format("%s=\"%s\"", key, attributes.get(key));
			}
			
			return String.join(" ", args);
		}
	}
}
