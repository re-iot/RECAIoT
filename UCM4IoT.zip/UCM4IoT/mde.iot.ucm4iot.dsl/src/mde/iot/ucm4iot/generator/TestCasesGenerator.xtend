package mde.iot.ucm4iot.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.UseCase
import java.util.stream.Collectors
import java.util.List
import org.eclipse.xtext.EcoreUtil2
import mde.iot.ucm4iot.ucm4iot.Step
import mde.iot.ucm4iot.Ucm4iotUtilities
import java.util.HashSet
import java.util.ArrayList
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock

class TestCasesGenerator extends IUcm4iotGeneratorImpl  {
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		var useCases = StreamSupport.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
  			.collect(Collectors.toList());
  		
  		var logs = newArrayList;
  		for (useCase : useCases) {
  			var log = createTestCase(useCases, useCase);
  			logs += log;
  		}
  		
  		createFile(fsa, folder, createFileName("testcases", ".csv"), String.join("\n\n\n", logs));
	}
	
	def createTestCase(List<UseCase> useCases, UseCase ctx) {
		var rows = newArrayList;
		rows += "Use Case: " + ctx.name;  // Displaying the name of the use case on top.
		
		System.out.println('test1');
		
		// Calculate paths
		var mainSteps = EcoreUtil2.getAllContentsOfType(ctx.main, Step).stream()
			.filter([step | Ucm4iotUtilities.hasStepNumber(step)])
			.collect(Collectors.toList());
		
		var header = newArrayList;
		header += "Path";
		
		System.out.println('test2');
		
		//header += "" + Ucm4iotUtilities.getStepNumber(step);
		var ArrayList<List<Step>> pathList = null;
		if (mainSteps.length > 0) {
			pathList = getPaths(ctx, mainSteps.get(0));
			
			for (path : pathList) {
				var pathoverview = path.stream()
					.map([step | Ucm4iotUtilities.getStepNumber(step)])
					.collect(Collectors.toList());
				
				header += "'" + String.join('-', pathoverview) + "'";
			}
		}
		
		System.out.println('test3');
		
		var paths = String.join(",", header);  // Header with paths
		
		// Get Test Steps for each path.
		var testSteps = newArrayList;
		testSteps += "Test Steps";
		
		for (path : pathList) {
			var pathDescription = path.stream()
				.map([step | Ucm4iotUtilities.getStepNumber(step) + '.' + step.description])
				.collect(Collectors.toList());
			
			testSteps += String.join(' >> ', pathDescription);
		}
		
		System.out.println('test4');
		
		var tests = String.join(",", testSteps);
		
		// Get Initial Condition for each path.
		var initialCondition = newArrayList;
		initialCondition += "Initial Condition";
		
		// Get Expected Result for each path.
		var expectedResult = newArrayList;
		expectedResult += "Expected Result";
		
		System.out.println('test5');
		
		var useCasePrecondition = ctx.precondition;
		if (useCasePrecondition === null || useCasePrecondition.isEmpty() || useCasePrecondition.trim().isEmpty()) {
			useCasePrecondition = "<precondition>";
		}
		
		var useCasePostcondition = ctx.postcondition;
		if (useCasePostcondition === null || useCasePostcondition.isEmpty() || useCasePostcondition.trim().isEmpty()) {
			useCasePostcondition = "<postcondition>";
		}
		
		System.out.println('test6');
		
		for (var i = 0; i < header.length-1; i++) {
			initialCondition += useCasePrecondition;
			expectedResult += useCasePostcondition;
		}
		
		System.out.println('test7');
		
		var preconditions = String.join(",", initialCondition);
		var postconditions = String.join(",", expectedResult);
		
		rows += paths;
		rows += preconditions;
		rows += tests;
		rows += postconditions;
		
		System.out.println('test8');
		
		return String.join("\n", rows);
	}
	
	def getPaths(UseCase ctx, Step firstStep) {
		var paths = newArrayList;
		getPathsHelper(ctx, paths, firstStep, newArrayList, new HashSet<Step>());
		return paths;
	}
	
	def void getPathsHelper(UseCase ctx, List<List<Step>> paths, Step currentStep, List<Step> currentPath, HashSet<Step> visited) {
		if (ctx === null || currentStep === null || visited.contains(currentStep)) {
			paths.add(new ArrayList<Step>(currentPath));
			return;
		}
		
		var mainSteps = EcoreUtil2.getAllContentsOfType(ctx.main, Step).stream()
			.filter([step | Ucm4iotUtilities.hasStepNumber(step)])
			.collect(Collectors.toList());
		
		var blocks = EcoreUtil2.getAllContentsOfType(ctx, ExtensionBlock).stream()
			.collect(Collectors.toList());
		
		// Recursive Depth+1
		visited.add(currentStep);
		currentPath.add(currentStep);
		
		if (mainSteps.contains(currentStep)) {
			var index = mainSteps.indexOf(currentStep);
			
			// Next step in the main scenario.
			var Step nextStep = null;
			if (index+1 < mainSteps.length) {
				nextStep = mainSteps.get(index+1);
			}
			
			getPathsHelper(ctx, paths, nextStep, currentPath, visited);  // recursively find paths.
			/*
			// Next step in the extensions.
			var blockIndex = blocks.stream()
				.map([block | block.getRefStep()])
				.collect(Collectors.toList())
				.indexOf(currentStep);  // TODO: get all
			
			if (blockIndex != -1) {
				var blockSteps = EcoreUtil2.getAllContentsOfType(blocks.get(blockIndex), Step).stream()
					.filter([step | Ucm4iotUtilities.hasStepNumber(step)])
					.collect(Collectors.toList());
				
				var Step blockStep = null;
				if (blockSteps.length > 0) {
					blockStep = blockSteps.get(0);
				}
				getPathsHelper(ctx, paths, blockStep, currentPath, visited);  // recursively find paths.
			} */
		} else {
			//getPathsHelper(ctx, paths, null, currentPath, visited);  // recursively find paths.
		}
		
		// Extensions....
		
		// Recursive Depth-1
		visited.remove(currentStep);
		currentPath.remove(currentStep);
	}
	
	
}