package mde.iot.ucm4iot.generator

import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Mode
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.AbstractGenerator
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext
import java.util.List
import mde.iot.ucm4iot.ucm4iot.ModeType
import java.util.function.Predicate
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.Ucm4iotUtilities
import org.eclipse.emf.common.util.EList
import org.eclipse.emf.ecore.EObject
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock

class ContextMenuModeTablesGenerator extends AbstractGenerator {

	static final String GEN_MODE_LIST = "modes/";

	Resource resource;

	override doGenerate(Resource input, IFileSystemAccess2 fsa, IGeneratorContext context) {
		var date = Calendar.getInstance().getTime();
		var dateFormat = new SimpleDateFormat("yyyy-MM-dd_hh.mm.ss/");

		generateCompleteModes(input, fsa, context, dateFormat.format(date) + GEN_MODE_LIST);
	}

	protected def void generateCompleteModes(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context,
		String folder) {

		this.resource = resource;

		try {

			// getAllModes(resource);
			val useCases = StreamSupport.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false).
				collect(Collectors.toList());

			var table = createModeTables(useCases)

			table += "\n"
			table += "\n"
			//table += createModeSummeryTables(useCases)

			// println(table);

			createFile(fsa, folder, createFileName("modes-table", ".txt"), String.join("\n\n\n", table));

		} catch (Throwable e) {
			e.printStackTrace()
		}
	}

	protected def List<Mode> getAllModes(Resource resource) {
		return StreamSupport.stream(resource.allContents.toIterable.filter(Mode).spliterator(), false).collect(
			Collectors.toList())
	}

	protected def String getDefaultModeName() {

		var defaultMode = StreamSupport.stream(this.resource.allContents.toIterable.filter(Mode).spliterator(), false).
			filter(new Predicate<Mode>() {
				override test(Mode mode) {
					mode.getType() === ModeType.NORMAL && mode.isDefault
				}

			}).findAny();

		if (defaultMode.isPresent()) {
			return defaultMode.get().getName();
		}

		return null;
	}

	protected def String createModeTables(Iterable<UseCase> useCases) {
		var modeTableRows = newArrayList;
		
		var exceptionalUseCases = newArrayList;
		var handlerUseCases = newArrayList;
		
		for (useCase : useCases) {
			var row = createRow(useCase);
			if (row !== null) {
				
				
				if(useCase instanceof ExceptionalUseCase){
					exceptionalUseCases.add(row);
				}
				if(useCase instanceof HandlerUseCase){
					handlerUseCases.add(row);
				}
				
				//modeTableRows.add(row);
			}
		}

		return createModesTable(exceptionalUseCases, handlerUseCases);
	}

	private def ArrayList<String> createRow(UseCase useCase) {

		var modeSwitch = getModeSwitch(useCase);
		var preMode = getPreModes(useCase)

		if (preMode === null && modeSwitch === null) {
			return null;
		}

		if (modeSwitch !== null) {
			var row = newArrayList

			var usecaseName = useCase.name;

			row.add(usecaseName);
			if (preMode === null) {
				row.add(getDefaultModeName());
			} else {
				row.add(preMode);
			}

			row.add(getModeSwitch(useCase));
			return row;
		}

		return null;
	}

	protected def String getPreModes(UseCase useCase) {
		var mainScenario = useCase.getMain();
		if (mainScenario !== null) {
			var preModeSwitch = mainScenario.getPreModeSwitch();
			if (preModeSwitch !== null) {
				return preModeSwitch.name;
			} else if (mainScenario.getPostModeSwitch() !== null) {
				return getDefaultModeName();
			}
		}

		return null;
	}



	protected def String getModeSwitch(UseCase useCase) {
		try {
			var modeSwitches = newArrayList;

			var mainScenario = useCase.getMain();
			if (mainScenario !== null) {
				var postModeSwitch = mainScenario.getPostModeSwitch();
				if (postModeSwitch !== null) {
					modeSwitches.add(postModeSwitch.name);
				}
			}

			var extensions = useCase.getExtensions();

			if (extensions !== null) {
				
				var blocks = extensions.getBlocks()
				
				for (block : blocks) {
					var modeSwitch = block.getPreModeSwitch();
					if (modeSwitch !== null) {
						modeSwitches.add(modeSwitch.name);
					}
					var postModeSwitch = block.getPostModeSwitch();
					if (postModeSwitch !== null) {
						modeSwitches.add(postModeSwitch.name);
					}
				}
			}

			if (modeSwitches.size() > 0) {
				return IterableExtensions.join(modeSwitches, ", ");
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}

		return null;
	}


	
	def getExtensionBlocks(EList<EObject> list) {
		throw new UnsupportedOperationException("TODO: auto-generated method stub")
	}


	private def String createModesTable(ArrayList<ArrayList<String>> exceptionalUseCases, ArrayList<ArrayList<String>> handlerUseCases) {
		var rows = newArrayList;

		// Creates the format of the table.
		var columns = #[25, 35];
		var titleFormat = createTableFormat(columns.stream.reduce(0, [a, b|a + b]) + columns.size - 1);
		var titleLine = String.format(titleFormat, "").replace(" ", "-").replace("|", "+");
		var format = createTableFormat(columns);
		var line = String.format(format, "", "", "", "", "", "", "").replace(" ", "-").replace("|", "+");

		// Adds the title of the table.
		rows += titleLine;
		rows += String.format(titleFormat, " Mode Table: ");

		// Builds the content of the table.
		rows += line;
		rows += String.format(format, " Use Case Name", " Switched Mode");
		rows += line;

		for (item : exceptionalUseCases) {
			rows += String.format(format, item.get(0), item.get(1) + " --> " + item.get(2));
		}
		
		rows += line;
		for (item : handlerUseCases) {
			rows += String.format(format, item.get(0), item.get(1) + " --> " + item.get(2));
		}

		rows += line;
		return String.join("\n", rows);

	}

	private def String createTableFormat(int... columnSizes) {
		var formatBuilder = new StringBuilder();

		// Builds the format.
		for (size : columnSizes) {
			formatBuilder.append(String.format(" %%-%ds ", size));
		}

		return formatBuilder.toString().replaceAll(" +", " ").replaceAll(" ", "|");
	}

	def createModeSummeryTables(Iterable<UseCase> useCases) {
		var normalMode = newArrayList
		var emergencyMode = newArrayList
		var restrictedMode = newArrayList
		var degradedMode = newArrayList

		for (useCase : useCases) {

			var mainScenario = useCase.getMain();

			if (mainScenario !== null) {
				var preModeSwitch = mainScenario.getPreModeSwitch();
				if (preModeSwitch === null) {
					normalMode.add(useCase.name)
				} else {
					switch (preModeSwitch.name) {
						case "Normal":
							normalMode.add(useCase.name)
						case "Emergency":
							emergencyMode.add(useCase.name)
						case "Restricted":
							restrictedMode.add(useCase.name)
						case "Degraded":
							degradedMode.add(useCase.name)
					}
				}
			}

			var extensions = useCase.getExtensions();

			if (extensions !== null) {
				var blocks = extensions.getBlocks()
				for (block : blocks) {
					var modeSwitch = block.getPreModeSwitch();
					if (modeSwitch !== null) {
						switch (modeSwitch.name) {
							case "Normal":
								normalMode.add(useCase.name)
							case "Emergency":
								emergencyMode.add(useCase.name)
							case "Restricted":
								restrictedMode.add(useCase.name)
							case "Degraded":
								degradedMode.add(useCase.name)
						}
					}

					var postModeSwitch = block.getPostModeSwitch();

					if (postModeSwitch !== null) {
						switch (postModeSwitch.name) {
							case "Normal":
								normalMode.add(useCase.name)
							case "Emergency":
								emergencyMode.add(useCase.name)
							case "Restricted":
								restrictedMode.add(useCase.name)
							case "Degraded":
								degradedMode.add(useCase.name)
						}
					}
				}
			}
		}

		var normalModesInString = IterableExtensions.join(normalMode, ", ")
		var emergencyModesInString = IterableExtensions.join(emergencyMode, ", ")
		var restrictedModesInString = IterableExtensions.join(restrictedMode, ", ")
		var degradedModeInString = IterableExtensions.join(degradedMode, ", ")

		var columnWidth = Math.max(Math.max(normalModesInString.length, emergencyModesInString.length),
			Math.max(restrictedModesInString.length, degradedModeInString.length));

		// Mode summary table
		// mode names, uses cases
		// Creates the format of the table.
		var rows = newArrayList;
		var columns = #[25, columnWidth];
		var titleFormat = createTableFormat(columns.stream.reduce(0, [a, b|a + b]) + columns.size - 1);
		var titleLine = String.format(titleFormat, "").replace(" ", "-").replace("|", "+");
		var format = createTableFormat(columns);
		var line = String.format(format, "", "").replace(" ", "-").replace("|", "+");

		// Adds the title of the table.
		rows += titleLine;
		rows += String.format(titleFormat, " Mode Summary Table: ");

		// Builds the content of the table.
		rows += line;
		rows += String.format(format, "Mode Names", " Uses Cases");
		rows += line;

		rows += String.format(format, "Normal", normalModesInString);
		rows += String.format(format, "Emergency", emergencyModesInString);
		rows += String.format(format, "Restricted", restrictedModesInString);
		rows += String.format(format, "Degraded", degradedModeInString);

		rows += line;

		return String.join("\n", rows);
	}

	private def String createFileName(String name, String ext) {
		if (ext !== null && ext.trim().isEmpty() && !ext.startsWith(".")) {
			throw new IllegalArgumentException(
				"File extension is not valid. Make sure passed argument begins with '.'");
		}

		return name + ext;
	}

	private def void createFile(IFileSystemAccess2 fsa, String path, String file, String data) {
		fsa.generateFile(path + "/" + file, data);
	}

}
