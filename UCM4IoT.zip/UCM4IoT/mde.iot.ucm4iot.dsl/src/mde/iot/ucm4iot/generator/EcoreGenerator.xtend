package mde.iot.ucm4iot.generator

import java.io.IOException
import java.util.HashMap
import org.eclipse.emf.common.util.URI
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.emf.ecore.xmi.XMLResource
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

class EcoreGenerator extends IUcm4iotGeneratorImpl {
	
	/**
	 * generate(..)
	 * ------------
	 * Generates an ecore file from a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	/**
	 * generate(..)
	 * ------------
	 * Generates an ecore file from a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
        try {
			var saveOptions = new HashMap<String, String>();
			saveOptions.put(XMLResource.OPTION_ENCODING,"UTF-8");
			
			var path = resource.getURI().toString().replace("ucmiot", "ucmiot.xmi");
			var xmiResource = new XMIResourceImpl(URI.createURI(path));
			
			xmiResource.getContents().add(resource.getContents().get(0));
			xmiResource.save(saveOptions);
			System.out.println("Xmi file created.");
		} catch (IOException e) {
			System.out.println("Error during creating Xmi.");
			e.printStackTrace();
		}
	}
} // Class EcoreGenerator
