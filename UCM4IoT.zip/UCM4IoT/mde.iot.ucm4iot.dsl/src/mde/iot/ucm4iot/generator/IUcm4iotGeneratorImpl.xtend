package mde.iot.ucm4iot.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext
import java.util.List
import java.util.Collections
import java.util.stream.Collectors
import java.util.stream.Stream
import java.util.HashMap
import java.util.function.Function

/**
 * Class: IUcm4iotGeneratorImpl
 * ----------------------------
 * Implementation of the IUcm4iotGenerator interface.
 */
abstract class IUcm4iotGeneratorImpl implements IUcm4iotGenerator {
	
	override void generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context);
	override void generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder);
	
	/**
	 * createFileName(..)
	 * ------------------
	 * Creates a file name with a given file extension.
	 */
	override String createFileName(String name, String ext) {
		if (ext !== null && ext.trim().isEmpty() && !ext.startsWith(".")) {
			throw new IllegalArgumentException("File extension is not valid. Make sure passed argument begins with '.'");
		}
		
		return name + ext;
	}
	
	/**
	 * createFile(..)
	 * --------------
	 * Creates a file.
	 */
	override void createFile(IFileSystemAccess2 fsa, String path, String file, String data) {
		fsa.generateFile(path + "/" + file, data);
	}
	
	/**
	 * createTableFormat(..)
	 * ---------------------
	 * Creates the format of a table.
	 */
	protected def String createTableFormat(int... columnSizes) {
		var formatBuilder = new StringBuilder();
		
		// Builds the format.
		for (size : columnSizes) {
			formatBuilder.append(String.format(" %%-%ds ", size));
		}
		
		return formatBuilder
				.toString()
				.replaceAll(" +", " ")
				.replaceAll(" ", "|");
	}

	/**
	 * fitColumnWidth(..)
	 * ------------------
	 * Generic function to transform the values from a hash table into string representations.
	 */
	protected def <T, U> fitColumnWidth(String columnName, int defaultSize, HashMap<T, U> table, Function<U, List<String>> getData) {
		var n = 0;
		
		// Converts the values from table into a column of string representations.
		for (key : table.keySet()) {
			var value = table.get(key);
			var temp = fitColumnWidth(columnName, defaultSize, getData.apply(value));
			n = Math.max(temp, n);
		}
		
		var temp = fitColumnWidth(columnName, defaultSize, #[])
		n = Math.max(temp, n);
		
		return n;
	}
	
	/**
	 * fitColumnWidth(..)
	 * ------------------
	 * Fit the column width to the largest element in the column.
	 */
	protected def fitColumnWidth(String columnName, int defaultSize, List<String> values) {
		var list = Stream.concat(#[columnName].stream(), values.stream())
			.collect(Collectors.toList());
		
		var maxLength = Collections.max(list.stream()
			.map([str | str.length])
			.collect(Collectors.toList())
		);
		
		return Math.max(maxLength, defaultSize) + 2;
	}
	
	/**
	 * maxSize(..)
	 * -----------
	 * Gets the maximum column size.
	 */
	protected def maxSize(List<String>... columns) {
		return Collections.max(columns.stream()
			.map([list | list.size()])
			.collect(Collectors.toList())
		);
	}
	
	/**
	 * getDataOrDefault(..)
	 * --------------------
	 * Gets data from a particular index if it exists; otherwise get nothing.
	 */
	protected def getDataOrDefault(int i, List<String>... columns) {
		return columns.stream()
			.map([list | getDataOrDefaultHelper(i, list)])
			.toArray();
	}
	
	/**
	 * getDataOrDefaultHelper(..)
	 * --------------------------
	 * Gets data from a particular index if it exists; otherwise get nothing.
	 */
	protected def getDataOrDefaultHelper(int i, List<String> list) {
		if (i < list.size()) {
			return " " + list.get(i);
		} else {
			return " "
		}
	}
}
