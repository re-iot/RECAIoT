package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.HashMap
import java.util.HashSet
import java.util.List
import java.util.Map
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.Ucm4iotUtilities
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.HumanActor
import mde.iot.ucm4iot.ucm4iot.InteractionStep
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.MainScenario
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.OutcomeEndings
import mde.iot.ucm4iot.ucm4iot.OutcomeEnds
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.Step
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

/**
 * Obsolete - Feel free to remove.
 * 
 * Class: SummaryTableGenerator
 * ----------------------------
 * Generates Exception Summary Tables.
 */
class SummaryTableGenerator extends IUcm4iotGeneratorImpl {
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	/**
	 * generate(..)
	 * ------------
	 * Generates summary tables for all use cases within a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		var useCases = StreamSupport.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
  			.collect(Collectors.toList());
  			
  		var logs = newArrayList;
  		for (useCase : useCases) {
  			var log = generateTable(useCases, useCase);
  			createFile(fsa, folder, createFileName("exceptionTable-" + useCase.getName(), ".txt"), log);
  			logs += log;
  		}
  		
  		createFile(fsa, folder, createFileName("exceptionTables", ".txt"), String.join("\n\n\n", logs));
	}
	
	/**
	 * generateTable(..)
	 * -----------------
	 * Generates a summary table for the passed use case.
	 */
	protected def String generateTable(List<UseCase> useCases, UseCase ctx) {
		var table = #{
			'exceptions' -> newArrayList,
			'interrupts' -> newArrayList,
			'sources'    -> newArrayList,
			'levels'     -> newArrayList,
			'globals'    -> newArrayList,
			'handlers'   -> newArrayList
		};
		
		var pathMap = newLinkedHashMap;
		var actorMap = newLinkedHashMap;
		
		getExceptions(ctx, table, new HashSet());
		getGlobalExceptions(useCases, ctx, ctx, table, new HashSet());
		getHandlers(useCases, table);
		getPaths(useCases, ctx, table, pathMap);
		getExceptionActors(table, actorMap);
		
		return createExceptionTable(ctx, table, pathMap, actorMap);
	}
	
	/**
	 * getExceptions(..)
	 * -----------------
	 * Gets exceptions recursively.
	 */
	protected def void getExceptions(UseCase ctx, Map<String, ArrayList<Object>> table, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			return;
		}
		
		var foundExceptions = EcoreUtil2.getAllContentsOfType(ctx, ExceptionStep).stream
			.map([step | step.refException])
			.collect(Collectors.toList());
		
		for (exception : foundExceptions) {
				table.get('exceptions').add(exception);
				table.get('interrupts').add(getInterruptType(ctx, exception));
				table.get('sources').add(ctx);
				table.get('levels').add(ctx.level);
				table.get('globals').add(false);
		}
		
		visited.add(ctx);
		
		// Traverse downwards (the use cases invoked by the current use case).
		var invokedUseCases = ctx.getInvokedUseCases;
		for (invokedUseCase : invokedUseCases) {
			getExceptions(invokedUseCase, table, visited);
		}
	}
	
	/**
	 * getGlobalExceptions(..)
	 * -----------------------
	 * Get global exceptions by searching recursively upwards.
	 */
	protected def void getGlobalExceptions(List<UseCase> useCases, UseCase start, UseCase ctx, Map<String, ArrayList<Object>> table, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			return;
		}
		
		// Assuming that environment exceptions are global.
		var foundExceptions = EcoreUtil2.getAllContentsOfType(ctx, ExceptionStep).stream
			.map([step | step.refException])
			.filter([step | step instanceof EnvironmentException])
			.collect(Collectors.toList());
		
		// Assuming that any exception not included in the table must be global.
		for (exception : foundExceptions) {
			if (!table.get('exceptions').contains(exception)) {
				table.get('exceptions').add(exception);
				table.get('interrupts').add(getInterruptType(ctx, exception));
				table.get('sources').add(ctx);
				table.get('levels').add(ctx.level);
				table.get('globals').add(true);
			}
		}
		
		visited.add(ctx);
		
		// Traverse upwards (the use cases that invoke the current use case).
		var parents = findParentUseCases(useCases, ctx);
		for (parent : parents) {
			getGlobalExceptions(useCases, start, parent, table, visited);
		}
	}
	
	/**
	 * getHandlers(..)
	 * ---------------
	 * Gets a handler that handles the given exception.
	 */
	protected def void getHandlers(List<UseCase> useCases, Map<String, ArrayList<Object>> table) {
		var potentialHandlers = useCases.stream
			.filter([useCase | useCase instanceof HandlerUseCase])
			.map([useCase | useCase as HandlerUseCase])
			.collect(Collectors.toList());
		
		// Find a handler that handles the exception.
		for (exception : table.get('exceptions')) {
			table.get('handlers').add(Ucm4iotUtilities.findHandlerForException(potentialHandlers, exception as Exception));
		}
	}
	
	/**
	 * getExceptionActors(..)
	 * ----------------------
	 * Gets the actors that appear when an exception is raised.
	 */
	protected def void getExceptionActors(Map<String, ArrayList<Object>> table, HashMap<Exception, List<Actor>> actorMap) {
		for (var n = 0; n < table.get('exceptions').size; n++) {
			val exception = table.get('exceptions').get(n) as Exception;
			var useCase = table.get('sources').get(n) as UseCase;
			
			// Pick the first step encountered (arbitrarily) as the step that was raised.
			var relevantSteps = EcoreUtil2.getAllContentsOfType(useCase, ExceptionStep).stream
				.filter([step | step.refException === exception])
				.collect(Collectors.toList());
			var step = relevantSteps.get(0) as Step;
			
			// Filter for actors mentioned in the relevant steps.
			var actors = new HashSet<Actor>();
			var list = #[step];
			
			getExceptionActorsHelper(useCase, list, Ucm4iotUtilities.getActors(useCase), actors);
			
			actorMap.put(exception, new ArrayList<Actor>(actors));
		}
	}
	
	private def void getExceptionActorsHelper(UseCase useCase, List<Step> steps, List<Actor> poss_actors, HashSet<Actor> actors) {
		if (steps.size == 0) {
			return;
		}
		
		// Filter for actors found within the list of steps
		for (step : steps) {
			if (step instanceof InteractionStep && !step.isIgnoreDescription) {
				var actorsInStep = poss_actors.stream()
						.filter([actor | hasWord(step, Ucm4iotUtilities.getActorName(actor))])
						.collect(Collectors.toSet());
				
				actors.addAll(actorsInStep);
			}
		} // for (step)
		
		var block = EcoreUtil2.getContainerOfType(steps.get(0), ExtensionBlock);
		if (block !== null) {
			var parentStep = block.refStep;
			
			// Get parent steps;
			var list = newArrayList;
			list.add(parentStep);
			
			if (block.hasRangedRef) {
				var flow = getSurroundingStep(parentStep).stream()
						.collect(Collectors.toList());
				
				var include = false;
				for (s : flow) {
					if (s === block.refStep) {
						include = true;
					} else if (s === block.endRefStep) {
						include = false;
					}
					
					if (include == true) {
						list.add(s);
					}
				}
			}
			
			getExceptionActorsHelper(useCase, list, poss_actors, actors);
		}
	}
	
	private def List<Step> getSurroundingStep(Step step) {
		var steps = newArrayList;
		
		if (step.eContainer() instanceof ExtensionBlock) {
			var block = EcoreUtil2.getContainerOfType(step, ExtensionBlock);
			steps = new ArrayList<Step>(block.steps);
		} else if (step.eContainer() instanceof MainScenario) {
			var main = EcoreUtil2.getContainerOfType(step, MainScenario);
			steps = new ArrayList<Step>(main.steps);
		}
		
		return steps;
	}
	
	/**
	 * getPaths(..)
	 * ------------
	 * Gets the paths that lead to an exception occurring.
	 */
	protected def void getPaths(List<UseCase> useCases, UseCase ctx, Map<String, ArrayList<Object>> table, HashMap<Exception, List<String>> pathMap) {
		var handlers = useCases.stream
			.filter([useCase | useCase instanceof HandlerUseCase])
			.map([useCase | useCase as HandlerUseCase])
			.collect(Collectors.toList());
		
		// Finds the handlers that end a given path.
		for (var n = 0; n < table.get('exceptions').size; n++) {
			var exception = table.get('exceptions').get(n) as Exception;
			
			var parentHandlers = Ucm4iotUtilities.findHandlersForException(handlers, exception);
			var parentHandlerPaths = new ArrayList<String>();
			
			for (handler : parentHandlers) {
				var parentHandlerUseCases = newArrayList;
				var parentHandlerLevels = newArrayList;
				
				getPathsHelper(useCases, parentHandlerUseCases, parentHandlerLevels, handler, 0, new HashSet());
				for (var i = 0; i < parentHandlerUseCases.size; i++) {
					var path = createPath(parentHandlerUseCases, parentHandlerLevels, i);
					
					if (path.startsWith(handler.name)) {
						path = path.replaceFirst(handler.name, "{" + handler.name + "}")
						parentHandlerPaths.add(path);
					}
				}
			} // for (handlers)
			
			// Find the invocations that begin a given path.
			var source = table.get('sources').get(n) as UseCase;
			var isGlobal = table.get('globals').get(n) as Boolean;
			
			var parentUseCases = newArrayList;
			var levels = newArrayList;
			
			getPathsHelper(useCases, parentUseCases, levels, source, 0, new HashSet());
			
			// Adds the paths that lead to the exception occurring.
			var paths = new ArrayList<String>();
			for (var i = 0; i < parentUseCases.size; i++) {
				var path = createPath(parentUseCases, levels, i);
				
				if (isGlobal) {
					if (parentHandlerPaths.size > 0) {
						for (handlerPath : parentHandlerPaths) {
								paths.add("GLOBAL::" + ctx.name + " >> " + handlerPath);
						}
					} else {
						paths.add("GLOBAL::" + ctx.name + " >> {~No Handler~}");
					}
				} else {
					if (path.startsWith(ctx.name)) {
						if (parentHandlerPaths.size > 0) {
							for (handlerPath : parentHandlerPaths) {
								paths.add(path + " >> " + handlerPath);
							}
						} else {
							paths.add(path + " >> {~No Handler~}");
						}
					}
				}
				
				pathMap.put(exception, paths);
			} // for (i < parentUseCases)
		} // for (n < exceptions)
	} // getPaths(..)
	
	private def void getPathsHelper(List<UseCase> useCases, List<UseCase> containers, List<Integer> levels, UseCase ctx, int level, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			return;
		}
		
		// Add current use case to the list of use cases.
		containers.add(ctx);
		levels.add(level);
		
		visited.add(ctx);
		
		// Traverse upwards (the use cases that invoke the current use case).
		var parents = findParentUseCases(useCases, ctx);
		for (parent : parents) {
			getPathsHelper(useCases, containers, levels, parent, level+1, visited);
		}
		
		visited.remove(ctx);
	}
	
	private def String createPath(List<UseCase> parentUseCases, List<Integer> levels, int index) {
		var path = new StringBuilder();
		path.append(parentUseCases.get(index).name);
		
		// Finds the path.
		var level = levels.get(index) - 1;
		for (var i = index; i >= 0; i--) {
			if (levels.get(i) == level) {
				path.append(" -> ");
				path.append(parentUseCases.get(i).name);
				level--;
			}
		}
		
		return path.toString();
	}
	
	/**
	 * getInvokedUseCases(..)
	 * ----------------------
	 * Gets the invoked use cases within a use case.
	 */
	protected def List<UseCase> getInvokedUseCases(UseCase useCase) {
		var invocations = EcoreUtil2.getAllContentsOfType(useCase, InvocationStep).stream
			.map([step | step.invokedUseCase])
			.collect(Collectors.toList());
		
		return invocations;
	}
	
	/**
	 * findParentUseCases(..)
	 * ----------------------
	 * Find use cases that invoke the given use case.
	 */
	protected def List<UseCase> findParentUseCases(List<UseCase> useCases, UseCase invokedUseCase) {
		var parentUseCases = newArrayList;
		
		for (useCase : useCases) {
			var hasInvokedUseCase = EcoreUtil2.getAllContentsOfType(useCase, InvocationStep).stream
				.anyMatch([step | step.invokedUseCase === invokedUseCase]);
				
			if (hasInvokedUseCase) {
				parentUseCases.add(useCase)
			}
		}
		
		return parentUseCases;
	}
	
	/**
	 * getInterruptType(..)
	 * --------------------
	 * Determine the interrupt type of an exception within a use case.
	 */
	protected def String getInterruptType(UseCase useCase, Exception exception) {
		var relevantSteps = EcoreUtil2.getAllContentsOfType(useCase, ExceptionStep).stream
			.filter([step | step.refException === exception])
			.collect(Collectors.toList());
		
		// Pick the first occurrence of the exception (arbitrarily) and determine interrupt type.
		var block = EcoreUtil2.getContainerOfType(relevantSteps.get(0), ExtensionBlock);
		if (block.outcome instanceof OutcomeContinues) {
			return "Interrupt and continue";
		} else {
			var outcome = block.outcome as OutcomeEnds;
			
			if (outcome.type == OutcomeEndings.FAILURE) {
				return "Interrupt and fail";
			} else {
				return "Unknown";
			}
		}
	}
	
	/**
	 * getActorNameAndType(..)
	 * -----------------------
	 * Gets the name of an actor.
	 */
	def String getActorNameAndType(Actor actor) {
		if (actor instanceof DeviceActor) {
			return "DEVICE::" + (actor as DeviceActor).getName();
		} else if (actor instanceof PhysicalEntityActor) {
			return "PHYSICAL_ENTITY::" + (actor as PhysicalEntityActor).getName();
		} else if (actor instanceof SoftwareActor) {
			return "SOFTWARE::" + (actor as SoftwareActor).getName();
		} else {
			return "HUMAN::" + (actor as HumanActor).getName();
		}
	}
	
	/**
	 * hasWord(..)
	 * -----------
	 * Returns true if a step has the passed word; false otherwise.
	 */
	def boolean hasWord(Step step, String value) {
		var description = step.getDescription();
		if (description === null) {
			description = "";
		}
		
		var words = description
				.replaceAll("[^a-zA-Z0-9]", " ")
				.split("\\s+");
		
		// Check if any words match the passed String.
		for (String word : words) {
			if (value.equals(word)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * createExceptionTable(..)
	 * ------------------------
	 * Creates the table.
	 */
	private def String createExceptionTable(UseCase ctx, Map<String, ArrayList<Object>> table, HashMap<Exception, List<String>> pathMap, HashMap<Exception, List<Actor>> actorMap) {
		var rows = newArrayList;
		
		// Creates the format of the table.
		var columns = #[22, 26, 25, 30, 20, 24, 180];
		var titleFormat = createTableFormat(columns.stream.reduce(0, [a,b | a+b]) + columns.size - 1);
		var titleLine = String.format(titleFormat, "").replace(" ", "-").replace("|", "+");
		var format = createTableFormat(columns);
		var line = String.format(format, "", "", "", "", "", "", "").replace(" ", "-").replace("|", "+");
		var subLine = String.format(line
			.replaceFirst("-+", String.format("%%-%ds", columns.get(0)))
			.replaceFirst("\\+", "|"), ""
		);
		
		// Adds the title of the table.
		rows += titleLine;
		if (ctx instanceof ExceptionalUseCase) {
			rows += String.format(titleFormat, " Exceptional Use Case: " + ctx.name);
		} else if (ctx instanceof HandlerUseCase) {
			rows += String.format(titleFormat, " Handler Use Case: " + ctx.name);
		}
		
		// Builds the content of the table.
		rows += line;
		rows += String.format(format, " Exception Type", " Exception Name", " Exception Source", " Associated Actors", " Handler", " Interrupt Type", " Path >> {HANDLER}");
		rows += line;
		
		// Sort the exceptions into their type.
		var types = #[typeof(HardwareException), typeof(SoftwareException), typeof(NetworkException), typeof(EnvironmentException)];
		for (type : types) {
			var newGroup = 0;
			var elmAdded = false;
			
			// Looks through every exception.
			for (var i = 0; i < table.get('exceptions').size; i++) {
				var exception = table.get('exceptions').get(i) as Exception;
				var interrupt = table.get('interrupts').get(i) as String;
				var source    = table.get('sources').get(i)    as UseCase;
				var handler   = table.get('handlers').get(i)   as HandlerUseCase;
				var paths  = pathMap.get(exception);
				var actors = actorMap.get(exception);
				
				if (type.isInstance(exception)) {
					var exceptionGroup = (newGroup++ == 0) ? (" " + type.getSimpleName()) : "";
					var exceptionName = " " + exception.name;
					var sourceName = " " + source.name;
					var handlerName = (handler !== null) ? (" " + handler.name) : " n/a";
					var interruptType = " " + interrupt;
					
					// Logic for printing out rows in a organized way.
					if (actors.size > 0) {
						var actorName = " "+ getActorNameAndType(actors.get(0));
						var path = " " + paths.get(0);
						rows += String.format(format, exceptionGroup, exceptionName, sourceName, actorName, handlerName, interruptType, path);
					} else {
						var path = " " + paths.get(0);
						rows += String.format(format, exceptionGroup, exceptionName, sourceName, " n/a", handlerName, interruptType, path);
					}
					
					var j = 1;
					for (; j < paths.size && j < actors.size; j++) {
						var actorName = " " + getActorNameAndType(actors.get(j));
						var path = " " + paths.get(j);
						rows += String.format(format, "", "", "", actorName, "", "", path);
					}
					
					for (; j < paths.size; j++) {
						var path = " " + paths.get(j);
						rows += String.format(format, "", "", "", "", "", "", path);
					}
					
					for (; j < actors.size; j++) {
						var actorName = " " + getActorNameAndType(actors.get(j));
						rows += String.format(format, "", "", "", actorName, "", "", "");
					}
					
					rows += subLine;
					elmAdded = true;
				} // if (type)
			} // for (i < table)
			
			// Removes the last subLine.
			if (rows.get(rows.size - 1).equals(subLine)) {
				rows.remove(rows.size - 1);
			}
			
			// Adds a line at the bottom of a group of exceptions if at least one exception was added.
			if (elmAdded) {
				rows += line;
			}
		} // for (type)
		
		return String.join("\n", rows);
	}
} // Class SummaryTableGenerator
