package mde.iot.ucm4iot.generator

import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import java.util.Map
import java.util.function.Function
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.HumanActor
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import java.util.Map
import java.util.function.Function
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.HumanActor
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

import static extension org.eclipse.xtext.EcoreUtil2.*

class YakinduStateChartGenerator extends IUcm4iotGeneratorImpl {
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		var data = createYakinduStateChart(resource);
		createFile(fsa, folder, createFileName("statechart", ".sgraph"), data);
	}
	
	def String createYakinduStateChart(Resource resource) {
		var table = createTable(resource);
		
		// Creates a use case diagram.
		var tag = "sgraph:StateChart";
		var attributes = #{
			'xmi:version'          -> '2.0',
			'xmlns:xmi'            -> 'http://www.omg.org/XMI',
			'xmlns:xsi'            -> 'http://www.w3.org/2001/XMLSchema-instance',
			'xmlns:usecasediagram' -> 'http://www.yakindu.org/sct/sgraph/2.0.0'
		};
		
		var root = new DiagramRepresentation(null, tag, attributes);
		//linkScopes(table, root);
		//linkActors(table, root);
		//addAssociations(root);
		
		var data = createDiagram(root);
		return String.join("\n", data);
	}
	
	/**
	 * createTable(..)
	 * ---------------
	 * Creates a table of information.
	 */
	protected def HashMap<String, List<EObject>> createTable(Resource resource) {
		var useCases = StreamSupport
			.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var actors = StreamSupport
			.stream(resource.allContents.toIterable.filter(Actor).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var exceptions = StreamSupport
			.stream(resource.allContents.toIterable.filter(Exception).spliterator(), false)
			.map([eo | eo as EObject])
			.collect(Collectors.toList());
		
		var table = new HashMap<String, List<EObject>>();
		table.put('use_cases',  useCases);
		table.put('actors',     actors);
		table.put('exceptions', exceptions)
		
		return table;
	}
	
	
	/**
	 * createDiagram(..)
	 * -----------------
	 * Creates a diagram.
	 */
	protected def List<String> createDiagram(DiagramRepresentation rep) {
		var data = newArrayList;
		data += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		createDiagramHelper(rep, 0, data);
		return data;
	}
	
	/**
	 * createDiagramHelper(..)
	 * -----------------------
	 * Recursively goes through a diagram representation and outputs a diagram.
	 */
	private def void createDiagramHelper(DiagramRepresentation rep, int depth, ArrayList<String> output) {
		if (rep === null) {
			return;
		}
		
		// Gets the appropriate tag of this element.
		if (rep.hasChildren()) {
			output += createTabs(depth) + rep.getStartTag();
			
			// Recursively goes through each child.
			for (key : rep.keySet()) {
				for (child : rep.getChildren(key)) {
					createDiagramHelper(child, depth+1, output);
				}
			}
			
			output += createTabs(depth) + rep.getEndTag();
		} else {
			output += createTabs(depth) + rep.getOneLineTag();
		}
	}
	
	/**
	 * createTab(..)
	 * -------------
	 * Creates a string with the specified number of tabs.
	 */
	private def String createTabs(int indents) {
		var builder = new StringBuilder();
		builder.append("");
		
		// Repeat the number of tabs.
		for (var i = 0; i < indents; i++) {
			builder.append("\t")
		}
		
		return builder.toString();
	}
	
	/**
	 * Class: DiagramRepresentation
	 * ----------------------------
	 * Creates a representation of a diagram.
	 */
	protected static class DiagramRepresentation {
		// Ecore representation.
		EObject element;
		HashMap<String, List<DiagramRepresentation>> childrenMap;
		
		// Diagram representation.
		String tag;
		Map<String, String> attributes;
		
		/**
		 * Creates a new diagram representation.
		 */
		new (EObject element, String tag) {
			this(element, tag, new HashMap<String, String>());
		}
		
		/**
		 * Creates a new diagram representation.
		 */
		new (EObject element, String tag, Map<String, String> attributes) {
			this.element = element;
			this.tag = tag;
			
			this.attributes = new HashMap<String, String>();
			this.attributes.putAll(attributes);
			
			this.childrenMap = new HashMap<String, List<DiagramRepresentation>>();
		}
		
		/**
		 * getElement(..)
		 * --------------
		 * Gets the object this element is associated with.
		 */
		def getElement() {
			return this.element;
		}
		
		/**
		 * addChildren(..)
		 * ---------------
		 * Adds a list of children to this element.
		 */
		def void addChildren(String key, List<DiagramRepresentation> children) {			
			if (!childrenMap.containsKey(key)) {
				childrenMap.put(key, newArrayList);
			}
			childrenMap.get(key).addAll(children);
		}
		
		/**
		 * keySet(..)
		 * ----------
		 * Get the keys associated with the children.
		 */
		def keySet() {
			return childrenMap.keySet();
		}
		
		/**
		 * getChildren(..)
		 * ---------------
		 * Gets the children of this element.
		 */
		def getChildren(String key) {
			return this.childrenMap.get(key);
		}
		
		/**
		 * hasChildren(..)
		 * ---------------
		 * Returns true if this element has children.
		 */
		def hasChildren() {
			return !this.childrenMap.isEmpty();
		}
		
		/**
		 * getStartTag(..)
		 * ---------------
		 * Gets the tag for the start of an element.
		 */
		def getStartTag() {
			if (attributes.isEmpty()) {
				return String.format("<%s>", tag);
			}
			
			return String.format("<%s %s>", tag, getAttributes());
		}
		
		/**
		 * getEndTag(..)
		 * -------------
		 * Gets the tag for the end of an element.
		 */
		def getEndTag() {
			return String.format("</%s>", tag);
		}
		
		/**
		 * getOneLineTag(..)
		 * -----------------
		 * Gets the tag in a one line representation.
		 */
		def getOneLineTag() {
			if (attributes.isEmpty()) {
				return String.format("<%s/>", tag);
			}
			
			return String.format("<%s %s/>", tag, getAttributes());
		}
		
		/**
		 * addAttribute(..)
		 * ----------------
		 * Adds an attribute to this element.
		 */
		def addAttribute(String key, String value) {
			this.attributes.put(key, value);
		}
		
		/**
		 * addAttributes(..)
		 * -----------------
		 * Adds many attributes to this element.
		 */
		def addAttributes(Map<String, String> attributes) {
			this.attributes.putAll(attributes);
		}
		
		/**
		 * getAttribute(..)
		 * ----------------
		 * Gets an attribute from the element.
		 */
		def getAttribute(String key) {
			this.attributes.get(key);
		}
		
		/**
		 * getAttributes(..)
		 * -----------------
		 * Gets the attributes formatted into a string.
		 */
		def String getAttributes() {
			var args = newArrayList;
			
			// Create attribute-value pairs.
			for (key : attributes.keySet()) {
				args += String.format("%s=\"%s\"", key, attributes.get(key));
			}
			
			return String.join(" ", args);
		}
	}
}