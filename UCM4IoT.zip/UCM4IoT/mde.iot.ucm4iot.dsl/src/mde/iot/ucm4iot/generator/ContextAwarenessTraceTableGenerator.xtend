package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.HashSet
import java.util.List
import java.util.stream.Collectors
import mde.iot.ucm4iot.ucm4iot.ContextAwarenessEnabledUseCase
import mde.iot.ucm4iot.ucm4iot.ContextItem
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.UseCase
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

/**
 * Obsolete - Feel free to remove.
 * 
 * Class: SummaryTableGenerator
 * ----------------------------
 * Generates Exception Summary Tables.
 */
class ContextAwarenessTraceTableGenerator extends IUcm4iotGeneratorImpl {

	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}

	/**
	 * generate(..)
	 * ------------
	 * Generates summary tables for all use cases within a ucm4iot model.
	 */
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		val useCases = resource.allContents.toIterable.filter[it instanceof ContextAwarenessEnabledUseCase].map [
			it as ContextAwarenessEnabledUseCase
		].toList

		val allContextItems = resource.allContents.toIterable.filter[it instanceof ContextItem].map [
			it as ContextItem
		].toList

		var table = createContextSummaryTable(allContextItems, useCases, resource);

		createFile(fsa, folder, createFileName("CaTraceTable ", ".txt"), table);
	}

	protected def getParents(List<UseCase> useCases, UseCase invokedUseCase) {
		var parentUseCases = newArrayList;

		// Checks which use cases invoke the passed use case.
		for (useCase : useCases) {
			var hasInvokedUseCase = EcoreUtil2.getAllContentsOfType(useCase, InvocationStep).stream.anyMatch([ step |
				step.invokedUseCase === invokedUseCase
			]);

			if (hasInvokedUseCase) {
				parentUseCases.add(useCase)
			}
		}

		return parentUseCases;
	}

	/**
	 * getPaths(..)
	 * ------------
	 * Gets the paths that lead to this use case being called.
	 */
	protected def getPaths(List<UseCase> useCases, UseCase ctx) {
		var paths = newArrayList;
		getPathsHelper(useCases, ctx, paths, new ArrayList<UseCase>(), new HashSet<UseCase>());
		return paths;
	}

	private def void getPathsHelper(List<UseCase> useCases, UseCase ctx, List<List<UseCase>> paths,
		List<UseCase> currentPath, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			return;
		}

		visited.add(ctx)
		currentPath.add(ctx)

		// Find next use cases (parents) to traverse to.
		var parents = getParents(useCases, ctx)

		if (parents.isEmpty) {
			// No further parents, so currentPath is a complete path.
			paths.add(new ArrayList<UseCase>(currentPath))
		} else {
			// Recurse upwards for each parent.
			for (parent : parents) {
				getPathsHelper(useCases, parent, paths, currentPath, visited)
			}
		}

		// Backtrack.
		currentPath.remove(ctx)
		visited.remove(ctx)
	}

	/**
	 * getInvocationPaths(..)
	 * ----------------------
	 * Gets the paths of the invoked use cases.
	 */
	protected def getInvocationPaths(List<UseCase> useCases, UseCase ctx) {
		var paths = newArrayList;
		getInvocationPathsHelper(useCases, ctx, paths, new ArrayList<UseCase>(), new HashSet<UseCase>());
		return paths;
	}

	/**
	 * getInvocationPathsHelper(..)
	 * ----------------------------
	 * Helper function that recursively searches for invoked paths from the passed use case.
	 */
	private def void getInvocationPathsHelper(List<UseCase> useCases, UseCase ctx, List<List<UseCase>> paths,
		List<UseCase> currentPath, HashSet<UseCase> visited) {
		if (ctx === null || visited.contains(ctx)) {
			return;
		}

		visited.add(ctx);
		currentPath.add(ctx);

		// Add the current path to the list of paths.
		paths.add(new ArrayList<UseCase>(currentPath));

		// Find next use cases to traverse to.
		var children = getChildren(ctx);

		// Traverse downwards to the invoked use case in the current use case.
		for (child : children) {
			getInvocationPathsHelper(useCases, child, paths, currentPath, visited);
		}

		currentPath.remove(ctx);
		visited.remove(ctx);
	}

	protected def getChildren(UseCase useCase) {
		return EcoreUtil2.getAllContentsOfType(useCase, InvocationStep).stream().map([step|step.invokedUseCase]).
			collect(Collectors.toList());
	}

	/**
	 * Joins the names of the UseCases in a single path with an arrow "->".
	 * For example, if a path contains UseCases with names "UseSmartStore", "Shopping",
	 * "PurchaseItem", and "IdentifyItem", the result will be:
	 * 
	 *   "UseSmartStore->Shopping->PurchaseItem->IdentifyItem"
	 */
	def String joinPath(List<UseCase> path) {
		if (path === null || path.isEmpty) {
			return ""
		}
		return path.reverse.map[it.name].join("->")
	}

	def String joinString(List<String> path) {
		if (path === null || path.isEmpty) {
			return ""
		}
		return path.map[it].join("->")
	}

	/**
	 * Processes an ArrayList of ArrayLists of UseCase objects (paths) and returns
	 * an ArrayList of String, where each string is a joined representation of a path.
	 */
	def List<String> joinPaths(ArrayList<List<UseCase>> paths) {
		val result = new ArrayList<String>()
		for (path : paths) {
			result.add(joinPath(path))
		}
		return result
	}

	/**
	 * Builds a table for context items with columns:
	 *  (1) ID
	 *  (2) Description
	 *  (3) Source (Use Case)
	 *  (4) Path
	 *  (5) CA-enabled
	 * 
	 * The table widths are computed dynamically to fit the largest text in each column.
	 */
	protected def String createContextSummaryTable(
		List<ContextItem> contextItems,
		List<ContextAwarenessEnabledUseCase> contextUseCases,
		Resource resource
	) {

		val allUseCases = resource.allContents.toIterable.filter[it instanceof UseCase].map[it as UseCase].toList

		var records = newArrayList()

		for (item : contextItems) {
			var usecase = findUseCaseNameByContextItemId(allUseCases, item.id);
			val usecaseName = usecase.name ?: ""
			var caEnabeldUseCase = findCaEnableUseCase(item, contextUseCases)
			var paths = getPaths(allUseCases, usecase);
			val path = joinString(joinPaths(paths));

			val record = new ContextIdRecord(
				item.id,
				item.description,
				usecaseName,
				path,
				caEnabeldUseCase
			)

			records.add(record)
		}

		// Build the table string
		val tableString = createContextIdTable(records)
		println(tableString)

		return tableString

	}

	/**
	 * Splits a cell's content into lines (using newline as delimiter).
	 */
	def List<String> splitCell(String cell) {
		if (cell === null)
			return newArrayList
		return cell.split("\\n").toList
	}

	/**
	 * Builds a separator line based on the provided column widths.
	 */
	def String buildSeparator(List<Integer> colWidths) {
		val sb = new StringBuilder
		for (width : colWidths) {
			sb.append("+").append("-".repeat(width + 2))
		}
		sb.append("+")
		return sb.toString
	}

	/**
	 * Formats a row (which may contain multi-line cells) into a list of strings.
	 * Each string represents one line of the printed row.
	 */
	def List<String> formatRowMultiline(List<String> row, List<Integer> colWidths) {
		// Split each cell into its lines.
		val cellsLines = row.map[splitCell(it ?: "")].toList // List<List<String>>
		// Determine how many lines this row must occupy.
		val maxHeight = cellsLines.map[it.size].max
		val linesList = newArrayList()
		for (lineIndex : 0 ..< maxHeight) {
			var lineStr = "|"
			for (i : 0 ..< row.size) {
				val cellLines = cellsLines.get(i)
				// Use the line if available, otherwise an empty string.
				val cellContent = if(lineIndex < cellLines.size) cellLines.get(lineIndex) else ""
				// Left-align the content in a fixed width field.
				lineStr += " " + String.format("%-" + colWidths.get(i) + "s", cellContent) + " |"
			}
			linesList.add(lineStr)
		}
		return linesList
	}

	/**
	 * Creates a formatted table from a list of rows.
	 * Each row is a List<String> (cells may contain newline characters).
	 * The first row is assumed to be the header.
	 */
	def String createTable(List<List<String>> rows) {
		if (rows.isEmpty)
			return ""

		val colCount = rows.get(0).size
		// Determine maximum width for each column. If a cell contains multiple lines,
		// use the maximum line length.
		val colWidths = newArrayList
		for (i : 0 ..< colCount) {
			colWidths.add(0)
		}
		for (row : rows) {
			for (i : 0 ..< colCount) {
				val cell = row.get(i) ?: ""
				val cellLines = splitCell(cell)
				val maxLineLength = if(cellLines.isEmpty) 0 else cellLines.map[it.length].max
				if (maxLineLength > colWidths.get(i))
					colWidths.set(i, maxLineLength)
			}
		}

		val separator = buildSeparator(colWidths)
		val sb = new StringBuilder
		sb.append(separator).append("\n")

		// Process the header row.
		val headerLines = formatRowMultiline(rows.get(0), colWidths)
		for (line : headerLines) {
			sb.append(line).append("\n")
		}
		sb.append(separator).append("\n")

		// Process each data row.
		for (row : rows.subList(1, rows.size)) {
			val rowLines = formatRowMultiline(row, colWidths)
			for (line : rowLines) {
				sb.append(line).append("\n")
			}
			sb.append(separator).append("\n")
		}

		return sb.toString
	}

	/**
	 * Creates a table string from a list of ContextIdRecord.
	 */
	def String createContextIdTable(List<ContextIdRecord> records) {
		// Header row for the table.
		val List<List<String>> allRows = newArrayList(
			newArrayList("ID", "Description", "Source (Use Case)", "Path", "CA-enabled")
		)

		// Add a row for each record.
		for (record : records) {
			allRows.add(newArrayList(
				record.id,
				record.description,
				record.source,
				record.path,
				record.caEnabled.toString
			))
		}

		// Create and return the formatted table string.
		return createTable(allRows)
	}

	def UseCase findUseCaseNameByContextItemId(List<UseCase> allUseCases, String id) {
		for (useCase : allUseCases) {
			val contextAwareness = useCase.getContextAwareness()
			if (contextAwareness !== null) {
				for (contextItem : contextAwareness.getContextItems()) {
					if (contextItem.id == id) {
						return useCase
					}
				}
			}
		}
		return null;
	}

	def String findCaEnableUseCase(ContextItem item, List<ContextAwarenessEnabledUseCase> cases) {
		for (ca : cases) {
			if (ca.context.contains(item.id)) {
				return ca.name
			}
		}
		return ""
	}

	/**
	 * Creates a printf-style format string for each column
	 * (left-justified by the computed width).
	 */
	def String createDynamicTableFormat(List<Integer> colWidths) {
		// For each column width, build a segment like "%-<width>s"
		return colWidths.map[w|"%-" + w + "s"].join(" | ")
	}

	/**
	 * Builds a horizontal separator line like:
	 *  "-------+-----------------+-------" etc.
	 * based on the computed column widths.
	 */
	def String buildSeparatorLine(List<Integer> colWidths) {
		// Each column becomes a string of dashes matching the width
		val segments = colWidths.map[w|"-".repeat(w)]
		// Join with '-+-' to visually separate columns
		return segments.join("-+-")
	}

	/**
	 * Prints one row by applying the format string to each column's text.
	 */
	def String printRow(List<String> rowValues, String format) {
		// rowValues must be turned into an Object[] to match Java's varargs
		return String.format(format, rowValues.toArray)
	}

	/**
	 * Represents an exception record with the following fields:
	 * (1) ID
	 * (2) Description
	 * (3) Source (UseCase)
	 * (4) Path
	 * (5) CA-enabled UseCase
	 */
	static class ContextIdRecord {
		String id
		String description
		String source
		String path
		String caEnabled

		/**
		 * Constructor to initialize all fields.
		 */
		new(String id, String description, String source, String path, String caEnabled) {
			this.id = id
			this.description = description
			this.source = source
			this.path = path
			this.caEnabled = caEnabled
		}
	}
}
