package mde.iot.ucm4iot.generator

import java.util.ArrayList
import java.util.HashMap
import java.util.List
import java.util.Map
import java.util.function.Function
import java.util.stream.Collectors
import java.util.stream.StreamSupport
import mde.iot.ucm4iot.ucm4iot.Actor
import mde.iot.ucm4iot.ucm4iot.DeviceActor
import mde.iot.ucm4iot.ucm4iot.EnvironmentException
import mde.iot.ucm4iot.ucm4iot.Exception
import mde.iot.ucm4iot.ucm4iot.ExceptionStep
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase
import mde.iot.ucm4iot.ucm4iot.HardwareException
import mde.iot.ucm4iot.ucm4iot.HumanActor
import mde.iot.ucm4iot.ucm4iot.InvocationStep
import mde.iot.ucm4iot.ucm4iot.NetworkException
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor
import mde.iot.ucm4iot.ucm4iot.SoftwareActor
import mde.iot.ucm4iot.ucm4iot.SoftwareException
import mde.iot.ucm4iot.ucm4iot.UseCase
import mde.iot.ucm4iot.ucm4iot.ContextExceptionMapping
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.EcoreUtil2
import org.eclipse.xtext.generator.IFileSystemAccess2
import org.eclipse.xtext.generator.IGeneratorContext

import static extension org.eclipse.xtext.EcoreUtil2.*
import mde.iot.ucm4iot.ucm4iot.InternalStep
import mde.iot.ucm4iot.ucm4iot.IoTUseCaseModel
import mde.iot.ucm4iot.ucm4iot.ConditionControlStep
import mde.iot.ucm4iot.ucm4iot.Mode
import mde.iot.ucm4iot.ucm4iot.Level
import mde.iot.ucm4iot.ucm4iot.Step
import java.util.HashSet

class StateChartPrototypeGenerator extends IUcm4iotGeneratorImpl {
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context) {
		generate(resource, fsa, context, "");
	}
	
	override generate(Resource resource, IFileSystemAccess2 fsa, IGeneratorContext context, String folder) {
		//var data = createStateChart(resource);
		var data = createStateChartModel(resource);
		createFile(fsa, folder, createFileName("statechart", ".stcmiot"), data);
		createFile(fsa, folder, createFileName("congif", ".iotconfig"), config());
	}
	
	def String createStateChartModel(Resource resource) {
		var useCases = StreamSupport
			.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
			.collect(Collectors.toList());
			
		if (useCases.size == 0) {
			return '';
		}
		
		var root = EcoreUtil2.getContainerOfType(useCases.get(0), IoTUseCaseModel);
		var rows = newArrayList;
		rows += "/* Generated */";
		rows += "";
		
		// Interface Generation
		// - Mode Switch Events
		// - Exception Events
		// - Exception Handled Events
		// - Use Case Finished
		// - ...
		rows += "interface:";
		var modes = EcoreUtil2.getAllContentsOfType(root, Mode).stream().collect(Collectors.toList());
		var modeNames = modes.stream().map([mode | mode.name]).collect(Collectors.toList());
		for (modeName : modeNames) {
			rows += indent(1) +  '@Mode';
			rows += indent(1) + 'in event ' + 'Enter' + formatName(modeName) + 'Mode';
		}
		
		rows += "";
		
		var exceptionEvents = newArrayList;
		var exceptionHandledEvents = newArrayList;
		var exceptionSteps = EcoreUtil2.getAllContentsOfType(root, ExceptionStep).stream().collect(Collectors.toList());
		for (exceptionStep : exceptionSteps) {
			var useCase = EcoreUtil2.getContainerOfType(exceptionStep, UseCase);
			var exceptionEvent = formatName(exceptionStep.refException.name) + 'RaisedIn' + formatName(useCase.name)
			
			var str = indent(1) + 'in event ' + exceptionEvent;
			
			rows += indent(1) + '@Exception';
			rows += str;
			
			rows += indent(1) + '@Exception';
			rows += str + 'Handled';
			
			exceptionEvents += exceptionEvent;
			exceptionHandledEvents += exceptionEvent + 'Handled';
		}
		
		rows += "";
		
		// Steps and use cases
		for (useCase : useCases) {
			rows += indent(1) + 'in event ' + formatName(useCase.name) + 'Finished';
			
			// Includes all kinds of steps.
			// TODO: ignore condition/control flow steps (unless device actor is involved)
			var steps = EcoreUtil2.getAllContentsOfType(useCase, Step).stream().collect(Collectors.toList());
			for (step : steps) {
				if (step.description !== null) {
					if (step instanceof ConditionControlStep) {
						//var actors = EcoreUtil2.getAllContentsOfType(useCase, DeviceActor).map([a | a.name]).stream().collect(Collectors.toList());
					}
					
					rows += indent(1) + 'in event ' + formatName(step.description) + 'Finished';
				}
			}
			
			rows += "";
		}
		
		
		
		// for ()
		// use case finished + steps
		
		
		rows += "";
		
		// Statechart Generation
		// - Summary-Level Use Cases
		//   - recursive invocation use cases
		// - Handler Use Cases
		// - Mode Detection
		var rootState = 'Operating' + formatName(useCases.get(0).scope);
		rows += "entry -> "          + rootState;
		rows += 'orthogonal state: ' + rootState + ' {';
		
		// Summary Level Use Cases
		var summaryUseCases = useCases.stream.filter([useCase | useCase.level === Level.SUMMARY]).collect(Collectors.toList());
		for (summaryUseCase : summaryUseCases) {
			rows += indent(1) + 'region: '  + 'r'   + formatName(summaryUseCase.name) + 'View';
			rows += indent(2) + 'entry -> '         + formatName(summaryUseCase.name) + 'Behaviour';
			rows += indent(2) + 'composite state: ' + formatName(summaryUseCase.name) + 'Behaviour' + ' {';
			
			for (exceptionEvent : exceptionEvents) {
				rows += indent(3) + '@Exception';
				rows += indent(3) + 'out -> ' + 'Pause' + ' by event ' + formatName(exceptionEvent);
			}
			
			rows += indent(3) + 'region: r'
			rows += indent(4) + 'entry -> INSERT'
			rows += indent(4) + 'state: ' + 'INSERT' + ' {'
			rows += indent(5) + 'out -> final' 
			rows += indent(4) + '}'
			
			if (summaryUseCase.primaryActor instanceof DeviceActor) {
				rows += indent(4) + 'state: ' + 'DeviceDecidesToRepeat' + ' {'
				rows += indent(5) + 'out -> ' + 'INSERT' + ' after 100ms'
				rows += indent(4) + '}'
			} else {
				rows += indent(4) + 'state: ' + 'Finished' + ' {'
				rows += indent(5) + 'out -> final'// + 'raising'
				rows += indent(4) + '}'
			}
			
			rows += indent(2) + '}';
			
			rows += indent(2) + '@Exception';
			rows += indent(2) + 'state: '         + 'Pause' + ' {';
			
			for (exceptionHandledEvent : exceptionHandledEvents) {
				rows += indent(3) + 'out -> ' + formatName(summaryUseCase.name) + 'Behaviour' + ' by event ' + formatName(exceptionHandledEvent);
			}
			
			rows += indent(2) + '}';
			rows += "";
		}
		
		// Handlers
		var handlerUseCases = useCases.stream.filter([useCase | useCase instanceof HandlerUseCase]).collect(Collectors.toList());
		for (handlerUseCase : handlerUseCases) {
			var behaviourState = formatName(handlerUseCase.name) + 'Behaviour';
			
			rows += indent(1) + '@Handler'
			rows += indent(1) + 'region: '  + 'r' + formatName(handlerUseCase.name) + 'Handler';
			rows += indent(2) + 'entry -> '       + 'Idle';
			rows += indent(2) + 'state: '         + 'Idle' + ' {';
			
			// Transition to handler behaviour when relevant exception occurs
			var ceMapping = (handlerUseCase as HandlerUseCase).contextExceptions;
			for (mapping : ceMapping) {
				var exceptionEvent = formatName(mapping.exception.name) + 'RaisedIn' + formatName(mapping.context.name);
				rows += indent(3) + 'out -> ' + behaviourState + ' by event ' + exceptionEvent;
			}
			
			rows += indent(2) + '}';
			rows += indent(2) + 'composite state: '         + behaviourState + ' {';
			
			var handlerEvents = newArrayList;
			for (mapping : ceMapping) {
				var handlerEvent = formatName(mapping.exception.name) + 'RaisedIn' + formatName(mapping.context.name) + 'Handled';
				rows += indent(3) + 'out -> ' + 'Idle' + ' by event ' + handlerEvent;
				
				handlerEvents += handlerEvent;
			}
			
			rows += indent(3) + 'region: r';
			rows += indent(4) + 'entry -> EnterHandler';
			
			rows += indent(4) + '@Mode';
			rows += indent(4) + 'state: EnterHandler {';
			
			if (handlerUseCase.main.preModeSwitch !== null) {
				rows += indent(5) + 'out -> '+ 'INSERT' + ' raising ' + 'Enter' + formatName(handlerUseCase.main.preModeSwitch.name) + 'Mode';
			} else {
				rows += indent(5) + 'out -> '+ 'INSERT';
			}
			
			rows += indent(4) + '}';
			
			/* Use Case States Begin */
			
			rows += indent(4) + 'state: INSERT {';
			rows += indent(5) + 'out -> '+ 'ExitHandler';
			rows += indent(4) + '}';
			
			/* Use Case States Ends */
			
			rows += indent(4) + '@Mode';
			rows += indent(4) + 'state: ExitHandler {';
			
			if (handlerUseCase.main.postModeSwitch !== null) {
				rows += indent(5) + 'out -> Finish' + ' raising ' + 'Enter' +  formatName(handlerUseCase.main.postModeSwitch.name) + 'Mode';
			} else {
				rows += indent(5) + 'out -> Finish'
			}
			
			rows += indent(4) + '}';
			rows += indent(4) + 'state: Finish {';
			rows += indent(5) + 'out -> final' + ' raising ' + handlerEvents.join(', ');
			rows += indent(4) + '}';
			
			rows += indent(2) + '}'
			rows += "";
		}
		
		// Modes
		var defaultMode = modes.stream().filter([mode | mode.isDefault]).findFirst().orElse(null);
		var defaultModeName = "";
		if (defaultMode === null) {
			defaultModeName = "null";
		} else {
			defaultModeName = defaultMode.name;
		}
		
		rows += indent(1) + '@Mode';
		rows += indent(1) + 'region: ' + 'mode_detection';
		rows += indent(2) + 'entry -> ' + formatName(defaultModeName);
		for (modeName : modeNames) {
			rows += indent(2) + 'state: ' + formatName(modeName) + ' {';
			
			for (other : modeNames.stream().filter([other | other != modeName]).collect(Collectors.toList())) {
				rows += indent(3) + 'out -> ' + formatName(other) + ' by event ' + 'Enter' + formatName(other) + 'Mode';
			}
			
			rows += indent(2) + '}'
		}
		
		rows += "}";
		return String.join("\n", rows);
	}
	
	def String indent(int num) {
		var indents = newArrayList;
		indents += "";
		
		for (var i = 0; i < num; i+=1) {
			indents += "\t";
		}
		
		return String.join("", indents);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	def String createStateChart(Resource resource) {
		var useCases = StreamSupport
			.stream(resource.allContents.toIterable.filter(UseCase).spliterator(), false)
			.collect(Collectors.toList());
		
		if (useCases.size == 0) {
			return '';
		}
		
		// Get the root element.	
		var root = EcoreUtil2.getContainerOfType(useCases.get(0), IoTUseCaseModel);
		
		var modes = EcoreUtil2.getAllContentsOfType(root, Mode).stream().collect(Collectors.toList());
		var modeNames = modes.stream().map([mode | mode.name]).collect(Collectors.toList());
		
		var defaultMode = modes.stream().filter([mode | mode.isDefault]).findFirst().orElse(null);
		
		var defaultModeName = "";
		if (defaultMode === null) {
			defaultModeName = "null";
		} else {
			defaultModeName = defaultMode.name;
		}
		
		modeNames += defaultModeName;
		modeNames = modeNames.stream().distinct().collect(Collectors.toList());
		
		var interface = '''
		/* Generated */
		
		interface: 
			�FOR uc : useCases�
			�FOR step : EcoreUtil2.getAllContentsOfType(uc, InternalStep).stream().filter([step | step.isTimeout]).collect(Collectors.toList())�
			var �uc.name + step.stepNumber + 'timeout'� : integer = �step.timeoutTime�
			�ENDFOR�
			�FOR name : EcoreUtil2.getAllContentsOfType(uc, ConditionControlStep).stream().map([step | formatName(step.description)]).filter([name | include(name)]).distinct().collect(Collectors.toList())�
			in event �formatName(name)�
			�ENDFOR�
			�ENDFOR�
			�FOR modeName : modeNames�
			in event �'Enter' + modeName + 'Mode'�
			�ENDFOR�
		'''
		
		var summaryLevelUseCases = useCases.stream().filter([uc | uc.level === Level.SUMMARY]).collect(Collectors.toList());
		var entryStateName = 'Operating' + useCases.get(0).scope;
		
		var HashMap<UseCase, List<StateNode>> map = new HashMap<UseCase, List<StateNode>>();
		for (summary : summaryLevelUseCases) {
			map.put(summary, collectStates(summary));
		}
		
		// new - test
		var handlerUseCases = useCases.stream().filter([uc | uc instanceof HandlerUseCase]).collect(Collectors.toList());
		for (handler : handlerUseCases) {
			map.put(handler, collectStates(handler));
		}
		
		var states = '''
		entry -> �entryStateName�
		
		orthogonal state: �entryStateName� {
			�FOR summary : summaryLevelUseCases�
			region: �'r' + summary.name�
				�IF map.get(summary).size == 0�
				entry -> Unknown
				state: Unknown
				�ELSE�
				entry -> �map.get(summary).get(0).name�
				�FOR state : map.get(summary)�
				state: �state.name� {
					�var int index = map.get(summary).indexOf(state)�
					�IF index < map.get(summary).size-1�
					�var node = map.get(summary).get(index+1)�
					�var internalStep = node.step as InternalStep�
					out -> �node.name� �IF internalStep.isTimeout�after �internalStep.timeoutTime� �internalStep.timeoutUnit��ENDIF�
					�ELSE�
					out -> final
					�ENDIF�
				}
				�ENDFOR�
				�ENDIF�
				
			�ENDFOR�
			region: mode_detection
				entry -> �defaultModeName�
				�FOR modeName : modeNames�
				state: �modeName� {
					�FOR other : modeNames.stream().filter([other | other != modeName]).collect(Collectors.toList())�
					out -> �other� by event �'Enter' + other + 'Mode'�
					�ENDFOR�
				}
				�ENDFOR�
		}
		'''
		
		return interface + states;
	}
	
	static class StateNode {
		var String name;
		var Step step;
		
		new (String name, Step step) {
			this.name = name;
			this.step = step;
		}
	}
	
	def collectStates(UseCase useCase) {
		var List<StateNode> states = newArrayList;
		
		collectStates(useCase, new HashSet<UseCase>(), states);
		return states;
	}
	
	
	def collectStates(UseCase useCase, HashSet<UseCase> visited, List<StateNode> states) {
		if (visited.contains(useCase)) {
			return;
		}
		
		var steps = EcoreUtil2.getAllContentsOfType(useCase, Step).stream().collect(Collectors.toList());
		var stateSteps = steps.stream().filter([step | step instanceof InternalStep || step instanceof InvocationStep]).collect(Collectors.toList());
		if (stateSteps.size == 0) {
			return;
		}
		
		visited.add(useCase);
		
		for (step : stateSteps) {
			if (step instanceof InternalStep) {
				states.add(new StateNode(formatName(step.description), step));
			}
			
			if (step instanceof InvocationStep) {
				collectStates((step as InvocationStep).invokedUseCase, visited, states);
			}
		}
		
		visited.remove(useCase);
	}
	
	
	
	def formatName(String string) {
		var words = string.replaceAll("[^a-zA-Z0-9]", " ")
				.split("\\s+");
		
		for (var i = 0; i < words.size; i++) {
			words.set(i, words.get(i).substring(0, 1).toUpperCase() + words.get(i).substring(1));
		}
		
		return String.join("", words);
	}
	
	def include(String name) {
		var keywords = #['Repeat', 'While', 'For Each', 'Step'];
		
		for (keyword : keywords) {
			if (name.contains(keyword)) {
				return false;
			}
		}
		
		return true;
	}
	
	def String config() {
		return '''
		group group1 {
			input  pin name1: 4, 
			output pin name2: 5
		}
		
		/****************************************************************
		 * postSetup will be called after all pins have been configured *
		 ****************************************************************/
		function postSetup {
			(param1:int, param2:String)
			code: ||>
				Serial.printf("printing param1 %d and param2 %s... ", param1, param2);
			<||
		}
		'''
	}
	
}
