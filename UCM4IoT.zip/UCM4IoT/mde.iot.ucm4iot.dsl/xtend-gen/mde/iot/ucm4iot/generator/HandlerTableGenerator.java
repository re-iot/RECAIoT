package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.Ucm4iotUtilities;
import mde.iot.ucm4iot.ucm4iot.Actor;
import mde.iot.ucm4iot.ucm4iot.ContextExceptionMapping;
import mde.iot.ucm4iot.ucm4iot.DeviceActor;
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase;
import mde.iot.ucm4iot.ucm4iot.HardwareException;
import mde.iot.ucm4iot.ucm4iot.NetworkException;
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareException;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

/**
 * Class: HandlerTableGenerator
 * ----------------------------
 * Generates Handler Summary Tables.
 */
@SuppressWarnings("all")
public class HandlerTableGenerator extends IUcm4iotGeneratorImpl {
  /**
   * generate(..)
   * ------------
   * Generates handler tables for all use cases within a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates handler tables for all use cases within a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    List<HandlerUseCase> handlers = StreamSupport.<HandlerUseCase>stream(Iterables.<HandlerUseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), HandlerUseCase.class).spliterator(), false).collect(Collectors.<HandlerUseCase>toList());
    String table = this.generateTable(handlers);
    this.createFile(fsa, folder, this.createFileName("handlerTable", ".txt"), table);
  }

  /**
   * generateTable(..)
   * -----------------
   * Generates the handler summary table.
   */
  protected String generateTable(final List<HandlerUseCase> handlers) {
    HashMap<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>> handlerInfo = new HashMap<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>>();
    HashMap<HandlerUseCase, List<UseCase>> dependents = new HashMap<HandlerUseCase, List<UseCase>>();
    for (final HandlerUseCase ctx : handlers) {
      {
        List<UseCase> depUseCases = this.getDependentUseCases(ctx);
        HashMap<UseCase, HashMap<String, ArrayList<String>>> table = new HashMap<UseCase, HashMap<String, ArrayList<String>>>();
        for (final UseCase useCase : depUseCases) {
          {
            HashMap<String, ArrayList<String>> hashmap = new HashMap<String, ArrayList<String>>();
            ArrayList<String> _arrayList = new ArrayList<String>();
            hashmap.put("handled_exceptions", _arrayList);
            ArrayList<String> _arrayList_1 = new ArrayList<String>();
            hashmap.put("unhandled_exceptions", _arrayList_1);
            ArrayList<String> _arrayList_2 = new ArrayList<String>();
            hashmap.put("actors", _arrayList_2);
            table.put(useCase, hashmap);
          }
        }
        this.getHandledExceptions(ctx, depUseCases, table);
        this.getUnhandledExceptions(ctx, depUseCases, table);
        this.getActors(ctx, depUseCases, table);
        handlerInfo.put(ctx, table);
        dependents.put(ctx, depUseCases);
      }
    }
    return this.createHandlerTable(handlers, dependents, handlerInfo);
  }

  /**
   * getDependentUseCases(..)
   * ------------------------
   * Get the use cases that are dependent on the passed handler.
   */
  protected List<UseCase> getDependentUseCases(final HandlerUseCase ctx) {
    final Function<ContextExceptionMapping, UseCase> _function = (ContextExceptionMapping ce) -> {
      return ce.getContext();
    };
    return ctx.getContextExceptions().stream().<UseCase>map(_function).distinct().collect(Collectors.<UseCase>toList());
  }

  /**
   * getHandledExceptions(..)
   * ------------------------
   * Gets all handled exceptions.
   */
  protected void getHandledExceptions(final HandlerUseCase ctx, final List<UseCase> depUseCases, final HashMap<UseCase, HashMap<String, ArrayList<String>>> table) {
    for (final UseCase useCase : depUseCases) {
      {
        final Predicate<ContextExceptionMapping> _function = (ContextExceptionMapping ce) -> {
          UseCase _context = ce.getContext();
          return (_context == useCase);
        };
        final Function<ContextExceptionMapping, String> _function_1 = (ContextExceptionMapping ce) -> {
          return this.formatExceptionName(ce.getException());
        };
        List<String> exceptions = ctx.getContextExceptions().stream().filter(_function).<String>map(_function_1).collect(Collectors.<String>toList());
        table.get(useCase).get("handled_exceptions").addAll(exceptions);
      }
    }
  }

  /**
   * getUnhandledExceptions(..)
   * --------------------------
   * Gets all exceptions from the dependent use cases that are not handled.
   */
  protected void getUnhandledExceptions(final HandlerUseCase ctx, final List<UseCase> depUseCases, final HashMap<UseCase, HashMap<String, ArrayList<String>>> table) {
    for (final UseCase useCase : depUseCases) {
    }
  }

  /**
   * getActors(..)
   * -------------
   * Gets all actors from the dependent use case and the handler use case.
   */
  protected void getActors(final HandlerUseCase ctx, final List<UseCase> depUseCases, final HashMap<UseCase, HashMap<String, ArrayList<String>>> table) {
    for (final UseCase useCase : depUseCases) {
      {
        ArrayList<Actor> useCaseActors = Ucm4iotUtilities.getActors(useCase);
        ArrayList<Actor> handlerActors = Ucm4iotUtilities.getActors(ctx);
        final Function<Actor, String> _function = (Actor actor) -> {
          return this.formatActorName(actor);
        };
        final List<String> useCaseActorNames = useCaseActors.stream().<String>map(_function).distinct().collect(Collectors.<String>toList());
        final Function<Actor, String> _function_1 = (Actor actor) -> {
          return this.formatActorName(actor);
        };
        final Function<String, String> _function_2 = (String actorName) -> {
          return this.formatExceptionalActor(useCaseActorNames, actorName);
        };
        final List<String> handlerActorNames = handlerActors.stream().<String>map(_function_1).<String>map(_function_2).distinct().collect(Collectors.<String>toList());
        List<String> actorNames = Stream.<String>concat(useCaseActorNames.stream(), handlerActorNames.stream()).distinct().collect(Collectors.<String>toList());
        table.get(useCase).get("actors").addAll(actorNames);
      }
    }
  }

  /**
   * formatExceptionalActor(..)
   * --------------------------
   * Formats the name of an actor with a '*' if it is an exceptional actor
   */
  private String formatExceptionalActor(final List<String> useCaseActorNames, final String actorName) {
    boolean _contains = useCaseActorNames.contains(actorName);
    if (_contains) {
      return actorName;
    } else {
      return (actorName + "*");
    }
  }

  /**
   * formatExceptionName(..)
   * -----------------------
   * Formats the name of the passed exception.
   */
  protected String formatExceptionName(final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    String exceptionFormat = "%s::%s";
    if ((exception instanceof HardwareException)) {
      return String.format(exceptionFormat, "HARDWARE_EXCEPTION", ((HardwareException)exception).getName());
    } else {
      if ((exception instanceof SoftwareException)) {
        return String.format(exceptionFormat, "SOFTWARE_EXCEPTION", ((SoftwareException)exception).getName());
      } else {
        if ((exception instanceof NetworkException)) {
          return String.format(exceptionFormat, "NETWORK_EXCEPTION", ((NetworkException)exception).getName());
        } else {
          return String.format(exceptionFormat, "ENVIRONMENT_EXCEPTION", exception.getName());
        }
      }
    }
  }

  /**
   * getActorNameAndType(..)
   * -----------------------
   * Formats the name of the passed actor.
   */
  protected String formatActorName(final Actor actor) {
    String actorFormat = "%s::%s";
    if ((actor instanceof DeviceActor)) {
      return String.format(actorFormat, "DEVICE", ((DeviceActor)actor).getName());
    } else {
      if ((actor instanceof PhysicalEntityActor)) {
        return String.format(actorFormat, "PHYSICAL_ENTITY", ((PhysicalEntityActor)actor).getName());
      } else {
        if ((actor instanceof SoftwareActor)) {
          return String.format(actorFormat, "SOFTWARE", ((SoftwareActor)actor).getName());
        } else {
          return String.format(actorFormat, "HUMAN", actor.getName());
        }
      }
    }
  }

  /**
   * createHandlerTable(..)
   * ----------------------
   * Creates a table.
   */
  protected String createHandlerTable(final List<HandlerUseCase> handlers, final HashMap<HandlerUseCase, List<UseCase>> dependents, final HashMap<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>> handlerInfo) {
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    final Function1<List<UseCase>, List<String>> _function = (List<UseCase> useCases) -> {
      final Function<UseCase, String> _function_1 = (UseCase uc) -> {
        return uc.getName();
      };
      return useCases.stream().<String>map(_function_1).collect(Collectors.<String>toList());
    };
    final Function1<List<UseCase>, List<String>> dependentsToColumn = _function;
    final Function1<String, Function1<HashMap<UseCase, HashMap<String, ArrayList<String>>>, List<String>>> _function_1 = (String columnName) -> {
      final Function1<HashMap<UseCase, HashMap<String, ArrayList<String>>>, List<String>> _function_2 = (HashMap<UseCase, HashMap<String, ArrayList<String>>> table) -> {
        final ArrayList<String> list = CollectionLiterals.<String>newArrayList();
        Set<UseCase> _keySet = table.keySet();
        for (final UseCase key : _keySet) {
          list.addAll(table.get(key).get(columnName));
        }
        return IterableExtensions.<String>toList(list);
      };
      return _function_2;
    };
    final Function1<String, Function1<HashMap<UseCase, HashMap<String, ArrayList<String>>>, List<String>>> tableToColumn = _function_1;
    List<String> columnNames = Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("Handlers", "Dependent Use Cases", "Handled Exceptions", "Actors"));
    final Function<HandlerUseCase, String> _function_2 = (HandlerUseCase uc) -> {
      return uc.getName();
    };
    int _fitColumnWidth = this.fitColumnWidth(columnNames.get(0), 2, handlers.stream().<String>map(_function_2).collect(Collectors.<String>toList()));
    int _fitColumnWidth_1 = this.<HandlerUseCase, List<UseCase>>fitColumnWidth(columnNames.get(1), 2, dependents, new Function<List<UseCase>, List<String>>() {
        public List<String> apply(List<UseCase> t) {
          return dependentsToColumn.apply(t);
        }
    });
    int _fitColumnWidth_2 = this.<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>>fitColumnWidth(columnNames.get(2), 2, handlerInfo, new Function<HashMap<UseCase, HashMap<String, ArrayList<String>>>, List<String>>() {
        public List<String> apply(HashMap<UseCase, HashMap<String, ArrayList<String>>> t) {
          return tableToColumn.apply("handled_exceptions").apply(t);
        }
    });
    int _fitColumnWidth_3 = this.<HandlerUseCase, HashMap<UseCase, HashMap<String, ArrayList<String>>>>fitColumnWidth(columnNames.get(3), 2, handlerInfo, new Function<HashMap<UseCase, HashMap<String, ArrayList<String>>>, List<String>>() {
        public List<String> apply(HashMap<UseCase, HashMap<String, ArrayList<String>>> t) {
          return tableToColumn.apply("actors").apply(t);
        }
    });
    List<Integer> columns = Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(_fitColumnWidth), Integer.valueOf(_fitColumnWidth_1), Integer.valueOf(_fitColumnWidth_2), Integer.valueOf(_fitColumnWidth_3)));
    final List<Integer> _converted_columns = (List<Integer>)columns;
    String format = this.createTableFormat(((int[])Conversions.unwrapArray(_converted_columns, int.class)));
    String line = String.format(format, "", "", "", "").replace(" ", "-").replace("|", "+");
    String partialLine = String.format(
      line.replaceFirst("-+", String.format("%%-%ds", columns.get(0))).replaceFirst("\\+", "|"), "");
    rows.add(line);
    String _get = columnNames.get(0);
    String _plus = (" " + _get);
    String _get_1 = columnNames.get(1);
    String _plus_1 = (" " + _get_1);
    String _get_2 = columnNames.get(2);
    String _plus_2 = (" " + _get_2);
    String _get_3 = columnNames.get(3);
    String _plus_3 = (" " + _get_3);
    String _format = String.format(format, _plus, _plus_1, _plus_2, _plus_3);
    rows.add(_format);
    rows.add(line);
    for (final HandlerUseCase handler : handlers) {
      {
        List<UseCase> handlerDependents = dependents.get(handler);
        boolean rowStarted = false;
        for (final UseCase handledUseCase : handlerDependents) {
          {
            HashMap<String, ArrayList<String>> table = handlerInfo.get(handler).get(handledUseCase);
            ArrayList<String> handledExceptions = table.get("handled_exceptions");
            ArrayList<String> actors = table.get("actors");
            String _name = handler.getName();
            String _name_1 = handledUseCase.getName();
            List<? extends List<String>> rowData = Collections.<List<String>>unmodifiableList(CollectionLiterals.<List<String>>newArrayList(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(_name)), Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(_name_1)), handledExceptions, actors));
            if (rowStarted) {
              String _name_2 = handledUseCase.getName();
              rowData = Collections.<List<String>>unmodifiableList(CollectionLiterals.<List<String>>newArrayList(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("")), Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(_name_2)), handledExceptions, actors));
            }
            final List<? extends List<String>> _converted_rowData = (List<? extends List<String>>)rowData;
            final Integer n = this.maxSize(((List<String>[])Conversions.unwrapArray(_converted_rowData, List.class)));
            for (int i = 0; (i < (n).intValue()); i++) {
              final List<? extends List<String>> _converted_rowData_1 = (List<? extends List<String>>)rowData;
              String _format_1 = String.format(format, this.getDataOrDefault(i, ((List<String>[])Conversions.unwrapArray(_converted_rowData_1, List.class))));
              rows.add(_format_1);
            }
            rows.add(partialLine);
            rowStarted = true;
          }
        }
        int _size = rows.size();
        int _minus = (_size - 1);
        rows.remove(_minus);
        rows.add(line);
      }
    }
    return String.join("\n", rows);
  }
}
