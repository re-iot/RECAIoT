package mde.iot.ucm4iot.generator;

import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;

/**
 * Interface: IUcm4iotGenerator
 * ----------------------------
 * Interface for Ucm4iot Generators.
 */
@SuppressWarnings("all")
public interface IUcm4iotGenerator {
  void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context);

  void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder);

  String createFileName(final String name, final String ext);

  void createFile(final IFileSystemAccess2 fsa, final String path, final String file, final String data);
}
