package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.ucm4iot.ConditionControlStep;
import mde.iot.ucm4iot.ucm4iot.ContextExceptionMapping;
import mde.iot.ucm4iot.ucm4iot.DeviceActor;
import mde.iot.ucm4iot.ucm4iot.ExceptionStep;
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase;
import mde.iot.ucm4iot.ucm4iot.InternalStep;
import mde.iot.ucm4iot.ucm4iot.InvocationStep;
import mde.iot.ucm4iot.ucm4iot.IoTUseCaseModel;
import mde.iot.ucm4iot.ucm4iot.Level;
import mde.iot.ucm4iot.ucm4iot.Mode;
import mde.iot.ucm4iot.ucm4iot.PrimaryActor;
import mde.iot.ucm4iot.ucm4iot.Step;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

@SuppressWarnings("all")
public class StateChartPrototypeGenerator extends IUcm4iotGeneratorImpl {
  public static class StateNode {
    private String name;

    private Step step;

    public StateNode(final String name, final Step step) {
      this.name = name;
      this.step = step;
    }
  }

  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    String data = this.createStateChartModel(resource);
    this.createFile(fsa, folder, this.createFileName("statechart", ".stcmiot"), data);
    this.createFile(fsa, folder, this.createFileName("congif", ".iotconfig"), this.config());
  }

  public String createStateChartModel(final Resource resource) {
    List<UseCase> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).collect(Collectors.<UseCase>toList());
    int _size = useCases.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      return "";
    }
    IoTUseCaseModel root = EcoreUtil2.<IoTUseCaseModel>getContainerOfType(useCases.get(0), IoTUseCaseModel.class);
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    rows.add("/* Generated */");
    rows.add("");
    rows.add("interface:");
    List<Mode> modes = EcoreUtil2.<Mode>getAllContentsOfType(root, Mode.class).stream().collect(Collectors.<Mode>toList());
    final Function<Mode, String> _function = (Mode mode) -> {
      return mode.getName();
    };
    List<String> modeNames = modes.stream().<String>map(_function).collect(Collectors.<String>toList());
    for (final String modeName : modeNames) {
      {
        String _indent = this.indent(1);
        String _plus = (_indent + "@Mode");
        rows.add(_plus);
        String _indent_1 = this.indent(1);
        String _plus_1 = (_indent_1 + "in event ");
        String _plus_2 = (_plus_1 + "Enter");
        String _formatName = this.formatName(modeName);
        String _plus_3 = (_plus_2 + _formatName);
        String _plus_4 = (_plus_3 + "Mode");
        rows.add(_plus_4);
      }
    }
    rows.add("");
    ArrayList<String> exceptionEvents = CollectionLiterals.<String>newArrayList();
    ArrayList<String> exceptionHandledEvents = CollectionLiterals.<String>newArrayList();
    List<ExceptionStep> exceptionSteps = EcoreUtil2.<ExceptionStep>getAllContentsOfType(root, ExceptionStep.class).stream().collect(Collectors.<ExceptionStep>toList());
    for (final ExceptionStep exceptionStep : exceptionSteps) {
      {
        UseCase useCase = EcoreUtil2.<UseCase>getContainerOfType(exceptionStep, UseCase.class);
        String _formatName = this.formatName(exceptionStep.getRefException().getName());
        String _plus = (_formatName + "RaisedIn");
        String _formatName_1 = this.formatName(useCase.getName());
        String exceptionEvent = (_plus + _formatName_1);
        String _indent = this.indent(1);
        String _plus_1 = (_indent + "in event ");
        String str = (_plus_1 + exceptionEvent);
        String _indent_1 = this.indent(1);
        String _plus_2 = (_indent_1 + "@Exception");
        rows.add(_plus_2);
        rows.add(str);
        String _indent_2 = this.indent(1);
        String _plus_3 = (_indent_2 + "@Exception");
        rows.add(_plus_3);
        rows.add((str + "Handled"));
        exceptionEvents.add(exceptionEvent);
        exceptionHandledEvents.add((exceptionEvent + "Handled"));
      }
    }
    rows.add("");
    for (final UseCase useCase : useCases) {
      {
        String _indent = this.indent(1);
        String _plus = (_indent + "in event ");
        String _formatName = this.formatName(useCase.getName());
        String _plus_1 = (_plus + _formatName);
        String _plus_2 = (_plus_1 + "Finished");
        rows.add(_plus_2);
        List<Step> steps = EcoreUtil2.<Step>getAllContentsOfType(useCase, Step.class).stream().collect(Collectors.<Step>toList());
        for (final Step step : steps) {
          String _description = step.getDescription();
          boolean _tripleNotEquals = (_description != null);
          if (_tripleNotEquals) {
            if ((step instanceof ConditionControlStep)) {
            }
            String _indent_1 = this.indent(1);
            String _plus_3 = (_indent_1 + "in event ");
            String _formatName_1 = this.formatName(step.getDescription());
            String _plus_4 = (_plus_3 + _formatName_1);
            String _plus_5 = (_plus_4 + "Finished");
            rows.add(_plus_5);
          }
        }
        rows.add("");
      }
    }
    rows.add("");
    String _formatName = this.formatName(useCases.get(0).getScope());
    String rootState = ("Operating" + _formatName);
    rows.add(("entry -> " + rootState));
    rows.add((("orthogonal state: " + rootState) + " {"));
    final Predicate<UseCase> _function_1 = (UseCase useCase_1) -> {
      Level _level = useCase_1.getLevel();
      return (_level == Level.SUMMARY);
    };
    List<UseCase> summaryUseCases = useCases.stream().filter(_function_1).collect(Collectors.<UseCase>toList());
    for (final UseCase summaryUseCase : summaryUseCases) {
      {
        String _indent = this.indent(1);
        String _plus = (_indent + "region: ");
        String _plus_1 = (_plus + "r");
        String _formatName_1 = this.formatName(summaryUseCase.getName());
        String _plus_2 = (_plus_1 + _formatName_1);
        String _plus_3 = (_plus_2 + "View");
        rows.add(_plus_3);
        String _indent_1 = this.indent(2);
        String _plus_4 = (_indent_1 + "entry -> ");
        String _formatName_2 = this.formatName(summaryUseCase.getName());
        String _plus_5 = (_plus_4 + _formatName_2);
        String _plus_6 = (_plus_5 + "Behaviour");
        rows.add(_plus_6);
        String _indent_2 = this.indent(2);
        String _plus_7 = (_indent_2 + "composite state: ");
        String _formatName_3 = this.formatName(summaryUseCase.getName());
        String _plus_8 = (_plus_7 + _formatName_3);
        String _plus_9 = (_plus_8 + "Behaviour");
        String _plus_10 = (_plus_9 + " {");
        rows.add(_plus_10);
        for (final String exceptionEvent : exceptionEvents) {
          {
            String _indent_3 = this.indent(3);
            String _plus_11 = (_indent_3 + "@Exception");
            rows.add(_plus_11);
            String _indent_4 = this.indent(3);
            String _plus_12 = (_indent_4 + "out -> ");
            String _plus_13 = (_plus_12 + "Pause");
            String _plus_14 = (_plus_13 + " by event ");
            String _formatName_4 = this.formatName(exceptionEvent);
            String _plus_15 = (_plus_14 + _formatName_4);
            rows.add(_plus_15);
          }
        }
        String _indent_3 = this.indent(3);
        String _plus_11 = (_indent_3 + "region: r");
        rows.add(_plus_11);
        String _indent_4 = this.indent(4);
        String _plus_12 = (_indent_4 + "entry -> INSERT");
        rows.add(_plus_12);
        String _indent_5 = this.indent(4);
        String _plus_13 = (_indent_5 + "state: ");
        String _plus_14 = (_plus_13 + "INSERT");
        String _plus_15 = (_plus_14 + " {");
        rows.add(_plus_15);
        String _indent_6 = this.indent(5);
        String _plus_16 = (_indent_6 + "out -> final");
        rows.add(_plus_16);
        String _indent_7 = this.indent(4);
        String _plus_17 = (_indent_7 + "}");
        rows.add(_plus_17);
        PrimaryActor _primaryActor = summaryUseCase.getPrimaryActor();
        if ((_primaryActor instanceof DeviceActor)) {
          String _indent_8 = this.indent(4);
          String _plus_18 = (_indent_8 + "state: ");
          String _plus_19 = (_plus_18 + "DeviceDecidesToRepeat");
          String _plus_20 = (_plus_19 + " {");
          rows.add(_plus_20);
          String _indent_9 = this.indent(5);
          String _plus_21 = (_indent_9 + "out -> ");
          String _plus_22 = (_plus_21 + "INSERT");
          String _plus_23 = (_plus_22 + " after 100ms");
          rows.add(_plus_23);
          String _indent_10 = this.indent(4);
          String _plus_24 = (_indent_10 + "}");
          rows.add(_plus_24);
        } else {
          String _indent_11 = this.indent(4);
          String _plus_25 = (_indent_11 + "state: ");
          String _plus_26 = (_plus_25 + "Finished");
          String _plus_27 = (_plus_26 + " {");
          rows.add(_plus_27);
          String _indent_12 = this.indent(5);
          String _plus_28 = (_indent_12 + "out -> final");
          rows.add(_plus_28);
          String _indent_13 = this.indent(4);
          String _plus_29 = (_indent_13 + "}");
          rows.add(_plus_29);
        }
        String _indent_14 = this.indent(2);
        String _plus_30 = (_indent_14 + "}");
        rows.add(_plus_30);
        String _indent_15 = this.indent(2);
        String _plus_31 = (_indent_15 + "@Exception");
        rows.add(_plus_31);
        String _indent_16 = this.indent(2);
        String _plus_32 = (_indent_16 + "state: ");
        String _plus_33 = (_plus_32 + "Pause");
        String _plus_34 = (_plus_33 + " {");
        rows.add(_plus_34);
        for (final String exceptionHandledEvent : exceptionHandledEvents) {
          String _indent_17 = this.indent(3);
          String _plus_35 = (_indent_17 + "out -> ");
          String _formatName_4 = this.formatName(summaryUseCase.getName());
          String _plus_36 = (_plus_35 + _formatName_4);
          String _plus_37 = (_plus_36 + "Behaviour");
          String _plus_38 = (_plus_37 + " by event ");
          String _formatName_5 = this.formatName(exceptionHandledEvent);
          String _plus_39 = (_plus_38 + _formatName_5);
          rows.add(_plus_39);
        }
        String _indent_18 = this.indent(2);
        String _plus_40 = (_indent_18 + "}");
        rows.add(_plus_40);
        rows.add("");
      }
    }
    final Predicate<UseCase> _function_2 = (UseCase useCase_1) -> {
      return (useCase_1 instanceof HandlerUseCase);
    };
    List<UseCase> handlerUseCases = useCases.stream().filter(_function_2).collect(Collectors.<UseCase>toList());
    for (final UseCase handlerUseCase : handlerUseCases) {
      {
        String _formatName_1 = this.formatName(handlerUseCase.getName());
        String behaviourState = (_formatName_1 + "Behaviour");
        String _indent = this.indent(1);
        String _plus = (_indent + "@Handler");
        rows.add(_plus);
        String _indent_1 = this.indent(1);
        String _plus_1 = (_indent_1 + "region: ");
        String _plus_2 = (_plus_1 + "r");
        String _formatName_2 = this.formatName(handlerUseCase.getName());
        String _plus_3 = (_plus_2 + _formatName_2);
        String _plus_4 = (_plus_3 + "Handler");
        rows.add(_plus_4);
        String _indent_2 = this.indent(2);
        String _plus_5 = (_indent_2 + "entry -> ");
        String _plus_6 = (_plus_5 + "Idle");
        rows.add(_plus_6);
        String _indent_3 = this.indent(2);
        String _plus_7 = (_indent_3 + "state: ");
        String _plus_8 = (_plus_7 + "Idle");
        String _plus_9 = (_plus_8 + " {");
        rows.add(_plus_9);
        EList<ContextExceptionMapping> ceMapping = ((HandlerUseCase) handlerUseCase).getContextExceptions();
        for (final ContextExceptionMapping mapping : ceMapping) {
          {
            String _formatName_3 = this.formatName(mapping.getException().getName());
            String _plus_10 = (_formatName_3 + "RaisedIn");
            String _formatName_4 = this.formatName(mapping.getContext().getName());
            String exceptionEvent = (_plus_10 + _formatName_4);
            String _indent_4 = this.indent(3);
            String _plus_11 = (_indent_4 + "out -> ");
            String _plus_12 = (_plus_11 + behaviourState);
            String _plus_13 = (_plus_12 + " by event ");
            String _plus_14 = (_plus_13 + exceptionEvent);
            rows.add(_plus_14);
          }
        }
        String _indent_4 = this.indent(2);
        String _plus_10 = (_indent_4 + "}");
        rows.add(_plus_10);
        String _indent_5 = this.indent(2);
        String _plus_11 = (_indent_5 + "composite state: ");
        String _plus_12 = (_plus_11 + behaviourState);
        String _plus_13 = (_plus_12 + " {");
        rows.add(_plus_13);
        ArrayList<String> handlerEvents = CollectionLiterals.<String>newArrayList();
        for (final ContextExceptionMapping mapping_1 : ceMapping) {
          {
            String _formatName_3 = this.formatName(mapping_1.getException().getName());
            String _plus_14 = (_formatName_3 + "RaisedIn");
            String _formatName_4 = this.formatName(mapping_1.getContext().getName());
            String _plus_15 = (_plus_14 + _formatName_4);
            String handlerEvent = (_plus_15 + "Handled");
            String _indent_6 = this.indent(3);
            String _plus_16 = (_indent_6 + "out -> ");
            String _plus_17 = (_plus_16 + "Idle");
            String _plus_18 = (_plus_17 + " by event ");
            String _plus_19 = (_plus_18 + handlerEvent);
            rows.add(_plus_19);
            handlerEvents.add(handlerEvent);
          }
        }
        String _indent_6 = this.indent(3);
        String _plus_14 = (_indent_6 + "region: r");
        rows.add(_plus_14);
        String _indent_7 = this.indent(4);
        String _plus_15 = (_indent_7 + "entry -> EnterHandler");
        rows.add(_plus_15);
        String _indent_8 = this.indent(4);
        String _plus_16 = (_indent_8 + "@Mode");
        rows.add(_plus_16);
        String _indent_9 = this.indent(4);
        String _plus_17 = (_indent_9 + "state: EnterHandler {");
        rows.add(_plus_17);
        Mode _preModeSwitch = handlerUseCase.getMain().getPreModeSwitch();
        boolean _tripleNotEquals = (_preModeSwitch != null);
        if (_tripleNotEquals) {
          String _indent_10 = this.indent(5);
          String _plus_18 = (_indent_10 + "out -> ");
          String _plus_19 = (_plus_18 + "INSERT");
          String _plus_20 = (_plus_19 + " raising ");
          String _plus_21 = (_plus_20 + "Enter");
          String _formatName_3 = this.formatName(handlerUseCase.getMain().getPreModeSwitch().getName());
          String _plus_22 = (_plus_21 + _formatName_3);
          String _plus_23 = (_plus_22 + "Mode");
          rows.add(_plus_23);
        } else {
          String _indent_11 = this.indent(5);
          String _plus_24 = (_indent_11 + "out -> ");
          String _plus_25 = (_plus_24 + "INSERT");
          rows.add(_plus_25);
        }
        String _indent_12 = this.indent(4);
        String _plus_26 = (_indent_12 + "}");
        rows.add(_plus_26);
        String _indent_13 = this.indent(4);
        String _plus_27 = (_indent_13 + "state: INSERT {");
        rows.add(_plus_27);
        String _indent_14 = this.indent(5);
        String _plus_28 = (_indent_14 + "out -> ");
        String _plus_29 = (_plus_28 + "ExitHandler");
        rows.add(_plus_29);
        String _indent_15 = this.indent(4);
        String _plus_30 = (_indent_15 + "}");
        rows.add(_plus_30);
        String _indent_16 = this.indent(4);
        String _plus_31 = (_indent_16 + "@Mode");
        rows.add(_plus_31);
        String _indent_17 = this.indent(4);
        String _plus_32 = (_indent_17 + "state: ExitHandler {");
        rows.add(_plus_32);
        Mode _postModeSwitch = handlerUseCase.getMain().getPostModeSwitch();
        boolean _tripleNotEquals_1 = (_postModeSwitch != null);
        if (_tripleNotEquals_1) {
          String _indent_18 = this.indent(5);
          String _plus_33 = (_indent_18 + "out -> Finish");
          String _plus_34 = (_plus_33 + " raising ");
          String _plus_35 = (_plus_34 + "Enter");
          String _formatName_4 = this.formatName(handlerUseCase.getMain().getPostModeSwitch().getName());
          String _plus_36 = (_plus_35 + _formatName_4);
          String _plus_37 = (_plus_36 + "Mode");
          rows.add(_plus_37);
        } else {
          String _indent_19 = this.indent(5);
          String _plus_38 = (_indent_19 + "out -> Finish");
          rows.add(_plus_38);
        }
        String _indent_20 = this.indent(4);
        String _plus_39 = (_indent_20 + "}");
        rows.add(_plus_39);
        String _indent_21 = this.indent(4);
        String _plus_40 = (_indent_21 + "state: Finish {");
        rows.add(_plus_40);
        String _indent_22 = this.indent(5);
        String _plus_41 = (_indent_22 + "out -> final");
        String _plus_42 = (_plus_41 + " raising ");
        String _join = IterableExtensions.join(handlerEvents, ", ");
        String _plus_43 = (_plus_42 + _join);
        rows.add(_plus_43);
        String _indent_23 = this.indent(4);
        String _plus_44 = (_indent_23 + "}");
        rows.add(_plus_44);
        String _indent_24 = this.indent(2);
        String _plus_45 = (_indent_24 + "}");
        rows.add(_plus_45);
        rows.add("");
      }
    }
    final Predicate<Mode> _function_3 = (Mode mode) -> {
      return mode.isDefault();
    };
    Mode defaultMode = modes.stream().filter(_function_3).findFirst().orElse(null);
    String defaultModeName = "";
    if ((defaultMode == null)) {
      defaultModeName = "null";
    } else {
      defaultModeName = defaultMode.getName();
    }
    String _indent = this.indent(1);
    String _plus = (_indent + "@Mode");
    rows.add(_plus);
    String _indent_1 = this.indent(1);
    String _plus_1 = (_indent_1 + "region: ");
    String _plus_2 = (_plus_1 + "mode_detection");
    rows.add(_plus_2);
    String _indent_2 = this.indent(2);
    String _plus_3 = (_indent_2 + "entry -> ");
    String _formatName_1 = this.formatName(defaultModeName);
    String _plus_4 = (_plus_3 + _formatName_1);
    rows.add(_plus_4);
    for (final String modeName_1 : modeNames) {
      {
        String _indent_3 = this.indent(2);
        String _plus_5 = (_indent_3 + "state: ");
        String _formatName_2 = this.formatName(modeName_1);
        String _plus_6 = (_plus_5 + _formatName_2);
        String _plus_7 = (_plus_6 + " {");
        rows.add(_plus_7);
        final Predicate<String> _function_4 = (String other) -> {
          return (!Objects.equals(other, modeName_1));
        };
        List<String> _collect = modeNames.stream().filter(_function_4).collect(Collectors.<String>toList());
        for (final String other : _collect) {
          String _indent_4 = this.indent(3);
          String _plus_8 = (_indent_4 + "out -> ");
          String _formatName_3 = this.formatName(other);
          String _plus_9 = (_plus_8 + _formatName_3);
          String _plus_10 = (_plus_9 + " by event ");
          String _plus_11 = (_plus_10 + "Enter");
          String _formatName_4 = this.formatName(other);
          String _plus_12 = (_plus_11 + _formatName_4);
          String _plus_13 = (_plus_12 + "Mode");
          rows.add(_plus_13);
        }
        String _indent_5 = this.indent(2);
        String _plus_14 = (_indent_5 + "}");
        rows.add(_plus_14);
      }
    }
    rows.add("}");
    return String.join("\n", rows);
  }

  public String indent(final int num) {
    ArrayList<String> indents = CollectionLiterals.<String>newArrayList();
    indents.add("");
    {
      int i = 0;
      boolean _while = (i < num);
      while (_while) {
        indents.add("\t");
        int _i = i;
        i = (_i + 1);
        _while = (i < num);
      }
    }
    return String.join("", indents);
  }

  public String createStateChart(final Resource resource) {
    List<UseCase> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).collect(Collectors.<UseCase>toList());
    int _size = useCases.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      return "";
    }
    IoTUseCaseModel root = EcoreUtil2.<IoTUseCaseModel>getContainerOfType(useCases.get(0), IoTUseCaseModel.class);
    List<Mode> modes = EcoreUtil2.<Mode>getAllContentsOfType(root, Mode.class).stream().collect(Collectors.<Mode>toList());
    final Function<Mode, String> _function = (Mode mode) -> {
      return mode.getName();
    };
    List<String> modeNames = modes.stream().<String>map(_function).collect(Collectors.<String>toList());
    final Predicate<Mode> _function_1 = (Mode mode) -> {
      return mode.isDefault();
    };
    Mode defaultMode = modes.stream().filter(_function_1).findFirst().orElse(null);
    String defaultModeName = "";
    if ((defaultMode == null)) {
      defaultModeName = "null";
    } else {
      defaultModeName = defaultMode.getName();
    }
    modeNames.add(defaultModeName);
    modeNames = modeNames.stream().distinct().collect(Collectors.<String>toList());
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("/* Generated */");
    _builder.newLine();
    _builder.newLine();
    _builder.append("interface: ");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�FOR uc : useCases�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�FOR step : EcoreUtil2.getAllContentsOfType(uc, InternalStep).stream().filter([step | step.isTimeout]).collect(Collectors.toList())�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("var �uc.name + step.stepNumber + \'timeout\'� : integer = �step.timeoutTime�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�ENDFOR�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�FOR name : EcoreUtil2.getAllContentsOfType(uc, ConditionControlStep).stream().map([step | formatName(step.description)]).filter([name | include(name)]).distinct().collect(Collectors.toList())�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("in event �formatName(name)�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�ENDFOR�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�ENDFOR�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�FOR modeName : modeNames�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("in event �\'Enter\' + modeName + \'Mode\'�");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("�ENDFOR�");
    _builder.newLine();
    String interface_ = _builder.toString();
    final Predicate<UseCase> _function_2 = (UseCase uc) -> {
      Level _level = uc.getLevel();
      return (_level == Level.SUMMARY);
    };
    List<UseCase> summaryLevelUseCases = useCases.stream().filter(_function_2).collect(Collectors.<UseCase>toList());
    String _scope = useCases.get(0).getScope();
    String entryStateName = ("Operating" + _scope);
    HashMap<UseCase, List<StateChartPrototypeGenerator.StateNode>> map = new HashMap<UseCase, List<StateChartPrototypeGenerator.StateNode>>();
    for (final UseCase summary : summaryLevelUseCases) {
      map.put(summary, this.collectStates(summary));
    }
    final Predicate<UseCase> _function_3 = (UseCase uc) -> {
      return (uc instanceof HandlerUseCase);
    };
    List<UseCase> handlerUseCases = useCases.stream().filter(_function_3).collect(Collectors.<UseCase>toList());
    for (final UseCase handler : handlerUseCases) {
      map.put(handler, this.collectStates(handler));
    }
    StringConcatenation _builder_1 = new StringConcatenation();
    _builder_1.append("entry -> �entryStateName�");
    _builder_1.newLine();
    _builder_1.newLine();
    _builder_1.append("orthogonal state: �entryStateName� {");
    _builder_1.newLine();
    _builder_1.append("\t");
    _builder_1.append("�FOR summary : summaryLevelUseCases�");
    _builder_1.newLine();
    _builder_1.append("\t");
    _builder_1.append("region: �\'r\' + summary.name�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�IF map.get(summary).size == 0�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("entry -> Unknown");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("state: Unknown");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�ELSE�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("entry -> �map.get(summary).get(0).name�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�FOR state : map.get(summary)�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("state: �state.name� {");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�var int index = map.get(summary).indexOf(state)�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�IF index < map.get(summary).size-1�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�var node = map.get(summary).get(index+1)�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�var internalStep = node.step as InternalStep�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("out -> �node.name� �IF internalStep.isTimeout�after �internalStep.timeoutTime� �internalStep.timeoutUnit��ENDIF�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�ELSE�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("out -> final");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�ENDIF�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("}");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�ENDFOR�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�ENDIF�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.newLine();
    _builder_1.append("\t");
    _builder_1.append("�ENDFOR�");
    _builder_1.newLine();
    _builder_1.append("\t");
    _builder_1.append("region: mode_detection");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("entry -> �defaultModeName�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�FOR modeName : modeNames�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("state: �modeName� {");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�FOR other : modeNames.stream().filter([other | other != modeName]).collect(Collectors.toList())�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("out -> �other� by event �\'Enter\' + other + \'Mode\'�");
    _builder_1.newLine();
    _builder_1.append("\t\t\t");
    _builder_1.append("�ENDFOR�");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("}");
    _builder_1.newLine();
    _builder_1.append("\t\t");
    _builder_1.append("�ENDFOR�");
    _builder_1.newLine();
    _builder_1.append("}");
    _builder_1.newLine();
    String states = _builder_1.toString();
    return (interface_ + states);
  }

  public List<StateChartPrototypeGenerator.StateNode> collectStates(final UseCase useCase) {
    List<StateChartPrototypeGenerator.StateNode> states = CollectionLiterals.<StateChartPrototypeGenerator.StateNode>newArrayList();
    HashSet<UseCase> _hashSet = new HashSet<UseCase>();
    this.collectStates(useCase, _hashSet, states);
    return states;
  }

  public void collectStates(final UseCase useCase, final HashSet<UseCase> visited, final List<StateChartPrototypeGenerator.StateNode> states) {
    boolean _contains = visited.contains(useCase);
    if (_contains) {
      return;
    }
    List<Step> steps = EcoreUtil2.<Step>getAllContentsOfType(useCase, Step.class).stream().collect(Collectors.<Step>toList());
    final Predicate<Step> _function = (Step step) -> {
      return ((step instanceof InternalStep) || (step instanceof InvocationStep));
    };
    List<Step> stateSteps = steps.stream().filter(_function).collect(Collectors.<Step>toList());
    int _size = stateSteps.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      return;
    }
    visited.add(useCase);
    for (final Step step : stateSteps) {
      {
        if ((step instanceof InternalStep)) {
          String _formatName = this.formatName(((InternalStep)step).getDescription());
          StateChartPrototypeGenerator.StateNode _stateNode = new StateChartPrototypeGenerator.StateNode(_formatName, step);
          states.add(_stateNode);
        }
        if ((step instanceof InvocationStep)) {
          this.collectStates(((InvocationStep) step).getInvokedUseCase(), visited, states);
        }
      }
    }
    visited.remove(useCase);
  }

  public String formatName(final String string) {
    String[] words = string.replaceAll("[^a-zA-Z0-9]", " ").split("\\s+");
    for (int i = 0; (i < ((List<String>)Conversions.doWrapArray(words)).size()); i++) {
      String _upperCase = (words[i]).substring(0, 1).toUpperCase();
      String _substring = (words[i]).substring(1);
      String _plus = (_upperCase + _substring);
      words[i] = _plus;
    }
    return String.join("", words);
  }

  public boolean include(final String name) {
    List<String> keywords = Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("Repeat", "While", "For Each", "Step"));
    for (final String keyword : keywords) {
      boolean _contains = name.contains(keyword);
      if (_contains) {
        return false;
      }
    }
    return true;
  }

  public String config() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("group group1 {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input  pin name1: 4, ");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output pin name2: 5");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("/****************************************************************");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("* postSetup will be called after all pins have been configured *");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("****************************************************************/");
    _builder.newLine();
    _builder.append("function postSetup {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("(param1:int, param2:String)");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("code: ||>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("Serial.printf(\"printing param1 %d and param2 %s... \", param1, param2);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<||");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }
}
