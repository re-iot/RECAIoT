package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.ucm4iot.Actor;
import mde.iot.ucm4iot.ucm4iot.ContextExceptionMapping;
import mde.iot.ucm4iot.ucm4iot.DeviceActor;
import mde.iot.ucm4iot.ucm4iot.ExceptionStep;
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock;
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase;
import mde.iot.ucm4iot.ucm4iot.HardwareException;
import mde.iot.ucm4iot.ucm4iot.InteractionStep;
import mde.iot.ucm4iot.ucm4iot.InternalStep;
import mde.iot.ucm4iot.ucm4iot.InvocationStep;
import mde.iot.ucm4iot.ucm4iot.MainScenario;
import mde.iot.ucm4iot.ucm4iot.NetworkException;
import mde.iot.ucm4iot.ucm4iot.Outcome;
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues;
import mde.iot.ucm4iot.ucm4iot.OutcomeEndings;
import mde.iot.ucm4iot.ucm4iot.OutcomeEnds;
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareException;
import mde.iot.ucm4iot.ucm4iot.Step;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

/**
 * Class: ExceptionSummaryTableGenerator
 * -------------------------------------
 * Generates Exception Summary Table.
 */
@SuppressWarnings("all")
public class ExceptionSummaryTableGenerator extends IUcm4iotGeneratorImpl {
  /**
   * generate(..)
   * ------------
   * Generates the exception summary table for all exceptions found within a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates the exception summary table for all exceptions found within a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    final List<UseCase> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).collect(Collectors.<UseCase>toList());
    final List<mde.iot.ucm4iot.ucm4iot.Exception> exceptions = StreamSupport.<mde.iot.ucm4iot.ucm4iot.Exception>stream(Iterables.<mde.iot.ucm4iot.ucm4iot.Exception>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), mde.iot.ucm4iot.ucm4iot.Exception.class).spliterator(), false).collect(Collectors.<mde.iot.ucm4iot.ucm4iot.Exception>toList());
    String table = this.generateTable(useCases, exceptions);
    this.createFile(fsa, folder, this.createFileName("exceptionSummaryTable", ".txt"), table);
  }

  /**
   * generateTable(..)
   * -----------------
   * Generates the exception summary table.
   */
  protected String generateTable(final List<UseCase> useCases, final List<mde.iot.ucm4iot.ucm4iot.Exception> exceptions) {
    HashMap<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>> exceptionInfo = new HashMap<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>();
    for (final mde.iot.ucm4iot.ucm4iot.Exception ctx : exceptions) {
      {
        HashMap<String, ArrayList<String>> table = new HashMap<String, ArrayList<String>>();
        ArrayList<String> _arrayList = new ArrayList<String>();
        table.put("type", _arrayList);
        ArrayList<String> _arrayList_1 = new ArrayList<String>();
        table.put("sources", _arrayList_1);
        ArrayList<String> _arrayList_2 = new ArrayList<String>();
        table.put("actors", _arrayList_2);
        ArrayList<String> _arrayList_3 = new ArrayList<String>();
        table.put("handlers", _arrayList_3);
        ArrayList<String> _arrayList_4 = new ArrayList<String>();
        table.put("interrupts", _arrayList_4);
        ArrayList<String> _arrayList_5 = new ArrayList<String>();
        table.put("paths", _arrayList_5);
        this.getExceptionType(ctx, table);
        this.getSources(ctx, table, useCases);
        this.getActors(ctx, table, useCases);
        this.getHandlers(ctx, table, useCases);
        this.getInterruptType(ctx, table, useCases);
        this.getPaths(ctx, table, useCases);
        this.getGlobalPaths(ctx, table, useCases);
        exceptionInfo.put(ctx, table);
      }
    }
    return this.createExceptionSummaryTable(exceptions, exceptionInfo);
  }

  /**
   * getExceptionType(..)
   * --------------------
   * Gets the type of the exception.
   */
  protected void getExceptionType(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table) {
    table.get("type").add(this.formatExceptionType(ctx));
  }

  /**
   * getSources(..)
   * --------------
   * Get the use cases that raise the exception.
   */
  protected void getSources(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table, final List<UseCase> useCases) {
    ArrayList<UseCase> _useCasesRaisingException = this.getUseCasesRaisingException(ctx, useCases);
    for (final UseCase useCase : _useCasesRaisingException) {
      table.get("sources").add(useCase.getName());
    }
  }

  /**
   * getActors(..)
   * -------------
   * Get the actors that participate in the raising of the exception.
   */
  protected void getActors(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table, final List<UseCase> useCases) {
    ArrayList<Actor> foundActors = CollectionLiterals.<Actor>newArrayList();
    ArrayList<UseCase> _useCasesRaisingException = this.getUseCasesRaisingException(ctx, useCases);
    for (final UseCase useCase : _useCasesRaisingException) {
      {
        List<Actor> possibleActors = EcoreUtil2.<Actor>getAllContentsOfType(useCase, Actor.class);
        List<ExceptionStep> _stepsRaisingException = this.getStepsRaisingException(ctx, useCase);
        for (final ExceptionStep step : _stepsRaisingException) {
          {
            ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(step, ExtensionBlock.class);
            foundActors.addAll(this.getActors(ctx, block, possibleActors));
          }
        }
      }
    }
    final Function<Actor, String> _function = (Actor actor) -> {
      return this.formatActorName(actor);
    };
    List<String> formattedActors = foundActors.stream().<String>map(_function).distinct().collect(Collectors.<String>toList());
    table.get("actors").addAll(formattedActors);
  }

  /**
   * getActors(..)
   * -------------
   * Gets the actors that participate in the raising of the exception.
   */
  private List<Actor> getActors(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final ExtensionBlock block, final List<Actor> possibleActors) {
    ArrayList<Actor> actors = CollectionLiterals.<Actor>newArrayList();
    this.getActorsHelper(ctx, block.getSteps(), possibleActors, actors);
    return actors.stream().distinct().collect(Collectors.<Actor>toList());
  }

  /**
   * getActorsHelper(..)
   * -------------------
   * Helper function to recursively search for actors.
   */
  private void getActorsHelper(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final List<Step> steps, final List<Actor> possibleActors, final List<Actor> actors) {
    int _size = steps.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      return;
    }
    final Predicate<Step> _function = (Step step) -> {
      return ((step instanceof InteractionStep) || (step instanceof InternalStep));
    };
    final Predicate<Step> _function_1 = (Step step) -> {
      boolean _isIgnoreDescription = step.isIgnoreDescription();
      return (!_isIgnoreDescription);
    };
    List<Step> candidateSteps = steps.stream().filter(_function).filter(_function_1).collect(Collectors.<Step>toList());
    for (final Step step : candidateSteps) {
      {
        final Predicate<Actor> _function_2 = (Actor actor) -> {
          return this.hasWord(step, actor.getName());
        };
        List<Actor> foundActors = possibleActors.stream().filter(_function_2).collect(Collectors.<Actor>toList());
        actors.addAll(foundActors);
      }
    }
    ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(steps.get(0), ExtensionBlock.class);
    if ((block != null)) {
      ArrayList<Step> parentSteps = this.getParentSteps(block);
      this.getActorsHelper(ctx, parentSteps, possibleActors, actors);
    }
  }

  /**
   * hasWord(..)
   * -----------
   * Returns true if a step has the passed word; false otherwise.
   */
  private boolean hasWord(final Step step, final String value) {
    String description = step.getDescription();
    if ((description == null)) {
      description = "";
    }
    String[] words = description.replaceAll("[^a-zA-Z0-9]", " ").split("\\s+");
    for (final String word : words) {
      boolean _equals = value.equals(word);
      if (_equals) {
        return true;
      }
    }
    return false;
  }

  /**
   * getHandlers(..)
   * ---------------
   * Get the handlers that handle the exception.
   */
  protected void getHandlers(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table, final List<UseCase> useCases) {
    ArrayList<HandlerUseCase> _handlers = this.getHandlers(useCases, ctx);
    for (final HandlerUseCase handler : _handlers) {
      ArrayList<String> _get = table.get("handlers");
      String _name = handler.getName();
      String _plus = ("{" + _name);
      String _plus_1 = (_plus + "}");
      _get.add(_plus_1);
    }
  }

  /**
   * getInterruptType(..)
   * --------------------
   * Gets how the exception interrupts the system.
   */
  protected void getInterruptType(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table, final List<UseCase> useCases) {
    ArrayList<String> interrupts = CollectionLiterals.<String>newArrayList();
    ArrayList<UseCase> _useCasesRaisingException = this.getUseCasesRaisingException(ctx, useCases);
    for (final UseCase useCase : _useCasesRaisingException) {
      List<ExceptionStep> _stepsRaisingException = this.getStepsRaisingException(ctx, useCase);
      for (final ExceptionStep step : _stepsRaisingException) {
        interrupts.add(this.getInterruptType(step));
      }
    }
    List<String> interruptTypes = interrupts.stream().distinct().collect(Collectors.<String>toList());
    int _size = interruptTypes.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      table.get("interrupts").add(interruptTypes.get(0));
    } else {
      int _size_1 = interruptTypes.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        final Predicate<String> _function = (String type) -> {
          return Objects.equals(type, "Interrupt and Continue");
        };
        final long x = interrupts.stream().filter(_function).count();
        final Predicate<String> _function_1 = (String type) -> {
          return Objects.equals(type, "Interrupt and Fail");
        };
        final long y = interrupts.stream().filter(_function_1).count();
        final Predicate<String> _function_2 = (String type) -> {
          return Objects.equals(type, "Cannot be Determined");
        };
        final long z = interrupts.stream().filter(_function_2).count();
        table.get("interrupts").add((("Interrupt and Continue (" + Long.valueOf(x)) + ")"));
        table.get("interrupts").add((("Interrupt and Fail (" + Long.valueOf(y)) + ")"));
        if ((z > 0)) {
          table.get("interrupts").add((("Cannot be Determined (" + Long.valueOf(z)) + ")"));
        }
      } else {
        table.get("interrupts").add("Error");
      }
    }
  }

  /**
   * getInterruptType(..)
   * --------------------
   * Gets how the exception interrupts the system.
   */
  protected String getInterruptType(final ExceptionStep step) {
    ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(step, ExtensionBlock.class);
    Outcome _outcome = block.getOutcome();
    if ((_outcome instanceof OutcomeContinues)) {
      return "Interrupt and Continue";
    } else {
      Outcome _outcome_1 = block.getOutcome();
      OutcomeEnds outcome = ((OutcomeEnds) _outcome_1);
      OutcomeEndings _type = outcome.getType();
      boolean _equals = Objects.equals(_type, OutcomeEndings.FAILURE);
      if (_equals) {
        return "Interrupt and Fail";
      } else {
        return "Cannot be Determined";
      }
    }
  }

  /**
   * getPath(..)
   * -----------
   * Get the paths that lead to the exception being raised, and handled.
   */
  protected void getPaths(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table, final List<UseCase> useCases) {
    boolean _isGlobalException = this.isGlobalException(ctx);
    if (_isGlobalException) {
      return;
    }
    ArrayList<UseCase> _useCasesRaisingException = this.getUseCasesRaisingException(ctx, useCases);
    for (final UseCase useCase : _useCasesRaisingException) {
      {
        ArrayList<HandlerUseCase> handlers = this.getHandlers(useCases, useCase, ctx);
        ArrayList<List<UseCase>> paths = this.getPaths(useCases, useCase);
        boolean _isEmpty = handlers.isEmpty();
        if (_isEmpty) {
          handlers.add(null);
        }
        for (final HandlerUseCase handler : handlers) {
          for (final List<UseCase> path : paths) {
            table.get("paths").add(this.formatPath(path, ctx, handler));
          }
        }
      }
    }
  }

  /**
   * getGlobalPaths(..)
   * ------------------
   * Determine where global exceptions can be raised.
   */
  protected void getGlobalPaths(final mde.iot.ucm4iot.ucm4iot.Exception ctx, final HashMap<String, ArrayList<String>> table, final List<UseCase> useCases) {
    boolean _isGlobalException = this.isGlobalException(ctx);
    boolean _not = (!_isGlobalException);
    if (_not) {
      return;
    }
    ArrayList<UseCase> _useCasesRaisingException = this.getUseCasesRaisingException(ctx, useCases);
    for (final UseCase useCase : _useCasesRaisingException) {
      {
        ArrayList<HandlerUseCase> handlers = this.getHandlers(useCases, useCase, ctx);
        ArrayList<List<UseCase>> paths = this.getInvocationPaths(useCases, useCase);
        boolean _isEmpty = handlers.isEmpty();
        if (_isEmpty) {
          handlers.add(null);
        }
        final Function<List<UseCase>, Stream<UseCase>> _function = (List<UseCase> path) -> {
          return path.stream();
        };
        List<UseCase> globalUseCases = paths.stream().<UseCase>flatMap(_function).distinct().collect(Collectors.<UseCase>toList());
        for (final HandlerUseCase handler : handlers) {
          for (final UseCase globalUseCase : globalUseCases) {
            table.get("paths").add(this.formatGlobalPath(useCase, globalUseCase, ctx, handler));
          }
        }
      }
    }
  }

  /**
   * getPaths(..)
   * ------------
   * Gets the paths that lead to this use case being called.
   */
  protected ArrayList<List<UseCase>> getPaths(final List<UseCase> useCases, final UseCase ctx) {
    ArrayList<List<UseCase>> paths = CollectionLiterals.<List<UseCase>>newArrayList();
    ArrayList<UseCase> _arrayList = new ArrayList<UseCase>();
    HashSet<UseCase> _hashSet = new HashSet<UseCase>();
    this.getPathsHelper(useCases, ctx, paths, _arrayList, _hashSet);
    return paths;
  }

  /**
   * getPathsHelper(..)
   * ------------------
   * Helper function that recursively searches for paths that lead to the passed use case.
   */
  private void getPathsHelper(final List<UseCase> useCases, final UseCase ctx, final List<List<UseCase>> paths, final List<UseCase> currentPath, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      ArrayList<UseCase> _arrayList = new ArrayList<UseCase>(currentPath);
      paths.add(_arrayList);
      return;
    }
    visited.add(ctx);
    currentPath.add(ctx);
    ArrayList<UseCase> parents = this.getParents(useCases, ctx);
    boolean _isEmpty = parents.isEmpty();
    if (_isEmpty) {
      ArrayList<UseCase> _arrayList_1 = new ArrayList<UseCase>(currentPath);
      paths.add(_arrayList_1);
    }
    for (final UseCase parent : parents) {
      this.getPathsHelper(useCases, parent, paths, currentPath, visited);
    }
    currentPath.remove(ctx);
    visited.remove(ctx);
  }

  /**
   * getInvocationPaths(..)
   * ----------------------
   * Gets the paths of the invoked use cases.
   */
  protected ArrayList<List<UseCase>> getInvocationPaths(final List<UseCase> useCases, final UseCase ctx) {
    ArrayList<List<UseCase>> paths = CollectionLiterals.<List<UseCase>>newArrayList();
    ArrayList<UseCase> _arrayList = new ArrayList<UseCase>();
    HashSet<UseCase> _hashSet = new HashSet<UseCase>();
    this.getInvocationPathsHelper(useCases, ctx, paths, _arrayList, _hashSet);
    return paths;
  }

  /**
   * getInvocationPathsHelper(..)
   * ----------------------------
   * Helper function that recursively searches for invoked paths from the passed use case.
   */
  private void getInvocationPathsHelper(final List<UseCase> useCases, final UseCase ctx, final List<List<UseCase>> paths, final List<UseCase> currentPath, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      ArrayList<UseCase> _arrayList = new ArrayList<UseCase>(currentPath);
      paths.add(_arrayList);
      return;
    }
    visited.add(ctx);
    currentPath.add(ctx);
    List<UseCase> children = this.getChildren(ctx);
    boolean _isEmpty = children.isEmpty();
    if (_isEmpty) {
      ArrayList<UseCase> _arrayList_1 = new ArrayList<UseCase>(currentPath);
      paths.add(_arrayList_1);
    }
    for (final UseCase child : children) {
      this.getInvocationPathsHelper(useCases, child, paths, currentPath, visited);
    }
    currentPath.remove(ctx);
    visited.remove(ctx);
  }

  /**
   * formatPath(..)
   * --------------
   * Formats the given path.
   */
  protected String formatPath(final List<UseCase> path, final mde.iot.ucm4iot.ucm4iot.Exception exception, final HandlerUseCase handler) {
    StringBuilder builder = new StringBuilder();
    ArrayList<UseCase> realPath = new ArrayList<UseCase>(path);
    UseCase last = null;
    Collections.reverse(realPath);
    for (final UseCase useCase : realPath) {
      {
        String _name = useCase.getName();
        String _plus = (_name + " >> ");
        builder.append(_plus);
        last = useCase;
      }
    }
    ArrayList<String> interrupts = CollectionLiterals.<String>newArrayList();
    List<ExceptionStep> _stepsRaisingException = this.getStepsRaisingException(exception, last);
    for (final ExceptionStep step : _stepsRaisingException) {
      interrupts.add(this.getInterruptType(step));
    }
    if ((handler == null)) {
      builder.append("{ ~ }");
    } else {
      String _name = handler.getName();
      String _plus = ("{" + _name);
      String _plus_1 = (_plus + "}");
      builder.append(_plus_1);
    }
    long _count = interrupts.stream().distinct().count();
    boolean _equals = (_count == 1);
    if (_equals) {
      String _get = interrupts.get(0);
      boolean _equals_1 = Objects.equals(_get, "Interrupt and Continue");
      if (_equals_1) {
        builder.append(" !I&C");
      } else {
        String _get_1 = interrupts.get(0);
        boolean _equals_2 = Objects.equals(_get_1, "Interrupt and Fail");
        if (_equals_2) {
          builder.append(" !I&F");
        }
      }
    }
    return builder.toString();
  }

  /**
   * formatGlobalPath(..)
   * --------------------
   * Formats a global path.
   */
  protected String formatGlobalPath(final UseCase source, final UseCase ctx, final mde.iot.ucm4iot.ucm4iot.Exception exception, final HandlerUseCase handler) {
    ArrayList<String> interrupts = CollectionLiterals.<String>newArrayList();
    List<ExceptionStep> _stepsRaisingException = this.getStepsRaisingException(exception, source);
    for (final ExceptionStep step : _stepsRaisingException) {
      interrupts.add(this.getInterruptType(step));
    }
    String interruptType = "";
    long _count = interrupts.stream().distinct().count();
    boolean _equals = (_count == 1);
    if (_equals) {
      String _get = interrupts.get(0);
      boolean _equals_1 = Objects.equals(_get, "Interrupt and Continue");
      if (_equals_1) {
        interruptType = " !I&C";
      } else {
        String _get_1 = interrupts.get(0);
        boolean _equals_2 = Objects.equals(_get_1, "Interrupt and Fail");
        if (_equals_2) {
          interruptType = " !I&F";
        }
      }
    }
    if ((source == ctx)) {
      String _name = ctx.getName();
      String _plus = (_name + " >> {");
      String _name_1 = handler.getName();
      String _plus_1 = (_plus + _name_1);
      String _plus_2 = (_plus_1 + "}");
      return (_plus_2 + interruptType);
    } else {
      String _name_2 = ctx.getName();
      String _plus_3 = ("GLOBAL::" + _name_2);
      String _plus_4 = (_plus_3 + " >> {");
      String _name_3 = handler.getName();
      String _plus_5 = (_plus_4 + _name_3);
      String _plus_6 = (_plus_5 + "}");
      return (_plus_6 + interruptType);
    }
  }

  /**
   * isGlobalException(..)
   * ---------------------
   * Returns true if the passed exception is a global exception.
   */
  protected boolean isGlobalException(final mde.iot.ucm4iot.ucm4iot.Exception ctx) {
    return ctx.isGlobal();
  }

  /**
   * getChildren(..)
   * ---------------
   * Returns a list of use cases that are invoked by the passed use case.
   */
  protected List<UseCase> getChildren(final UseCase useCase) {
    final Function<InvocationStep, UseCase> _function = (InvocationStep step) -> {
      return step.getInvokedUseCase();
    };
    return EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class).stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
  }

  /**
   * getParents(..)
   * --------------
   * Returns a list of use cases that invoke the passed use case.
   */
  protected ArrayList<UseCase> getParents(final List<UseCase> useCases, final UseCase invokedUseCase) {
    ArrayList<UseCase> parentUseCases = CollectionLiterals.<UseCase>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        final Predicate<InvocationStep> _function = (InvocationStep step) -> {
          UseCase _invokedUseCase = step.getInvokedUseCase();
          return (_invokedUseCase == invokedUseCase);
        };
        boolean hasInvokedUseCase = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class).stream().anyMatch(_function);
        if (hasInvokedUseCase) {
          parentUseCases.add(useCase);
        }
      }
    }
    return parentUseCases;
  }

  /**
   * getUseCasesRaisingException(..)
   * -------------------------------
   * Get the use cases that raise the exception.
   */
  protected ArrayList<UseCase> getUseCasesRaisingException(final mde.iot.ucm4iot.ucm4iot.Exception exception, final List<UseCase> useCases) {
    ArrayList<UseCase> sourceUseCases = CollectionLiterals.<UseCase>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        final Function<ExceptionStep, mde.iot.ucm4iot.ucm4iot.Exception> _function = (ExceptionStep step) -> {
          return step.getRefException();
        };
        List<mde.iot.ucm4iot.ucm4iot.Exception> useCaseExceptions = EcoreUtil2.<ExceptionStep>getAllContentsOfType(useCase, ExceptionStep.class).stream().<mde.iot.ucm4iot.ucm4iot.Exception>map(_function).collect(Collectors.<mde.iot.ucm4iot.ucm4iot.Exception>toList());
        boolean _contains = useCaseExceptions.contains(exception);
        if (_contains) {
          sourceUseCases.add(useCase);
        }
      }
    }
    return sourceUseCases;
  }

  /**
   * getStepsRaisingException(..)
   * ----------------------------
   * Gets the steps that raise an exception.
   */
  protected List<ExceptionStep> getStepsRaisingException(final mde.iot.ucm4iot.ucm4iot.Exception exception, final UseCase useCase) {
    final Predicate<ExceptionStep> _function = (ExceptionStep step) -> {
      mde.iot.ucm4iot.ucm4iot.Exception _refException = step.getRefException();
      return (_refException == exception);
    };
    return EcoreUtil2.<ExceptionStep>getAllContentsOfType(useCase, ExceptionStep.class).stream().filter(_function).collect(Collectors.<ExceptionStep>toList());
  }

  /**
   * getHandlers(..)
   * ---------------
   * Returns a list of use cases that handle the passed use case and exception.
   */
  protected ArrayList<HandlerUseCase> getHandlers(final List<UseCase> useCases, final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    ArrayList<HandlerUseCase> exceptionHandlers = CollectionLiterals.<HandlerUseCase>newArrayList();
    final Predicate<UseCase> _function = (UseCase uc) -> {
      return (uc instanceof HandlerUseCase);
    };
    final Function<UseCase, HandlerUseCase> _function_1 = (UseCase uc) -> {
      return ((HandlerUseCase) uc);
    };
    List<HandlerUseCase> handlers = useCases.stream().filter(_function).<HandlerUseCase>map(_function_1).collect(Collectors.<HandlerUseCase>toList());
    for (final HandlerUseCase handler : handlers) {
      {
        final Predicate<ContextExceptionMapping> _function_2 = (ContextExceptionMapping cx) -> {
          mde.iot.ucm4iot.ucm4iot.Exception _exception = cx.getException();
          return (_exception == exception);
        };
        boolean handlesException = handler.getContextExceptions().stream().anyMatch(_function_2);
        if (handlesException) {
          exceptionHandlers.add(handler);
        }
      }
    }
    return exceptionHandlers;
  }

  /**
   * getHandlers(..)
   * ---------------
   * Returns a list of use cases that handle the passed use case and exception.
   */
  protected ArrayList<HandlerUseCase> getHandlers(final List<UseCase> useCases, final UseCase context, final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    ArrayList<HandlerUseCase> exceptionHandlers = CollectionLiterals.<HandlerUseCase>newArrayList();
    final Predicate<UseCase> _function = (UseCase uc) -> {
      return (uc instanceof HandlerUseCase);
    };
    final Function<UseCase, HandlerUseCase> _function_1 = (UseCase uc) -> {
      return ((HandlerUseCase) uc);
    };
    List<HandlerUseCase> handlers = useCases.stream().filter(_function).<HandlerUseCase>map(_function_1).collect(Collectors.<HandlerUseCase>toList());
    for (final HandlerUseCase handler : handlers) {
      {
        final Predicate<ContextExceptionMapping> _function_2 = (ContextExceptionMapping cx) -> {
          return ((cx.getContext() == context) && (cx.getException() == exception));
        };
        boolean handlesException = handler.getContextExceptions().stream().anyMatch(_function_2);
        if (handlesException) {
          exceptionHandlers.add(handler);
        }
      }
    }
    return exceptionHandlers;
  }

  /**
   * getParentSteps(..)
   * ------------------
   * Returns a list of steps that are the context of an extension block.
   */
  protected ArrayList<Step> getParentSteps(final ExtensionBlock block) {
    ArrayList<Step> parentSteps = CollectionLiterals.<Step>newArrayList();
    ArrayList<Step> steps = CollectionLiterals.<Step>newArrayList();
    EObject parent = block.eContainer();
    if ((parent instanceof ExtensionBlock)) {
      steps.addAll(((ExtensionBlock) parent).getSteps());
    } else {
      MainScenario main = EcoreUtil2.<UseCase>getContainerOfType(block, UseCase.class).getMain();
      steps.addAll(main.getSteps());
    }
    int start = steps.indexOf(block.getRefStep());
    int end = (start + 1);
    boolean _isHasRangedRef = block.isHasRangedRef();
    if (_isHasRangedRef) {
      int _indexOf = steps.indexOf(block.getEndRefStep());
      int _plus = (_indexOf + 1);
      end = _plus;
    }
    parentSteps.addAll(steps.subList(start, end));
    return parentSteps;
  }

  /**
   * getActorNameAndType(..)
   * -----------------------
   * Formats the name of the passed actor.
   */
  protected String formatActorName(final Actor actor) {
    String actorFormat = "%s::%s";
    if ((actor instanceof DeviceActor)) {
      return String.format(actorFormat, "DEVICE", ((DeviceActor)actor).getName());
    } else {
      if ((actor instanceof PhysicalEntityActor)) {
        return String.format(actorFormat, "PHYSICAL_ENTITY", ((PhysicalEntityActor)actor).getName());
      } else {
        if ((actor instanceof SoftwareActor)) {
          return String.format(actorFormat, "SOFTWARE", ((SoftwareActor)actor).getName());
        } else {
          return String.format(actorFormat, "HUMAN", actor.getName());
        }
      }
    }
  }

  /**
   * formatExceptionType(..)
   * -----------------------
   * Formats the type of the passed exception.
   */
  protected String formatExceptionType(final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    String exceptionFormat = "%s";
    if ((exception instanceof HardwareException)) {
      return String.format(exceptionFormat, "HARDWARE_EXCEPTION");
    } else {
      if ((exception instanceof SoftwareException)) {
        return String.format(exceptionFormat, "SOFTWARE_EXCEPTION");
      } else {
        if ((exception instanceof NetworkException)) {
          return String.format(exceptionFormat, "NETWORK_EXCEPTION");
        } else {
          return String.format(exceptionFormat, "ENVIRONMENT_EXCEPTION");
        }
      }
    }
  }

  /**
   * createExceptionTable(..)
   * ------------------------
   * Creates the table.
   */
  protected String createExceptionSummaryTable(final List<mde.iot.ucm4iot.ucm4iot.Exception> exceptions, final HashMap<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>> exceptionInfo) {
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    final Function1<String, Function1<HashMap<String, ArrayList<String>>, List<String>>> _function = (String columnName) -> {
      final Function1<HashMap<String, ArrayList<String>>, List<String>> _function_1 = (HashMap<String, ArrayList<String>> table) -> {
        return IterableExtensions.<String>toList(table.get(columnName));
      };
      return _function_1;
    };
    final Function1<String, Function1<HashMap<String, ArrayList<String>>, List<String>>> tableToColumn = _function;
    List<String> columnNames = Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("Exception Type", "Exception Name", "Exception Source", "Associated Actors", "Handler", "Interrupt Type", "Path"));
    int _fitColumnWidth = this.<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>fitColumnWidth(columnNames.get(0), 5, exceptionInfo, new Function<HashMap<String, ArrayList<String>>, List<String>>() {
        public List<String> apply(HashMap<String, ArrayList<String>> t) {
          return tableToColumn.apply("type").apply(t);
        }
    });
    final Function<mde.iot.ucm4iot.ucm4iot.Exception, String> _function_1 = (mde.iot.ucm4iot.ucm4iot.Exception ex) -> {
      return ex.getName();
    };
    int _fitColumnWidth_1 = this.fitColumnWidth(columnNames.get(1), 5, exceptions.stream().<String>map(_function_1).collect(Collectors.<String>toList()));
    int _fitColumnWidth_2 = this.<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>fitColumnWidth(columnNames.get(2), 5, exceptionInfo, new Function<HashMap<String, ArrayList<String>>, List<String>>() {
        public List<String> apply(HashMap<String, ArrayList<String>> t) {
          return tableToColumn.apply("sources").apply(t);
        }
    });
    int _fitColumnWidth_3 = this.<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>fitColumnWidth(columnNames.get(3), 5, exceptionInfo, new Function<HashMap<String, ArrayList<String>>, List<String>>() {
        public List<String> apply(HashMap<String, ArrayList<String>> t) {
          return tableToColumn.apply("actors").apply(t);
        }
    });
    int _fitColumnWidth_4 = this.<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>fitColumnWidth(columnNames.get(4), 5, exceptionInfo, new Function<HashMap<String, ArrayList<String>>, List<String>>() {
        public List<String> apply(HashMap<String, ArrayList<String>> t) {
          return tableToColumn.apply("handlers").apply(t);
        }
    });
    int _fitColumnWidth_5 = this.<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>fitColumnWidth(columnNames.get(5), 5, exceptionInfo, new Function<HashMap<String, ArrayList<String>>, List<String>>() {
        public List<String> apply(HashMap<String, ArrayList<String>> t) {
          return tableToColumn.apply("interrupts").apply(t);
        }
    });
    int _fitColumnWidth_6 = this.<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>>fitColumnWidth(columnNames.get(6), 4, exceptionInfo, new Function<HashMap<String, ArrayList<String>>, List<String>>() {
        public List<String> apply(HashMap<String, ArrayList<String>> t) {
          return tableToColumn.apply("paths").apply(t);
        }
    });
    List<Integer> columns = Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(_fitColumnWidth), Integer.valueOf(_fitColumnWidth_1), Integer.valueOf(_fitColumnWidth_2), Integer.valueOf(_fitColumnWidth_3), Integer.valueOf(_fitColumnWidth_4), Integer.valueOf(_fitColumnWidth_5), Integer.valueOf(_fitColumnWidth_6)));
    final List<Integer> _converted_columns = (List<Integer>)columns;
    String format = this.createTableFormat(((int[])Conversions.unwrapArray(_converted_columns, int.class)));
    String line = String.format(format, "", "", "", "", "", "", "").replace(" ", "-").replace("|", "+");
    String partialLine = String.format(
      line.replaceFirst("-+", String.format("%%-%ds", columns.get(0))).replaceFirst("\\+", "|"), "");
    rows.add(line);
    String _get = columnNames.get(0);
    String _plus = (" " + _get);
    String _get_1 = columnNames.get(1);
    String _plus_1 = (" " + _get_1);
    String _get_2 = columnNames.get(2);
    String _plus_2 = (" " + _get_2);
    String _get_3 = columnNames.get(3);
    String _plus_3 = (" " + _get_3);
    String _get_4 = columnNames.get(4);
    String _plus_4 = (" " + _get_4);
    String _get_5 = columnNames.get(5);
    String _plus_5 = (" " + _get_5);
    String _get_6 = columnNames.get(6);
    String _plus_6 = (" " + _get_6);
    String _format = String.format(format, _plus, _plus_1, _plus_2, _plus_3, _plus_4, _plus_5, _plus_6);
    rows.add(_format);
    rows.add(line);
    List<String> _exceptionTypes = this.getExceptionTypes(exceptionInfo);
    for (final String exceptionType : _exceptionTypes) {
      {
        boolean exceptionTypeStarted = false;
        for (final mde.iot.ucm4iot.ucm4iot.Exception exception : exceptions) {
          {
            HashMap<String, ArrayList<String>> table = exceptionInfo.get(exception);
            String type = table.get("type").get(0);
            ArrayList<String> sources = table.get("sources");
            ArrayList<String> actors = table.get("actors");
            ArrayList<String> handlers = table.get("handlers");
            ArrayList<String> interrupts = table.get("interrupts");
            ArrayList<String> paths = table.get("paths");
            boolean _equals = exceptionType.equals(type);
            if (_equals) {
              String _name = exception.getName();
              List<? extends List<String>> rowData = Collections.<List<String>>unmodifiableList(CollectionLiterals.<List<String>>newArrayList(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(exceptionType)), Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(_name)), sources, actors, handlers, interrupts, paths));
              if (exceptionTypeStarted) {
                String _name_1 = exception.getName();
                rowData = Collections.<List<String>>unmodifiableList(CollectionLiterals.<List<String>>newArrayList(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("")), Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(_name_1)), sources, actors, handlers, interrupts, paths));
              }
              final List<? extends List<String>> _converted_rowData = (List<? extends List<String>>)rowData;
              final Integer n = this.maxSize(((List<String>[])Conversions.unwrapArray(_converted_rowData, List.class)));
              for (int i = 0; (i < (n).intValue()); i++) {
                final List<? extends List<String>> _converted_rowData_1 = (List<? extends List<String>>)rowData;
                String _format_1 = String.format(format, this.getDataOrDefault(i, ((List<String>[])Conversions.unwrapArray(_converted_rowData_1, List.class))));
                rows.add(_format_1);
              }
              rows.add(partialLine);
              exceptionTypeStarted = true;
            }
          }
        }
        if (exceptionTypeStarted) {
          int _size = rows.size();
          int _minus = (_size - 1);
          rows.remove(_minus);
          rows.add(line);
        }
      }
    }
    return String.join("\n", rows);
  }

  /**
   * getExceptionTypes(..)
   * ---------------------
   * List the exception types found in exceptionInfo
   */
  private List<String> getExceptionTypes(final HashMap<mde.iot.ucm4iot.ucm4iot.Exception, HashMap<String, ArrayList<String>>> exceptionInfo) {
    final Function<HashMap<String, ArrayList<String>>, ArrayList<String>> _function = (HashMap<String, ArrayList<String>> table) -> {
      return table.get("type");
    };
    final Function<ArrayList<String>, Stream<String>> _function_1 = (ArrayList<String> list) -> {
      return list.stream();
    };
    return exceptionInfo.values().stream().<ArrayList<String>>map(_function).<String>flatMap(_function_1).distinct().sorted().collect(Collectors.<String>toList());
  }
}
