package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.ucm4iot.Actor;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class YakinduStateChartGenerator extends IUcm4iotGeneratorImpl {
  /**
   * Class: DiagramRepresentation
   * ----------------------------
   * Creates a representation of a diagram.
   */
  protected static class DiagramRepresentation {
    private EObject element;

    private HashMap<String, List<YakinduStateChartGenerator.DiagramRepresentation>> childrenMap;

    private String tag;

    private Map<String, String> attributes;

    /**
     * Creates a new diagram representation.
     */
    public DiagramRepresentation(final EObject element, final String tag) {
      this(element, tag, new HashMap<String, String>());
    }

    /**
     * Creates a new diagram representation.
     */
    public DiagramRepresentation(final EObject element, final String tag, final Map<String, String> attributes) {
      this.element = element;
      this.tag = tag;
      HashMap<String, String> _hashMap = new HashMap<String, String>();
      this.attributes = _hashMap;
      this.attributes.putAll(attributes);
      HashMap<String, List<YakinduStateChartGenerator.DiagramRepresentation>> _hashMap_1 = new HashMap<String, List<YakinduStateChartGenerator.DiagramRepresentation>>();
      this.childrenMap = _hashMap_1;
    }

    /**
     * getElement(..)
     * --------------
     * Gets the object this element is associated with.
     */
    public EObject getElement() {
      return this.element;
    }

    /**
     * addChildren(..)
     * ---------------
     * Adds a list of children to this element.
     */
    public void addChildren(final String key, final List<YakinduStateChartGenerator.DiagramRepresentation> children) {
      boolean _containsKey = this.childrenMap.containsKey(key);
      boolean _not = (!_containsKey);
      if (_not) {
        this.childrenMap.put(key, CollectionLiterals.<YakinduStateChartGenerator.DiagramRepresentation>newArrayList());
      }
      this.childrenMap.get(key).addAll(children);
    }

    /**
     * keySet(..)
     * ----------
     * Get the keys associated with the children.
     */
    public Set<String> keySet() {
      return this.childrenMap.keySet();
    }

    /**
     * getChildren(..)
     * ---------------
     * Gets the children of this element.
     */
    public List<YakinduStateChartGenerator.DiagramRepresentation> getChildren(final String key) {
      return this.childrenMap.get(key);
    }

    /**
     * hasChildren(..)
     * ---------------
     * Returns true if this element has children.
     */
    public boolean hasChildren() {
      boolean _isEmpty = this.childrenMap.isEmpty();
      return (!_isEmpty);
    }

    /**
     * getStartTag(..)
     * ---------------
     * Gets the tag for the start of an element.
     */
    public String getStartTag() {
      boolean _isEmpty = this.attributes.isEmpty();
      if (_isEmpty) {
        return String.format("<%s>", this.tag);
      }
      return String.format("<%s %s>", this.tag, this.getAttributes());
    }

    /**
     * getEndTag(..)
     * -------------
     * Gets the tag for the end of an element.
     */
    public String getEndTag() {
      return String.format("</%s>", this.tag);
    }

    /**
     * getOneLineTag(..)
     * -----------------
     * Gets the tag in a one line representation.
     */
    public String getOneLineTag() {
      boolean _isEmpty = this.attributes.isEmpty();
      if (_isEmpty) {
        return String.format("<%s/>", this.tag);
      }
      return String.format("<%s %s/>", this.tag, this.getAttributes());
    }

    /**
     * addAttribute(..)
     * ----------------
     * Adds an attribute to this element.
     */
    public String addAttribute(final String key, final String value) {
      return this.attributes.put(key, value);
    }

    /**
     * addAttributes(..)
     * -----------------
     * Adds many attributes to this element.
     */
    public void addAttributes(final Map<String, String> attributes) {
      this.attributes.putAll(attributes);
    }

    /**
     * getAttribute(..)
     * ----------------
     * Gets an attribute from the element.
     */
    public String getAttribute(final String key) {
      return this.attributes.get(key);
    }

    /**
     * getAttributes(..)
     * -----------------
     * Gets the attributes formatted into a string.
     */
    public String getAttributes() {
      ArrayList<String> args = CollectionLiterals.<String>newArrayList();
      Set<String> _keySet = this.attributes.keySet();
      for (final String key : _keySet) {
        String _format = String.format("%s=\"%s\"", key, this.attributes.get(key));
        args.add(_format);
      }
      return String.join(" ", args);
    }
  }

  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    String data = this.createYakinduStateChart(resource);
    this.createFile(fsa, folder, this.createFileName("statechart", ".sgraph"), data);
  }

  public String createYakinduStateChart(final Resource resource) {
    HashMap<String, List<EObject>> table = this.createTable(resource);
    String tag = "sgraph:StateChart";
    Pair<String, String> _mappedTo = Pair.<String, String>of("xmi:version", "2.0");
    Pair<String, String> _mappedTo_1 = Pair.<String, String>of("xmlns:xmi", "http://www.omg.org/XMI");
    Pair<String, String> _mappedTo_2 = Pair.<String, String>of("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    Pair<String, String> _mappedTo_3 = Pair.<String, String>of("xmlns:usecasediagram", "http://www.yakindu.org/sct/sgraph/2.0.0");
    Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1, _mappedTo_2, _mappedTo_3));
    YakinduStateChartGenerator.DiagramRepresentation root = new YakinduStateChartGenerator.DiagramRepresentation(null, tag, attributes);
    List<String> data = this.createDiagram(root);
    return String.join("\n", data);
  }

  /**
   * createTable(..)
   * ---------------
   * Creates a table of information.
   */
  protected HashMap<String, List<EObject>> createTable(final Resource resource) {
    final Function<UseCase, EObject> _function = (UseCase eo) -> {
      return ((EObject) eo);
    };
    List<EObject> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).<EObject>map(_function).collect(Collectors.<EObject>toList());
    final Function<Actor, EObject> _function_1 = (Actor eo) -> {
      return ((EObject) eo);
    };
    List<EObject> actors = StreamSupport.<Actor>stream(Iterables.<Actor>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), Actor.class).spliterator(), false).<EObject>map(_function_1).collect(Collectors.<EObject>toList());
    final Function<mde.iot.ucm4iot.ucm4iot.Exception, EObject> _function_2 = (mde.iot.ucm4iot.ucm4iot.Exception eo) -> {
      return ((EObject) eo);
    };
    List<EObject> exceptions = StreamSupport.<mde.iot.ucm4iot.ucm4iot.Exception>stream(Iterables.<mde.iot.ucm4iot.ucm4iot.Exception>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), mde.iot.ucm4iot.ucm4iot.Exception.class).spliterator(), false).<EObject>map(_function_2).collect(Collectors.<EObject>toList());
    HashMap<String, List<EObject>> table = new HashMap<String, List<EObject>>();
    table.put("use_cases", useCases);
    table.put("actors", actors);
    table.put("exceptions", exceptions);
    return table;
  }

  /**
   * createDiagram(..)
   * -----------------
   * Creates a diagram.
   */
  protected List<String> createDiagram(final YakinduStateChartGenerator.DiagramRepresentation rep) {
    ArrayList<String> data = CollectionLiterals.<String>newArrayList();
    data.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    this.createDiagramHelper(rep, 0, data);
    return data;
  }

  /**
   * createDiagramHelper(..)
   * -----------------------
   * Recursively goes through a diagram representation and outputs a diagram.
   */
  private void createDiagramHelper(final YakinduStateChartGenerator.DiagramRepresentation rep, final int depth, final ArrayList<String> output) {
    if ((rep == null)) {
      return;
    }
    boolean _hasChildren = rep.hasChildren();
    if (_hasChildren) {
      String _createTabs = this.createTabs(depth);
      String _startTag = rep.getStartTag();
      String _plus = (_createTabs + _startTag);
      output.add(_plus);
      Set<String> _keySet = rep.keySet();
      for (final String key : _keySet) {
        List<YakinduStateChartGenerator.DiagramRepresentation> _children = rep.getChildren(key);
        for (final YakinduStateChartGenerator.DiagramRepresentation child : _children) {
          this.createDiagramHelper(child, (depth + 1), output);
        }
      }
      String _createTabs_1 = this.createTabs(depth);
      String _endTag = rep.getEndTag();
      String _plus_1 = (_createTabs_1 + _endTag);
      output.add(_plus_1);
    } else {
      String _createTabs_2 = this.createTabs(depth);
      String _oneLineTag = rep.getOneLineTag();
      String _plus_2 = (_createTabs_2 + _oneLineTag);
      output.add(_plus_2);
    }
  }

  /**
   * createTab(..)
   * -------------
   * Creates a string with the specified number of tabs.
   */
  private String createTabs(final int indents) {
    StringBuilder builder = new StringBuilder();
    builder.append("");
    for (int i = 0; (i < indents); i++) {
      builder.append("\t");
    }
    return builder.toString();
  }
}
