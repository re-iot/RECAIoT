package mde.iot.ucm4iot.generator;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;

/**
 * Class: ContextMenuHandlerGenerator
 * ----------------------------------
 * Generator for the context menu.
 */
@SuppressWarnings("all")
public class ContextMenuHandlerGenerator extends AbstractGenerator {
  public static final String GEN_EXCEPTION_LIST = "exceptions/";

  public static final String GEN_HANDLER_LIST = "handlers/";

  public static final String OUTDATED_LIST = "outdated/";

  /**
   * doGenerate(..)
   * --------------
   * Generates exception related artifacts from a UCM4IoT model.
   */
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    Date date = Calendar.getInstance().getTime();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss/");
    HandlerTableGenerator handlerGenerator = new HandlerTableGenerator();
    String _format = dateFormat.format(date);
    String _plus = (_format + ContextMenuHandlerGenerator.GEN_HANDLER_LIST);
    handlerGenerator.generate(resource, fsa, context, _plus);
  }
}
