package mde.iot.ucm4iot.generator;

import java.io.IOException;
import java.util.HashMap;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.Exceptions;

@SuppressWarnings("all")
public class EcoreGenerator extends IUcm4iotGeneratorImpl {
  /**
   * generate(..)
   * ------------
   * Generates an ecore file from a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates an ecore file from a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    try {
      HashMap<String, String> saveOptions = new HashMap<String, String>();
      saveOptions.put(XMLResource.OPTION_ENCODING, "UTF-8");
      String path = resource.getURI().toString().replace("ucmiot", "ucmiot.xmi");
      URI _createURI = URI.createURI(path);
      XMIResourceImpl xmiResource = new XMIResourceImpl(_createURI);
      xmiResource.getContents().add(resource.getContents().get(0));
      xmiResource.save(saveOptions);
      System.out.println("Xmi file created.");
    } catch (final Throwable _t) {
      if (_t instanceof IOException) {
        final IOException e = (IOException)_t;
        System.out.println("Error during creating Xmi.");
        e.printStackTrace();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
}
