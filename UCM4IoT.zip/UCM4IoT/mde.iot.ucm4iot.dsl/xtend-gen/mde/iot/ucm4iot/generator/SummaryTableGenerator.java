package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.Ucm4iotUtilities;
import mde.iot.ucm4iot.ucm4iot.Actor;
import mde.iot.ucm4iot.ucm4iot.DeviceActor;
import mde.iot.ucm4iot.ucm4iot.EnvironmentException;
import mde.iot.ucm4iot.ucm4iot.ExceptionStep;
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase;
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock;
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase;
import mde.iot.ucm4iot.ucm4iot.HardwareException;
import mde.iot.ucm4iot.ucm4iot.HumanActor;
import mde.iot.ucm4iot.ucm4iot.InteractionStep;
import mde.iot.ucm4iot.ucm4iot.InvocationStep;
import mde.iot.ucm4iot.ucm4iot.MainScenario;
import mde.iot.ucm4iot.ucm4iot.NetworkException;
import mde.iot.ucm4iot.ucm4iot.Outcome;
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues;
import mde.iot.ucm4iot.ucm4iot.OutcomeEndings;
import mde.iot.ucm4iot.ucm4iot.OutcomeEnds;
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareException;
import mde.iot.ucm4iot.ucm4iot.Step;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

/**
 * Obsolete - Feel free to remove.
 * 
 * Class: SummaryTableGenerator
 * ----------------------------
 * Generates Exception Summary Tables.
 */
@SuppressWarnings("all")
public class SummaryTableGenerator extends IUcm4iotGeneratorImpl {
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates summary tables for all use cases within a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    List<UseCase> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).collect(Collectors.<UseCase>toList());
    ArrayList<String> logs = CollectionLiterals.<String>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        String log = this.generateTable(useCases, useCase);
        String _name = useCase.getName();
        String _plus = ("exceptionTable-" + _name);
        this.createFile(fsa, folder, this.createFileName(_plus, ".txt"), log);
        logs.add(log);
      }
    }
    this.createFile(fsa, folder, this.createFileName("exceptionTables", ".txt"), String.join("\n\n\n", logs));
  }

  /**
   * generateTable(..)
   * -----------------
   * Generates a summary table for the passed use case.
   */
  protected String generateTable(final List<UseCase> useCases, final UseCase ctx) {
    ArrayList<Object> _newArrayList = CollectionLiterals.<Object>newArrayList();
    Pair<String, ArrayList<Object>> _mappedTo = Pair.<String, ArrayList<Object>>of("exceptions", _newArrayList);
    ArrayList<Object> _newArrayList_1 = CollectionLiterals.<Object>newArrayList();
    Pair<String, ArrayList<Object>> _mappedTo_1 = Pair.<String, ArrayList<Object>>of("interrupts", _newArrayList_1);
    ArrayList<Object> _newArrayList_2 = CollectionLiterals.<Object>newArrayList();
    Pair<String, ArrayList<Object>> _mappedTo_2 = Pair.<String, ArrayList<Object>>of("sources", _newArrayList_2);
    ArrayList<Object> _newArrayList_3 = CollectionLiterals.<Object>newArrayList();
    Pair<String, ArrayList<Object>> _mappedTo_3 = Pair.<String, ArrayList<Object>>of("levels", _newArrayList_3);
    ArrayList<Object> _newArrayList_4 = CollectionLiterals.<Object>newArrayList();
    Pair<String, ArrayList<Object>> _mappedTo_4 = Pair.<String, ArrayList<Object>>of("globals", _newArrayList_4);
    ArrayList<Object> _newArrayList_5 = CollectionLiterals.<Object>newArrayList();
    Pair<String, ArrayList<Object>> _mappedTo_5 = Pair.<String, ArrayList<Object>>of("handlers", _newArrayList_5);
    Map<String, ArrayList<Object>> table = Collections.<String, ArrayList<Object>>unmodifiableMap(CollectionLiterals.<String, ArrayList<Object>>newHashMap(_mappedTo, _mappedTo_1, _mappedTo_2, _mappedTo_3, _mappedTo_4, _mappedTo_5));
    LinkedHashMap<mde.iot.ucm4iot.ucm4iot.Exception, List<String>> pathMap = CollectionLiterals.<mde.iot.ucm4iot.ucm4iot.Exception, List<String>>newLinkedHashMap();
    LinkedHashMap<mde.iot.ucm4iot.ucm4iot.Exception, List<Actor>> actorMap = CollectionLiterals.<mde.iot.ucm4iot.ucm4iot.Exception, List<Actor>>newLinkedHashMap();
    HashSet<UseCase> _hashSet = new HashSet<UseCase>();
    this.getExceptions(ctx, table, _hashSet);
    HashSet<UseCase> _hashSet_1 = new HashSet<UseCase>();
    this.getGlobalExceptions(useCases, ctx, ctx, table, _hashSet_1);
    this.getHandlers(useCases, table);
    this.getPaths(useCases, ctx, table, pathMap);
    this.getExceptionActors(table, actorMap);
    return this.createExceptionTable(ctx, table, pathMap, actorMap);
  }

  /**
   * getExceptions(..)
   * -----------------
   * Gets exceptions recursively.
   */
  protected void getExceptions(final UseCase ctx, final Map<String, ArrayList<Object>> table, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      return;
    }
    final Function<ExceptionStep, mde.iot.ucm4iot.ucm4iot.Exception> _function = (ExceptionStep step) -> {
      return step.getRefException();
    };
    List<mde.iot.ucm4iot.ucm4iot.Exception> foundExceptions = EcoreUtil2.<ExceptionStep>getAllContentsOfType(ctx, ExceptionStep.class).stream().<mde.iot.ucm4iot.ucm4iot.Exception>map(_function).collect(Collectors.<mde.iot.ucm4iot.ucm4iot.Exception>toList());
    for (final mde.iot.ucm4iot.ucm4iot.Exception exception : foundExceptions) {
      {
        table.get("exceptions").add(exception);
        table.get("interrupts").add(this.getInterruptType(ctx, exception));
        table.get("sources").add(ctx);
        table.get("levels").add(ctx.getLevel());
        table.get("globals").add(Boolean.valueOf(false));
      }
    }
    visited.add(ctx);
    List<UseCase> invokedUseCases = this.getInvokedUseCases(ctx);
    for (final UseCase invokedUseCase : invokedUseCases) {
      this.getExceptions(invokedUseCase, table, visited);
    }
  }

  /**
   * getGlobalExceptions(..)
   * -----------------------
   * Get global exceptions by searching recursively upwards.
   */
  protected void getGlobalExceptions(final List<UseCase> useCases, final UseCase start, final UseCase ctx, final Map<String, ArrayList<Object>> table, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      return;
    }
    final Function<ExceptionStep, mde.iot.ucm4iot.ucm4iot.Exception> _function = (ExceptionStep step) -> {
      return step.getRefException();
    };
    final Predicate<mde.iot.ucm4iot.ucm4iot.Exception> _function_1 = (mde.iot.ucm4iot.ucm4iot.Exception step) -> {
      return (step instanceof EnvironmentException);
    };
    List<mde.iot.ucm4iot.ucm4iot.Exception> foundExceptions = EcoreUtil2.<ExceptionStep>getAllContentsOfType(ctx, ExceptionStep.class).stream().<mde.iot.ucm4iot.ucm4iot.Exception>map(_function).filter(_function_1).collect(Collectors.<mde.iot.ucm4iot.ucm4iot.Exception>toList());
    for (final mde.iot.ucm4iot.ucm4iot.Exception exception : foundExceptions) {
      boolean _contains = table.get("exceptions").contains(exception);
      boolean _not = (!_contains);
      if (_not) {
        table.get("exceptions").add(exception);
        table.get("interrupts").add(this.getInterruptType(ctx, exception));
        table.get("sources").add(ctx);
        table.get("levels").add(ctx.getLevel());
        table.get("globals").add(Boolean.valueOf(true));
      }
    }
    visited.add(ctx);
    List<UseCase> parents = this.findParentUseCases(useCases, ctx);
    for (final UseCase parent : parents) {
      this.getGlobalExceptions(useCases, start, parent, table, visited);
    }
  }

  /**
   * getHandlers(..)
   * ---------------
   * Gets a handler that handles the given exception.
   */
  protected void getHandlers(final List<UseCase> useCases, final Map<String, ArrayList<Object>> table) {
    final Predicate<UseCase> _function = (UseCase useCase) -> {
      return (useCase instanceof HandlerUseCase);
    };
    final Function<UseCase, HandlerUseCase> _function_1 = (UseCase useCase) -> {
      return ((HandlerUseCase) useCase);
    };
    List<HandlerUseCase> potentialHandlers = useCases.stream().filter(_function).<HandlerUseCase>map(_function_1).collect(Collectors.<HandlerUseCase>toList());
    ArrayList<Object> _get = table.get("exceptions");
    for (final Object exception : _get) {
      table.get("handlers").add(Ucm4iotUtilities.findHandlerForException(potentialHandlers, ((mde.iot.ucm4iot.ucm4iot.Exception) exception)));
    }
  }

  /**
   * getExceptionActors(..)
   * ----------------------
   * Gets the actors that appear when an exception is raised.
   */
  protected void getExceptionActors(final Map<String, ArrayList<Object>> table, final HashMap<mde.iot.ucm4iot.ucm4iot.Exception, List<Actor>> actorMap) {
    for (int n = 0; (n < table.get("exceptions").size()); n++) {
      {
        Object _get = table.get("exceptions").get(n);
        final mde.iot.ucm4iot.ucm4iot.Exception exception = ((mde.iot.ucm4iot.ucm4iot.Exception) _get);
        Object _get_1 = table.get("sources").get(n);
        UseCase useCase = ((UseCase) _get_1);
        final Predicate<ExceptionStep> _function = (ExceptionStep step) -> {
          mde.iot.ucm4iot.ucm4iot.Exception _refException = step.getRefException();
          return (_refException == exception);
        };
        List<ExceptionStep> relevantSteps = EcoreUtil2.<ExceptionStep>getAllContentsOfType(useCase, ExceptionStep.class).stream().filter(_function).collect(Collectors.<ExceptionStep>toList());
        ExceptionStep _get_2 = relevantSteps.get(0);
        Step step = ((Step) _get_2);
        HashSet<Actor> actors = new HashSet<Actor>();
        List<Step> list = Collections.<Step>unmodifiableList(CollectionLiterals.<Step>newArrayList(step));
        this.getExceptionActorsHelper(useCase, list, Ucm4iotUtilities.getActors(useCase), actors);
        ArrayList<Actor> _arrayList = new ArrayList<Actor>(actors);
        actorMap.put(exception, _arrayList);
      }
    }
  }

  private void getExceptionActorsHelper(final UseCase useCase, final List<Step> steps, final List<Actor> poss_actors, final HashSet<Actor> actors) {
    int _size = steps.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      return;
    }
    for (final Step step : steps) {
      if (((step instanceof InteractionStep) && (!step.isIgnoreDescription()))) {
        final Predicate<Actor> _function = (Actor actor) -> {
          return this.hasWord(step, Ucm4iotUtilities.getActorName(actor));
        };
        Set<Actor> actorsInStep = poss_actors.stream().filter(_function).collect(Collectors.<Actor>toSet());
        actors.addAll(actorsInStep);
      }
    }
    ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(steps.get(0), ExtensionBlock.class);
    if ((block != null)) {
      Step parentStep = block.getRefStep();
      ArrayList<Step> list = CollectionLiterals.<Step>newArrayList();
      list.add(parentStep);
      boolean _isHasRangedRef = block.isHasRangedRef();
      if (_isHasRangedRef) {
        List<Step> flow = this.getSurroundingStep(parentStep).stream().collect(Collectors.<Step>toList());
        boolean include = false;
        for (final Step s : flow) {
          {
            Step _refStep = block.getRefStep();
            boolean _tripleEquals = (s == _refStep);
            if (_tripleEquals) {
              include = true;
            } else {
              Step _endRefStep = block.getEndRefStep();
              boolean _tripleEquals_1 = (s == _endRefStep);
              if (_tripleEquals_1) {
                include = false;
              }
            }
            if ((include == true)) {
              list.add(s);
            }
          }
        }
      }
      this.getExceptionActorsHelper(useCase, list, poss_actors, actors);
    }
  }

  private List<Step> getSurroundingStep(final Step step) {
    ArrayList<Step> steps = CollectionLiterals.<Step>newArrayList();
    EObject _eContainer = step.eContainer();
    if ((_eContainer instanceof ExtensionBlock)) {
      ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(step, ExtensionBlock.class);
      EList<Step> _steps = block.getSteps();
      ArrayList<Step> _arrayList = new ArrayList<Step>(_steps);
      steps = _arrayList;
    } else {
      EObject _eContainer_1 = step.eContainer();
      if ((_eContainer_1 instanceof MainScenario)) {
        MainScenario main = EcoreUtil2.<MainScenario>getContainerOfType(step, MainScenario.class);
        EList<Step> _steps_1 = main.getSteps();
        ArrayList<Step> _arrayList_1 = new ArrayList<Step>(_steps_1);
        steps = _arrayList_1;
      }
    }
    return steps;
  }

  /**
   * getPaths(..)
   * ------------
   * Gets the paths that lead to an exception occurring.
   */
  protected void getPaths(final List<UseCase> useCases, final UseCase ctx, final Map<String, ArrayList<Object>> table, final HashMap<mde.iot.ucm4iot.ucm4iot.Exception, List<String>> pathMap) {
    final Predicate<UseCase> _function = (UseCase useCase) -> {
      return (useCase instanceof HandlerUseCase);
    };
    final Function<UseCase, HandlerUseCase> _function_1 = (UseCase useCase) -> {
      return ((HandlerUseCase) useCase);
    };
    List<HandlerUseCase> handlers = useCases.stream().filter(_function).<HandlerUseCase>map(_function_1).collect(Collectors.<HandlerUseCase>toList());
    for (int n = 0; (n < table.get("exceptions").size()); n++) {
      {
        Object _get = table.get("exceptions").get(n);
        mde.iot.ucm4iot.ucm4iot.Exception exception = ((mde.iot.ucm4iot.ucm4iot.Exception) _get);
        List<HandlerUseCase> parentHandlers = Ucm4iotUtilities.findHandlersForException(handlers, exception);
        ArrayList<String> parentHandlerPaths = new ArrayList<String>();
        for (final HandlerUseCase handler : parentHandlers) {
          {
            ArrayList<UseCase> parentHandlerUseCases = CollectionLiterals.<UseCase>newArrayList();
            ArrayList<Integer> parentHandlerLevels = CollectionLiterals.<Integer>newArrayList();
            HashSet<UseCase> _hashSet = new HashSet<UseCase>();
            this.getPathsHelper(useCases, parentHandlerUseCases, parentHandlerLevels, handler, 0, _hashSet);
            for (int i = 0; (i < parentHandlerUseCases.size()); i++) {
              {
                String path = this.createPath(parentHandlerUseCases, parentHandlerLevels, i);
                boolean _startsWith = path.startsWith(handler.getName());
                if (_startsWith) {
                  String _name = handler.getName();
                  String _name_1 = handler.getName();
                  String _plus = ("{" + _name_1);
                  String _plus_1 = (_plus + "}");
                  path = path.replaceFirst(_name, _plus_1);
                  parentHandlerPaths.add(path);
                }
              }
            }
          }
        }
        Object _get_1 = table.get("sources").get(n);
        UseCase source = ((UseCase) _get_1);
        Object _get_2 = table.get("globals").get(n);
        Boolean isGlobal = ((Boolean) _get_2);
        ArrayList<UseCase> parentUseCases = CollectionLiterals.<UseCase>newArrayList();
        ArrayList<Integer> levels = CollectionLiterals.<Integer>newArrayList();
        HashSet<UseCase> _hashSet = new HashSet<UseCase>();
        this.getPathsHelper(useCases, parentUseCases, levels, source, 0, _hashSet);
        ArrayList<String> paths = new ArrayList<String>();
        for (int i = 0; (i < parentUseCases.size()); i++) {
          {
            String path = this.createPath(parentUseCases, levels, i);
            if ((isGlobal).booleanValue()) {
              int _size = parentHandlerPaths.size();
              boolean _greaterThan = (_size > 0);
              if (_greaterThan) {
                for (final String handlerPath : parentHandlerPaths) {
                  String _name = ctx.getName();
                  String _plus = ("GLOBAL::" + _name);
                  String _plus_1 = (_plus + " >> ");
                  String _plus_2 = (_plus_1 + handlerPath);
                  paths.add(_plus_2);
                }
              } else {
                String _name_1 = ctx.getName();
                String _plus_3 = ("GLOBAL::" + _name_1);
                String _plus_4 = (_plus_3 + " >> {~No Handler~}");
                paths.add(_plus_4);
              }
            } else {
              boolean _startsWith = path.startsWith(ctx.getName());
              if (_startsWith) {
                int _size_1 = parentHandlerPaths.size();
                boolean _greaterThan_1 = (_size_1 > 0);
                if (_greaterThan_1) {
                  for (final String handlerPath_1 : parentHandlerPaths) {
                    paths.add(((path + " >> ") + handlerPath_1));
                  }
                } else {
                  paths.add((path + " >> {~No Handler~}"));
                }
              }
            }
            pathMap.put(exception, paths);
          }
        }
      }
    }
  }

  private void getPathsHelper(final List<UseCase> useCases, final List<UseCase> containers, final List<Integer> levels, final UseCase ctx, final int level, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      return;
    }
    containers.add(ctx);
    levels.add(Integer.valueOf(level));
    visited.add(ctx);
    List<UseCase> parents = this.findParentUseCases(useCases, ctx);
    for (final UseCase parent : parents) {
      this.getPathsHelper(useCases, containers, levels, parent, (level + 1), visited);
    }
    visited.remove(ctx);
  }

  private String createPath(final List<UseCase> parentUseCases, final List<Integer> levels, final int index) {
    StringBuilder path = new StringBuilder();
    path.append(parentUseCases.get(index).getName());
    Integer _get = levels.get(index);
    int level = ((_get).intValue() - 1);
    for (int i = index; (i >= 0); i--) {
      Integer _get_1 = levels.get(i);
      boolean _equals = ((_get_1).intValue() == level);
      if (_equals) {
        path.append(" -> ");
        path.append(parentUseCases.get(i).getName());
        level--;
      }
    }
    return path.toString();
  }

  /**
   * getInvokedUseCases(..)
   * ----------------------
   * Gets the invoked use cases within a use case.
   */
  protected List<UseCase> getInvokedUseCases(final UseCase useCase) {
    final Function<InvocationStep, UseCase> _function = (InvocationStep step) -> {
      return step.getInvokedUseCase();
    };
    List<UseCase> invocations = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class).stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
    return invocations;
  }

  /**
   * findParentUseCases(..)
   * ----------------------
   * Find use cases that invoke the given use case.
   */
  protected List<UseCase> findParentUseCases(final List<UseCase> useCases, final UseCase invokedUseCase) {
    ArrayList<UseCase> parentUseCases = CollectionLiterals.<UseCase>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        final Predicate<InvocationStep> _function = (InvocationStep step) -> {
          UseCase _invokedUseCase = step.getInvokedUseCase();
          return (_invokedUseCase == invokedUseCase);
        };
        boolean hasInvokedUseCase = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class).stream().anyMatch(_function);
        if (hasInvokedUseCase) {
          parentUseCases.add(useCase);
        }
      }
    }
    return parentUseCases;
  }

  /**
   * getInterruptType(..)
   * --------------------
   * Determine the interrupt type of an exception within a use case.
   */
  protected String getInterruptType(final UseCase useCase, final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    final Predicate<ExceptionStep> _function = (ExceptionStep step) -> {
      mde.iot.ucm4iot.ucm4iot.Exception _refException = step.getRefException();
      return (_refException == exception);
    };
    List<ExceptionStep> relevantSteps = EcoreUtil2.<ExceptionStep>getAllContentsOfType(useCase, ExceptionStep.class).stream().filter(_function).collect(Collectors.<ExceptionStep>toList());
    ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(relevantSteps.get(0), ExtensionBlock.class);
    Outcome _outcome = block.getOutcome();
    if ((_outcome instanceof OutcomeContinues)) {
      return "Interrupt and continue";
    } else {
      Outcome _outcome_1 = block.getOutcome();
      OutcomeEnds outcome = ((OutcomeEnds) _outcome_1);
      OutcomeEndings _type = outcome.getType();
      boolean _equals = Objects.equals(_type, OutcomeEndings.FAILURE);
      if (_equals) {
        return "Interrupt and fail";
      } else {
        return "Unknown";
      }
    }
  }

  /**
   * getActorNameAndType(..)
   * -----------------------
   * Gets the name of an actor.
   */
  public String getActorNameAndType(final Actor actor) {
    if ((actor instanceof DeviceActor)) {
      String _name = ((DeviceActor) actor).getName();
      return ("DEVICE::" + _name);
    } else {
      if ((actor instanceof PhysicalEntityActor)) {
        String _name_1 = ((PhysicalEntityActor) actor).getName();
        return ("PHYSICAL_ENTITY::" + _name_1);
      } else {
        if ((actor instanceof SoftwareActor)) {
          String _name_2 = ((SoftwareActor) actor).getName();
          return ("SOFTWARE::" + _name_2);
        } else {
          String _name_3 = ((HumanActor) actor).getName();
          return ("HUMAN::" + _name_3);
        }
      }
    }
  }

  /**
   * hasWord(..)
   * -----------
   * Returns true if a step has the passed word; false otherwise.
   */
  public boolean hasWord(final Step step, final String value) {
    String description = step.getDescription();
    if ((description == null)) {
      description = "";
    }
    String[] words = description.replaceAll("[^a-zA-Z0-9]", " ").split("\\s+");
    for (final String word : words) {
      boolean _equals = value.equals(word);
      if (_equals) {
        return true;
      }
    }
    return false;
  }

  /**
   * createExceptionTable(..)
   * ------------------------
   * Creates the table.
   */
  private String createExceptionTable(final UseCase ctx, final Map<String, ArrayList<Object>> table, final HashMap<mde.iot.ucm4iot.ucm4iot.Exception, List<String>> pathMap, final HashMap<mde.iot.ucm4iot.ucm4iot.Exception, List<Actor>> actorMap) {
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    List<Integer> columns = Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(22), Integer.valueOf(26), Integer.valueOf(25), Integer.valueOf(30), Integer.valueOf(20), Integer.valueOf(24), Integer.valueOf(180)));
    final BinaryOperator<Integer> _function = (Integer a, Integer b) -> {
      return Integer.valueOf(((a).intValue() + (b).intValue()));
    };
    Integer _reduce = columns.stream().reduce(Integer.valueOf(0), _function);
    int _size = columns.size();
    int _plus = ((_reduce).intValue() + _size);
    int _minus = (_plus - 1);
    String titleFormat = this.createTableFormat(_minus);
    String titleLine = String.format(titleFormat, "").replace(" ", "-").replace("|", "+");
    final List<Integer> _converted_columns = (List<Integer>)columns;
    String format = this.createTableFormat(((int[])Conversions.unwrapArray(_converted_columns, int.class)));
    String line = String.format(format, "", "", "", "", "", "", "").replace(" ", "-").replace("|", "+");
    String subLine = String.format(
      line.replaceFirst("-+", String.format("%%-%ds", columns.get(0))).replaceFirst("\\+", "|"), "");
    rows.add(titleLine);
    if ((ctx instanceof ExceptionalUseCase)) {
      String _name = ((ExceptionalUseCase)ctx).getName();
      String _plus_1 = (" Exceptional Use Case: " + _name);
      String _format = String.format(titleFormat, _plus_1);
      rows.add(_format);
    } else {
      if ((ctx instanceof HandlerUseCase)) {
        String _name_1 = ((HandlerUseCase)ctx).getName();
        String _plus_2 = (" Handler Use Case: " + _name_1);
        String _format_1 = String.format(titleFormat, _plus_2);
        rows.add(_format_1);
      }
    }
    rows.add(line);
    String _format_2 = String.format(format, " Exception Type", " Exception Name", " Exception Source", " Associated Actors", " Handler", " Interrupt Type", " Path >> {HANDLER}");
    rows.add(_format_2);
    rows.add(line);
    List<? extends Class<? extends mde.iot.ucm4iot.ucm4iot.Exception>> types = Collections.<Class<? extends mde.iot.ucm4iot.ucm4iot.Exception>>unmodifiableList(CollectionLiterals.<Class<? extends mde.iot.ucm4iot.ucm4iot.Exception>>newArrayList(HardwareException.class, SoftwareException.class, NetworkException.class, EnvironmentException.class));
    for (final Class<? extends mde.iot.ucm4iot.ucm4iot.Exception> type : types) {
      {
        int newGroup = 0;
        boolean elmAdded = false;
        for (int i = 0; (i < table.get("exceptions").size()); i++) {
          {
            Object _get = table.get("exceptions").get(i);
            mde.iot.ucm4iot.ucm4iot.Exception exception = ((mde.iot.ucm4iot.ucm4iot.Exception) _get);
            Object _get_1 = table.get("interrupts").get(i);
            String interrupt = ((String) _get_1);
            Object _get_2 = table.get("sources").get(i);
            UseCase source = ((UseCase) _get_2);
            Object _get_3 = table.get("handlers").get(i);
            HandlerUseCase handler = ((HandlerUseCase) _get_3);
            List<String> paths = pathMap.get(exception);
            List<Actor> actors = actorMap.get(exception);
            boolean _isInstance = type.isInstance(exception);
            if (_isInstance) {
              String _xifexpression = null;
              int _plusPlus = newGroup++;
              boolean _equals = (_plusPlus == 0);
              if (_equals) {
                String _simpleName = type.getSimpleName();
                _xifexpression = (" " + _simpleName);
              } else {
                _xifexpression = "";
              }
              String exceptionGroup = _xifexpression;
              String _name_2 = exception.getName();
              String exceptionName = (" " + _name_2);
              String _name_3 = source.getName();
              String sourceName = (" " + _name_3);
              String _xifexpression_1 = null;
              if ((handler != null)) {
                String _name_4 = handler.getName();
                _xifexpression_1 = (" " + _name_4);
              } else {
                _xifexpression_1 = " n/a";
              }
              String handlerName = _xifexpression_1;
              String interruptType = (" " + interrupt);
              int _size_1 = actors.size();
              boolean _greaterThan = (_size_1 > 0);
              if (_greaterThan) {
                String _actorNameAndType = this.getActorNameAndType(actors.get(0));
                String actorName = (" " + _actorNameAndType);
                String _get_4 = paths.get(0);
                String path = (" " + _get_4);
                String _format_3 = String.format(format, exceptionGroup, exceptionName, sourceName, actorName, handlerName, interruptType, path);
                rows.add(_format_3);
              } else {
                String _get_5 = paths.get(0);
                String path_1 = (" " + _get_5);
                String _format_4 = String.format(format, exceptionGroup, exceptionName, sourceName, " n/a", handlerName, interruptType, path_1);
                rows.add(_format_4);
              }
              int j = 1;
              for (; ((j < paths.size()) && (j < actors.size())); j++) {
                {
                  String _actorNameAndType_1 = this.getActorNameAndType(actors.get(j));
                  String actorName_1 = (" " + _actorNameAndType_1);
                  String _get_6 = paths.get(j);
                  String path_2 = (" " + _get_6);
                  String _format_5 = String.format(format, "", "", "", actorName_1, "", "", path_2);
                  rows.add(_format_5);
                }
              }
              for (; (j < paths.size()); j++) {
                {
                  String _get_6 = paths.get(j);
                  String path_2 = (" " + _get_6);
                  String _format_5 = String.format(format, "", "", "", "", "", "", path_2);
                  rows.add(_format_5);
                }
              }
              for (; (j < actors.size()); j++) {
                {
                  String _actorNameAndType_1 = this.getActorNameAndType(actors.get(j));
                  String actorName_1 = (" " + _actorNameAndType_1);
                  String _format_5 = String.format(format, "", "", "", actorName_1, "", "", "");
                  rows.add(_format_5);
                }
              }
              rows.add(subLine);
              elmAdded = true;
            }
          }
        }
        int _size_1 = rows.size();
        int _minus_1 = (_size_1 - 1);
        boolean _equals = rows.get(_minus_1).equals(subLine);
        if (_equals) {
          int _size_2 = rows.size();
          int _minus_2 = (_size_2 - 1);
          rows.remove(_minus_2);
        }
        if (elmAdded) {
          rows.add(line);
        }
      }
    }
    return String.join("\n", rows);
  }
}
