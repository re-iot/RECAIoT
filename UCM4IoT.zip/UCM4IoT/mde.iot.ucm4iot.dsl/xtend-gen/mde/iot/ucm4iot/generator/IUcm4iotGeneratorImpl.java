package mde.iot.ucm4iot.generator;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;

/**
 * Class: IUcm4iotGeneratorImpl
 * ----------------------------
 * Implementation of the IUcm4iotGenerator interface.
 */
@SuppressWarnings("all")
public abstract class IUcm4iotGeneratorImpl implements IUcm4iotGenerator {
  @Override
  public abstract void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context);

  @Override
  public abstract void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder);

  /**
   * createFileName(..)
   * ------------------
   * Creates a file name with a given file extension.
   */
  @Override
  public String createFileName(final String name, final String ext) {
    if ((((ext != null) && ext.trim().isEmpty()) && (!ext.startsWith(".")))) {
      throw new IllegalArgumentException("File extension is not valid. Make sure passed argument begins with \'.\'");
    }
    return (name + ext);
  }

  /**
   * createFile(..)
   * --------------
   * Creates a file.
   */
  @Override
  public void createFile(final IFileSystemAccess2 fsa, final String path, final String file, final String data) {
    fsa.generateFile(((path + "/") + file), data);
  }

  /**
   * createTableFormat(..)
   * ---------------------
   * Creates the format of a table.
   */
  protected String createTableFormat(final int... columnSizes) {
    StringBuilder formatBuilder = new StringBuilder();
    for (final int size : columnSizes) {
      formatBuilder.append(String.format(" %%-%ds ", Integer.valueOf(size)));
    }
    return formatBuilder.toString().replaceAll(" +", " ").replaceAll(" ", "|");
  }

  /**
   * fitColumnWidth(..)
   * ------------------
   * Generic function to transform the values from a hash table into string representations.
   */
  protected <T extends Object, U extends Object> int fitColumnWidth(final String columnName, final int defaultSize, final HashMap<T, U> table, final Function<U, List<String>> getData) {
    int n = 0;
    Set<T> _keySet = table.keySet();
    for (final T key : _keySet) {
      {
        U value = table.get(key);
        int temp = this.fitColumnWidth(columnName, defaultSize, getData.apply(value));
        n = Math.max(temp, n);
      }
    }
    int temp = this.fitColumnWidth(columnName, defaultSize, Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList()));
    n = Math.max(temp, n);
    return n;
  }

  /**
   * fitColumnWidth(..)
   * ------------------
   * Fit the column width to the largest element in the column.
   */
  protected int fitColumnWidth(final String columnName, final int defaultSize, final List<String> values) {
    List<String> list = Stream.<String>concat(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(columnName)).stream(), values.stream()).collect(Collectors.<String>toList());
    final Function<String, Integer> _function = (String str) -> {
      return Integer.valueOf(str.length());
    };
    Integer maxLength = Collections.<Integer>max(
      list.stream().<Integer>map(_function).collect(Collectors.<Integer>toList()));
    int _max = Math.max((maxLength).intValue(), defaultSize);
    return (_max + 2);
  }

  /**
   * maxSize(..)
   * -----------
   * Gets the maximum column size.
   */
  protected Integer maxSize(final List<String>... columns) {
    final Function<List<String>, Integer> _function = (List<String> list) -> {
      return Integer.valueOf(list.size());
    };
    return Collections.<Integer>max(
      ((List<List<String>>)Conversions.doWrapArray(columns)).stream().<Integer>map(_function).collect(Collectors.<Integer>toList()));
  }

  /**
   * getDataOrDefault(..)
   * --------------------
   * Gets data from a particular index if it exists; otherwise get nothing.
   */
  protected Object[] getDataOrDefault(final int i, final List<String>... columns) {
    final Function<List<String>, String> _function = (List<String> list) -> {
      return this.getDataOrDefaultHelper(i, list);
    };
    return ((List<List<String>>)Conversions.doWrapArray(columns)).stream().<String>map(_function).toArray();
  }

  /**
   * getDataOrDefaultHelper(..)
   * --------------------------
   * Gets data from a particular index if it exists; otherwise get nothing.
   */
  protected String getDataOrDefaultHelper(final int i, final List<String> list) {
    int _size = list.size();
    boolean _lessThan = (i < _size);
    if (_lessThan) {
      String _get = list.get(i);
      return (" " + _get);
    } else {
      return " ";
    }
  }
}
