package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.ucm4iot.Actor;
import mde.iot.ucm4iot.ucm4iot.DeviceActor;
import mde.iot.ucm4iot.ucm4iot.DeviceType;
import mde.iot.ucm4iot.ucm4iot.HumanActor;
import mde.iot.ucm4iot.ucm4iot.InvocationStep;
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareActor;
import mde.iot.ucm4iot.ucm4iot.Step;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class IoTDomainModelGenerator extends IUcm4iotGeneratorImpl {
  /**
   * Class: DiagramRepresentation
   * ----------------------------
   * Creates a representation of a diagram.
   */
  protected static class DiagramRepresentation {
    private EObject element;

    private HashMap<String, List<IoTDomainModelGenerator.DiagramRepresentation>> childrenMap;

    private String tag;

    private Map<String, String> attributes;

    /**
     * Creates a new diagram representation.
     */
    public DiagramRepresentation(final EObject element, final String tag) {
      this(element, tag, new HashMap<String, String>());
    }

    /**
     * Creates a new diagram representation.
     */
    public DiagramRepresentation(final EObject element, final String tag, final Map<String, String> attributes) {
      this.element = element;
      this.tag = tag;
      HashMap<String, String> _hashMap = new HashMap<String, String>();
      this.attributes = _hashMap;
      this.attributes.putAll(attributes);
      HashMap<String, List<IoTDomainModelGenerator.DiagramRepresentation>> _hashMap_1 = new HashMap<String, List<IoTDomainModelGenerator.DiagramRepresentation>>();
      this.childrenMap = _hashMap_1;
    }

    /**
     * getElement(..)
     * --------------
     * Gets the object this element is associated with.
     */
    public EObject getElement() {
      return this.element;
    }

    /**
     * addChildren(..)
     * ---------------
     * Adds a list of children to this element.
     */
    public void addChildren(final String key, final List<IoTDomainModelGenerator.DiagramRepresentation> children) {
      boolean _containsKey = this.childrenMap.containsKey(key);
      boolean _not = (!_containsKey);
      if (_not) {
        this.childrenMap.put(key, CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList());
      }
      this.childrenMap.get(key).addAll(children);
    }

    /**
     * keySet(..)
     * ----------
     * Get the keys associated with the children.
     */
    public Set<String> keySet() {
      return this.childrenMap.keySet();
    }

    /**
     * getChildren(..)
     * ---------------
     * Gets the children of this element.
     */
    public List<IoTDomainModelGenerator.DiagramRepresentation> getChildren(final String key) {
      return this.childrenMap.get(key);
    }

    /**
     * hasChildren(..)
     * ---------------
     * Returns true if this element has children of the desired type.
     */
    public boolean hasChildren(final String key) {
      return this.childrenMap.containsKey(key);
    }

    /**
     * hasChildren(..)
     * ---------------
     * Returns true if this element has children.
     */
    public boolean hasChildren() {
      boolean _isEmpty = this.childrenMap.isEmpty();
      return (!_isEmpty);
    }

    /**
     * getStartTag(..)
     * ---------------
     * Gets the tag for the start of an element.
     */
    public String getStartTag() {
      boolean _isEmpty = this.attributes.isEmpty();
      if (_isEmpty) {
        return String.format("<%s>", this.tag);
      }
      return String.format("<%s %s>", this.tag, this.getAttributes());
    }

    /**
     * getEndTag(..)
     * -------------
     * Gets the tag for the end of an element.
     */
    public String getEndTag() {
      return String.format("</%s>", this.tag);
    }

    /**
     * getOneLineTag(..)
     * -----------------
     * Gets the tag in a one line representation.
     */
    public String getOneLineTag() {
      boolean _isEmpty = this.attributes.isEmpty();
      if (_isEmpty) {
        return String.format("<%s/>", this.tag);
      }
      return String.format("<%s %s/>", this.tag, this.getAttributes());
    }

    /**
     * addAttribute(..)
     * ----------------
     * Adds an attribute to this element.
     */
    public String addAttribute(final String key, final String value) {
      return this.attributes.put(key, value);
    }

    /**
     * addAttributes(..)
     * -----------------
     * Adds many attributes to this element.
     */
    public void addAttributes(final Map<String, String> attributes) {
      this.attributes.putAll(attributes);
    }

    /**
     * hasAttribute(..)
     * ----------------
     * Returns true if the element contains the given attribute.
     */
    public boolean hasAttribute(final String key) {
      return this.attributes.containsKey(key);
    }

    /**
     * getAttribute(..)
     * ----------------
     * Gets an attribute from the element.
     */
    public String getAttribute(final String key) {
      return this.attributes.get(key);
    }

    /**
     * getAttributes(..)
     * -----------------
     * Gets the attributes formatted into a string.
     */
    public String getAttributes() {
      ArrayList<String> args = CollectionLiterals.<String>newArrayList();
      Set<String> _keySet = this.attributes.keySet();
      for (final String key : _keySet) {
        String _format = String.format("%s=\"%s\"", key, this.attributes.get(key));
        args.add(_format);
      }
      return String.join(" ", args);
    }
  }

  /**
   * generate(..)
   * ------------
   * Generates a use case diagram for a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates a use case diagram for a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    String data = this.generateDomainModel(resource);
    this.createFile(fsa, folder, this.createFileName(EcoreUtil2.getNormalizedURI(resource).lastSegment().replace(".ucmiot", ""), ".iotdomainmodel"), data);
  }

  /**
   * createTable(..)
   * ---------------
   * Creates a table of information.
   */
  protected HashMap<String, List<EObject>> createTable(final Resource resource) {
    final Function<UseCase, EObject> _function = (UseCase eo) -> {
      return ((EObject) eo);
    };
    List<EObject> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).<EObject>map(_function).collect(Collectors.<EObject>toList());
    final Function<Actor, EObject> _function_1 = (Actor eo) -> {
      return ((EObject) eo);
    };
    List<EObject> actors = StreamSupport.<Actor>stream(Iterables.<Actor>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), Actor.class).spliterator(), false).<EObject>map(_function_1).collect(Collectors.<EObject>toList());
    final Function<mde.iot.ucm4iot.ucm4iot.Exception, EObject> _function_2 = (mde.iot.ucm4iot.ucm4iot.Exception eo) -> {
      return ((EObject) eo);
    };
    List<EObject> exceptions = StreamSupport.<mde.iot.ucm4iot.ucm4iot.Exception>stream(Iterables.<mde.iot.ucm4iot.ucm4iot.Exception>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), mde.iot.ucm4iot.ucm4iot.Exception.class).spliterator(), false).<EObject>map(_function_2).collect(Collectors.<EObject>toList());
    HashMap<String, List<EObject>> table = new HashMap<String, List<EObject>>();
    table.put("use_cases", useCases);
    table.put("actors", actors);
    table.put("exceptions", exceptions);
    return table;
  }

  protected String generateDomainModel(final Resource resource) {
    HashMap<String, List<EObject>> table = this.createTable(resource);
    String tag = "iotdomainmodel:IoTDomainModel";
    Pair<String, String> _mappedTo = Pair.<String, String>of("xmi:version", "2.0");
    Pair<String, String> _mappedTo_1 = Pair.<String, String>of("xmlns:xmi", "http://www.omg.org/XMI");
    Pair<String, String> _mappedTo_2 = Pair.<String, String>of("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    Pair<String, String> _mappedTo_3 = Pair.<String, String>of("xmlns:iotdomainmodel", "http://www.ucm4iot.org/mde/iot/iotdomainmodel");
    Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1, _mappedTo_2, _mappedTo_3));
    IoTDomainModelGenerator.DiagramRepresentation root = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
    this.findUsers(table, root);
    this.findPhysicalEntities(table, root);
    this.findServices(table, root);
    this.addAssociations(table, root);
    List<String> data = this.createDiagram(root);
    return String.join("\n", data);
  }

  protected void findUsers(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root) {
    final Predicate<EObject> _function = (EObject actor) -> {
      return (actor instanceof HumanActor);
    };
    final Function<EObject, Actor> _function_1 = (EObject actor) -> {
      return ((Actor) actor);
    };
    final Function<Actor, String> _function_2 = (Actor actor) -> {
      return actor.getName();
    };
    List<String> humanUsers = table.get("actors").stream().filter(_function).<Actor>map(_function_1).<String>map(_function_2).distinct().collect(Collectors.<String>toList());
    for (final String actorName : humanUsers) {
      {
        String tag = "users";
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", "iotdomainmodel:HumanUser");
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", actorName);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        IoTDomainModelGenerator.DiagramRepresentation actorRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("users", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
    final Predicate<EObject> _function_3 = (EObject actor) -> {
      return (actor instanceof SoftwareActor);
    };
    final Function<EObject, Actor> _function_4 = (EObject actor) -> {
      return ((Actor) actor);
    };
    final Function<Actor, String> _function_5 = (Actor actor) -> {
      return actor.getName();
    };
    List<String> softwareUsers = table.get("actors").stream().filter(_function_3).<Actor>map(_function_4).<String>map(_function_5).distinct().collect(Collectors.<String>toList());
    for (final String actorName_1 : softwareUsers) {
      {
        String tag = "users";
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", "iotdomainmodel:VirtualEntity");
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", actorName_1);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        IoTDomainModelGenerator.DiagramRepresentation actorRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("users", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
  }

  protected void findPhysicalEntities(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root) {
    final Predicate<EObject> _function = (EObject actor) -> {
      return (actor instanceof PhysicalEntityActor);
    };
    final Function<EObject, Actor> _function_1 = (EObject actor) -> {
      return ((Actor) actor);
    };
    final Function<Actor, String> _function_2 = (Actor actor) -> {
      return actor.getName();
    };
    List<String> physicalEntitiesUsers = table.get("actors").stream().filter(_function).<Actor>map(_function_1).<String>map(_function_2).distinct().collect(Collectors.<String>toList());
    for (final String actorName : physicalEntitiesUsers) {
      {
        String tag = "physicalEntities";
        Pair<String, String> _mappedTo = Pair.<String, String>of("name", actorName);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo));
        IoTDomainModelGenerator.DiagramRepresentation actorRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("physicalEntities", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
    final Predicate<EObject> _function_3 = (EObject actor) -> {
      return (actor instanceof DeviceActor);
    };
    final Function<EObject, DeviceActor> _function_4 = (EObject actor) -> {
      return ((DeviceActor) actor);
    };
    final Predicate<DeviceActor> _function_5 = (DeviceActor actor) -> {
      DeviceType _deviceType = actor.getDeviceType();
      return Objects.equals(_deviceType, DeviceType.SENSOR);
    };
    final Function<DeviceActor, String> _function_6 = (DeviceActor actor) -> {
      return actor.getName();
    };
    List<String> sensorUsers = table.get("actors").stream().filter(_function_3).<DeviceActor>map(_function_4).filter(_function_5).<String>map(_function_6).distinct().collect(Collectors.<String>toList());
    for (final String actorName_1 : sensorUsers) {
      {
        String tag = "devices";
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", "iotdomainmodel:Sensor");
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", actorName_1);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        IoTDomainModelGenerator.DiagramRepresentation actorRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("devices", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
    final Predicate<EObject> _function_7 = (EObject actor) -> {
      return (actor instanceof DeviceActor);
    };
    final Function<EObject, DeviceActor> _function_8 = (EObject actor) -> {
      return ((DeviceActor) actor);
    };
    final Predicate<DeviceActor> _function_9 = (DeviceActor actor) -> {
      DeviceType _deviceType = actor.getDeviceType();
      return Objects.equals(_deviceType, DeviceType.TAG);
    };
    final Function<DeviceActor, String> _function_10 = (DeviceActor actor) -> {
      return actor.getName();
    };
    List<String> tagUsers = table.get("actors").stream().filter(_function_7).<DeviceActor>map(_function_8).filter(_function_9).<String>map(_function_10).distinct().collect(Collectors.<String>toList());
    for (final String actorName_2 : tagUsers) {
      {
        String tag = "devices";
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", "iotdomainmodel:Tag");
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", actorName_2);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        IoTDomainModelGenerator.DiagramRepresentation actorRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("devices", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
    final Predicate<EObject> _function_11 = (EObject actor) -> {
      return (actor instanceof DeviceActor);
    };
    final Function<EObject, DeviceActor> _function_12 = (EObject actor) -> {
      return ((DeviceActor) actor);
    };
    final Predicate<DeviceActor> _function_13 = (DeviceActor actor) -> {
      DeviceType _deviceType = actor.getDeviceType();
      return Objects.equals(_deviceType, DeviceType.ACTUATOR);
    };
    final Function<DeviceActor, String> _function_14 = (DeviceActor actor) -> {
      return actor.getName();
    };
    List<String> actuatorUsers = table.get("actors").stream().filter(_function_11).<DeviceActor>map(_function_12).filter(_function_13).<String>map(_function_14).distinct().collect(Collectors.<String>toList());
    for (final String actorName_3 : actuatorUsers) {
      {
        String tag = "devices";
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", "iotdomainmodel:Actuator");
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", actorName_3);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        IoTDomainModelGenerator.DiagramRepresentation actorRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("devices", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
  }

  protected void findServices(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root) {
    final Function<EObject, UseCase> _function = (EObject ob) -> {
      return ((UseCase) ob);
    };
    List<UseCase> useCases = table.get("use_cases").stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
    ArrayList<UseCase> services = CollectionLiterals.<UseCase>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        List<InvocationStep> invocationSteps = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class);
        final Predicate<Actor> _function_1 = (Actor actor) -> {
          return ((actor instanceof HumanActor) || (actor instanceof SoftwareActor));
        };
        List<Actor> actors = EcoreUtil2.<Actor>getAllContentsOfType(useCase, Actor.class).stream().filter(_function_1).collect(Collectors.<Actor>toList());
        for (final InvocationStep invocationStep : invocationSteps) {
          {
            final Predicate<Actor> _function_2 = (Actor actor) -> {
              return this.hasWord(invocationStep, actor.getName());
            };
            boolean hasActor = actors.stream().anyMatch(_function_2);
            if (hasActor) {
              services.add(invocationStep.getInvokedUseCase());
            }
          }
        }
      }
    }
    List<UseCase> uniqueServices = services.stream().distinct().collect(Collectors.<UseCase>toList());
    for (final UseCase service : uniqueServices) {
      {
        String tag = "users";
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", "iotdomainmodel:Service");
        String _name = service.getName();
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", _name);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        IoTDomainModelGenerator.DiagramRepresentation serviceRep = new IoTDomainModelGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("users", Collections.<IoTDomainModelGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList(serviceRep)));
      }
    }
  }

  /**
   * hasWord(..)
   * -----------
   * Returns true if a step has the passed word; false otherwise.
   */
  private boolean hasWord(final Step step, final String value) {
    String description = step.getDescription();
    if ((description == null)) {
      description = "";
    }
    String[] words = description.replaceAll("[^a-zA-Z0-9]", " ").split("\\s+");
    for (final String word : words) {
      boolean _equals = value.equals(word);
      if (_equals) {
        return true;
      }
    }
    return false;
  }

  /**
   * addAssociations(..)
   * -------------------
   * Add relationships between the elements in the table.
   */
  protected void addAssociations(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root) {
    List<IoTDomainModelGenerator.DiagramRepresentation> _children = root.getChildren("users");
    for (final IoTDomainModelGenerator.DiagramRepresentation user : _children) {
      {
        this.addInteractions(table, root, user);
        this.addDeviceInteractions(table, root, user);
        this.addServiceInteractions(table, root, user);
      }
    }
    List<IoTDomainModelGenerator.DiagramRepresentation> _children_1 = root.getChildren("devices");
    for (final IoTDomainModelGenerator.DiagramRepresentation device : _children_1) {
      this.addDeviceRelationships(table, root, device);
    }
  }

  protected String addInteractions(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root, final IoTDomainModelGenerator.DiagramRepresentation user) {
    String _xblockexpression = null;
    {
      final Function<EObject, UseCase> _function = (EObject ob) -> {
        return ((UseCase) ob);
      };
      List<UseCase> useCases = table.get("use_cases").stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
      final String userName = user.getAttribute("name");
      ArrayList<String> interactedEntities = CollectionLiterals.<String>newArrayList();
      ArrayList<IoTDomainModelGenerator.DiagramRepresentation> physicalEntities = CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList();
      boolean _hasChildren = root.hasChildren("physicalEntities");
      if (_hasChildren) {
        physicalEntities.addAll(root.getChildren("physicalEntities"));
      }
      for (final UseCase useCase : useCases) {
        {
          final Predicate<Step> _function_1 = (Step step) -> {
            String _description = step.getDescription();
            return (_description != null);
          };
          List<Step> steps = EcoreUtil2.<Step>getAllContentsOfType(useCase, Step.class).stream().filter(_function_1).collect(Collectors.<Step>toList());
          final Function<IoTDomainModelGenerator.DiagramRepresentation, String> _function_2 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
            return entity.getAttribute("name");
          };
          List<String> physicalEntityNames = physicalEntities.stream().<String>map(_function_2).collect(Collectors.<String>toList());
          for (final Step step : steps) {
            for (final String physicalEntityName : physicalEntityNames) {
              if ((this.hasWord(step, userName) && this.hasWord(step, physicalEntityName))) {
                interactedEntities.add(physicalEntityName);
              }
            }
          }
        }
      }
      List<String> distinctEntities = interactedEntities.stream().distinct().collect(Collectors.<String>toList());
      final ArrayList<String> entityAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity : distinctEntities) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity));
          };
          int index = this.indexMatched(physicalEntities, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("physicalEntities", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          entityAssociations.add(association);
        }
      }
      _xblockexpression = user.addAttribute("interactsWith", String.join(" ", entityAssociations));
    }
    return _xblockexpression;
  }

  protected String addDeviceInteractions(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root, final IoTDomainModelGenerator.DiagramRepresentation user) {
    String _xblockexpression = null;
    {
      final Function<EObject, UseCase> _function = (EObject ob) -> {
        return ((UseCase) ob);
      };
      List<UseCase> useCases = table.get("use_cases").stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
      final String userName = user.getAttribute("name");
      ArrayList<String> interactedEntities = CollectionLiterals.<String>newArrayList();
      ArrayList<IoTDomainModelGenerator.DiagramRepresentation> devices = CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList();
      boolean _hasChildren = root.hasChildren("devices");
      if (_hasChildren) {
        devices.addAll(root.getChildren("devices"));
      }
      for (final UseCase useCase : useCases) {
        {
          final Predicate<Step> _function_1 = (Step step) -> {
            String _description = step.getDescription();
            return (_description != null);
          };
          List<Step> steps = EcoreUtil2.<Step>getAllContentsOfType(useCase, Step.class).stream().filter(_function_1).collect(Collectors.<Step>toList());
          final Function<IoTDomainModelGenerator.DiagramRepresentation, String> _function_2 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
            return entity.getAttribute("name");
          };
          List<String> deviceNames = devices.stream().<String>map(_function_2).collect(Collectors.<String>toList());
          for (final Step step : steps) {
            for (final String deviceName : deviceNames) {
              if ((this.hasWord(step, userName) && this.hasWord(step, deviceName))) {
                interactedEntities.add(deviceName);
              }
            }
          }
        }
      }
      List<String> distinctEntities = interactedEntities.stream().distinct().collect(Collectors.<String>toList());
      final ArrayList<String> entityAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity : distinctEntities) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity));
          };
          int index = this.indexMatched(devices, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("devices", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          entityAssociations.add(association);
        }
      }
      _xblockexpression = user.addAttribute("interactsWith", String.join(" ", entityAssociations));
    }
    return _xblockexpression;
  }

  protected String addServiceInteractions(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root, final IoTDomainModelGenerator.DiagramRepresentation user) {
    String _xblockexpression = null;
    {
      final Function<EObject, UseCase> _function = (EObject ob) -> {
        return ((UseCase) ob);
      };
      List<UseCase> useCases = table.get("use_cases").stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
      ArrayList<String> invokedEntities = CollectionLiterals.<String>newArrayList();
      ArrayList<IoTDomainModelGenerator.DiagramRepresentation> users = CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList();
      ArrayList<IoTDomainModelGenerator.DiagramRepresentation> services = CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList();
      boolean _hasChildren = root.hasChildren("users");
      if (_hasChildren) {
        List<IoTDomainModelGenerator.DiagramRepresentation> userList = root.getChildren("users");
        users.addAll(userList);
        final Predicate<IoTDomainModelGenerator.DiagramRepresentation> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation dr) -> {
          String _attribute = dr.getAttribute("xsi:type");
          return Objects.equals(_attribute, "iotdomainmodel:Service");
        };
        List<IoTDomainModelGenerator.DiagramRepresentation> serviceList = users.stream().filter(_function_1).collect(Collectors.<IoTDomainModelGenerator.DiagramRepresentation>toList());
        services.addAll(serviceList);
      }
      for (final UseCase useCase : useCases) {
        {
          List<InvocationStep> invocationSteps = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class);
          String actorName = user.getAttribute("name");
          for (final IoTDomainModelGenerator.DiagramRepresentation service : services) {
            {
              final String serviceName = service.getAttribute("name");
              final Predicate<InvocationStep> _function_2 = (InvocationStep step) -> {
                String _name = step.getInvokedUseCase().getName();
                return Objects.equals(_name, serviceName);
              };
              List<InvocationStep> serviceSteps = invocationSteps.stream().filter(_function_2).collect(Collectors.<InvocationStep>toList());
              for (final InvocationStep serviceStep : serviceSteps) {
                boolean _hasWord = this.hasWord(serviceStep, actorName);
                if (_hasWord) {
                  invokedEntities.add(serviceName);
                }
              }
            }
          }
        }
      }
      List<String> distinctEntities = invokedEntities.stream().distinct().collect(Collectors.<String>toList());
      final ArrayList<String> serviceAssociations = CollectionLiterals.<String>newArrayList();
      for (final String service : distinctEntities) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_2 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == service));
          };
          int index = this.indexMatched(users, _function_2);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("users", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          serviceAssociations.add(association);
        }
      }
      _xblockexpression = user.addAttribute("invokes", String.join(" ", serviceAssociations));
    }
    return _xblockexpression;
  }

  protected String addDeviceRelationships(final HashMap<String, List<EObject>> table, final IoTDomainModelGenerator.DiagramRepresentation root, final IoTDomainModelGenerator.DiagramRepresentation device) {
    String _xblockexpression = null;
    {
      final Function<EObject, UseCase> _function = (EObject ob) -> {
        return ((UseCase) ob);
      };
      List<UseCase> useCases = table.get("use_cases").stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
      final String ctxDeviceName = device.getAttribute("name");
      ArrayList<String> containsDevices = CollectionLiterals.<String>newArrayList();
      ArrayList<String> containsPE = CollectionLiterals.<String>newArrayList();
      ArrayList<String> readDevices = CollectionLiterals.<String>newArrayList();
      ArrayList<String> monitorsDevices = CollectionLiterals.<String>newArrayList();
      ArrayList<String> identifiesDevices = CollectionLiterals.<String>newArrayList();
      ArrayList<String> actsDevices = CollectionLiterals.<String>newArrayList();
      ArrayList<IoTDomainModelGenerator.DiagramRepresentation> devices = CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList();
      boolean _hasChildren = root.hasChildren("devices");
      if (_hasChildren) {
        devices.addAll(root.getChildren("devices"));
      }
      ArrayList<IoTDomainModelGenerator.DiagramRepresentation> physicalEntities = CollectionLiterals.<IoTDomainModelGenerator.DiagramRepresentation>newArrayList();
      boolean _hasChildren_1 = root.hasChildren("physicalEntities");
      if (_hasChildren_1) {
        physicalEntities.addAll(root.getChildren("physicalEntities"));
      }
      for (final UseCase useCase : useCases) {
        {
          final Predicate<Step> _function_1 = (Step step) -> {
            String _description = step.getDescription();
            return (_description != null);
          };
          List<Step> steps = EcoreUtil2.<Step>getAllContentsOfType(useCase, Step.class).stream().filter(_function_1).collect(Collectors.<Step>toList());
          final Function<IoTDomainModelGenerator.DiagramRepresentation, String> _function_2 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
            return entity.getAttribute("name");
          };
          List<String> deviceNames = devices.stream().<String>map(_function_2).collect(Collectors.<String>toList());
          final Function<IoTDomainModelGenerator.DiagramRepresentation, String> _function_3 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
            return entity.getAttribute("name");
          };
          List<String> physicalEntityNames = physicalEntities.stream().<String>map(_function_3).collect(Collectors.<String>toList());
          final Predicate<IoTDomainModelGenerator.DiagramRepresentation> _function_4 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
            String _attribute = entity.getAttribute("name");
            return Objects.equals(_attribute, ctxDeviceName);
          };
          final Function<IoTDomainModelGenerator.DiagramRepresentation, String> _function_5 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
            return entity.getAttribute("xsi:type");
          };
          String ctxDeviceType = devices.stream().filter(_function_4).<String>map(_function_5).findFirst().orElse("");
          for (final Step step : steps) {
            {
              for (final String deviceName : deviceNames) {
                {
                  final Predicate<IoTDomainModelGenerator.DiagramRepresentation> _function_6 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
                    String _attribute = entity.getAttribute("name");
                    return Objects.equals(_attribute, deviceName);
                  };
                  final Function<IoTDomainModelGenerator.DiagramRepresentation, String> _function_7 = (IoTDomainModelGenerator.DiagramRepresentation entity) -> {
                    return entity.getAttribute("xsi:type");
                  };
                  String deviceType = devices.stream().filter(_function_6).<String>map(_function_7).findFirst().orElse("");
                  if (((Objects.equals(ctxDeviceType, "iotdomainmodel:Sensor") && Objects.equals(deviceType, "iotdomainmodel:Tag")) && this.hasInteraction(step, "reads", ctxDeviceName, deviceName))) {
                    readDevices.add(deviceName);
                  }
                  boolean _hasInteraction = this.hasInteraction(step, "contains", ctxDeviceName, deviceName);
                  if (_hasInteraction) {
                    containsDevices.add(deviceName);
                  }
                }
              }
              for (final String physicalEntityName : physicalEntityNames) {
                {
                  if ((Objects.equals(ctxDeviceType, "iotdomainmodel:Sensor") && this.hasInteraction(step, "monitors", ctxDeviceName, physicalEntityName))) {
                    monitorsDevices.add(physicalEntityName);
                  }
                  if ((Objects.equals(ctxDeviceType, "iotdomainmodel:Tag") && this.hasInteraction(step, "identifies", ctxDeviceName, physicalEntityName))) {
                    identifiesDevices.add(physicalEntityName);
                  }
                  if ((Objects.equals(ctxDeviceType, "iotdomainmodel:Actuator") && this.hasInteraction(step, "acts on", ctxDeviceName, physicalEntityName))) {
                    actsDevices.add(physicalEntityName);
                  }
                  boolean _hasInteraction = this.hasInteraction(step, "attached to", ctxDeviceName, physicalEntityName);
                  if (_hasInteraction) {
                    containsPE.add(physicalEntityName);
                  }
                }
              }
            }
          }
        }
      }
      List<String> distinctContainsDevices = containsDevices.stream().distinct().collect(Collectors.<String>toList());
      List<String> distinctContainsPE = containsPE.stream().distinct().collect(Collectors.<String>toList());
      List<String> distinctReadDevices = readDevices.stream().distinct().collect(Collectors.<String>toList());
      List<String> distinctMonitorsDevices = monitorsDevices.stream().distinct().collect(Collectors.<String>toList());
      List<String> distinctIdentifiesDevices = identifiesDevices.stream().distinct().collect(Collectors.<String>toList());
      List<String> distinctActsDevices = actsDevices.stream().distinct().collect(Collectors.<String>toList());
      final ArrayList<String> containDevicesAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity : distinctContainsDevices) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity));
          };
          int index = this.indexMatched(devices, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("devices", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          containDevicesAssociations.add(association);
        }
      }
      final ArrayList<String> containPEAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity_1 : distinctContainsPE) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity_1));
          };
          int index = this.indexMatched(physicalEntities, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("physicalEntities", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          containPEAssociations.add(association);
        }
      }
      final ArrayList<String> readDevicesAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity_2 : distinctReadDevices) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity_2));
          };
          int index = this.indexMatched(devices, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("devices", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          readDevicesAssociations.add(association);
        }
      }
      final ArrayList<String> monitorsDevicesAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity_3 : distinctMonitorsDevices) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity_3));
          };
          int index = this.indexMatched(physicalEntities, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("physicalEntities", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          monitorsDevicesAssociations.add(association);
        }
      }
      final ArrayList<String> identifiesDevicesAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity_4 : distinctIdentifiesDevices) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity_4));
          };
          int index = this.indexMatched(physicalEntities, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("physicalEntities", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          identifiesDevicesAssociations.add(association);
        }
      }
      final ArrayList<String> actsDevicesAssociations = CollectionLiterals.<String>newArrayList();
      for (final String entity_5 : distinctActsDevices) {
        {
          final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> _function_1 = (IoTDomainModelGenerator.DiagramRepresentation rep) -> {
            String _attribute = rep.getAttribute("name");
            return Boolean.valueOf((_attribute == entity_5));
          };
          int index = this.indexMatched(physicalEntities, _function_1);
          Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("physicalEntities", Integer.valueOf(index));
          String association = this.formatAssociation(_mappedTo);
          actsDevicesAssociations.add(association);
        }
      }
      int _size = containDevicesAssociations.size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        device.addAttribute("contains", String.join(" ", containDevicesAssociations));
      }
      int _size_1 = containPEAssociations.size();
      boolean _greaterThan_1 = (_size_1 > 0);
      if (_greaterThan_1) {
        device.addAttribute("attachedTo", String.join(" ", containPEAssociations));
      }
      int _size_2 = readDevicesAssociations.size();
      boolean _greaterThan_2 = (_size_2 > 0);
      if (_greaterThan_2) {
        device.addAttribute("reads", String.join(" ", readDevicesAssociations));
      }
      int _size_3 = monitorsDevicesAssociations.size();
      boolean _greaterThan_3 = (_size_3 > 0);
      if (_greaterThan_3) {
        device.addAttribute("monitors", String.join(" ", monitorsDevicesAssociations));
      }
      int _size_4 = identifiesDevicesAssociations.size();
      boolean _greaterThan_4 = (_size_4 > 0);
      if (_greaterThan_4) {
        device.addAttribute("identifies", String.join(" ", identifiesDevicesAssociations));
      }
      String _xifexpression = null;
      int _size_5 = actsDevicesAssociations.size();
      boolean _greaterThan_5 = (_size_5 > 0);
      if (_greaterThan_5) {
        _xifexpression = device.addAttribute("actsOn", String.join(" ", actsDevicesAssociations));
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }

  private boolean hasInteraction(final Step step, final String action, final String actor1, final String actor2) {
    String description = step.getDescription();
    if ((description == null)) {
      description = "";
    }
    String interactionType1 = String.format("%s %s %s", actor1, action, actor2);
    String interactionType2 = String.format("%s %s a %s", actor1, action, actor2);
    String interactionType3 = String.format("%s %s an %s", actor1, action, actor2);
    String interactionType4 = String.format("%s %s the %s", actor1, action, actor2);
    if ((this.hasWord(step, actor1) && this.hasWord(step, actor2))) {
      boolean output1 = description.contains(interactionType1);
      boolean output2 = description.contains(interactionType2);
      boolean output3 = description.contains(interactionType3);
      boolean output4 = description.contains(interactionType4);
      return (((output1 || output2) || output3) || output4);
    }
    return false;
  }

  /**
   * indexMatched(..)
   * ----------------
   * Determines the first index the passed function returns true.
   */
  protected int indexMatched(final List<IoTDomainModelGenerator.DiagramRepresentation> reps, final Function<IoTDomainModelGenerator.DiagramRepresentation, Boolean> match) {
    for (int i = 0; (i < reps.size()); i++) {
      Boolean _apply = match.apply(reps.get(i));
      if ((_apply).booleanValue()) {
        return i;
      }
    }
    return (-1);
  }

  /**
   * formatAssociation(..)
   * ---------------------
   * Formats an association to an existing element.
   */
  protected String formatAssociation(final Pair<String, Integer>... indexMap) {
    StringBuilder builder = new StringBuilder();
    final String format = "/@%s.%s";
    builder.append("/");
    for (final Pair<String, Integer> pair : indexMap) {
      builder.append(String.format(format, pair.getKey(), pair.getValue()));
    }
    return builder.toString();
  }

  /**
   * createDiagram(..)
   * -----------------
   * Creates a diagram.
   */
  protected List<String> createDiagram(final IoTDomainModelGenerator.DiagramRepresentation rep) {
    ArrayList<String> data = CollectionLiterals.<String>newArrayList();
    data.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    this.createDiagramHelper(rep, 0, data);
    return data;
  }

  /**
   * createDiagramHelper(..)
   * -----------------------
   * Recursively goes through a diagram representation and outputs a diagram.
   */
  private void createDiagramHelper(final IoTDomainModelGenerator.DiagramRepresentation rep, final int depth, final ArrayList<String> output) {
    if ((rep == null)) {
      return;
    }
    boolean _hasChildren = rep.hasChildren();
    if (_hasChildren) {
      String _createTabs = this.createTabs(depth);
      String _startTag = rep.getStartTag();
      String _plus = (_createTabs + _startTag);
      output.add(_plus);
      Set<String> _keySet = rep.keySet();
      for (final String key : _keySet) {
        List<IoTDomainModelGenerator.DiagramRepresentation> _children = rep.getChildren(key);
        for (final IoTDomainModelGenerator.DiagramRepresentation child : _children) {
          this.createDiagramHelper(child, (depth + 1), output);
        }
      }
      String _createTabs_1 = this.createTabs(depth);
      String _endTag = rep.getEndTag();
      String _plus_1 = (_createTabs_1 + _endTag);
      output.add(_plus_1);
    } else {
      String _createTabs_2 = this.createTabs(depth);
      String _oneLineTag = rep.getOneLineTag();
      String _plus_2 = (_createTabs_2 + _oneLineTag);
      output.add(_plus_2);
    }
  }

  /**
   * createTab(..)
   * -------------
   * Creates a string with the specified number of tabs.
   */
  private String createTabs(final int indents) {
    StringBuilder builder = new StringBuilder();
    builder.append("");
    for (int i = 0; (i < indents); i++) {
      builder.append("\t");
    }
    return builder.toString();
  }
}
