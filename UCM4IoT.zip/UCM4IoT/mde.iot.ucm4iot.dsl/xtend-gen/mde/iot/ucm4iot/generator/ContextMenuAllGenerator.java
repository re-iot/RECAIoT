package mde.iot.ucm4iot.generator;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;

/**
 * Class: ContextMenuAllGenerator
 * ------------------------------
 * Generator for the context menu.
 */
@SuppressWarnings("all")
public class ContextMenuAllGenerator extends AbstractGenerator {
  public static final String GEN_EXCEPTION_LIST = "exceptions/";

  public static final String GEN_HANDLER_LIST = "handlers/";

  public static final String OUTDATED_LIST = "outdated/";

  /**
   * doGenerate(..)
   * --------------
   * Generates exception related artifacts from a UCM4IoT model.
   */
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    Date date = Calendar.getInstance().getTime();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss/");
    SummaryTableGenerator tableGenerator = new SummaryTableGenerator();
    String _format = dateFormat.format(date);
    String _plus = (_format + ContextMenuAllGenerator.GEN_EXCEPTION_LIST);
    String _plus_1 = (_plus + ContextMenuAllGenerator.OUTDATED_LIST);
    tableGenerator.generate(resource, fsa, context, _plus_1);
    ExceptionSummaryTableGenerator exceptionGenerator = new ExceptionSummaryTableGenerator();
    String _format_1 = dateFormat.format(date);
    String _plus_2 = (_format_1 + ContextMenuAllGenerator.GEN_EXCEPTION_LIST);
    exceptionGenerator.generate(resource, fsa, context, _plus_2);
    ExceptionUseCaseTableGenerator exceptionUseCaseGenerator = new ExceptionUseCaseTableGenerator();
    String _format_2 = dateFormat.format(date);
    String _plus_3 = (_format_2 + ContextMenuAllGenerator.GEN_EXCEPTION_LIST);
    exceptionUseCaseGenerator.generate(resource, fsa, context, _plus_3);
    HandlerTableGenerator handlerGenerator = new HandlerTableGenerator();
    String _format_3 = dateFormat.format(date);
    String _plus_4 = (_format_3 + ContextMenuAllGenerator.GEN_HANDLER_LIST);
    handlerGenerator.generate(resource, fsa, context, _plus_4);
    UseCaseDiagramGenerator diagramGenerator = new UseCaseDiagramGenerator();
    diagramGenerator.generate(resource, fsa, context, dateFormat.format(date));
    IoTDomainModelGenerator domainGenerator = new IoTDomainModelGenerator();
    domainGenerator.generate(resource, fsa, context, dateFormat.format(date));
    StateChartPrototypeGenerator stateChartGenerator = new StateChartPrototypeGenerator();
    stateChartGenerator.generate(resource, fsa, context, dateFormat.format(date));
    YakinduStateChartGenerator yakinduStateChartGenerator = new YakinduStateChartGenerator();
    yakinduStateChartGenerator.generate(resource, fsa, context, dateFormat.format(date));
  }
}
