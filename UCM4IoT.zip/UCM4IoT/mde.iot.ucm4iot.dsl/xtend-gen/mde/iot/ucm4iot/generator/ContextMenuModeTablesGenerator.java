package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase;
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock;
import mde.iot.ucm4iot.ucm4iot.Extensions;
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase;
import mde.iot.ucm4iot.ucm4iot.MainScenario;
import mde.iot.ucm4iot.ucm4iot.Mode;
import mde.iot.ucm4iot.ucm4iot.ModeType;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

@SuppressWarnings("all")
public class ContextMenuModeTablesGenerator extends AbstractGenerator {
  private static final String GEN_MODE_LIST = "modes/";

  private Resource resource;

  @Override
  public void doGenerate(final Resource input, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    Date date = Calendar.getInstance().getTime();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_hh.mm.ss/");
    String _format = dateFormat.format(date);
    String _plus = (_format + ContextMenuModeTablesGenerator.GEN_MODE_LIST);
    this.generateCompleteModes(input, fsa, context, _plus);
  }

  protected void generateCompleteModes(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    this.resource = resource;
    try {
      final List<UseCase> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).collect(Collectors.<UseCase>toList());
      String table = this.createModeTables(useCases);
      String _table = table;
      table = (_table + "\n");
      String _table_1 = table;
      table = (_table_1 + "\n");
      this.createFile(fsa, folder, this.createFileName("modes-table", ".txt"), String.join("\n\n\n", table));
    } catch (final Throwable _t) {
      if (_t instanceof Throwable) {
        final Throwable e = (Throwable)_t;
        e.printStackTrace();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }

  protected List<Mode> getAllModes(final Resource resource) {
    return StreamSupport.<Mode>stream(Iterables.<Mode>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), Mode.class).spliterator(), false).collect(
      Collectors.<Mode>toList());
  }

  protected String getDefaultModeName() {
    Stream<Mode> _stream = StreamSupport.<Mode>stream(Iterables.<Mode>filter(IteratorExtensions.<EObject>toIterable(this.resource.getAllContents()), Mode.class).spliterator(), false);
    Optional<Mode> defaultMode = _stream.filter(new Predicate<Mode>() {
      @Override
      public boolean test(final Mode mode) {
        return ((mode.getType() == ModeType.NORMAL) && mode.isDefault());
      }
    }).findAny();
    boolean _isPresent = defaultMode.isPresent();
    if (_isPresent) {
      return defaultMode.get().getName();
    }
    return null;
  }

  protected String createModeTables(final Iterable<UseCase> useCases) {
    ArrayList<Object> modeTableRows = CollectionLiterals.<Object>newArrayList();
    ArrayList<ArrayList<String>> exceptionalUseCases = CollectionLiterals.<ArrayList<String>>newArrayList();
    ArrayList<ArrayList<String>> handlerUseCases = CollectionLiterals.<ArrayList<String>>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        ArrayList<String> row = this.createRow(useCase);
        if ((row != null)) {
          if ((useCase instanceof ExceptionalUseCase)) {
            exceptionalUseCases.add(row);
          }
          if ((useCase instanceof HandlerUseCase)) {
            handlerUseCases.add(row);
          }
        }
      }
    }
    return this.createModesTable(exceptionalUseCases, handlerUseCases);
  }

  private ArrayList<String> createRow(final UseCase useCase) {
    String modeSwitch = this.getModeSwitch(useCase);
    String preMode = this.getPreModes(useCase);
    if (((preMode == null) && (modeSwitch == null))) {
      return null;
    }
    if ((modeSwitch != null)) {
      ArrayList<String> row = CollectionLiterals.<String>newArrayList();
      String usecaseName = useCase.getName();
      row.add(usecaseName);
      if ((preMode == null)) {
        row.add(this.getDefaultModeName());
      } else {
        row.add(preMode);
      }
      row.add(this.getModeSwitch(useCase));
      return row;
    }
    return null;
  }

  protected String getPreModes(final UseCase useCase) {
    MainScenario mainScenario = useCase.getMain();
    if ((mainScenario != null)) {
      Mode preModeSwitch = mainScenario.getPreModeSwitch();
      if ((preModeSwitch != null)) {
        return preModeSwitch.getName();
      } else {
        Mode _postModeSwitch = mainScenario.getPostModeSwitch();
        boolean _tripleNotEquals = (_postModeSwitch != null);
        if (_tripleNotEquals) {
          return this.getDefaultModeName();
        }
      }
    }
    return null;
  }

  protected String getModeSwitch(final UseCase useCase) {
    try {
      ArrayList<String> modeSwitches = CollectionLiterals.<String>newArrayList();
      MainScenario mainScenario = useCase.getMain();
      if ((mainScenario != null)) {
        Mode postModeSwitch = mainScenario.getPostModeSwitch();
        if ((postModeSwitch != null)) {
          modeSwitches.add(postModeSwitch.getName());
        }
      }
      Extensions extensions = useCase.getExtensions();
      if ((extensions != null)) {
        EList<ExtensionBlock> blocks = extensions.getBlocks();
        for (final ExtensionBlock block : blocks) {
          {
            Mode modeSwitch = block.getPreModeSwitch();
            if ((modeSwitch != null)) {
              modeSwitches.add(modeSwitch.getName());
            }
            Mode postModeSwitch_1 = block.getPostModeSwitch();
            if ((postModeSwitch_1 != null)) {
              modeSwitches.add(postModeSwitch_1.getName());
            }
          }
        }
      }
      int _size = modeSwitches.size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        return IterableExtensions.join(modeSwitches, ", ");
      }
    } catch (final Throwable _t) {
      if (_t instanceof Throwable) {
        final Throwable e = (Throwable)_t;
        e.printStackTrace();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
    return null;
  }

  public void getExtensionBlocks(final EList<EObject> list) {
    throw new UnsupportedOperationException("TODO: auto-generated method stub");
  }

  private String createModesTable(final ArrayList<ArrayList<String>> exceptionalUseCases, final ArrayList<ArrayList<String>> handlerUseCases) {
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    List<Integer> columns = Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(25), Integer.valueOf(35)));
    final BinaryOperator<Integer> _function = (Integer a, Integer b) -> {
      return Integer.valueOf(((a).intValue() + (b).intValue()));
    };
    Integer _reduce = columns.stream().reduce(Integer.valueOf(0), _function);
    int _size = columns.size();
    int _plus = ((_reduce).intValue() + _size);
    int _minus = (_plus - 1);
    String titleFormat = this.createTableFormat(_minus);
    String titleLine = String.format(titleFormat, "").replace(" ", "-").replace("|", "+");
    final List<Integer> _converted_columns = (List<Integer>)columns;
    String format = this.createTableFormat(((int[])Conversions.unwrapArray(_converted_columns, int.class)));
    String line = String.format(format, "", "", "", "", "", "", "").replace(" ", "-").replace("|", "+");
    rows.add(titleLine);
    String _format = String.format(titleFormat, " Mode Table: ");
    rows.add(_format);
    rows.add(line);
    String _format_1 = String.format(format, " Use Case Name", " Switched Mode");
    rows.add(_format_1);
    rows.add(line);
    for (final ArrayList<String> item : exceptionalUseCases) {
      String _get = item.get(0);
      String _get_1 = item.get(1);
      String _plus_1 = (_get_1 + " --> ");
      String _get_2 = item.get(2);
      String _plus_2 = (_plus_1 + _get_2);
      String _format_2 = String.format(format, _get, _plus_2);
      rows.add(_format_2);
    }
    rows.add(line);
    for (final ArrayList<String> item_1 : handlerUseCases) {
      String _get_3 = item_1.get(0);
      String _get_4 = item_1.get(1);
      String _plus_3 = (_get_4 + " --> ");
      String _get_5 = item_1.get(2);
      String _plus_4 = (_plus_3 + _get_5);
      String _format_3 = String.format(format, _get_3, _plus_4);
      rows.add(_format_3);
    }
    rows.add(line);
    return String.join("\n", rows);
  }

  private String createTableFormat(final int... columnSizes) {
    StringBuilder formatBuilder = new StringBuilder();
    for (final int size : columnSizes) {
      formatBuilder.append(String.format(" %%-%ds ", Integer.valueOf(size)));
    }
    return formatBuilder.toString().replaceAll(" +", " ").replaceAll(" ", "|");
  }

  public String createModeSummeryTables(final Iterable<UseCase> useCases) {
    ArrayList<String> normalMode = CollectionLiterals.<String>newArrayList();
    ArrayList<String> emergencyMode = CollectionLiterals.<String>newArrayList();
    ArrayList<String> restrictedMode = CollectionLiterals.<String>newArrayList();
    ArrayList<String> degradedMode = CollectionLiterals.<String>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        MainScenario mainScenario = useCase.getMain();
        if ((mainScenario != null)) {
          Mode preModeSwitch = mainScenario.getPreModeSwitch();
          if ((preModeSwitch == null)) {
            normalMode.add(useCase.getName());
          } else {
            String _name = preModeSwitch.getName();
            if (_name != null) {
              switch (_name) {
                case "Normal":
                  normalMode.add(useCase.getName());
                  break;
                case "Emergency":
                  emergencyMode.add(useCase.getName());
                  break;
                case "Restricted":
                  restrictedMode.add(useCase.getName());
                  break;
                case "Degraded":
                  degradedMode.add(useCase.getName());
                  break;
              }
            }
          }
        }
        Extensions extensions = useCase.getExtensions();
        if ((extensions != null)) {
          EList<ExtensionBlock> blocks = extensions.getBlocks();
          for (final ExtensionBlock block : blocks) {
            {
              Mode modeSwitch = block.getPreModeSwitch();
              if ((modeSwitch != null)) {
                String _name_1 = modeSwitch.getName();
                if (_name_1 != null) {
                  switch (_name_1) {
                    case "Normal":
                      normalMode.add(useCase.getName());
                      break;
                    case "Emergency":
                      emergencyMode.add(useCase.getName());
                      break;
                    case "Restricted":
                      restrictedMode.add(useCase.getName());
                      break;
                    case "Degraded":
                      degradedMode.add(useCase.getName());
                      break;
                  }
                }
              }
              Mode postModeSwitch = block.getPostModeSwitch();
              if ((postModeSwitch != null)) {
                String _name_2 = postModeSwitch.getName();
                if (_name_2 != null) {
                  switch (_name_2) {
                    case "Normal":
                      normalMode.add(useCase.getName());
                      break;
                    case "Emergency":
                      emergencyMode.add(useCase.getName());
                      break;
                    case "Restricted":
                      restrictedMode.add(useCase.getName());
                      break;
                    case "Degraded":
                      degradedMode.add(useCase.getName());
                      break;
                  }
                }
              }
            }
          }
        }
      }
    }
    String normalModesInString = IterableExtensions.join(normalMode, ", ");
    String emergencyModesInString = IterableExtensions.join(emergencyMode, ", ");
    String restrictedModesInString = IterableExtensions.join(restrictedMode, ", ");
    String degradedModeInString = IterableExtensions.join(degradedMode, ", ");
    int columnWidth = Math.max(Math.max(normalModesInString.length(), emergencyModesInString.length()), 
      Math.max(restrictedModesInString.length(), degradedModeInString.length()));
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    List<Integer> columns = Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(25), Integer.valueOf(columnWidth)));
    final BinaryOperator<Integer> _function = (Integer a, Integer b) -> {
      return Integer.valueOf(((a).intValue() + (b).intValue()));
    };
    Integer _reduce = columns.stream().reduce(Integer.valueOf(0), _function);
    int _size = columns.size();
    int _plus = ((_reduce).intValue() + _size);
    int _minus = (_plus - 1);
    String titleFormat = this.createTableFormat(_minus);
    String titleLine = String.format(titleFormat, "").replace(" ", "-").replace("|", "+");
    final List<Integer> _converted_columns = (List<Integer>)columns;
    String format = this.createTableFormat(((int[])Conversions.unwrapArray(_converted_columns, int.class)));
    String line = String.format(format, "", "").replace(" ", "-").replace("|", "+");
    rows.add(titleLine);
    String _format = String.format(titleFormat, " Mode Summary Table: ");
    rows.add(_format);
    rows.add(line);
    String _format_1 = String.format(format, "Mode Names", " Uses Cases");
    rows.add(_format_1);
    rows.add(line);
    String _format_2 = String.format(format, "Normal", normalModesInString);
    rows.add(_format_2);
    String _format_3 = String.format(format, "Emergency", emergencyModesInString);
    rows.add(_format_3);
    String _format_4 = String.format(format, "Restricted", restrictedModesInString);
    rows.add(_format_4);
    String _format_5 = String.format(format, "Degraded", degradedModeInString);
    rows.add(_format_5);
    rows.add(line);
    return String.join("\n", rows);
  }

  private String createFileName(final String name, final String ext) {
    if ((((ext != null) && ext.trim().isEmpty()) && (!ext.startsWith(".")))) {
      throw new IllegalArgumentException(
        "File extension is not valid. Make sure passed argument begins with \'.\'");
    }
    return (name + ext);
  }

  private void createFile(final IFileSystemAccess2 fsa, final String path, final String file, final String data) {
    fsa.generateFile(((path + "/") + file), data);
  }
}
