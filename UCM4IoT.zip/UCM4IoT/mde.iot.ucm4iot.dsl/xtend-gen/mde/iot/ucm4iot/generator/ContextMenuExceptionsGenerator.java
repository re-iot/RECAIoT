package mde.iot.ucm4iot.generator;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;

/**
 * Class: ContextMenuExceptionsGenerator
 * -------------------------------------
 * Generator for the context menu.
 */
@SuppressWarnings("all")
public class ContextMenuExceptionsGenerator extends AbstractGenerator {
  public static final String GEN_EXCEPTION_LIST = "exceptions/";

  public static final String OUTDATED_LIST = "outdated/";

  /**
   * doGenerate(..)
   * --------------
   * Generates exception related artifacts from a UCM4IoT model.
   */
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    Date date = Calendar.getInstance().getTime();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss/");
    SummaryTableGenerator tableGenerator = new SummaryTableGenerator();
    String _format = dateFormat.format(date);
    String _plus = (_format + ContextMenuExceptionsGenerator.GEN_EXCEPTION_LIST);
    String _plus_1 = (_plus + ContextMenuExceptionsGenerator.OUTDATED_LIST);
    tableGenerator.generate(resource, fsa, context, _plus_1);
    ExceptionSummaryTableGenerator exceptionGenerator = new ExceptionSummaryTableGenerator();
    String _format_1 = dateFormat.format(date);
    String _plus_2 = (_format_1 + ContextMenuExceptionsGenerator.GEN_EXCEPTION_LIST);
    exceptionGenerator.generate(resource, fsa, context, _plus_2);
    ExceptionUseCaseTableGenerator exceptionUseCaseGenerator = new ExceptionUseCaseTableGenerator();
    String _format_2 = dateFormat.format(date);
    String _plus_3 = (_format_2 + ContextMenuExceptionsGenerator.GEN_EXCEPTION_LIST);
    exceptionUseCaseGenerator.generate(resource, fsa, context, _plus_3);
  }
}
