package mde.iot.ucm4iot.generator;

import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;

@SuppressWarnings("all")
public class ContextMenuEcoreGenerator extends AbstractGenerator {
  /**
   * doGenerate(..)
   * --------------
   * Generates exception related artifacts from a UCM4IoT model.
   */
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    EcoreGenerator ecoreGenerator = new EcoreGenerator();
    ecoreGenerator.generate(resource, fsa, context);
  }
}
