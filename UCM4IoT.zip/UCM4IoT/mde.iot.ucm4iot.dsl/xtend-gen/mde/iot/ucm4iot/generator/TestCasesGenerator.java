package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.Ucm4iotUtilities;
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock;
import mde.iot.ucm4iot.ucm4iot.Step;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

@SuppressWarnings("all")
public class TestCasesGenerator extends IUcm4iotGeneratorImpl {
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    List<UseCase> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).collect(Collectors.<UseCase>toList());
    ArrayList<String> logs = CollectionLiterals.<String>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        String log = this.createTestCase(useCases, useCase);
        logs.add(log);
      }
    }
    this.createFile(fsa, folder, this.createFileName("testcases", ".csv"), String.join("\n\n\n", logs));
  }

  public String createTestCase(final List<UseCase> useCases, final UseCase ctx) {
    ArrayList<String> rows = CollectionLiterals.<String>newArrayList();
    String _name = ctx.getName();
    String _plus = ("Use Case: " + _name);
    rows.add(_plus);
    System.out.println("test1");
    final Predicate<Step> _function = (Step step) -> {
      return Ucm4iotUtilities.hasStepNumber(step);
    };
    List<Step> mainSteps = EcoreUtil2.<Step>getAllContentsOfType(ctx.getMain(), Step.class).stream().filter(_function).collect(Collectors.<Step>toList());
    ArrayList<String> header = CollectionLiterals.<String>newArrayList();
    header.add("Path");
    System.out.println("test2");
    ArrayList<List<Step>> pathList = null;
    final List<Step> _converted_mainSteps = (List<Step>)mainSteps;
    int _length = ((Object[])Conversions.unwrapArray(_converted_mainSteps, Object.class)).length;
    boolean _greaterThan = (_length > 0);
    if (_greaterThan) {
      pathList = this.getPaths(ctx, mainSteps.get(0));
      for (final List<Step> path : pathList) {
        {
          final Function<Step, String> _function_1 = (Step step) -> {
            return Ucm4iotUtilities.getStepNumber(step);
          };
          List<String> pathoverview = path.stream().<String>map(_function_1).collect(Collectors.<String>toList());
          String _join = String.join("-", pathoverview);
          String _plus_1 = ("\'" + _join);
          String _plus_2 = (_plus_1 + "\'");
          header.add(_plus_2);
        }
      }
    }
    System.out.println("test3");
    String paths = String.join(",", header);
    ArrayList<String> testSteps = CollectionLiterals.<String>newArrayList();
    testSteps.add("Test Steps");
    for (final List<Step> path_1 : pathList) {
      {
        final Function<Step, String> _function_1 = (Step step) -> {
          String _stepNumber = Ucm4iotUtilities.getStepNumber(step);
          String _plus_1 = (_stepNumber + ".");
          String _description = step.getDescription();
          return (_plus_1 + _description);
        };
        List<String> pathDescription = path_1.stream().<String>map(_function_1).collect(Collectors.<String>toList());
        String _join = String.join(" >> ", pathDescription);
        testSteps.add(_join);
      }
    }
    System.out.println("test4");
    String tests = String.join(",", testSteps);
    ArrayList<String> initialCondition = CollectionLiterals.<String>newArrayList();
    initialCondition.add("Initial Condition");
    ArrayList<String> expectedResult = CollectionLiterals.<String>newArrayList();
    expectedResult.add("Expected Result");
    System.out.println("test5");
    String useCasePrecondition = ctx.getPrecondition();
    if ((((useCasePrecondition == null) || useCasePrecondition.isEmpty()) || useCasePrecondition.trim().isEmpty())) {
      useCasePrecondition = "<precondition>";
    }
    String useCasePostcondition = ctx.getPostcondition();
    if ((((useCasePostcondition == null) || useCasePostcondition.isEmpty()) || useCasePostcondition.trim().isEmpty())) {
      useCasePostcondition = "<postcondition>";
    }
    System.out.println("test6");
    for (int i = 0; (i < (((Object[])Conversions.unwrapArray(header, Object.class)).length - 1)); i++) {
      {
        initialCondition.add(useCasePrecondition);
        expectedResult.add(useCasePostcondition);
      }
    }
    System.out.println("test7");
    String preconditions = String.join(",", initialCondition);
    String postconditions = String.join(",", expectedResult);
    rows.add(paths);
    rows.add(preconditions);
    rows.add(tests);
    rows.add(postconditions);
    System.out.println("test8");
    return String.join("\n", rows);
  }

  public ArrayList<List<Step>> getPaths(final UseCase ctx, final Step firstStep) {
    ArrayList<List<Step>> paths = CollectionLiterals.<List<Step>>newArrayList();
    HashSet<Step> _hashSet = new HashSet<Step>();
    this.getPathsHelper(ctx, paths, firstStep, CollectionLiterals.<Step>newArrayList(), _hashSet);
    return paths;
  }

  public void getPathsHelper(final UseCase ctx, final List<List<Step>> paths, final Step currentStep, final List<Step> currentPath, final HashSet<Step> visited) {
    if ((((ctx == null) || (currentStep == null)) || visited.contains(currentStep))) {
      ArrayList<Step> _arrayList = new ArrayList<Step>(currentPath);
      paths.add(_arrayList);
      return;
    }
    final Predicate<Step> _function = (Step step) -> {
      return Ucm4iotUtilities.hasStepNumber(step);
    };
    List<Step> mainSteps = EcoreUtil2.<Step>getAllContentsOfType(ctx.getMain(), Step.class).stream().filter(_function).collect(Collectors.<Step>toList());
    List<ExtensionBlock> blocks = EcoreUtil2.<ExtensionBlock>getAllContentsOfType(ctx, ExtensionBlock.class).stream().collect(Collectors.<ExtensionBlock>toList());
    visited.add(currentStep);
    currentPath.add(currentStep);
    boolean _contains = mainSteps.contains(currentStep);
    if (_contains) {
      int index = mainSteps.indexOf(currentStep);
      Step nextStep = null;
      final List<Step> _converted_mainSteps = (List<Step>)mainSteps;
      int _length = ((Object[])Conversions.unwrapArray(_converted_mainSteps, Object.class)).length;
      boolean _lessThan = ((index + 1) < _length);
      if (_lessThan) {
        nextStep = mainSteps.get((index + 1));
      }
      this.getPathsHelper(ctx, paths, nextStep, currentPath, visited);
    } else {
    }
    visited.remove(currentStep);
    currentPath.remove(currentStep);
  }
}
