package mde.iot.ucm4iot.generator;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import mde.iot.ucm4iot.ucm4iot.Actor;
import mde.iot.ucm4iot.ucm4iot.ContextAwareness;
import mde.iot.ucm4iot.ucm4iot.ContextAwarenessEnabledUseCase;
import mde.iot.ucm4iot.ucm4iot.ContextExceptionMapping;
import mde.iot.ucm4iot.ucm4iot.ContextItem;
import mde.iot.ucm4iot.ucm4iot.DeviceActor;
import mde.iot.ucm4iot.ucm4iot.EnvironmentException;
import mde.iot.ucm4iot.ucm4iot.ExceptionStep;
import mde.iot.ucm4iot.ucm4iot.ExceptionalUseCase;
import mde.iot.ucm4iot.ucm4iot.ExtensionBlock;
import mde.iot.ucm4iot.ucm4iot.HandlerUseCase;
import mde.iot.ucm4iot.ucm4iot.HardwareException;
import mde.iot.ucm4iot.ucm4iot.HumanActor;
import mde.iot.ucm4iot.ucm4iot.InvocationStep;
import mde.iot.ucm4iot.ucm4iot.NetworkException;
import mde.iot.ucm4iot.ucm4iot.Outcome;
import mde.iot.ucm4iot.ucm4iot.OutcomeContinues;
import mde.iot.ucm4iot.ucm4iot.PhysicalEntityActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareActor;
import mde.iot.ucm4iot.ucm4iot.SoftwareException;
import mde.iot.ucm4iot.ucm4iot.Step;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class UseCaseDiagramGenerator extends IUcm4iotGeneratorImpl {
  /**
   * Class: DiagramRepresentation
   * ----------------------------
   * Creates a representation of a diagram.
   */
  protected static class DiagramRepresentation {
    private EObject element;

    private HashMap<String, List<UseCaseDiagramGenerator.DiagramRepresentation>> childrenMap;

    private String tag;

    private Map<String, String> attributes;

    /**
     * Creates a new diagram representation.
     */
    public DiagramRepresentation(final EObject element, final String tag) {
      this(element, tag, new HashMap<String, String>());
    }

    /**
     * Creates a new diagram representation.
     */
    public DiagramRepresentation(final EObject element, final String tag, final Map<String, String> attributes) {
      this.element = element;
      this.tag = tag;
      HashMap<String, String> _hashMap = new HashMap<String, String>();
      this.attributes = _hashMap;
      this.attributes.putAll(attributes);
      HashMap<String, List<UseCaseDiagramGenerator.DiagramRepresentation>> _hashMap_1 = new HashMap<String, List<UseCaseDiagramGenerator.DiagramRepresentation>>();
      this.childrenMap = _hashMap_1;
    }

    /**
     * getElement(..)
     * --------------
     * Gets the object this element is associated with.
     */
    public EObject getElement() {
      return this.element;
    }

    /**
     * addChildren(..)
     * ---------------
     * Adds a list of children to this element.
     */
    public void addChildren(final String key, final List<UseCaseDiagramGenerator.DiagramRepresentation> children) {
      boolean _containsKey = this.childrenMap.containsKey(key);
      boolean _not = (!_containsKey);
      if (_not) {
        this.childrenMap.put(key, CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList());
      }
      this.childrenMap.get(key).addAll(children);
    }

    /**
     * keySet(..)
     * ----------
     * Get the keys associated with the children.
     */
    public Set<String> keySet() {
      return this.childrenMap.keySet();
    }

    /**
     * getChildren(..)
     * ---------------
     * Gets the children of this element.
     */
    public List<UseCaseDiagramGenerator.DiagramRepresentation> getChildren(final String key) {
      return this.childrenMap.get(key);
    }

    /**
     * hasChildren(..)
     * ---------------
     * Returns true if this element has children.
     */
    public boolean hasChildren() {
      boolean _isEmpty = this.childrenMap.isEmpty();
      return (!_isEmpty);
    }

    /**
     * getStartTag(..)
     * ---------------
     * Gets the tag for the start of an element.
     */
    public String getStartTag() {
      boolean _isEmpty = this.attributes.isEmpty();
      if (_isEmpty) {
        return String.format("<%s>", this.tag);
      }
      return String.format("<%s %s>", this.tag, this.getAttributes());
    }

    /**
     * getEndTag(..)
     * -------------
     * Gets the tag for the end of an element.
     */
    public String getEndTag() {
      return String.format("</%s>", this.tag);
    }

    /**
     * getOneLineTag(..)
     * -----------------
     * Gets the tag in a one line representation.
     */
    public String getOneLineTag() {
      boolean _isEmpty = this.attributes.isEmpty();
      if (_isEmpty) {
        return String.format("<%s/>", this.tag);
      }
      return String.format("<%s %s/>", this.tag, this.getAttributes());
    }

    /**
     * addAttribute(..)
     * ----------------
     * Adds an attribute to this element.
     */
    public String addAttribute(final String key, final String value) {
      return this.attributes.put(key, value);
    }

    /**
     * addAttributes(..)
     * -----------------
     * Adds many attributes to this element.
     */
    public void addAttributes(final Map<String, String> attributes) {
      this.attributes.putAll(attributes);
    }

    /**
     * getAttribute(..)
     * ----------------
     * Gets an attribute from the element.
     */
    public String getAttribute(final String key) {
      return this.attributes.get(key);
    }

    /**
     * getAttributes(..)
     * -----------------
     * Gets the attributes formatted into a string.
     */
    public String getAttributes() {
      ArrayList<String> args = CollectionLiterals.<String>newArrayList();
      Set<String> _keySet = this.attributes.keySet();
      for (final String key : _keySet) {
        String _format = String.format("%s=\"%s\"", key, this.attributes.get(key));
        args.add(_format);
      }
      return String.join(" ", args);
    }
  }

  /**
   * generate(..)
   * ------------
   * Generates a use case diagram for a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates a use case diagram for a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    String data = this.generateDiagram(resource);
    this.createFile(fsa, folder, this.createFileName(EcoreUtil2.getNormalizedURI(resource).lastSegment().replace(".ucmiot", ""), ".usecasediagram"), data);
  }

  /**
   * createTable(..)
   * ---------------
   * Creates a table of information.
   */
  protected HashMap<String, List<EObject>> createTable(final Resource resource) {
    final Function<UseCase, EObject> _function = (UseCase eo) -> {
      return ((EObject) eo);
    };
    List<EObject> useCases = StreamSupport.<UseCase>stream(Iterables.<UseCase>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), UseCase.class).spliterator(), false).<EObject>map(_function).collect(Collectors.<EObject>toList());
    final Function<Actor, EObject> _function_1 = (Actor eo) -> {
      return ((EObject) eo);
    };
    List<EObject> actors = StreamSupport.<Actor>stream(Iterables.<Actor>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), Actor.class).spliterator(), false).<EObject>map(_function_1).collect(Collectors.<EObject>toList());
    final Function<mde.iot.ucm4iot.ucm4iot.Exception, EObject> _function_2 = (mde.iot.ucm4iot.ucm4iot.Exception eo) -> {
      return ((EObject) eo);
    };
    List<EObject> exceptions = StreamSupport.<mde.iot.ucm4iot.ucm4iot.Exception>stream(Iterables.<mde.iot.ucm4iot.ucm4iot.Exception>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), mde.iot.ucm4iot.ucm4iot.Exception.class).spliterator(), false).<EObject>map(_function_2).collect(Collectors.<EObject>toList());
    HashMap<String, List<EObject>> table = new HashMap<String, List<EObject>>();
    table.put("use_cases", useCases);
    table.put("actors", actors);
    table.put("exceptions", exceptions);
    return table;
  }

  /**
   * generateDiagram(..)
   * -------------------
   * Generates a diagram.
   */
  protected String generateDiagram(final Resource resource) {
    HashMap<String, List<EObject>> table = this.createTable(resource);
    String tag = "usecasediagram:UseCaseDiagram";
    Pair<String, String> _mappedTo = Pair.<String, String>of("xmi:version", "2.0");
    Pair<String, String> _mappedTo_1 = Pair.<String, String>of("xmlns:xmi", "http://www.omg.org/XMI");
    Pair<String, String> _mappedTo_2 = Pair.<String, String>of("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    Pair<String, String> _mappedTo_3 = Pair.<String, String>of("xmlns:usecasediagram", "http://www.ucm4iot.org/mde/iot/usecasediagram");
    Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1, _mappedTo_2, _mappedTo_3));
    UseCaseDiagramGenerator.DiagramRepresentation root = new UseCaseDiagramGenerator.DiagramRepresentation(null, tag, attributes);
    this.linkScopes(table, root);
    this.linkActors(table, root);
    this.addAssociations(root);
    List<String> data = this.createDiagram(root);
    return String.join("\n", data);
  }

  /**
   * linkScopes(..)
   * --------------
   * Links each scope in the model to the root element.
   */
  protected void linkScopes(final HashMap<String, List<EObject>> table, final UseCaseDiagramGenerator.DiagramRepresentation root) {
    final Function<EObject, UseCase> _function = (EObject ob) -> {
      return ((UseCase) ob);
    };
    List<UseCase> useCases = table.get("use_cases").stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
    final Function<UseCase, String> _function_1 = (UseCase uc) -> {
      return uc.getScope();
    };
    List<String> scopeNames = useCases.stream().<String>map(_function_1).distinct().collect(Collectors.<String>toList());
    for (final String scopeName : scopeNames) {
      {
        final Predicate<UseCase> _function_2 = (UseCase uc) -> {
          String _scope = uc.getScope();
          return Objects.equals(_scope, scopeName);
        };
        final List<UseCase> containedUseCases = useCases.stream().filter(_function_2).collect(Collectors.<UseCase>toList());
        final Function<EObject, mde.iot.ucm4iot.ucm4iot.Exception> _function_3 = (EObject ob) -> {
          return ((mde.iot.ucm4iot.ucm4iot.Exception) ob);
        };
        final Predicate<mde.iot.ucm4iot.ucm4iot.Exception> _function_4 = (mde.iot.ucm4iot.ucm4iot.Exception exception) -> {
          return this.hasExeption(containedUseCases, exception);
        };
        final List<mde.iot.ucm4iot.ucm4iot.Exception> containedExceptions = table.get("exceptions").stream().<mde.iot.ucm4iot.ucm4iot.Exception>map(_function_3).filter(_function_4).collect(Collectors.<mde.iot.ucm4iot.ucm4iot.Exception>toList());
        String tag = "scopes";
        Pair<String, String> _mappedTo = Pair.<String, String>of("name", scopeName);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo));
        UseCaseDiagramGenerator.DiagramRepresentation scopeRep = new UseCaseDiagramGenerator.DiagramRepresentation(null, tag, attributes);
        this.linkUseCases(scopeRep, containedUseCases);
        this.linkExceptions(scopeRep, containedExceptions);
        root.addChildren("scopes", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(scopeRep)));
      }
    }
  }

  /**
   * hasExeption(..)
   * ---------------
   * There exists a use case that raises the passed exception.
   */
  private boolean hasExeption(final List<UseCase> useCases, final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    final Predicate<UseCase> _function = (UseCase uc) -> {
      final Predicate<ExceptionStep> _function_1 = (ExceptionStep es) -> {
        mde.iot.ucm4iot.ucm4iot.Exception _refException = es.getRefException();
        return (_refException == exception);
      };
      return EcoreUtil2.<ExceptionStep>getAllContentsOfType(uc, ExceptionStep.class).stream().anyMatch(_function_1);
    };
    return useCases.stream().anyMatch(_function);
  }

  /**
   * linkUseCases(..)
   * ----------------
   * Links use cases to their respective scope.
   */
  protected void linkUseCases(final UseCaseDiagramGenerator.DiagramRepresentation scopeRep, final List<UseCase> containedUseCases) {
    for (final UseCase useCase : containedUseCases) {
      {
        String tag = "usecases";
        String _formatUseCaseType = this.formatUseCaseType(useCase);
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", _formatUseCaseType);
        String _name = useCase.getName();
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", _name);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        UseCaseDiagramGenerator.DiagramRepresentation useCaseRep = new UseCaseDiagramGenerator.DiagramRepresentation(useCase, tag, attributes);
        this.linkDynamicGoals(useCaseRep, useCase);
        this.linkContextRequirements(useCaseRep, useCase);
        scopeRep.addChildren("use_cases", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(useCaseRep)));
      }
    }
  }

  /**
   * Matches [DG:Name] and [RB:Name] tags embedded in step descriptions.
   */
  private static final Pattern DG_RB_PATTERN = Pattern.compile("\\[(?:DG|RB):\\s*([^\\]]+?)\\s*\\]");

  /**
   * linkDynamicGoals(..)
   * --------------------
   * Adds a child element for every distinct dynamic goal referenced (via
   * [DG:...] or [RB:...]) in the steps of the use case.
   */
  protected void linkDynamicGoals(final UseCaseDiagramGenerator.DiagramRepresentation useCaseRep, final UseCase useCase) {
    LinkedHashSet<String> _extractDynamicGoalNames = this.extractDynamicGoalNames(useCase);
    for (final String goalName : _extractDynamicGoalNames) {
      {
        Pair<String, String> _mappedTo = Pair.<String, String>of("name", goalName);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo));
        UseCaseDiagramGenerator.DiagramRepresentation goalRep = new UseCaseDiagramGenerator.DiagramRepresentation(null, "dynamicGoals", attributes);
        useCaseRep.addChildren("dynamic_goals", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(goalRep)));
      }
    }
  }

  /**
   * linkContextRequirements(..)
   * ---------------------------
   * Adds a child element for every CA requirement id associated with the use case.
   */
  protected void linkContextRequirements(final UseCaseDiagramGenerator.DiagramRepresentation useCaseRep, final UseCase useCase) {
    LinkedHashSet<String> _extractContextRequirementIds = this.extractContextRequirementIds(useCase);
    for (final String caId : _extractContextRequirementIds) {
      {
        Pair<String, String> _mappedTo = Pair.<String, String>of("id", caId);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo));
        UseCaseDiagramGenerator.DiagramRepresentation caRep = new UseCaseDiagramGenerator.DiagramRepresentation(null, "contextRequirements", attributes);
        useCaseRep.addChildren("context_requirements", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(caRep)));
      }
    }
  }

  /**
   * extractDynamicGoalNames(..)
   * ---------------------------
   * Scans every step description of the use case for [DG:...]/[RB:...] tags and
   * returns the distinct goal names, in first-seen order.
   */
  protected LinkedHashSet<String> extractDynamicGoalNames(final UseCase useCase) {
    final LinkedHashSet<String> names = new LinkedHashSet<String>();
    List<Step> _allContentsOfType = EcoreUtil2.<Step>getAllContentsOfType(useCase, Step.class);
    for (final Step step : _allContentsOfType) {
      {
        final EStructuralFeature feature = step.eClass().getEStructuralFeature("description");
        if ((feature != null)) {
          final Object value = step.eGet(feature);
          if ((value instanceof String)) {
            final Matcher matcher = UseCaseDiagramGenerator.DG_RB_PATTERN.matcher(((String) value));
            while (matcher.find()) {
              names.add(matcher.group(1).trim());
            }
          }
        }
      }
    }
    return names;
  }

  /**
   * extractContextRequirementIds(..)
   * --------------------------------
   * Collects CA requirement ids for the use case: those defined in its
   * context-awareness block, plus those referenced by a CA-enabled use case.
   */
  protected LinkedHashSet<String> extractContextRequirementIds(final UseCase useCase) {
    final LinkedHashSet<String> ids = new LinkedHashSet<String>();
    ContextAwareness _contextAwareness = useCase.getContextAwareness();
    boolean _tripleNotEquals = (_contextAwareness != null);
    if (_tripleNotEquals) {
      EList<ContextItem> _contextItems = useCase.getContextAwareness().getContextItems();
      for (final ContextItem item : _contextItems) {
        ids.add(item.getId());
      }
    }
    if ((useCase instanceof ContextAwarenessEnabledUseCase)) {
      EList<String> _context = ((ContextAwarenessEnabledUseCase) useCase).getContext();
      for (final String cid : _context) {
        ids.add(cid);
      }
    }
    return ids;
  }

  /**
   * linkExceptions(..)
   * ------------------
   * Links exceptions to their respective scope.
   */
  protected void linkExceptions(final UseCaseDiagramGenerator.DiagramRepresentation scopeRep, final List<mde.iot.ucm4iot.ucm4iot.Exception> containedExceptions) {
    for (final mde.iot.ucm4iot.ucm4iot.Exception exception : containedExceptions) {
      {
        String tag = "exceptions";
        String _formatExceptionType = this.formatExceptionType(exception);
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", _formatExceptionType);
        String _name = exception.getName();
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", _name);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1));
        UseCaseDiagramGenerator.DiagramRepresentation exceptionRep = new UseCaseDiagramGenerator.DiagramRepresentation(exception, tag, attributes);
        scopeRep.addChildren("exceptions", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(exceptionRep)));
      }
    }
  }

  /**
   * linkActors(..)
   * --------------
   * Links each actor in the model to the root element.
   */
  protected void linkActors(final HashMap<String, List<EObject>> table, final UseCaseDiagramGenerator.DiagramRepresentation root) {
    final Function<EObject, Actor> _function = (EObject ob) -> {
      return ((Actor) ob);
    };
    List<Actor> actors = table.get("actors").stream().<Actor>map(_function).collect(Collectors.<Actor>toList());
    final Function<Actor, String> _function_1 = (Actor ac) -> {
      return ac.getName();
    };
    List<String> actorNames = actors.stream().<String>map(_function_1).distinct().collect(Collectors.<String>toList());
    for (final String actorName : actorNames) {
      {
        final Predicate<Actor> _function_2 = (Actor ac) -> {
          String _name = ac.getName();
          return Objects.equals(_name, actorName);
        };
        final List<Actor> relevantActors = actors.stream().filter(_function_2).collect(Collectors.<Actor>toList());
        final Actor actor = relevantActors.stream().findFirst().orElse(null);
        String tag = "actors";
        String _formatActorType = this.formatActorType(actor);
        Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", _formatActorType);
        Pair<String, String> _mappedTo_1 = Pair.<String, String>of("name", actorName);
        String _formatActorMultiplicity = this.formatActorMultiplicity(actor.getLowerbound());
        Pair<String, String> _mappedTo_2 = Pair.<String, String>of("lowerBound", _formatActorMultiplicity);
        String _formatActorMultiplicity_1 = this.formatActorMultiplicity(actor.getUpperbound());
        Pair<String, String> _mappedTo_3 = Pair.<String, String>of("upperBound", _formatActorMultiplicity_1);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_1, _mappedTo_2, _mappedTo_3));
        UseCaseDiagramGenerator.DiagramRepresentation actorRep = new UseCaseDiagramGenerator.DiagramRepresentation(null, tag, attributes);
        root.addChildren("actors", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(actorRep)));
      }
    }
  }

  /**
   * addAssociations(..)
   * -------------------
   * Add relationships between the elements in the table.
   */
  protected void addAssociations(final UseCaseDiagramGenerator.DiagramRepresentation root) {
    List<UseCaseDiagramGenerator.DiagramRepresentation> _children = root.getChildren("scopes");
    for (final UseCaseDiagramGenerator.DiagramRepresentation scopeRep : _children) {
      List<UseCaseDiagramGenerator.DiagramRepresentation> _children_1 = scopeRep.getChildren("use_cases");
      for (final UseCaseDiagramGenerator.DiagramRepresentation useCaseRep : _children_1) {
        {
          this.addIncludesAssociations(root, useCaseRep);
          if ((useCaseRep.element instanceof HandlerUseCase)) {
            this.addInterruptsAssociations(root, useCaseRep);
          }
        }
      }
    }
    List<UseCaseDiagramGenerator.DiagramRepresentation> _children_2 = root.getChildren("actors");
    for (final UseCaseDiagramGenerator.DiagramRepresentation actorRep : _children_2) {
      this.addActorAssociations(root, actorRep);
    }
  }

  /**
   * addIncludesAssociations(..)
   * ---------------------------
   * Adds an includes relationship for each use case element.
   */
  protected void addIncludesAssociations(final UseCaseDiagramGenerator.DiagramRepresentation root, final UseCaseDiagramGenerator.DiagramRepresentation useCaseRep) {
    List<UseCaseDiagramGenerator.DiagramRepresentation> scopeReps = root.getChildren("scopes");
    final Function<InvocationStep, UseCase> _function = (InvocationStep step) -> {
      return step.getInvokedUseCase();
    };
    List<UseCase> invokedUseCases = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCaseRep.element, InvocationStep.class).stream().<UseCase>map(_function).distinct().collect(Collectors.<UseCase>toList());
    for (final UseCase invokedUseCase : invokedUseCases) {
      {
        final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_1 = (UseCaseDiagramGenerator.DiagramRepresentation scopeRep) -> {
          String _scope = invokedUseCase.getScope();
          String _attribute = scopeRep.getAttribute("name");
          return Boolean.valueOf(Objects.equals(_scope, _attribute));
        };
        int scopeIndex = this.indexMatched(scopeReps, _function_1);
        final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_2 = (UseCaseDiagramGenerator.DiagramRepresentation ucRep) -> {
          return Boolean.valueOf((invokedUseCase == ucRep.element));
        };
        int useCaseIndex = this.indexMatched(scopeReps.get(scopeIndex).getChildren("use_cases"), _function_2);
        String tag = "includes";
        Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("scopes", Integer.valueOf(scopeIndex));
        Pair<String, Integer> _mappedTo_1 = Pair.<String, Integer>of("usecases", Integer.valueOf(useCaseIndex));
        String _formatAssociation = this.formatAssociation(_mappedTo, _mappedTo_1);
        Pair<String, String> _mappedTo_2 = Pair.<String, String>of("includedCase", _formatAssociation);
        Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo_2));
        UseCaseDiagramGenerator.DiagramRepresentation includesRep = new UseCaseDiagramGenerator.DiagramRepresentation(null, tag, attributes);
        useCaseRep.addChildren("included_use_cases", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(includesRep)));
      }
    }
  }

  /**
   * addInterruptsAssociations(..)
   * -----------------------------
   * Adds an interrupts association for every handler use case.
   */
  protected void addInterruptsAssociations(final UseCaseDiagramGenerator.DiagramRepresentation root, final UseCaseDiagramGenerator.DiagramRepresentation useCaseRep) {
    final List<UseCaseDiagramGenerator.DiagramRepresentation> scopeReps = root.getChildren("scopes");
    final Function<ContextExceptionMapping, UseCase> _function = (ContextExceptionMapping cx) -> {
      return cx.getContext();
    };
    final List<UseCase> interruptedUseCases = ((HandlerUseCase) useCaseRep.element).getContextExceptions().stream().<UseCase>map(_function).distinct().collect(Collectors.<UseCase>toList());
    for (final UseCase interruptedUseCase : interruptedUseCases) {
      {
        final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_1 = (UseCaseDiagramGenerator.DiagramRepresentation scopeRep) -> {
          String _scope = interruptedUseCase.getScope();
          String _attribute = scopeRep.getAttribute("name");
          return Boolean.valueOf(Objects.equals(_scope, _attribute));
        };
        final int scopeIndex = this.indexMatched(scopeReps, _function_1);
        final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_2 = (UseCaseDiagramGenerator.DiagramRepresentation ucRep) -> {
          return Boolean.valueOf((interruptedUseCase == ucRep.element));
        };
        final int useCaseIndex = this.indexMatched(scopeReps.get(scopeIndex).getChildren("use_cases"), _function_2);
        ArrayList<mde.iot.ucm4iot.ucm4iot.Exception> interruptsContinues = CollectionLiterals.<mde.iot.ucm4iot.ucm4iot.Exception>newArrayList();
        ArrayList<mde.iot.ucm4iot.ucm4iot.Exception> interruptsEnds = CollectionLiterals.<mde.iot.ucm4iot.ucm4iot.Exception>newArrayList();
        final Predicate<ContextExceptionMapping> _function_3 = (ContextExceptionMapping cx) -> {
          UseCase _context = cx.getContext();
          return Objects.equals(interruptedUseCase, _context);
        };
        final Function<ContextExceptionMapping, mde.iot.ucm4iot.ucm4iot.Exception> _function_4 = (ContextExceptionMapping cx) -> {
          return cx.getException();
        };
        final List<mde.iot.ucm4iot.ucm4iot.Exception> exceptions = ((HandlerUseCase) useCaseRep.element).getContextExceptions().stream().filter(_function_3).<mde.iot.ucm4iot.ucm4iot.Exception>map(_function_4).collect(Collectors.<mde.iot.ucm4iot.ucm4iot.Exception>toList());
        for (final mde.iot.ucm4iot.ucm4iot.Exception exception : exceptions) {
          boolean _isInterruptsAndContinues = this.isInterruptsAndContinues(interruptedUseCase, exception);
          if (_isInterruptsAndContinues) {
            interruptsContinues.add(exception);
          } else {
            interruptsEnds.add(exception);
          }
        }
        boolean _isEmpty = interruptsContinues.isEmpty();
        boolean _not = (!_isEmpty);
        if (_not) {
          UseCaseDiagramGenerator.DiagramRepresentation interruptsRep = this.createInterruptElement(scopeReps, scopeIndex, interruptsContinues, useCaseIndex, true);
          useCaseRep.addChildren("interrupted_use_cases", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(interruptsRep)));
        }
        boolean _isEmpty_1 = interruptsEnds.isEmpty();
        boolean _not_1 = (!_isEmpty_1);
        if (_not_1) {
          UseCaseDiagramGenerator.DiagramRepresentation interruptsRep_1 = this.createInterruptElement(scopeReps, scopeIndex, interruptsEnds, useCaseIndex, false);
          useCaseRep.addChildren("interrupted_use_cases", Collections.<UseCaseDiagramGenerator.DiagramRepresentation>unmodifiableList(CollectionLiterals.<UseCaseDiagramGenerator.DiagramRepresentation>newArrayList(interruptsRep_1)));
        }
      }
    }
  }

  /**
   * createInterruptElement(..)
   * --------------------------
   * Helper function that creates interrupt representations.
   */
  private UseCaseDiagramGenerator.DiagramRepresentation createInterruptElement(final List<UseCaseDiagramGenerator.DiagramRepresentation> scopeReps, final int scopeIndex, final List<mde.iot.ucm4iot.ucm4iot.Exception> interruptsContinues, final int useCaseIndex, final boolean interruptsAndContinues) {
    final List<UseCaseDiagramGenerator.DiagramRepresentation> exceptionReps = scopeReps.get(scopeIndex).getChildren("exceptions");
    final Function<mde.iot.ucm4iot.ucm4iot.Exception, Integer> _function = (mde.iot.ucm4iot.ucm4iot.Exception exception) -> {
      final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_1 = (UseCaseDiagramGenerator.DiagramRepresentation exRep) -> {
        return Boolean.valueOf(Objects.equals(exception, exRep.element));
      };
      return Integer.valueOf(this.indexMatched(exceptionReps, _function_1));
    };
    final Function<Integer, String> _function_1 = (Integer exceptionIndex) -> {
      Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("scopes", Integer.valueOf(scopeIndex));
      Pair<String, Integer> _mappedTo_1 = Pair.<String, Integer>of("exceptions", exceptionIndex);
      return this.formatAssociation(_mappedTo, _mappedTo_1);
    };
    final List<String> exceptionAssociations = interruptsContinues.stream().<Integer>map(_function).<String>map(_function_1).collect(Collectors.<String>toList());
    String tag = "interrupts";
    String _formatInterrupt = this.formatInterrupt(interruptsAndContinues);
    Pair<String, String> _mappedTo = Pair.<String, String>of("xsi:type", _formatInterrupt);
    Pair<String, Integer> _mappedTo_1 = Pair.<String, Integer>of("scopes", Integer.valueOf(scopeIndex));
    Pair<String, Integer> _mappedTo_2 = Pair.<String, Integer>of("usecases", Integer.valueOf(useCaseIndex));
    String _formatAssociation = this.formatAssociation(_mappedTo_1, _mappedTo_2);
    Pair<String, String> _mappedTo_3 = Pair.<String, String>of("interruptedCase", _formatAssociation);
    String _join = String.join(" ", exceptionAssociations);
    Pair<String, String> _mappedTo_4 = Pair.<String, String>of("exceptions", _join);
    Map<String, String> attributes = Collections.<String, String>unmodifiableMap(CollectionLiterals.<String, String>newHashMap(_mappedTo, _mappedTo_3, _mappedTo_4));
    return new UseCaseDiagramGenerator.DiagramRepresentation(null, tag, attributes);
  }

  /**
   * isInterruptsAndContinues(..)
   * ----------------------------
   * Function returns true if this use case interrupts and continues when the passed exception is raised.
   */
  private boolean isInterruptsAndContinues(final UseCase useCase, final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    final Predicate<ExceptionStep> _function = (ExceptionStep step) -> {
      mde.iot.ucm4iot.ucm4iot.Exception _refException = step.getRefException();
      return (_refException == exception);
    };
    List<ExceptionStep> relevantSteps = EcoreUtil2.<ExceptionStep>getAllContentsOfType(useCase, ExceptionStep.class).stream().filter(_function).collect(Collectors.<ExceptionStep>toList());
    ExtensionBlock block = EcoreUtil2.<ExtensionBlock>getContainerOfType(relevantSteps.get(0), ExtensionBlock.class);
    Outcome _outcome = block.getOutcome();
    if ((_outcome instanceof OutcomeContinues)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * addActorAssociations(..)
   * ------------------------
   * Adds an association to a use case for every actor.
   */
  protected String addActorAssociations(final UseCaseDiagramGenerator.DiagramRepresentation root, final UseCaseDiagramGenerator.DiagramRepresentation actorRep) {
    String _xblockexpression = null;
    {
      final ArrayList<String> associations = CollectionLiterals.<String>newArrayList();
      List<UseCaseDiagramGenerator.DiagramRepresentation> _children = root.getChildren("scopes");
      for (final UseCaseDiagramGenerator.DiagramRepresentation scopeRep : _children) {
        List<UseCaseDiagramGenerator.DiagramRepresentation> _children_1 = scopeRep.getChildren("use_cases");
        for (final UseCaseDiagramGenerator.DiagramRepresentation useCaseRep : _children_1) {
          {
            final Predicate<Actor> _function = (Actor actor) -> {
              String _attribute = actorRep.getAttribute("name");
              String _name = actor.getName();
              return Objects.equals(_attribute, _name);
            };
            Actor actor = EcoreUtil2.<Actor>getAllContentsOfType(useCaseRep.element, Actor.class).stream().filter(_function).findFirst().orElse(null);
            if ((actor != null)) {
              List<UseCaseDiagramGenerator.DiagramRepresentation> scopeReps = root.getChildren("scopes");
              final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_1 = (UseCaseDiagramGenerator.DiagramRepresentation rep) -> {
                return Boolean.valueOf((rep == scopeRep));
              };
              final int scopeIndex = this.indexMatched(scopeReps, _function_1);
              List<UseCaseDiagramGenerator.DiagramRepresentation> useCaseReps = scopeReps.get(scopeIndex).getChildren("use_cases");
              final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> _function_2 = (UseCaseDiagramGenerator.DiagramRepresentation rep) -> {
                return Boolean.valueOf((rep == useCaseRep));
              };
              final int useCaseIndex = this.indexMatched(useCaseReps, _function_2);
              Pair<String, Integer> _mappedTo = Pair.<String, Integer>of("scopes", Integer.valueOf(scopeIndex));
              Pair<String, Integer> _mappedTo_1 = Pair.<String, Integer>of("usecases", Integer.valueOf(useCaseIndex));
              String association = this.formatAssociation(_mappedTo, _mappedTo_1);
              associations.add(association);
            }
          }
        }
      }
      _xblockexpression = actorRep.addAttribute("usecase", String.join(" ", associations));
    }
    return _xblockexpression;
  }

  /**
   * indexMatched(..)
   * ----------------
   * Determines the first index the passed function returns true.
   */
  protected int indexMatched(final List<UseCaseDiagramGenerator.DiagramRepresentation> reps, final Function<UseCaseDiagramGenerator.DiagramRepresentation, Boolean> match) {
    for (int i = 0; (i < reps.size()); i++) {
      Boolean _apply = match.apply(reps.get(i));
      if ((_apply).booleanValue()) {
        return i;
      }
    }
    return (-1);
  }

  /**
   * formatUseCaseType(..)
   * ---------------------
   * Formats the type of the passed use case.
   */
  private String formatUseCaseType(final UseCase useCase) {
    final String format = "usecasediagram:%s";
    if ((useCase instanceof ExceptionalUseCase)) {
      return String.format(format, "StandardUseCase");
    }
    return String.format(format, "HandlerUseCase");
  }

  /**
   * formatExceptionType(..)
   * -----------------------
   * Formats the type of the passed exception.
   */
  private String formatExceptionType(final mde.iot.ucm4iot.ucm4iot.Exception exception) {
    final String format = "usecasediagram:%s";
    if ((exception instanceof HardwareException)) {
      return String.format(format, "HardwareException");
    } else {
      if ((exception instanceof SoftwareException)) {
        return String.format(format, "SoftwareException");
      } else {
        if ((exception instanceof EnvironmentException)) {
          return String.format(format, "EnvironmentException");
        } else {
          if ((exception instanceof NetworkException)) {
            return String.format(format, "NetworkException");
          } else {
            return String.format(format, "Exception");
          }
        }
      }
    }
  }

  /**
   * formatActorType(..)
   * -------------------
   * Formats the type of the passed actor.
   */
  private String formatActorType(final Actor actor) {
    final String format = "usecasediagram:%s";
    if ((actor instanceof HumanActor)) {
      return String.format(format, "HumanActor");
    } else {
      if ((actor instanceof SoftwareActor)) {
        return String.format(format, "SoftwareActor");
      } else {
        if ((actor instanceof DeviceActor)) {
          return String.format(format, "DeviceActor");
        } else {
          if ((actor instanceof PhysicalEntityActor)) {
            return String.format(format, "PhysicalEntityActor");
          } else {
            return String.format(format, "Actor");
          }
        }
      }
    }
  }

  /**
   * formatActorMultiplicity(..)
   * ---------------------------
   * Formats the multiplicity of an actor.
   */
  private String formatActorMultiplicity(final String multiplicity) {
    if ((multiplicity == null)) {
      return "-1";
    } else {
      boolean _equals = multiplicity.equals("*");
      if (_equals) {
        return "-1";
      } else {
        return multiplicity;
      }
    }
  }

  /**
   * formatInterrupt(..)
   * -------------------
   * Formats the interrupted use case.
   */
  private String formatInterrupt(final boolean isInterruptContinues) {
    final String format = "usecasediagram:%s";
    if (isInterruptContinues) {
      return String.format(format, "InterruptAndContinue");
    }
    return String.format(format, "InterruptAndFail");
  }

  /**
   * formatAssociation(..)
   * ---------------------
   * Formats an association to an existing element.
   */
  protected String formatAssociation(final Pair<String, Integer>... indexMap) {
    StringBuilder builder = new StringBuilder();
    final String format = "/@%s.%s";
    builder.append("/");
    for (final Pair<String, Integer> pair : indexMap) {
      builder.append(String.format(format, pair.getKey(), pair.getValue()));
    }
    return builder.toString();
  }

  /**
   * createDiagram(..)
   * -----------------
   * Creates a diagram.
   */
  protected List<String> createDiagram(final UseCaseDiagramGenerator.DiagramRepresentation rep) {
    ArrayList<String> data = CollectionLiterals.<String>newArrayList();
    data.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    this.createDiagramHelper(rep, 0, data);
    return data;
  }

  /**
   * createDiagramHelper(..)
   * -----------------------
   * Recursively goes through a diagram representation and outputs a diagram.
   */
  private void createDiagramHelper(final UseCaseDiagramGenerator.DiagramRepresentation rep, final int depth, final ArrayList<String> output) {
    if ((rep == null)) {
      return;
    }
    boolean _hasChildren = rep.hasChildren();
    if (_hasChildren) {
      String _createTabs = this.createTabs(depth);
      String _startTag = rep.getStartTag();
      String _plus = (_createTabs + _startTag);
      output.add(_plus);
      Set<String> _keySet = rep.keySet();
      for (final String key : _keySet) {
        List<UseCaseDiagramGenerator.DiagramRepresentation> _children = rep.getChildren(key);
        for (final UseCaseDiagramGenerator.DiagramRepresentation child : _children) {
          this.createDiagramHelper(child, (depth + 1), output);
        }
      }
      String _createTabs_1 = this.createTabs(depth);
      String _endTag = rep.getEndTag();
      String _plus_1 = (_createTabs_1 + _endTag);
      output.add(_plus_1);
    } else {
      String _createTabs_2 = this.createTabs(depth);
      String _oneLineTag = rep.getOneLineTag();
      String _plus_2 = (_createTabs_2 + _oneLineTag);
      output.add(_plus_2);
    }
  }

  /**
   * createTab(..)
   * -------------
   * Creates a string with the specified number of tabs.
   */
  private String createTabs(final int indents) {
    StringBuilder builder = new StringBuilder();
    builder.append("");
    for (int i = 0; (i < indents); i++) {
      builder.append("\t");
    }
    return builder.toString();
  }
}
