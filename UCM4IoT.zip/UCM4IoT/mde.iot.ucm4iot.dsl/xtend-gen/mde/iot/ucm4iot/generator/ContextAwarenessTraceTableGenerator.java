package mde.iot.ucm4iot.generator;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import mde.iot.ucm4iot.ucm4iot.ContextAwareness;
import mde.iot.ucm4iot.ucm4iot.ContextAwarenessEnabledUseCase;
import mde.iot.ucm4iot.ucm4iot.ContextItem;
import mde.iot.ucm4iot.ucm4iot.InvocationStep;
import mde.iot.ucm4iot.ucm4iot.UseCase;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

/**
 * Obsolete - Feel free to remove.
 * 
 * Class: SummaryTableGenerator
 * ----------------------------
 * Generates Exception Summary Tables.
 */
@SuppressWarnings("all")
public class ContextAwarenessTraceTableGenerator extends IUcm4iotGeneratorImpl {
  /**
   * Represents an exception record with the following fields:
   * (1) ID
   * (2) Description
   * (3) Source (UseCase)
   * (4) Path
   * (5) CA-enabled UseCase
   */
  public static class ContextIdRecord {
    private String id;

    private String description;

    private String source;

    private String path;

    private String caEnabled;

    /**
     * Constructor to initialize all fields.
     */
    public ContextIdRecord(final String id, final String description, final String source, final String path, final String caEnabled) {
      this.id = id;
      this.description = description;
      this.source = source;
      this.path = path;
      this.caEnabled = caEnabled;
    }
  }

  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    this.generate(resource, fsa, context, "");
  }

  /**
   * generate(..)
   * ------------
   * Generates summary tables for all use cases within a ucm4iot model.
   */
  @Override
  public void generate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context, final String folder) {
    final Function1<EObject, Boolean> _function = (EObject it) -> {
      return Boolean.valueOf((it instanceof ContextAwarenessEnabledUseCase));
    };
    final Function1<EObject, ContextAwarenessEnabledUseCase> _function_1 = (EObject it) -> {
      return ((ContextAwarenessEnabledUseCase) it);
    };
    final List<ContextAwarenessEnabledUseCase> useCases = IterableExtensions.<ContextAwarenessEnabledUseCase>toList(IterableExtensions.<EObject, ContextAwarenessEnabledUseCase>map(IterableExtensions.<EObject>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), _function), _function_1));
    final Function1<EObject, Boolean> _function_2 = (EObject it) -> {
      return Boolean.valueOf((it instanceof ContextItem));
    };
    final Function1<EObject, ContextItem> _function_3 = (EObject it) -> {
      return ((ContextItem) it);
    };
    final List<ContextItem> allContextItems = IterableExtensions.<ContextItem>toList(IterableExtensions.<EObject, ContextItem>map(IterableExtensions.<EObject>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), _function_2), _function_3));
    String table = this.createContextSummaryTable(allContextItems, useCases, resource);
    this.createFile(fsa, folder, this.createFileName("CaTraceTable ", ".txt"), table);
  }

  protected ArrayList<UseCase> getParents(final List<UseCase> useCases, final UseCase invokedUseCase) {
    ArrayList<UseCase> parentUseCases = CollectionLiterals.<UseCase>newArrayList();
    for (final UseCase useCase : useCases) {
      {
        final Predicate<InvocationStep> _function = (InvocationStep step) -> {
          UseCase _invokedUseCase = step.getInvokedUseCase();
          return (_invokedUseCase == invokedUseCase);
        };
        boolean hasInvokedUseCase = EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class).stream().anyMatch(_function);
        if (hasInvokedUseCase) {
          parentUseCases.add(useCase);
        }
      }
    }
    return parentUseCases;
  }

  /**
   * getPaths(..)
   * ------------
   * Gets the paths that lead to this use case being called.
   */
  protected ArrayList<List<UseCase>> getPaths(final List<UseCase> useCases, final UseCase ctx) {
    ArrayList<List<UseCase>> paths = CollectionLiterals.<List<UseCase>>newArrayList();
    ArrayList<UseCase> _arrayList = new ArrayList<UseCase>();
    HashSet<UseCase> _hashSet = new HashSet<UseCase>();
    this.getPathsHelper(useCases, ctx, paths, _arrayList, _hashSet);
    return paths;
  }

  private void getPathsHelper(final List<UseCase> useCases, final UseCase ctx, final List<List<UseCase>> paths, final List<UseCase> currentPath, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      return;
    }
    visited.add(ctx);
    currentPath.add(ctx);
    ArrayList<UseCase> parents = this.getParents(useCases, ctx);
    boolean _isEmpty = parents.isEmpty();
    if (_isEmpty) {
      ArrayList<UseCase> _arrayList = new ArrayList<UseCase>(currentPath);
      paths.add(_arrayList);
    } else {
      for (final UseCase parent : parents) {
        this.getPathsHelper(useCases, parent, paths, currentPath, visited);
      }
    }
    currentPath.remove(ctx);
    visited.remove(ctx);
  }

  /**
   * getInvocationPaths(..)
   * ----------------------
   * Gets the paths of the invoked use cases.
   */
  protected ArrayList<List<UseCase>> getInvocationPaths(final List<UseCase> useCases, final UseCase ctx) {
    ArrayList<List<UseCase>> paths = CollectionLiterals.<List<UseCase>>newArrayList();
    ArrayList<UseCase> _arrayList = new ArrayList<UseCase>();
    HashSet<UseCase> _hashSet = new HashSet<UseCase>();
    this.getInvocationPathsHelper(useCases, ctx, paths, _arrayList, _hashSet);
    return paths;
  }

  /**
   * getInvocationPathsHelper(..)
   * ----------------------------
   * Helper function that recursively searches for invoked paths from the passed use case.
   */
  private void getInvocationPathsHelper(final List<UseCase> useCases, final UseCase ctx, final List<List<UseCase>> paths, final List<UseCase> currentPath, final HashSet<UseCase> visited) {
    if (((ctx == null) || visited.contains(ctx))) {
      return;
    }
    visited.add(ctx);
    currentPath.add(ctx);
    ArrayList<UseCase> _arrayList = new ArrayList<UseCase>(currentPath);
    paths.add(_arrayList);
    List<UseCase> children = this.getChildren(ctx);
    for (final UseCase child : children) {
      this.getInvocationPathsHelper(useCases, child, paths, currentPath, visited);
    }
    currentPath.remove(ctx);
    visited.remove(ctx);
  }

  protected List<UseCase> getChildren(final UseCase useCase) {
    final Function<InvocationStep, UseCase> _function = (InvocationStep step) -> {
      return step.getInvokedUseCase();
    };
    return EcoreUtil2.<InvocationStep>getAllContentsOfType(useCase, InvocationStep.class).stream().<UseCase>map(_function).collect(Collectors.<UseCase>toList());
  }

  /**
   * Joins the names of the UseCases in a single path with an arrow "->".
   * For example, if a path contains UseCases with names "UseSmartStore", "Shopping",
   * "PurchaseItem", and "IdentifyItem", the result will be:
   * 
   *   "UseSmartStore->Shopping->PurchaseItem->IdentifyItem"
   */
  public String joinPath(final List<UseCase> path) {
    if (((path == null) || path.isEmpty())) {
      return "";
    }
    final Function1<UseCase, String> _function = (UseCase it) -> {
      return it.getName();
    };
    return IterableExtensions.join(ListExtensions.<UseCase, String>map(ListExtensions.<UseCase>reverse(path), _function), "->");
  }

  public String joinString(final List<String> path) {
    if (((path == null) || path.isEmpty())) {
      return "";
    }
    final Function1<String, String> _function = (String it) -> {
      return it;
    };
    return IterableExtensions.join(ListExtensions.<String, String>map(path, _function), "->");
  }

  /**
   * Processes an ArrayList of ArrayLists of UseCase objects (paths) and returns
   * an ArrayList of String, where each string is a joined representation of a path.
   */
  public List<String> joinPaths(final ArrayList<List<UseCase>> paths) {
    final ArrayList<String> result = new ArrayList<String>();
    for (final List<UseCase> path : paths) {
      result.add(this.joinPath(path));
    }
    return result;
  }

  /**
   * Builds a table for context items with columns:
   *  (1) ID
   *  (2) Description
   *  (3) Source (Use Case)
   *  (4) Path
   *  (5) CA-enabled
   * 
   * The table widths are computed dynamically to fit the largest text in each column.
   */
  protected String createContextSummaryTable(final List<ContextItem> contextItems, final List<ContextAwarenessEnabledUseCase> contextUseCases, final Resource resource) {
    final Function1<EObject, Boolean> _function = (EObject it) -> {
      return Boolean.valueOf((it instanceof UseCase));
    };
    final Function1<EObject, UseCase> _function_1 = (EObject it) -> {
      return ((UseCase) it);
    };
    final List<UseCase> allUseCases = IterableExtensions.<UseCase>toList(IterableExtensions.<EObject, UseCase>map(IterableExtensions.<EObject>filter(IteratorExtensions.<EObject>toIterable(resource.getAllContents()), _function), _function_1));
    ArrayList<ContextAwarenessTraceTableGenerator.ContextIdRecord> records = CollectionLiterals.<ContextAwarenessTraceTableGenerator.ContextIdRecord>newArrayList();
    for (final ContextItem item : contextItems) {
      {
        UseCase usecase = this.findUseCaseNameByContextItemId(allUseCases, item.getId());
        String _elvis = null;
        String _name = usecase.getName();
        if (_name != null) {
          _elvis = _name;
        } else {
          _elvis = "";
        }
        final String usecaseName = _elvis;
        String caEnabeldUseCase = this.findCaEnableUseCase(item, contextUseCases);
        ArrayList<List<UseCase>> paths = this.getPaths(allUseCases, usecase);
        final String path = this.joinString(this.joinPaths(paths));
        String _id = item.getId();
        String _description = item.getDescription();
        final ContextAwarenessTraceTableGenerator.ContextIdRecord record = new ContextAwarenessTraceTableGenerator.ContextIdRecord(_id, _description, usecaseName, path, caEnabeldUseCase);
        records.add(record);
      }
    }
    final String tableString = this.createContextIdTable(records);
    InputOutput.<String>println(tableString);
    return tableString;
  }

  /**
   * Splits a cell's content into lines (using newline as delimiter).
   */
  public List<String> splitCell(final String cell) {
    if ((cell == null)) {
      return CollectionLiterals.<String>newArrayList();
    }
    return IterableExtensions.<String>toList(((Iterable<String>)Conversions.doWrapArray(cell.split("\\n"))));
  }

  /**
   * Builds a separator line based on the provided column widths.
   */
  public String buildSeparator(final List<Integer> colWidths) {
    final StringBuilder sb = new StringBuilder();
    for (final Integer width : colWidths) {
      sb.append("+").append("-".repeat(((width).intValue() + 2)));
    }
    sb.append("+");
    return sb.toString();
  }

  /**
   * Formats a row (which may contain multi-line cells) into a list of strings.
   * Each string represents one line of the printed row.
   */
  public List<String> formatRowMultiline(final List<String> row, final List<Integer> colWidths) {
    final Function1<String, List<String>> _function = (String it) -> {
      String _elvis = null;
      if (it != null) {
        _elvis = it;
      } else {
        _elvis = "";
      }
      return this.splitCell(_elvis);
    };
    final List<List<String>> cellsLines = IterableExtensions.<List<String>>toList(ListExtensions.<String, List<String>>map(row, _function));
    final Function1<List<String>, Integer> _function_1 = (List<String> it) -> {
      return Integer.valueOf(it.size());
    };
    final Integer maxHeight = IterableExtensions.<Integer>max(ListExtensions.<List<String>, Integer>map(cellsLines, _function_1));
    final ArrayList<String> linesList = CollectionLiterals.<String>newArrayList();
    ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, (maxHeight).intValue(), true);
    for (final Integer lineIndex : _doubleDotLessThan) {
      {
        String lineStr = "|";
        int _size = row.size();
        ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(0, _size, true);
        for (final Integer i : _doubleDotLessThan_1) {
          {
            final List<String> cellLines = cellsLines.get((i).intValue());
            String _xifexpression = null;
            int _size_1 = cellLines.size();
            boolean _lessThan = ((lineIndex).intValue() < _size_1);
            if (_lessThan) {
              _xifexpression = cellLines.get((lineIndex).intValue());
            } else {
              _xifexpression = "";
            }
            final String cellContent = _xifexpression;
            String _lineStr = lineStr;
            Integer _get = colWidths.get((i).intValue());
            String _plus = ("%-" + _get);
            String _plus_1 = (_plus + "s");
            String _format = String.format(_plus_1, cellContent);
            String _plus_2 = (" " + _format);
            String _plus_3 = (_plus_2 + " |");
            lineStr = (_lineStr + _plus_3);
          }
        }
        linesList.add(lineStr);
      }
    }
    return linesList;
  }

  /**
   * Creates a formatted table from a list of rows.
   * Each row is a List<String> (cells may contain newline characters).
   * The first row is assumed to be the header.
   */
  public String createTable(final List<List<String>> rows) {
    boolean _isEmpty = rows.isEmpty();
    if (_isEmpty) {
      return "";
    }
    final int colCount = rows.get(0).size();
    final ArrayList<Integer> colWidths = CollectionLiterals.<Integer>newArrayList();
    ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, colCount, true);
    for (final Integer i : _doubleDotLessThan) {
      colWidths.add(Integer.valueOf(0));
    }
    for (final List<String> row : rows) {
      ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(0, colCount, true);
      for (final Integer i_1 : _doubleDotLessThan_1) {
        {
          String _elvis = null;
          String _get = row.get((i_1).intValue());
          if (_get != null) {
            _elvis = _get;
          } else {
            _elvis = "";
          }
          final String cell = _elvis;
          final List<String> cellLines = this.splitCell(cell);
          Integer _xifexpression = null;
          boolean _isEmpty_1 = cellLines.isEmpty();
          if (_isEmpty_1) {
            _xifexpression = Integer.valueOf(0);
          } else {
            final Function1<String, Integer> _function = (String it) -> {
              return Integer.valueOf(it.length());
            };
            _xifexpression = IterableExtensions.<Integer>max(ListExtensions.<String, Integer>map(cellLines, _function));
          }
          final Integer maxLineLength = _xifexpression;
          Integer _get_1 = colWidths.get((i_1).intValue());
          boolean _greaterThan = (maxLineLength.compareTo(_get_1) > 0);
          if (_greaterThan) {
            colWidths.set((i_1).intValue(), maxLineLength);
          }
        }
      }
    }
    final String separator = this.buildSeparator(colWidths);
    final StringBuilder sb = new StringBuilder();
    sb.append(separator).append("\n");
    final List<String> headerLines = this.formatRowMultiline(rows.get(0), colWidths);
    for (final String line : headerLines) {
      sb.append(line).append("\n");
    }
    sb.append(separator).append("\n");
    List<List<String>> _subList = rows.subList(1, rows.size());
    for (final List<String> row_1 : _subList) {
      {
        final List<String> rowLines = this.formatRowMultiline(row_1, colWidths);
        for (final String line_1 : rowLines) {
          sb.append(line_1).append("\n");
        }
        sb.append(separator).append("\n");
      }
    }
    return sb.toString();
  }

  /**
   * Creates a table string from a list of ContextIdRecord.
   */
  public String createContextIdTable(final List<ContextAwarenessTraceTableGenerator.ContextIdRecord> records) {
    final List<List<String>> allRows = CollectionLiterals.<List<String>>newArrayList(
      CollectionLiterals.<String>newArrayList("ID", "Description", "Source (Use Case)", "Path", "CA-enabled"));
    for (final ContextAwarenessTraceTableGenerator.ContextIdRecord record : records) {
      allRows.add(
        CollectionLiterals.<String>newArrayList(
          record.id, 
          record.description, 
          record.source, 
          record.path, 
          record.caEnabled.toString()));
    }
    return this.createTable(allRows);
  }

  public UseCase findUseCaseNameByContextItemId(final List<UseCase> allUseCases, final String id) {
    for (final UseCase useCase : allUseCases) {
      {
        final ContextAwareness contextAwareness = useCase.getContextAwareness();
        if ((contextAwareness != null)) {
          EList<ContextItem> _contextItems = contextAwareness.getContextItems();
          for (final ContextItem contextItem : _contextItems) {
            String _id = contextItem.getId();
            boolean _equals = Objects.equals(_id, id);
            if (_equals) {
              return useCase;
            }
          }
        }
      }
    }
    return null;
  }

  public String findCaEnableUseCase(final ContextItem item, final List<ContextAwarenessEnabledUseCase> cases) {
    for (final ContextAwarenessEnabledUseCase ca : cases) {
      boolean _contains = ca.getContext().contains(item.getId());
      if (_contains) {
        return ca.getName();
      }
    }
    return "";
  }

  /**
   * Creates a printf-style format string for each column
   * (left-justified by the computed width).
   */
  public String createDynamicTableFormat(final List<Integer> colWidths) {
    final Function1<Integer, String> _function = (Integer w) -> {
      return (("%-" + w) + "s");
    };
    return IterableExtensions.join(ListExtensions.<Integer, String>map(colWidths, _function), " | ");
  }

  /**
   * Builds a horizontal separator line like:
   *  "-------+-----------------+-------" etc.
   * based on the computed column widths.
   */
  public String buildSeparatorLine(final List<Integer> colWidths) {
    final Function1<Integer, String> _function = (Integer w) -> {
      return "-".repeat((w).intValue());
    };
    final List<String> segments = ListExtensions.<Integer, String>map(colWidths, _function);
    return IterableExtensions.join(segments, "-+-");
  }

  /**
   * Prints one row by applying the format string to each column's text.
   */
  public String printRow(final List<String> rowValues, final String format) {
    return String.format(format, rowValues.toArray());
  }
}
