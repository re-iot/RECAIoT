package transformation;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Parser for UCM4IoT model files (.ucmiot format)
 * Pure Java implementation - no Xtend dependencies
 */
public class UCM4IoTParser {
    
    /**
     * Parse UCM4IoT file and create model objects
     */
    public UCM4IoTModel parseFile(String filePath) {
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                throw new RuntimeException("UCM4IoT file not found: " + filePath);
            }
            
            UCM4IoTModel model = new UCM4IoTModel();
            model.name = file.getName().replace(".ucmiot", "");
            
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            List<String> lines = new ArrayList<>();
            
            // Read all lines
            String line = bufferedReader.readLine();
            while (line != null) {
                lines.add(line);
                line = bufferedReader.readLine();
            }
            bufferedReader.close();
            
            // Parse the content
            parseContent(lines, model);
            
            return model;
        } catch (Exception e) {
            throw new RuntimeException("Error parsing UCM4IoT file: " + e.getMessage(), e);
        }
    }
    
    /**
     * Parse the file content and extract use cases, actors, and context awareness
     */
    private void parseContent(List<String> lines, UCM4IoTModel model) {
        // First pass: Parse use cases
        int i = 0;
        while (i < lines.size()) {
            String line = lines.get(i).trim();
            
            if (line.startsWith("use case:")) {
                i = parseUseCase(lines, i, model);
            } else if (line.startsWith("CA-enabled use case:")) {
                i = parseCAEnabledUseCase(lines, i, model);
            } else {
                i++;
            }
        }
        
        // Second pass: Parse standalone context-awareness sections
        parseStandaloneContextAwareness(lines, model);
    }
    
    /**
     * Parse standalone context-awareness sections
     */
    private void parseStandaloneContextAwareness(List<String> lines, UCM4IoTModel model) {
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            
            if (line.startsWith("context-awareness:")) {
                i = parseContextAwarenessStandalone(lines, i + 1, model) - 1; // -1 because loop will increment
            }
        }
    }
    
    /**
     * Parse context awareness section standalone (without usecase association)
     */
    private int parseContextAwarenessStandalone(List<String> lines, int startIndex, UCM4IoTModel model) {
        int i = startIndex;
        
        while (i < lines.size()) {
            String line = lines.get(i).trim();
            
            if (line.isEmpty() || line.startsWith("use case:") || line.startsWith("CA-enabled use case:") ||
                line.startsWith("handler use case:")) {
                return i;
            }
            
            // Parse context item (e.g., CA001: "Description")
            if (line.matches("CA\\d+:.*")) {
                ContextItem contextItem = parseContextItem(line);
                if (contextItem != null) {
                    // Check if context item already exists and update it
                    ContextItem existing = findContextItem(model.contextItems, contextItem.id);
                    if (existing != null) {
                        // Update existing item with real description
                        existing.description = contextItem.description;
                        existing.name = contextItem.name;
                    } else {
                        // Add new context item
                        model.contextItems.add(contextItem);
                    }
                }
            }
            i++;
        }
        
        return i;
    }
    
    /**
     * Parse a regular use case
     */
    private int parseUseCase(List<String> lines, int startIndex, UCM4IoTModel model) {
        UseCase useCase = new UseCase();
        int i = startIndex;
        String line = lines.get(i);
        
        // Extract use case name
        useCase.name = line.substring("use case:".length()).trim();
        useCase.id = "UC_" + useCase.name.replaceAll("\\s+", "_");
        i++;
        
        // Parse use case details
        while (i < lines.size()) {
            String currentLine = lines.get(i).trim();
            
            if (currentLine.startsWith("intention:")) {
                useCase.description = extractQuotedValue(currentLine);
            } else if (currentLine.startsWith("primary actor:")) {
                String actorInfo = currentLine.substring("primary actor:".length()).trim();
                Actor actor = parseActor(actorInfo);
                if (actor != null && !actorExists(model.actors, actor.name)) {
                    model.actors.add(actor);
                }
            } else if (currentLine.startsWith("secondary actor:")) {
                String actorInfo = currentLine.substring("secondary actor:".length()).trim();
                parseMultipleActors(actorInfo, model);
            } else if (currentLine.startsWith("facilitator actor:")) {
                String actorInfo = currentLine.substring("facilitator actor:".length()).trim();
                parseMultipleActors(actorInfo, model);
            } else if (currentLine.startsWith("main success scenario:")) {
                i++;
                StringBuilder scenario = new StringBuilder();
                while (i < lines.size()) {
                    String scenarioLine = lines.get(i).trim();
                    if (scenarioLine.startsWith("use case ends in:") || 
                        scenarioLine.startsWith("extensions:") ||
                        scenarioLine.startsWith("use case:") || 
                        scenarioLine.startsWith("CA-enabled use case:") ||
                        scenarioLine.startsWith("handler use case:") ||
                        scenarioLine.startsWith("context-awareness:")) {
                        break;
                    }
                    scenario.append(scenarioLine).append("\n");
                    i++;
                }
                useCase.mainSuccessScenario = scenario.toString();
                i--; // Back up one since loop will increment
            } else if (currentLine.startsWith("context-awareness:")) {
                i = parseContextAwareness(lines, i + 1, useCase, model);
                model.useCases.add(useCase);
                return i;
            } else if (currentLine.startsWith("use case:") || currentLine.startsWith("CA-enabled use case:") || 
                      currentLine.startsWith("handler use case:")) {
                model.useCases.add(useCase);
                return i;
            } else if (currentLine.contains("use case ends in:")) {
                i++;
                if (useCase.getName().equals("IdentifyItem")) {
                    System.out.println("DEBUG: IdentifyItem ended, looking for context-awareness...");
                }
                // Look ahead for context-awareness section (skipping blank lines and extensions)
                int lookAhead = i;
                while (lookAhead < lines.size()) {
                    String nextLine = lines.get(lookAhead).trim();
                    if (useCase.getName().equals("IdentifyItem")) {
                        System.out.println("DEBUG: Line " + lookAhead + ": '" + nextLine + "'");
                    }
                    if (nextLine.isEmpty() || nextLine.startsWith("extensions:") || nextLine.startsWith("exception for") || 
                        nextLine.startsWith("alternative for") || nextLine.matches("\\d+[ab]?\\..*") || 
                        nextLine.matches(".*use case\\s+continues at step:.*") || nextLine.endsWith("#")) {
                        lookAhead++;
                        continue;
                    }
                    if (nextLine.startsWith("context-awareness:")) {
                        System.out.println("Found context-awareness section for use case: " + useCase.getName());
                        i = parseContextAwareness(lines, lookAhead + 1, useCase, model);
                        System.out.println("After parsing context-awareness, " + useCase.getName() + " has " + 
                            (useCase.getContextItems() != null ? useCase.getContextItems().size() : 0) + " context items");
                        model.useCases.add(useCase);
                        return i;
                    }
                    if (useCase.getName().equals("IdentifyItem")) {
                        System.out.println("DEBUG: Breaking on non-matching line: '" + nextLine + "'");
                    }
                    break; // Found non-empty, non-extension, non-context-awareness line
                }
                model.useCases.add(useCase);
                return i;
            }
            i++;
        }
        
        model.useCases.add(useCase);
        return i;
    }
    
    /**
     * Parse a CA-enabled use case
     */
    private int parseCAEnabledUseCase(List<String> lines, int startIndex, UCM4IoTModel model) {
        UseCase useCase = new UseCase();
        int i = startIndex;
        String line = lines.get(i);
        
        // Extract use case name
        useCase.name = line.substring("CA-enabled use case:".length()).trim();
        useCase.id = "CA_UC_" + useCase.name.replaceAll("\\s+", "_");
        i++;
        
        // Parse use case details including context
        while (i < lines.size()) {
            String currentLine = lines.get(i).trim();
            
            if (currentLine.startsWith("intention:")) {
                useCase.description = extractQuotedValue(currentLine);
            } else if (currentLine.startsWith("context:")) {
                String contextIds = currentLine.substring("context:".length()).trim();
                parseContextReferences(contextIds, useCase, model);
            } else if (currentLine.startsWith("primary actor:")) {
                String actorInfo = currentLine.substring("primary actor:".length()).trim();
                Actor actor = parseActor(actorInfo);
                if (actor != null && !actorExists(model.actors, actor.name)) {
                    model.actors.add(actor);
                }
            } else if (currentLine.startsWith("secondary actor:")) {
                String actorInfo = currentLine.substring("secondary actor:".length()).trim();
                parseMultipleActors(actorInfo, model);
            } else if (currentLine.startsWith("main success scenario:")) {
                i++;
                StringBuilder scenario = new StringBuilder();
                while (i < lines.size()) {
                    String scenarioLine = lines.get(i).trim();
                    if (scenarioLine.startsWith("use case ends in:") || 
                        scenarioLine.startsWith("extensions:") ||
                        scenarioLine.startsWith("use case:") || 
                        scenarioLine.startsWith("CA-enabled use case:") ||
                        scenarioLine.startsWith("handler use case:") ||
                        scenarioLine.contains("use case continues at step:")) {
                        break;
                    }
                    scenario.append(scenarioLine).append("\n");
                    i++;
                }
                useCase.mainSuccessScenario = scenario.toString();
                i--; // Back up one since loop will increment
            } else if (currentLine.contains("use case ends in:") || currentLine.contains("use case continues at step:")) {
                i++;
                // Look ahead for context-awareness section (skipping blank lines)
                int lookAhead = i;
                while (lookAhead < lines.size()) {
                    String nextLine = lines.get(lookAhead).trim();
                    if (nextLine.isEmpty()) {
                        lookAhead++;
                        continue;
                    }
                    if (nextLine.startsWith("context-awareness:")) {
                        i = parseContextAwareness(lines, lookAhead + 1, useCase, model);
                        model.useCases.add(useCase);
                        return i;
                    }
                    break; // Found non-empty, non-context-awareness line
                }
                model.useCases.add(useCase);
                return i;
            } else if (currentLine.startsWith("use case:") || currentLine.startsWith("CA-enabled use case:")) {
                model.useCases.add(useCase);
                return i;
            }
            i++;
        }
        
        model.useCases.add(useCase);
        return i;
    }
    
    /**
     * Parse context awareness section
     */
    private int parseContextAwareness(List<String> lines, int startIndex, UseCase useCase, UCM4IoTModel model) {
        int i = startIndex;
        
        while (i < lines.size()) {
            String line = lines.get(i).trim();
            
            if (line.isEmpty() || line.startsWith("use case:") || line.startsWith("CA-enabled use case:") ||
                line.startsWith("handler use case:")) {
                return i;
            }
            
            // Parse context item (e.g., CA001: "Description")
            if (line.matches("CA\\d+:.*")) {
                ContextItem contextItem = parseContextItem(line);
                if (contextItem != null) {
                    // Check if context item already exists and update it
                    ContextItem existing = findContextItem(model.contextItems, contextItem.id);
                    if (existing != null) {
                        // Update existing item with real description
                        existing.description = contextItem.description;
                        existing.name = contextItem.name;
                    } else {
                        // Add new context item
                        model.contextItems.add(contextItem);
                    }
                    useCase.contextItems.add(contextItem);
                }
            }
            i++;
        }
        
        return i;
    }
    
    /**
     * Parse context references in CA-enabled use cases
     */
    private void parseContextReferences(String contextIds, UseCase useCase, UCM4IoTModel model) {
        String[] ids = contextIds.split(",");
        for (String id : ids) {
            String trimmedId = id.trim();
            // Find existing context item or create placeholder
            ContextItem contextItem = findContextItem(model.contextItems, trimmedId);
            if (contextItem == null) {
                contextItem = new ContextItem();
                contextItem.id = trimmedId;
                contextItem.name = "Context " + trimmedId;
                contextItem.description = "Context awareness requirement " + trimmedId;
                contextItem.type = ContextType.COMPUTATIONAL;
                model.contextItems.add(contextItem);
            }
            useCase.contextItems.add(contextItem);
        }
    }
    
    /**
     * Parse a context item from a line like "CA001: \"Description\""
     */
    private ContextItem parseContextItem(String line) {
        Pattern pattern = Pattern.compile("(CA\\d+):\\s*\"(.*)\"");
        Matcher matcher = pattern.matcher(line);
        
        if (matcher.find()) {
            ContextItem contextItem = new ContextItem();
            contextItem.id = matcher.group(1);
            contextItem.name = "Context " + contextItem.id;
            contextItem.description = matcher.group(2);
            contextItem.type = ContextType.COMPUTATIONAL; // Default type
            return contextItem;
        }
        
        return null;
    }
    
    /**
     * Parse an actor from actor information
     */
    private Actor parseActor(String actorInfo) {
        if (actorInfo.equals("N/A") || actorInfo.equals("None")) {
            return null;
        }
        
        String[] parts = actorInfo.split("::");
        if (parts.length >= 2) {
            Actor actor = new Actor();
            String actorType = parts[0].trim();
            actor.name = parts[1].trim();
            actor.id = "A_" + actor.name.replaceAll("\\s+", "_");
            
            switch (actorType) {
                case "HUMAN": actor.type = ActorType.HUMAN; break;
                case "SOFTWARE": actor.type = ActorType.SOFTWARE; break;
                case "SENSOR": actor.type = ActorType.DEVICE; break;
                case "READER": actor.type = ActorType.DEVICE; break;
                case "PHYSICAL_ENTITY": actor.type = ActorType.PHYSICAL_ENTITY; break;
                default: actor.type = ActorType.DEVICE; break;
            }
            
            return actor;
        }
        
        return null;
    }
    
    /**
     * Parse multiple actors from a comma-separated list
     */
    private void parseMultipleActors(String actorInfo, UCM4IoTModel model) {
        String[] actors = actorInfo.split(",");
        for (String actorStr : actors) {
            Actor actor = parseActor(actorStr.trim());
            if (actor != null && !actorExists(model.actors, actor.name)) {
                model.actors.add(actor);
            }
        }
    }
    
    /**
     * Extract quoted value from a line
     */
    private String extractQuotedValue(String line) {
        int startQuote = line.indexOf("\"");
        int endQuote = line.lastIndexOf("\"");
        
        if (startQuote != -1 && endQuote != -1 && startQuote < endQuote) {
            return line.substring(startQuote + 1, endQuote);
        }
        
        return line.substring(line.indexOf(":") + 1).trim();
    }
    
    // Helper methods
    private boolean actorExists(List<Actor> actors, String name) {
        for (Actor actor : actors) {
            if (actor.name.equals(name)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean contextItemExists(List<ContextItem> items, String id) {
        for (ContextItem item : items) {
            if (item.id.equals(id)) {
                return true;
            }
        }
        return false;
    }
    
    private ContextItem findContextItem(List<ContextItem> items, String id) {
        for (ContextItem item : items) {
            if (item.id.equals(id)) {
                return item;
            }
        }
        return null;
    }
}


class UseCase {
   
    
    public String id;
    public String name;
    public String description;
    public String mainSuccessScenario; 
    public List<ContextItem> contextItems = new ArrayList<>();
    
    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getMainSuccessScenario() { return mainSuccessScenario; }
    public List<ContextItem> getContextItems() { return contextItems; }
}


// Model classes
class UCM4IoTModel {
    public String name;
    public List<UseCase> useCases = new ArrayList<>();
    public List<Actor> actors = new ArrayList<>();
    public List<ContextItem> contextItems = new ArrayList<>();
    
    public String getName() { return name; }
    public List<UseCase> getUseCases() { return useCases; }
    public List<Actor> getActors() { return actors; }
    public List<ContextItem> getContextItems() { return contextItems; }
}



class Actor {
    public String id;
    public String name;
    public ActorType type;
    
    public String getId() { return id; }
    public String getName() { return name; }
    public ActorType getType() { return type; }
}

enum ActorType {
    HUMAN, SOFTWARE, DEVICE, PHYSICAL_ENTITY
}

class ContextItem {
    public String id;
    public String name;
    public String description;
    public ContextType type;
    public List<UseCase> useCases = new ArrayList<>();
    
    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public ContextType getType() { return type; }
    public List<UseCase> getUseCases() { return useCases; }
}

enum ContextType {
    ENVIRONMENTAL, SOCIAL, COMPUTATIONAL, USER, TEMPORAL
}

// CARDML4IoT Model classes
class CARDML4IoTModel {
    public String name;
    public List<CA_Requirement> caRequirements = new ArrayList<>();
    public List<Device> devices = new ArrayList<>();
    public List<TraceLink> traceLinks = new ArrayList<>();
    public List<Dependency> dependencies = new ArrayList<>();
}

class CA_Requirement {
    public String id;
    public String description;
    public Device associatedDevice;
    
    public String getId() { return id; }
    public String getDescription() { return description; }
    public Device getAssociatedDevice() { return associatedDevice; }
}

class Device {
    public String id;
    public String name;
    public String type;
    public List<CA_Requirement> requirements = new ArrayList<>();
    
    public String getId() { return id; }
    public String getName() { return name; }
    public String getType() { return type; }
    public List<CA_Requirement> getRequirements() { return requirements; }
}

class TraceLink {
    public String id;
    public String sourceElement;
    public String targetElement;
    public String type;
    
    public String getId() { return id; }
    public String getSourceElement() { return sourceElement; }
    public String getTargetElement() { return targetElement; }
    public String getType() { return type; }
}

abstract class Dependency {
    public String id;
    public String name;
    public CA_Requirement source;
    public CA_Requirement target;
    
    public String getId() { return id; }
    public String getName() { return name; }
    public CA_Requirement getSource() { return source; }
    public CA_Requirement getTarget() { return target; }
    public abstract String getType();
}

class DataDependency extends Dependency {
    public String dataType;
    
    @Override
    public String getType() { return "DATA"; }
}

class ResourceDependency extends Dependency {
    public String resourceType;
    
    @Override
    public String getType() { return "RESOURCE"; }
}

class TemporalDependency extends Dependency {
    public String temporalConstraint;
    
    @Override
    public String getType() { return "TEMPORAL"; }
}