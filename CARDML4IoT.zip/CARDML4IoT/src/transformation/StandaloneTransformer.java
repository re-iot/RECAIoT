package transformation;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * Standalone Java version of UCM4IoTToCARDML4IoTTransformer
 * No Xtend/Xtext dependencies required
 */
public class StandaloneTransformer {
    
    // Maps to track associations for dependency analysis
    private Map<String, CA_Requirement> caRequirementsMap = new HashMap<>();
    private Map<String, Device> deviceMap = new HashMap<>();
    private Map<String, List<CA_Requirement>> useCaseToCARequirements = new HashMap<>();
    private Map<String, List<CA_Requirement>> deviceToCARequirements = new HashMap<>();
    private UCM4IoTModel ucmModel; // Reference to the UCM4IoT model for lookups
    
    /**
     * Transform UCM4IoT model to CARDML4IoT model
     */
    public CARDML4IoTModel transform(UCM4IoTModel ucmModel) {
        try {
            System.out.println("Starting UCM4IoT to CARDML4IoT transformation...");
            
            // Store reference to UCM model for later use
            this.ucmModel = ucmModel;
            
            // Create CARDML4IoT model
            CARDML4IoTModel cardmlModel = createCARDML4IoTModel();
            cardmlModel.name = ucmModel.getName();
            
            // 1. Transform ContextItems to CA_Requirements
            transformContextItemsToCARequirements(ucmModel, cardmlModel);
            
            // 2. Transform Actors to Devices
            transformActorsToDevices(ucmModel, cardmlModel);
            
            // 3. Associate devices with CA_Requirements
            associateDevicesWithCARequirements(cardmlModel);
            
            // 4. Create TraceLinks between use cases and context items
            createTraceLinks(ucmModel, cardmlModel);
            
           
         // 5. Create dependencies between CA_Requirements
            createDependencies(ucmModel, cardmlModel);
         
            
            System.out.println("Transformation completed!");
            return cardmlModel;
            
        } catch (Exception e) {
            System.out.println("Error during transformation: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Create empty CARDML4IoT model
     */
    private CARDML4IoTModel createCARDML4IoTModel() {
        CARDML4IoTModel model = new CARDML4IoTModel();
        model.name = "CARDML4IoT Model";
        model.caRequirements = new ArrayList<>();
        model.devices = new ArrayList<>();
        model.traceLinks = new ArrayList<>();
        model.dependencies = new ArrayList<>();
        return model;
    }
    
    /**
     * Transform ContextItems to CA_Requirements
     */
    private void transformContextItemsToCARequirements(UCM4IoTModel ucmModel, CARDML4IoTModel cardmlModel) {
        List<ContextItem> contextItems = ucmModel.getContextItems();
        
        for (ContextItem contextItem : contextItems) {
            CA_Requirement caReq = new CA_Requirement();
            caReq.id = contextItem.getId();
            caReq.description = contextItem.getDescription();
            cardmlModel.caRequirements.add(caReq);
            caRequirementsMap.put(contextItem.getId(), caReq);
        }
        
        System.out.println("Created " + contextItems.size() + " CA_Requirements");
    }
    
    /**
     * Transform Actors to Devices
     */
    private void transformActorsToDevices(UCM4IoTModel ucmModel, CARDML4IoTModel cardmlModel) {
        List<Actor> actors = ucmModel.getActors();
        
        for (Actor actor : actors) {
            Device device = new Device();
            device.id = actor.getId();
            device.name = actor.getName();
            device.type = actor.getType().toString();
            cardmlModel.devices.add(device);
            deviceMap.put(actor.getName(), device);
        }
        
        System.out.println("Created " + actors.size() + " Devices");
    }
    
    /**
     * Associate devices with CA_Requirements based on context descriptions
     */
    private void associateDevicesWithCARequirements(CARDML4IoTModel cardmlModel) {
        for (CA_Requirement caReq : cardmlModel.caRequirements) {
            List<Device> associatedDevices = findDevicesInDescription(caReq.getDescription(), cardmlModel.devices);
            
            for (Device device : associatedDevices) {
                caReq.associatedDevice = device;
                device.requirements.add(caReq);
                
                // Track for dependency analysis
                if (!deviceToCARequirements.containsKey(device.getName())) {
                    deviceToCARequirements.put(device.getName(), new ArrayList<>());
                }
                deviceToCARequirements.get(device.getName()).add(caReq);
            }
        }
        
        System.out.println("Associated devices with CA_Requirements");
    }
    
    /**
     * Create TraceLinks between use cases and context items
     */
    private void createTraceLinks(UCM4IoTModel ucmModel, CARDML4IoTModel cardmlModel) {
        List<UseCase> useCases = ucmModel.getUseCases();
        
        for (UseCase useCase : useCases) {
            if (useCase.getContextItems() != null && !useCase.getContextItems().isEmpty()) {
                List<CA_Requirement> caRequirementsInUseCase = new ArrayList<>();
                
                for (ContextItem contextItem : useCase.getContextItems()) {
                    TraceLink traceLink = new TraceLink();
                    traceLink.id = "TL_" + useCase.getId() + "_" + contextItem.getId();
                    traceLink.sourceElement = useCase.getName();
                    traceLink.targetElement = contextItem.getId();
                    traceLink.type = "UseCase-ContextItem";
                    cardmlModel.traceLinks.add(traceLink);
                    
                    // Track for dependency analysis
                    if (caRequirementsMap.containsKey(contextItem.getId())) {
                        caRequirementsInUseCase.add(caRequirementsMap.get(contextItem.getId()));
                    }
                }
                
                // Store use case to CA_Requirements mapping for dependency analysis
                useCaseToCARequirements.put(useCase.getName(), caRequirementsInUseCase);
            }
        }
        
        System.out.println("Created " + cardmlModel.traceLinks.size() + " TraceLinks");
    }
    
    /**
     * Create dependencies between CA_Requirements
     */
    private void createDependencies(UCM4IoTModel ucmModel, CARDML4IoTModel cardmlModel) {
        List<Dependency> dependencies = new ArrayList<>();
        int depId = 1;
        
        // 1. Data Dependencies: Multiple CA_Requirements in same use case
        for (Map.Entry<String, List<CA_Requirement>> entry : useCaseToCARequirements.entrySet()) {
            List<CA_Requirement> caReqs = entry.getValue();
            if (caReqs.size() > 1) {
                for (int i = 0; i < caReqs.size(); i++) {
                    for (int j = i + 1; j < caReqs.size(); j++) {
                        DataDependency dataDep = new DataDependency();
                        dataDep.id = "DD" + depId++;
                        dataDep.name = "Data dependency in " + entry.getKey();
                        dataDep.source = caReqs.get(i);
                        dataDep.target = caReqs.get(j);
                        dataDep.dataType = "Context data";
                        dependencies.add(dataDep);
                    }
                }
            }
        }
        
        // 2. Resource Dependencies: Multiple CA_Requirements share same device
        for (Map.Entry<String, List<CA_Requirement>> entry : deviceToCARequirements.entrySet()) {
            List<CA_Requirement> caReqs = entry.getValue();
            if (caReqs.size() > 1) {
                for (int i = 0; i < caReqs.size(); i++) {
                    for (int j = i + 1; j < caReqs.size(); j++) {
                        ResourceDependency resourceDep = new ResourceDependency();
                        resourceDep.id = "RD" + depId++;
                        resourceDep.name = "Resource dependency on " + entry.getKey();
                        resourceDep.source = caReqs.get(i);
                        resourceDep.target = caReqs.get(j);
                        resourceDep.resourceType = "Device resource";
                        dependencies.add(resourceDep);
                    }
                }
            }
        }
        
     // 3. Temporal Dependencies: CA_Requirements in sequential use case invocations
        createTemporalDependencies(ucmModel, dependencies, depId);
        
        
        // Add all dependencies to model
        cardmlModel.dependencies.addAll(dependencies);
        
        System.out.println("Created " + dependencies.size() + " Dependencies");
    }
    
    
    /**
     * Create temporal dependencies based on use case invocation order
     */
    private int createTemporalDependencies(UCM4IoTModel ucmModel, List<Dependency> dependencies, int depId) {
        System.out.println("=== Creating Temporal Dependencies ===");
        
        // Track created temporal dependencies to avoid duplicates
        java.util.Set<String> createdDependencies = new java.util.HashSet<>();
        
        // Parse each use case for invoked use cases in main success scenario
        for (UseCase useCase : ucmModel.getUseCases()) {
            System.out.println("Checking use case: " + useCase.getName());
            System.out.println("Main success scenario: " + useCase.getMainSuccessScenario());
            List<String> invokedUseCases = parseInvokedUseCasesInOrder(useCase);
            System.out.println("Invoked use cases: " + invokedUseCases);
            
            if (invokedUseCases.size() > 1) {
                System.out.println("Found " + invokedUseCases.size() + " invoked use cases, creating temporal dependencies...");
                // Create temporal dependencies between consecutive invoked use cases
                for (int i = 0; i < invokedUseCases.size() - 1; i++) {
                    String firstUseCase = invokedUseCases.get(i);
                    String secondUseCase = invokedUseCases.get(i + 1);
                    
                    // Find CA_Requirements for these use cases
                    List<CA_Requirement> firstCAReqs = getCARequirementsForUseCase(firstUseCase);
                    List<CA_Requirement> secondCAReqs = getCARequirementsForUseCase(secondUseCase);
                    
                    System.out.println("  " + firstUseCase + " has " + firstCAReqs.size() + " CA_Requirements");
                    System.out.println("  " + secondUseCase + " has " + secondCAReqs.size() + " CA_Requirements");
                    
                    // Create temporal dependencies: first must execute before second
                    for (CA_Requirement firstCA : firstCAReqs) {
                        for (CA_Requirement secondCA : secondCAReqs) {
                            // Create unique key to check for duplicates
                            String dependencyKey = firstCA.getId() + "->" + secondCA.getId();
                            
                            if (!createdDependencies.contains(dependencyKey)) {
                                TemporalDependency tempDep = new TemporalDependency();
                                tempDep.id = "TD" + depId++;
                                tempDep.name = "Temporal dependency: " + firstUseCase + " before " + secondUseCase;
                                tempDep.source = firstCA;
                                tempDep.target = secondCA;
                                tempDep.temporalConstraint = "BEFORE";
                                dependencies.add(tempDep);
                                createdDependencies.add(dependencyKey);
                                System.out.println("  Created temporal dependency: " + firstCA.getId() + " BEFORE " + secondCA.getId());
                            } else {
                                System.out.println("  Skipped duplicate temporal dependency: " + firstCA.getId() + " BEFORE " + secondCA.getId());
                            }
                        }
                    }
                }
            }
        }
        
        return depId;
    }

    /**
     * Parse main success scenario to extract invoked use cases in order
     */
    private List<String> parseInvokedUseCasesInOrder(UseCase useCase) {
        List<String> invokedUseCases = new ArrayList<>();
        
        // Note: You'll need to add mainSuccessScenario field to UseCase class
        // or parse it from the UCM4IoT file during parsing
        String scenario = useCase.mainSuccessScenario;
        if (scenario == null) return invokedUseCases;
        
        // Parse lines looking for [UseCaseName] pattern
        String[] lines = scenario.split("\n");
        for (String line : lines) {
            String trimmedLine = line.trim();
            
            // Look for pattern like: 1. [IdentifyItem] "description"
            if (trimmedLine.matches(".*\\[\\w+\\].*")) {
                // Extract use case name from brackets
                int startBracket = trimmedLine.indexOf('[');
                int endBracket = trimmedLine.indexOf(']');
                
                if (startBracket != -1 && endBracket != -1 && startBracket < endBracket) {
                    String invokedUseCase = trimmedLine.substring(startBracket + 1, endBracket);
                    invokedUseCases.add(invokedUseCase);
                }
            }
        }
        
        return invokedUseCases;
    }

    /**
     * Get CA_Requirements associated with a specific use case name
     */
    private List<CA_Requirement> getCARequirementsForUseCase(String useCaseName) {
        System.out.println("    Looking up CA_Requirements for: " + useCaseName);
        
        // First try the direct mapping from createTraceLinks
        List<CA_Requirement> caReqs = useCaseToCARequirements.get(useCaseName);
        System.out.println("    Direct mapping returned: " + (caReqs != null ? caReqs.size() : "null") + " CA_Requirements");
        if (caReqs != null && !caReqs.isEmpty()) {
            return caReqs;
        }
        
        // If not found, search for use cases that have context items directly
        List<CA_Requirement> result = new ArrayList<>();
        for (UseCase useCase : ucmModel.getUseCases()) {
            if (useCase.getName().equals(useCaseName)) {
                System.out.println("    Found use case: " + useCaseName + " with " + 
                    (useCase.getContextItems() != null ? useCase.getContextItems().size() : 0) + " context items");
                if (useCase.getContextItems() != null) {
                    for (ContextItem contextItem : useCase.getContextItems()) {
                        System.out.println("      Context item: " + contextItem.getId());
                        if (caRequirementsMap.containsKey(contextItem.getId())) {
                            result.add(caRequirementsMap.get(contextItem.getId()));
                            System.out.println("        Added CA_Requirement: " + contextItem.getId());
                        }
                    }
                }
            }
        }
        
        return result;
    }
    
    
    /**
     * Find devices mentioned in CA_Requirements description
     */
    private List<Device> findDevicesInDescription(String description, List<Device> devices) {
        List<Device> associatedDevices = new ArrayList<>();
        
        for (Device device : devices) {
            // Check if device name appears in the description
            if (description.toLowerCase().contains(device.getName().toLowerCase())) {
                associatedDevices.add(device);
            }
        }
        
        return associatedDevices;
    }
}