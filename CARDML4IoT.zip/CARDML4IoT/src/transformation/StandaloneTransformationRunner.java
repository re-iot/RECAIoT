package transformation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;

/**
 * Standalone Java version of TransformationRunner
 * No Xtend/Xtext dependencies required
 */
public class StandaloneTransformationRunner {
    
    /**
     * Main method to run the transformation
     */
    public static void main(String[] args) {
        StandaloneTransformationRunner runner = new StandaloneTransformationRunner();
        runner.runTransformation();
    }
    
    /**
     * Execute the complete transformation with real model files
     */
    public void runTransformation() {
        try {
            System.out.println("=== UCM4IoT to CARDML4IoT Transformation ===");
            
            // 1. Find all UCM4IoT model files in model folder
            String[] modelPaths = findAllUCMModelFiles();
            if (modelPaths == null || modelPaths.length == 0) {
                System.out.println("✗ No .ucmiot files found in model/ folder");
                return;
            }
            
            System.out.println("ℹ Found " + modelPaths.length + " .ucmiot file(s) to transform");
            
            // 2. Transform each model file
            for (int i = 0; i < modelPaths.length; i++) {
                String modelPath = modelPaths[i];
                System.out.println("\n" + "=".repeat(50));
                System.out.println("Processing file " + (i + 1) + "/" + modelPaths.length + ": " + modelPath);
                System.out.println("=".repeat(50));
                
                transformSingleModel(modelPath);
            }
            
            System.out.println("\n" + "=".repeat(50));
            System.out.println("✓ All transformations completed successfully!");
            System.out.println("✓ Results saved to output/ folder");
            System.out.println("=".repeat(50));
            
        } catch (Exception e) {
            System.out.println("✗ Error during transformation: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Transform a single model file
     */
    private void transformSingleModel(String modelPath) {
        try {
            // Load UCM4IoT model
            UCM4IoTModel ucmModel = loadUCM4IoTModel(modelPath);
            System.out.println("✓ UCM4IoT model loaded from " + modelPath);
            printUCMModelInfo(ucmModel);
            
            // Run transformation
            StandaloneTransformer transformer = new StandaloneTransformer();
            CARDML4IoTModel cardmlModel = transformer.transform(ucmModel);
            
            if (cardmlModel == null) {
                System.out.println("✗ Transformation failed for " + modelPath);
                return;
            }
            
            System.out.println("✓ Transformation completed successfully!");
            
            // Save results
            saveResults(cardmlModel);
            
            // Print results
            printDetailedResults(cardmlModel);
            
        } catch (Exception e) {
            System.out.println("✗ Error transforming " + modelPath + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Find all .ucmiot files in the model folder
     */
    private String[] findAllUCMModelFiles() {
        File modelDir = new File("model");
        
        if (!modelDir.exists() || !modelDir.isDirectory()) {
            System.out.println("✗ Model directory 'model/' not found");
            return null;
        }
        
        File[] files = modelDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".ucmiot"));
        
        if (files == null || files.length == 0) {
            System.out.println("✗ No .ucmiot files found in model/ directory");
            return null;
        }
        
        // Convert to relative paths
        String[] modelPaths = new String[files.length];
        for (int i = 0; i < files.length; i++) {
            modelPaths[i] = "model/" + files[i].getName();
        }
        
        return modelPaths;
    }
    
    /**
     * Load UCM4IoT model from file
     */
    public UCM4IoTModel loadUCM4IoTModel(String relativePath) {
        String projectRoot = System.getProperty("user.dir");
        String filePath = projectRoot + "/" + relativePath;
        
        System.out.println("Loading UCM4IoT model from: " + filePath);
        
        UCM4IoTParser parser = new UCM4IoTParser();
        return parser.parseFile(filePath);
    }
    
    /**
     * Save transformation results to output folder
     */
    public void saveResults(CARDML4IoTModel model) {
        try {
            // Create output directory if it doesn't exist
            File outputDir = new File("output");
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }
            
            // Generate file names based on model name
            String modelName = model.name != null ? model.name : "UnknownModel";
            String jsonFileName = "output/" + modelName + "_CARDML4IoT.json";
            String reportFileName = "output/" + modelName + "_transformation_report.txt";
            
            // Save CARDML4IoT model as JSON
            saveModelAsJSON(model, jsonFileName);
            
            // Save transformation report
            saveTransformationReport(model, reportFileName);
            
            System.out.println("✓ Results saved to output folder");
            System.out.println("- CARDML4IoT model: " + jsonFileName);
            System.out.println("- Transformation report: " + reportFileName);
            
        } catch (Exception e) {
            System.out.println("✗ Error saving results: " + e.getMessage());
        }
    }
    
    /**
     * Save CARDML4IoT model as JSON format
     */
    public void saveModelAsJSON(CARDML4IoTModel model, String filePath) throws Exception {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
        
        writer.write("{\n");
        writer.write("  \"name\": \"" + model.name + "\",\n");
        writer.write("  \"ca_requirements\": [\n");
        
        // Write CA Requirements
        for (int i = 0; i < model.caRequirements.size(); i++) {
            CA_Requirement caReq = model.caRequirements.get(i);
            writer.write("    {\n");
            writer.write("      \"id\": \"" + caReq.getId() + "\",\n");
            writer.write("      \"description\": \"" + caReq.getDescription() + "\"\n");
            writer.write("    }");
            if (i < model.caRequirements.size() - 1) writer.write(",");
            writer.write("\n");
        }
        
        writer.write("  ],\n");
        writer.write("  \"devices\": [\n");
        
        // Write Devices
        for (int i = 0; i < model.devices.size(); i++) {
            Device device = model.devices.get(i);
            writer.write("    {\n");
            writer.write("      \"id\": \"" + device.getId() + "\",\n");
            writer.write("      \"name\": \"" + device.getName() + "\",\n");
            writer.write("      \"type\": \"" + device.getType() + "\"\n");
            writer.write("    }");
            if (i < model.devices.size() - 1) writer.write(",");
            writer.write("\n");
        }
        
        writer.write("  ],\n");
        writer.write("  \"trace_links\": [\n");
        
        // Write Trace Links
        for (int i = 0; i < model.traceLinks.size(); i++) {
            TraceLink traceLink = model.traceLinks.get(i);
            writer.write("    {\n");
            writer.write("      \"id\": \"" + traceLink.getId() + "\",\n");
            writer.write("      \"source\": \"" + traceLink.getSourceElement() + "\",\n");
            writer.write("      \"target\": \"" + traceLink.getTargetElement() + "\",\n");
            writer.write("      \"type\": \"" + traceLink.getType() + "\"\n");
            writer.write("    }");
            if (i < model.traceLinks.size() - 1) writer.write(",");
            writer.write("\n");
        }
        
        writer.write("  ],\n");
        writer.write("  \"dependencies\": [\n");
        
        // Write Dependencies
        for (int i = 0; i < model.dependencies.size(); i++) {
            Dependency dep = model.dependencies.get(i);
            writer.write("    {\n");
            writer.write("      \"id\": \"" + dep.getId() + "\",\n");
            writer.write("      \"source\": \"" + dep.getSource().getId() + "\",\n");
            writer.write("      \"target\": \"" + dep.getTarget().getId() + "\",\n");
            String type = (dep instanceof DataDependency) ? "DATA" : 
                         (dep instanceof ResourceDependency) ? "RESOURCE" : "TEMPORAL";
            writer.write("      \"type\": \"" + type + "\"\n");
            writer.write("    }");
            if (i < model.dependencies.size() - 1) writer.write(",");
            writer.write("\n");
        }
        
        writer.write("  ]\n");
        writer.write("}\n");
        
        writer.close();
    }
    
    /**
     * Save transformation report as text
     */
    public void saveTransformationReport(CARDML4IoTModel model, String filePath) throws Exception {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
        
        writer.write("UCM4IoT to CARDML4IoT Transformation Report\n");
        writer.write("==========================================\n\n");
        
        writer.write("Model: " + model.name + "\n");
        writer.write("Generated on: " + new Date() + "\n\n");
        
        writer.write("Transformation Summary:\n");
        writer.write("- CA Requirements: " + model.caRequirements.size() + "\n");
        writer.write("- Devices: " + model.devices.size() + "\n");
        writer.write("- Trace Links: " + model.traceLinks.size() + "\n");
        writer.write("- Dependencies: " + model.dependencies.size() + "\n\n");
        
        writer.write("CA Requirements:\n");
        writer.write("================\n");
        for (CA_Requirement caReq : model.caRequirements) {
            writer.write("- " + caReq.getId() + ": " + caReq.getDescription() + "\n");
        }
        
        writer.write("\nDevices:\n");
        writer.write("========\n");
        for (Device device : model.devices) {
            writer.write("- " + device.getName() + " (" + device.getType() + ")\n");
        }
        
        writer.write("\nTrace Links:\n");
        writer.write("============\n");
        for (TraceLink traceLink : model.traceLinks) {
            writer.write("- " + traceLink.getSourceElement() + " → " + traceLink.getTargetElement() + "\n");
        }
        
        writer.write("\nDependencies:\n");
        writer.write("=============\n");
        for (Dependency dep : model.dependencies) {
            String type = (dep instanceof DataDependency) ? "DATA" : 
                         (dep instanceof ResourceDependency) ? "RESOURCE" : "TEMPORAL";
            writer.write("- " + type + ": " + dep.getSource().getId() + " → " + dep.getTarget().getId() + "\n");
        }
        
        writer.close();
    }
    
    /**
     * Print information about the UCM4IoT model
     */
    public void printUCMModelInfo(UCM4IoTModel model) {
        System.out.println("\n--- UCM4IoT Model Information ---");
        System.out.println("Model Name: " + model.getName());
        System.out.println("Use Cases: " + model.getUseCases().size());
        System.out.println("Actors: " + model.getActors().size());
        System.out.println("Context Items: " + model.getContextItems().size());
        System.out.println();
    }
    
    /**
     * Print detailed transformation results
     */
    public void printDetailedResults(CARDML4IoTModel model) {
        System.out.println("\n=== Transformation Results ===");
        
        if (model == null) {
            System.out.println("No model generated");
            return;
        }
        
        System.out.println("Generated CARDML4IoT Model:");
        System.out.println("  • CA_Requirements: " + (model.caRequirements != null ? model.caRequirements.size() : 0));
        System.out.println("  • Devices: " + (model.devices != null ? model.devices.size() : 0));
        System.out.println("  • TraceLinks: " + (model.traceLinks != null ? model.traceLinks.size() : 0));
        System.out.println("  • Dependencies: " + (model.dependencies != null ? model.dependencies.size() : 0));
        
        // Print detailed content
        printModelDetails(model);
    }
    
    /**
     * Print detailed model content
     */
    public void printModelDetails(CARDML4IoTModel model) {
        System.out.println("\n--- Detailed Content ---");
        
        if (model.caRequirements != null && !model.caRequirements.isEmpty()) {
            System.out.println("\nCA_Requirements:");
            for (CA_Requirement caReq : model.caRequirements) {
                System.out.println("  " + caReq.getId() + ": " + caReq.getDescription());
                if (caReq.getAssociatedDevice() != null) {
                    System.out.println("    Associated device: " + caReq.getAssociatedDevice().getName());
                }
            }
        }
        
        if (model.devices != null && !model.devices.isEmpty()) {
            System.out.println("\nDevices:");
            for (Device device : model.devices) {
                System.out.println("  " + device.getName() + " (" + device.getType() + ")");
            }
        }
        
        if (model.traceLinks != null && !model.traceLinks.isEmpty()) {
            System.out.println("\nTraceLinks:");
            for (TraceLink traceLink : model.traceLinks) {
                System.out.println("  " + traceLink.getSourceElement() + " → " + traceLink.getTargetElement());
            }
        }
        
        if (model.dependencies != null && !model.dependencies.isEmpty()) {
            System.out.println("\nDependencies:");
            for (Dependency dep : model.dependencies) {
                String type = (dep instanceof DataDependency) ? "DATA" : 
                             (dep instanceof ResourceDependency) ? "RESOURCE" : "TEMPORAL";
                System.out.println("  " + type + ": " + dep.getSource().getId() + " → " + dep.getTarget().getId());
            }
        }
        
    }
}