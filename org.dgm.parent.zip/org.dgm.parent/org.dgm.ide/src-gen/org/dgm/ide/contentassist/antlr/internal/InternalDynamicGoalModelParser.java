package org.dgm.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.dgm.services.DynamicGoalModelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDynamicGoalModelParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'SENSOR'", "'TEMPORAL'", "'IDENTITY'", "'SPATIAL'", "'DERIVED'", "'ROLE'", "'CATALOG'", "'WITHIN'", "'NOT_WITHIN'", "'HELD_FOR'", "'REPEATED_WITHIN'", "'='", "'!='", "'>'", "'<'", "'REQUEST_MORE_EVIDENCE'", "'DEFAULT_NO_COMMIT'", "'NOTIFY_OPERATOR'", "'NORMAL'", "'EMERGENCY'", "'MAINTENANCE'", "'ENERGY_SAVING'", "'DGMSpecification'", "'{'", "'}'", "'description'", "'operationalMode'", "'DynamicGoal'", "'title'", "'useCaseRef'", "'precedence'", "'escalation'", "'ObservableAction'", "'signature'", "'trigger'", "'scopeStart'", "'scopeEnd'", "'Evidence'", "'type'", "'source'", "'predicate'", "'derivedFrom'", "'('", "')'", "'GoalHypothesis'", "'intention'", "'condition'", "'||'", "'&&'", "'NOT'", "','", "'Precedence'", "'justification'", "'ResponseBinding'", "'action'", "'ucmStep'", "'noCartWrite'", "'Escalation'", "'strategy'", "'additionalEvidence'", "'defaultResponse'", "'timeout'", "'noSideEffect'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalDynamicGoalModelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDynamicGoalModelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDynamicGoalModelParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDynamicGoalModel.g"; }


    	private DynamicGoalModelGrammarAccess grammarAccess;

    	public void setGrammarAccess(DynamicGoalModelGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleDGMSpecification"
    // InternalDynamicGoalModel.g:53:1: entryRuleDGMSpecification : ruleDGMSpecification EOF ;
    public final void entryRuleDGMSpecification() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:54:1: ( ruleDGMSpecification EOF )
            // InternalDynamicGoalModel.g:55:1: ruleDGMSpecification EOF
            {
             before(grammarAccess.getDGMSpecificationRule()); 
            pushFollow(FOLLOW_1);
            ruleDGMSpecification();

            state._fsp--;

             after(grammarAccess.getDGMSpecificationRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDGMSpecification"


    // $ANTLR start "ruleDGMSpecification"
    // InternalDynamicGoalModel.g:62:1: ruleDGMSpecification : ( ( rule__DGMSpecification__Group__0 ) ) ;
    public final void ruleDGMSpecification() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:66:2: ( ( ( rule__DGMSpecification__Group__0 ) ) )
            // InternalDynamicGoalModel.g:67:2: ( ( rule__DGMSpecification__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:67:2: ( ( rule__DGMSpecification__Group__0 ) )
            // InternalDynamicGoalModel.g:68:3: ( rule__DGMSpecification__Group__0 )
            {
             before(grammarAccess.getDGMSpecificationAccess().getGroup()); 
            // InternalDynamicGoalModel.g:69:3: ( rule__DGMSpecification__Group__0 )
            // InternalDynamicGoalModel.g:69:4: rule__DGMSpecification__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDGMSpecificationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDGMSpecification"


    // $ANTLR start "entryRuleDynamicGoal"
    // InternalDynamicGoalModel.g:78:1: entryRuleDynamicGoal : ruleDynamicGoal EOF ;
    public final void entryRuleDynamicGoal() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:79:1: ( ruleDynamicGoal EOF )
            // InternalDynamicGoalModel.g:80:1: ruleDynamicGoal EOF
            {
             before(grammarAccess.getDynamicGoalRule()); 
            pushFollow(FOLLOW_1);
            ruleDynamicGoal();

            state._fsp--;

             after(grammarAccess.getDynamicGoalRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDynamicGoal"


    // $ANTLR start "ruleDynamicGoal"
    // InternalDynamicGoalModel.g:87:1: ruleDynamicGoal : ( ( rule__DynamicGoal__Group__0 ) ) ;
    public final void ruleDynamicGoal() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:91:2: ( ( ( rule__DynamicGoal__Group__0 ) ) )
            // InternalDynamicGoalModel.g:92:2: ( ( rule__DynamicGoal__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:92:2: ( ( rule__DynamicGoal__Group__0 ) )
            // InternalDynamicGoalModel.g:93:3: ( rule__DynamicGoal__Group__0 )
            {
             before(grammarAccess.getDynamicGoalAccess().getGroup()); 
            // InternalDynamicGoalModel.g:94:3: ( rule__DynamicGoal__Group__0 )
            // InternalDynamicGoalModel.g:94:4: rule__DynamicGoal__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDynamicGoal"


    // $ANTLR start "entryRuleObservableAction"
    // InternalDynamicGoalModel.g:103:1: entryRuleObservableAction : ruleObservableAction EOF ;
    public final void entryRuleObservableAction() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:104:1: ( ruleObservableAction EOF )
            // InternalDynamicGoalModel.g:105:1: ruleObservableAction EOF
            {
             before(grammarAccess.getObservableActionRule()); 
            pushFollow(FOLLOW_1);
            ruleObservableAction();

            state._fsp--;

             after(grammarAccess.getObservableActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleObservableAction"


    // $ANTLR start "ruleObservableAction"
    // InternalDynamicGoalModel.g:112:1: ruleObservableAction : ( ( rule__ObservableAction__Group__0 ) ) ;
    public final void ruleObservableAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:116:2: ( ( ( rule__ObservableAction__Group__0 ) ) )
            // InternalDynamicGoalModel.g:117:2: ( ( rule__ObservableAction__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:117:2: ( ( rule__ObservableAction__Group__0 ) )
            // InternalDynamicGoalModel.g:118:3: ( rule__ObservableAction__Group__0 )
            {
             before(grammarAccess.getObservableActionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:119:3: ( rule__ObservableAction__Group__0 )
            // InternalDynamicGoalModel.g:119:4: rule__ObservableAction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getObservableActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObservableAction"


    // $ANTLR start "entryRuleEvidence"
    // InternalDynamicGoalModel.g:128:1: entryRuleEvidence : ruleEvidence EOF ;
    public final void entryRuleEvidence() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:129:1: ( ruleEvidence EOF )
            // InternalDynamicGoalModel.g:130:1: ruleEvidence EOF
            {
             before(grammarAccess.getEvidenceRule()); 
            pushFollow(FOLLOW_1);
            ruleEvidence();

            state._fsp--;

             after(grammarAccess.getEvidenceRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEvidence"


    // $ANTLR start "ruleEvidence"
    // InternalDynamicGoalModel.g:137:1: ruleEvidence : ( ( rule__Evidence__Group__0 ) ) ;
    public final void ruleEvidence() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:141:2: ( ( ( rule__Evidence__Group__0 ) ) )
            // InternalDynamicGoalModel.g:142:2: ( ( rule__Evidence__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:142:2: ( ( rule__Evidence__Group__0 ) )
            // InternalDynamicGoalModel.g:143:3: ( rule__Evidence__Group__0 )
            {
             before(grammarAccess.getEvidenceAccess().getGroup()); 
            // InternalDynamicGoalModel.g:144:3: ( rule__Evidence__Group__0 )
            // InternalDynamicGoalModel.g:144:4: rule__Evidence__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvidence"


    // $ANTLR start "entryRuleDerivedExpression"
    // InternalDynamicGoalModel.g:153:1: entryRuleDerivedExpression : ruleDerivedExpression EOF ;
    public final void entryRuleDerivedExpression() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:154:1: ( ruleDerivedExpression EOF )
            // InternalDynamicGoalModel.g:155:1: ruleDerivedExpression EOF
            {
             before(grammarAccess.getDerivedExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleDerivedExpression();

            state._fsp--;

             after(grammarAccess.getDerivedExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDerivedExpression"


    // $ANTLR start "ruleDerivedExpression"
    // InternalDynamicGoalModel.g:162:1: ruleDerivedExpression : ( ( rule__DerivedExpression__Group__0 ) ) ;
    public final void ruleDerivedExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:166:2: ( ( ( rule__DerivedExpression__Group__0 ) ) )
            // InternalDynamicGoalModel.g:167:2: ( ( rule__DerivedExpression__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:167:2: ( ( rule__DerivedExpression__Group__0 ) )
            // InternalDynamicGoalModel.g:168:3: ( rule__DerivedExpression__Group__0 )
            {
             before(grammarAccess.getDerivedExpressionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:169:3: ( rule__DerivedExpression__Group__0 )
            // InternalDynamicGoalModel.g:169:4: rule__DerivedExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DerivedExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDerivedExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDerivedExpression"


    // $ANTLR start "entryRuleGoalHypothesis"
    // InternalDynamicGoalModel.g:178:1: entryRuleGoalHypothesis : ruleGoalHypothesis EOF ;
    public final void entryRuleGoalHypothesis() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:179:1: ( ruleGoalHypothesis EOF )
            // InternalDynamicGoalModel.g:180:1: ruleGoalHypothesis EOF
            {
             before(grammarAccess.getGoalHypothesisRule()); 
            pushFollow(FOLLOW_1);
            ruleGoalHypothesis();

            state._fsp--;

             after(grammarAccess.getGoalHypothesisRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGoalHypothesis"


    // $ANTLR start "ruleGoalHypothesis"
    // InternalDynamicGoalModel.g:187:1: ruleGoalHypothesis : ( ( rule__GoalHypothesis__Group__0 ) ) ;
    public final void ruleGoalHypothesis() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:191:2: ( ( ( rule__GoalHypothesis__Group__0 ) ) )
            // InternalDynamicGoalModel.g:192:2: ( ( rule__GoalHypothesis__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:192:2: ( ( rule__GoalHypothesis__Group__0 ) )
            // InternalDynamicGoalModel.g:193:3: ( rule__GoalHypothesis__Group__0 )
            {
             before(grammarAccess.getGoalHypothesisAccess().getGroup()); 
            // InternalDynamicGoalModel.g:194:3: ( rule__GoalHypothesis__Group__0 )
            // InternalDynamicGoalModel.g:194:4: rule__GoalHypothesis__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGoalHypothesisAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGoalHypothesis"


    // $ANTLR start "entryRuleConditionExpression"
    // InternalDynamicGoalModel.g:203:1: entryRuleConditionExpression : ruleConditionExpression EOF ;
    public final void entryRuleConditionExpression() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:204:1: ( ruleConditionExpression EOF )
            // InternalDynamicGoalModel.g:205:1: ruleConditionExpression EOF
            {
             before(grammarAccess.getConditionExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleConditionExpression();

            state._fsp--;

             after(grammarAccess.getConditionExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConditionExpression"


    // $ANTLR start "ruleConditionExpression"
    // InternalDynamicGoalModel.g:212:1: ruleConditionExpression : ( ruleOrExpression ) ;
    public final void ruleConditionExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:216:2: ( ( ruleOrExpression ) )
            // InternalDynamicGoalModel.g:217:2: ( ruleOrExpression )
            {
            // InternalDynamicGoalModel.g:217:2: ( ruleOrExpression )
            // InternalDynamicGoalModel.g:218:3: ruleOrExpression
            {
             before(grammarAccess.getConditionExpressionAccess().getOrExpressionParserRuleCall()); 
            pushFollow(FOLLOW_2);
            ruleOrExpression();

            state._fsp--;

             after(grammarAccess.getConditionExpressionAccess().getOrExpressionParserRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConditionExpression"


    // $ANTLR start "entryRuleOrExpression"
    // InternalDynamicGoalModel.g:228:1: entryRuleOrExpression : ruleOrExpression EOF ;
    public final void entryRuleOrExpression() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:229:1: ( ruleOrExpression EOF )
            // InternalDynamicGoalModel.g:230:1: ruleOrExpression EOF
            {
             before(grammarAccess.getOrExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleOrExpression();

            state._fsp--;

             after(grammarAccess.getOrExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOrExpression"


    // $ANTLR start "ruleOrExpression"
    // InternalDynamicGoalModel.g:237:1: ruleOrExpression : ( ( rule__OrExpression__Group__0 ) ) ;
    public final void ruleOrExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:241:2: ( ( ( rule__OrExpression__Group__0 ) ) )
            // InternalDynamicGoalModel.g:242:2: ( ( rule__OrExpression__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:242:2: ( ( rule__OrExpression__Group__0 ) )
            // InternalDynamicGoalModel.g:243:3: ( rule__OrExpression__Group__0 )
            {
             before(grammarAccess.getOrExpressionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:244:3: ( rule__OrExpression__Group__0 )
            // InternalDynamicGoalModel.g:244:4: rule__OrExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__OrExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getOrExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOrExpression"


    // $ANTLR start "entryRuleAndExpression"
    // InternalDynamicGoalModel.g:253:1: entryRuleAndExpression : ruleAndExpression EOF ;
    public final void entryRuleAndExpression() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:254:1: ( ruleAndExpression EOF )
            // InternalDynamicGoalModel.g:255:1: ruleAndExpression EOF
            {
             before(grammarAccess.getAndExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleAndExpression();

            state._fsp--;

             after(grammarAccess.getAndExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAndExpression"


    // $ANTLR start "ruleAndExpression"
    // InternalDynamicGoalModel.g:262:1: ruleAndExpression : ( ( rule__AndExpression__Group__0 ) ) ;
    public final void ruleAndExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:266:2: ( ( ( rule__AndExpression__Group__0 ) ) )
            // InternalDynamicGoalModel.g:267:2: ( ( rule__AndExpression__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:267:2: ( ( rule__AndExpression__Group__0 ) )
            // InternalDynamicGoalModel.g:268:3: ( rule__AndExpression__Group__0 )
            {
             before(grammarAccess.getAndExpressionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:269:3: ( rule__AndExpression__Group__0 )
            // InternalDynamicGoalModel.g:269:4: rule__AndExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__AndExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAndExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAndExpression"


    // $ANTLR start "entryRuleUnaryExpression"
    // InternalDynamicGoalModel.g:278:1: entryRuleUnaryExpression : ruleUnaryExpression EOF ;
    public final void entryRuleUnaryExpression() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:279:1: ( ruleUnaryExpression EOF )
            // InternalDynamicGoalModel.g:280:1: ruleUnaryExpression EOF
            {
             before(grammarAccess.getUnaryExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleUnaryExpression();

            state._fsp--;

             after(grammarAccess.getUnaryExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUnaryExpression"


    // $ANTLR start "ruleUnaryExpression"
    // InternalDynamicGoalModel.g:287:1: ruleUnaryExpression : ( ( rule__UnaryExpression__Alternatives ) ) ;
    public final void ruleUnaryExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:291:2: ( ( ( rule__UnaryExpression__Alternatives ) ) )
            // InternalDynamicGoalModel.g:292:2: ( ( rule__UnaryExpression__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:292:2: ( ( rule__UnaryExpression__Alternatives ) )
            // InternalDynamicGoalModel.g:293:3: ( rule__UnaryExpression__Alternatives )
            {
             before(grammarAccess.getUnaryExpressionAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:294:3: ( rule__UnaryExpression__Alternatives )
            // InternalDynamicGoalModel.g:294:4: rule__UnaryExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__UnaryExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getUnaryExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUnaryExpression"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalDynamicGoalModel.g:303:1: entryRuleNegationExpression : ruleNegationExpression EOF ;
    public final void entryRuleNegationExpression() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:304:1: ( ruleNegationExpression EOF )
            // InternalDynamicGoalModel.g:305:1: ruleNegationExpression EOF
            {
             before(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleNegationExpression();

            state._fsp--;

             after(grammarAccess.getNegationExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalDynamicGoalModel.g:312:1: ruleNegationExpression : ( ( rule__NegationExpression__Group__0 ) ) ;
    public final void ruleNegationExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:316:2: ( ( ( rule__NegationExpression__Group__0 ) ) )
            // InternalDynamicGoalModel.g:317:2: ( ( rule__NegationExpression__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:317:2: ( ( rule__NegationExpression__Group__0 ) )
            // InternalDynamicGoalModel.g:318:3: ( rule__NegationExpression__Group__0 )
            {
             before(grammarAccess.getNegationExpressionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:319:3: ( rule__NegationExpression__Group__0 )
            // InternalDynamicGoalModel.g:319:4: rule__NegationExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__NegationExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNegationExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleAtomicCondition"
    // InternalDynamicGoalModel.g:328:1: entryRuleAtomicCondition : ruleAtomicCondition EOF ;
    public final void entryRuleAtomicCondition() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:329:1: ( ruleAtomicCondition EOF )
            // InternalDynamicGoalModel.g:330:1: ruleAtomicCondition EOF
            {
             before(grammarAccess.getAtomicConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleAtomicCondition();

            state._fsp--;

             after(grammarAccess.getAtomicConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAtomicCondition"


    // $ANTLR start "ruleAtomicCondition"
    // InternalDynamicGoalModel.g:337:1: ruleAtomicCondition : ( ( rule__AtomicCondition__Alternatives ) ) ;
    public final void ruleAtomicCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:341:2: ( ( ( rule__AtomicCondition__Alternatives ) ) )
            // InternalDynamicGoalModel.g:342:2: ( ( rule__AtomicCondition__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:342:2: ( ( rule__AtomicCondition__Alternatives ) )
            // InternalDynamicGoalModel.g:343:3: ( rule__AtomicCondition__Alternatives )
            {
             before(grammarAccess.getAtomicConditionAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:344:3: ( rule__AtomicCondition__Alternatives )
            // InternalDynamicGoalModel.g:344:4: rule__AtomicCondition__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__AtomicCondition__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAtomicConditionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAtomicCondition"


    // $ANTLR start "entryRuleEvidenceRef"
    // InternalDynamicGoalModel.g:353:1: entryRuleEvidenceRef : ruleEvidenceRef EOF ;
    public final void entryRuleEvidenceRef() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:354:1: ( ruleEvidenceRef EOF )
            // InternalDynamicGoalModel.g:355:1: ruleEvidenceRef EOF
            {
             before(grammarAccess.getEvidenceRefRule()); 
            pushFollow(FOLLOW_1);
            ruleEvidenceRef();

            state._fsp--;

             after(grammarAccess.getEvidenceRefRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEvidenceRef"


    // $ANTLR start "ruleEvidenceRef"
    // InternalDynamicGoalModel.g:362:1: ruleEvidenceRef : ( ( rule__EvidenceRef__Group__0 ) ) ;
    public final void ruleEvidenceRef() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:366:2: ( ( ( rule__EvidenceRef__Group__0 ) ) )
            // InternalDynamicGoalModel.g:367:2: ( ( rule__EvidenceRef__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:367:2: ( ( rule__EvidenceRef__Group__0 ) )
            // InternalDynamicGoalModel.g:368:3: ( rule__EvidenceRef__Group__0 )
            {
             before(grammarAccess.getEvidenceRefAccess().getGroup()); 
            // InternalDynamicGoalModel.g:369:3: ( rule__EvidenceRef__Group__0 )
            // InternalDynamicGoalModel.g:369:4: rule__EvidenceRef__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceRefAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvidenceRef"


    // $ANTLR start "entryRuleTemporalCondition"
    // InternalDynamicGoalModel.g:378:1: entryRuleTemporalCondition : ruleTemporalCondition EOF ;
    public final void entryRuleTemporalCondition() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:379:1: ( ruleTemporalCondition EOF )
            // InternalDynamicGoalModel.g:380:1: ruleTemporalCondition EOF
            {
             before(grammarAccess.getTemporalConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleTemporalCondition();

            state._fsp--;

             after(grammarAccess.getTemporalConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTemporalCondition"


    // $ANTLR start "ruleTemporalCondition"
    // InternalDynamicGoalModel.g:387:1: ruleTemporalCondition : ( ( rule__TemporalCondition__Group__0 ) ) ;
    public final void ruleTemporalCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:391:2: ( ( ( rule__TemporalCondition__Group__0 ) ) )
            // InternalDynamicGoalModel.g:392:2: ( ( rule__TemporalCondition__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:392:2: ( ( rule__TemporalCondition__Group__0 ) )
            // InternalDynamicGoalModel.g:393:3: ( rule__TemporalCondition__Group__0 )
            {
             before(grammarAccess.getTemporalConditionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:394:3: ( rule__TemporalCondition__Group__0 )
            // InternalDynamicGoalModel.g:394:4: rule__TemporalCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTemporalConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTemporalCondition"


    // $ANTLR start "entryRuleComparisonCondition"
    // InternalDynamicGoalModel.g:403:1: entryRuleComparisonCondition : ruleComparisonCondition EOF ;
    public final void entryRuleComparisonCondition() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:404:1: ( ruleComparisonCondition EOF )
            // InternalDynamicGoalModel.g:405:1: ruleComparisonCondition EOF
            {
             before(grammarAccess.getComparisonConditionRule()); 
            pushFollow(FOLLOW_1);
            ruleComparisonCondition();

            state._fsp--;

             after(grammarAccess.getComparisonConditionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComparisonCondition"


    // $ANTLR start "ruleComparisonCondition"
    // InternalDynamicGoalModel.g:412:1: ruleComparisonCondition : ( ( rule__ComparisonCondition__Group__0 ) ) ;
    public final void ruleComparisonCondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:416:2: ( ( ( rule__ComparisonCondition__Group__0 ) ) )
            // InternalDynamicGoalModel.g:417:2: ( ( rule__ComparisonCondition__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:417:2: ( ( rule__ComparisonCondition__Group__0 ) )
            // InternalDynamicGoalModel.g:418:3: ( rule__ComparisonCondition__Group__0 )
            {
             before(grammarAccess.getComparisonConditionAccess().getGroup()); 
            // InternalDynamicGoalModel.g:419:3: ( rule__ComparisonCondition__Group__0 )
            // InternalDynamicGoalModel.g:419:4: rule__ComparisonCondition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getComparisonConditionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparisonCondition"


    // $ANTLR start "entryRulePrecedence"
    // InternalDynamicGoalModel.g:428:1: entryRulePrecedence : rulePrecedence EOF ;
    public final void entryRulePrecedence() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:429:1: ( rulePrecedence EOF )
            // InternalDynamicGoalModel.g:430:1: rulePrecedence EOF
            {
             before(grammarAccess.getPrecedenceRule()); 
            pushFollow(FOLLOW_1);
            rulePrecedence();

            state._fsp--;

             after(grammarAccess.getPrecedenceRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrecedence"


    // $ANTLR start "rulePrecedence"
    // InternalDynamicGoalModel.g:437:1: rulePrecedence : ( ( rule__Precedence__Group__0 ) ) ;
    public final void rulePrecedence() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:441:2: ( ( ( rule__Precedence__Group__0 ) ) )
            // InternalDynamicGoalModel.g:442:2: ( ( rule__Precedence__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:442:2: ( ( rule__Precedence__Group__0 ) )
            // InternalDynamicGoalModel.g:443:3: ( rule__Precedence__Group__0 )
            {
             before(grammarAccess.getPrecedenceAccess().getGroup()); 
            // InternalDynamicGoalModel.g:444:3: ( rule__Precedence__Group__0 )
            // InternalDynamicGoalModel.g:444:4: rule__Precedence__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPrecedenceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrecedence"


    // $ANTLR start "entryRulePrecedenceEntry"
    // InternalDynamicGoalModel.g:453:1: entryRulePrecedenceEntry : rulePrecedenceEntry EOF ;
    public final void entryRulePrecedenceEntry() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:454:1: ( rulePrecedenceEntry EOF )
            // InternalDynamicGoalModel.g:455:1: rulePrecedenceEntry EOF
            {
             before(grammarAccess.getPrecedenceEntryRule()); 
            pushFollow(FOLLOW_1);
            rulePrecedenceEntry();

            state._fsp--;

             after(grammarAccess.getPrecedenceEntryRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrecedenceEntry"


    // $ANTLR start "rulePrecedenceEntry"
    // InternalDynamicGoalModel.g:462:1: rulePrecedenceEntry : ( ( rule__PrecedenceEntry__HypothesisAssignment ) ) ;
    public final void rulePrecedenceEntry() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:466:2: ( ( ( rule__PrecedenceEntry__HypothesisAssignment ) ) )
            // InternalDynamicGoalModel.g:467:2: ( ( rule__PrecedenceEntry__HypothesisAssignment ) )
            {
            // InternalDynamicGoalModel.g:467:2: ( ( rule__PrecedenceEntry__HypothesisAssignment ) )
            // InternalDynamicGoalModel.g:468:3: ( rule__PrecedenceEntry__HypothesisAssignment )
            {
             before(grammarAccess.getPrecedenceEntryAccess().getHypothesisAssignment()); 
            // InternalDynamicGoalModel.g:469:3: ( rule__PrecedenceEntry__HypothesisAssignment )
            // InternalDynamicGoalModel.g:469:4: rule__PrecedenceEntry__HypothesisAssignment
            {
            pushFollow(FOLLOW_2);
            rule__PrecedenceEntry__HypothesisAssignment();

            state._fsp--;


            }

             after(grammarAccess.getPrecedenceEntryAccess().getHypothesisAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrecedenceEntry"


    // $ANTLR start "entryRuleResponseBinding"
    // InternalDynamicGoalModel.g:478:1: entryRuleResponseBinding : ruleResponseBinding EOF ;
    public final void entryRuleResponseBinding() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:479:1: ( ruleResponseBinding EOF )
            // InternalDynamicGoalModel.g:480:1: ruleResponseBinding EOF
            {
             before(grammarAccess.getResponseBindingRule()); 
            pushFollow(FOLLOW_1);
            ruleResponseBinding();

            state._fsp--;

             after(grammarAccess.getResponseBindingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleResponseBinding"


    // $ANTLR start "ruleResponseBinding"
    // InternalDynamicGoalModel.g:487:1: ruleResponseBinding : ( ( rule__ResponseBinding__Group__0 ) ) ;
    public final void ruleResponseBinding() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:491:2: ( ( ( rule__ResponseBinding__Group__0 ) ) )
            // InternalDynamicGoalModel.g:492:2: ( ( rule__ResponseBinding__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:492:2: ( ( rule__ResponseBinding__Group__0 ) )
            // InternalDynamicGoalModel.g:493:3: ( rule__ResponseBinding__Group__0 )
            {
             before(grammarAccess.getResponseBindingAccess().getGroup()); 
            // InternalDynamicGoalModel.g:494:3: ( rule__ResponseBinding__Group__0 )
            // InternalDynamicGoalModel.g:494:4: rule__ResponseBinding__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getResponseBindingAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleResponseBinding"


    // $ANTLR start "entryRuleEscalationStrategy"
    // InternalDynamicGoalModel.g:503:1: entryRuleEscalationStrategy : ruleEscalationStrategy EOF ;
    public final void entryRuleEscalationStrategy() throws RecognitionException {
        try {
            // InternalDynamicGoalModel.g:504:1: ( ruleEscalationStrategy EOF )
            // InternalDynamicGoalModel.g:505:1: ruleEscalationStrategy EOF
            {
             before(grammarAccess.getEscalationStrategyRule()); 
            pushFollow(FOLLOW_1);
            ruleEscalationStrategy();

            state._fsp--;

             after(grammarAccess.getEscalationStrategyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEscalationStrategy"


    // $ANTLR start "ruleEscalationStrategy"
    // InternalDynamicGoalModel.g:512:1: ruleEscalationStrategy : ( ( rule__EscalationStrategy__Group__0 ) ) ;
    public final void ruleEscalationStrategy() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:516:2: ( ( ( rule__EscalationStrategy__Group__0 ) ) )
            // InternalDynamicGoalModel.g:517:2: ( ( rule__EscalationStrategy__Group__0 ) )
            {
            // InternalDynamicGoalModel.g:517:2: ( ( rule__EscalationStrategy__Group__0 ) )
            // InternalDynamicGoalModel.g:518:3: ( rule__EscalationStrategy__Group__0 )
            {
             before(grammarAccess.getEscalationStrategyAccess().getGroup()); 
            // InternalDynamicGoalModel.g:519:3: ( rule__EscalationStrategy__Group__0 )
            // InternalDynamicGoalModel.g:519:4: rule__EscalationStrategy__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEscalationStrategy"


    // $ANTLR start "ruleEvidenceType"
    // InternalDynamicGoalModel.g:528:1: ruleEvidenceType : ( ( rule__EvidenceType__Alternatives ) ) ;
    public final void ruleEvidenceType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:532:1: ( ( ( rule__EvidenceType__Alternatives ) ) )
            // InternalDynamicGoalModel.g:533:2: ( ( rule__EvidenceType__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:533:2: ( ( rule__EvidenceType__Alternatives ) )
            // InternalDynamicGoalModel.g:534:3: ( rule__EvidenceType__Alternatives )
            {
             before(grammarAccess.getEvidenceTypeAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:535:3: ( rule__EvidenceType__Alternatives )
            // InternalDynamicGoalModel.g:535:4: rule__EvidenceType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvidenceType"


    // $ANTLR start "ruleTemporalOperator"
    // InternalDynamicGoalModel.g:544:1: ruleTemporalOperator : ( ( rule__TemporalOperator__Alternatives ) ) ;
    public final void ruleTemporalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:548:1: ( ( ( rule__TemporalOperator__Alternatives ) ) )
            // InternalDynamicGoalModel.g:549:2: ( ( rule__TemporalOperator__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:549:2: ( ( rule__TemporalOperator__Alternatives ) )
            // InternalDynamicGoalModel.g:550:3: ( rule__TemporalOperator__Alternatives )
            {
             before(grammarAccess.getTemporalOperatorAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:551:3: ( rule__TemporalOperator__Alternatives )
            // InternalDynamicGoalModel.g:551:4: rule__TemporalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__TemporalOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTemporalOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTemporalOperator"


    // $ANTLR start "ruleComparator"
    // InternalDynamicGoalModel.g:560:1: ruleComparator : ( ( rule__Comparator__Alternatives ) ) ;
    public final void ruleComparator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:564:1: ( ( ( rule__Comparator__Alternatives ) ) )
            // InternalDynamicGoalModel.g:565:2: ( ( rule__Comparator__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:565:2: ( ( rule__Comparator__Alternatives ) )
            // InternalDynamicGoalModel.g:566:3: ( rule__Comparator__Alternatives )
            {
             before(grammarAccess.getComparatorAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:567:3: ( rule__Comparator__Alternatives )
            // InternalDynamicGoalModel.g:567:4: rule__Comparator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comparator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getComparatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparator"


    // $ANTLR start "ruleEscalationStrategyType"
    // InternalDynamicGoalModel.g:576:1: ruleEscalationStrategyType : ( ( rule__EscalationStrategyType__Alternatives ) ) ;
    public final void ruleEscalationStrategyType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:580:1: ( ( ( rule__EscalationStrategyType__Alternatives ) ) )
            // InternalDynamicGoalModel.g:581:2: ( ( rule__EscalationStrategyType__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:581:2: ( ( rule__EscalationStrategyType__Alternatives ) )
            // InternalDynamicGoalModel.g:582:3: ( rule__EscalationStrategyType__Alternatives )
            {
             before(grammarAccess.getEscalationStrategyTypeAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:583:3: ( rule__EscalationStrategyType__Alternatives )
            // InternalDynamicGoalModel.g:583:4: rule__EscalationStrategyType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategyType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEscalationStrategyType"


    // $ANTLR start "ruleOperationalMode"
    // InternalDynamicGoalModel.g:592:1: ruleOperationalMode : ( ( rule__OperationalMode__Alternatives ) ) ;
    public final void ruleOperationalMode() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:596:1: ( ( ( rule__OperationalMode__Alternatives ) ) )
            // InternalDynamicGoalModel.g:597:2: ( ( rule__OperationalMode__Alternatives ) )
            {
            // InternalDynamicGoalModel.g:597:2: ( ( rule__OperationalMode__Alternatives ) )
            // InternalDynamicGoalModel.g:598:3: ( rule__OperationalMode__Alternatives )
            {
             before(grammarAccess.getOperationalModeAccess().getAlternatives()); 
            // InternalDynamicGoalModel.g:599:3: ( rule__OperationalMode__Alternatives )
            // InternalDynamicGoalModel.g:599:4: rule__OperationalMode__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__OperationalMode__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getOperationalModeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOperationalMode"


    // $ANTLR start "rule__UnaryExpression__Alternatives"
    // InternalDynamicGoalModel.g:607:1: rule__UnaryExpression__Alternatives : ( ( ruleNegationExpression ) | ( ruleAtomicCondition ) | ( ( rule__UnaryExpression__Group_2__0 ) ) );
    public final void rule__UnaryExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:611:1: ( ( ruleNegationExpression ) | ( ruleAtomicCondition ) | ( ( rule__UnaryExpression__Group_2__0 ) ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 60:
                {
                alt1=1;
                }
                break;
            case RULE_ID:
            case 18:
            case 19:
            case 20:
            case 21:
                {
                alt1=2;
                }
                break;
            case 53:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalDynamicGoalModel.g:612:2: ( ruleNegationExpression )
                    {
                    // InternalDynamicGoalModel.g:612:2: ( ruleNegationExpression )
                    // InternalDynamicGoalModel.g:613:3: ruleNegationExpression
                    {
                     before(grammarAccess.getUnaryExpressionAccess().getNegationExpressionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleNegationExpression();

                    state._fsp--;

                     after(grammarAccess.getUnaryExpressionAccess().getNegationExpressionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:618:2: ( ruleAtomicCondition )
                    {
                    // InternalDynamicGoalModel.g:618:2: ( ruleAtomicCondition )
                    // InternalDynamicGoalModel.g:619:3: ruleAtomicCondition
                    {
                     before(grammarAccess.getUnaryExpressionAccess().getAtomicConditionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleAtomicCondition();

                    state._fsp--;

                     after(grammarAccess.getUnaryExpressionAccess().getAtomicConditionParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:624:2: ( ( rule__UnaryExpression__Group_2__0 ) )
                    {
                    // InternalDynamicGoalModel.g:624:2: ( ( rule__UnaryExpression__Group_2__0 ) )
                    // InternalDynamicGoalModel.g:625:3: ( rule__UnaryExpression__Group_2__0 )
                    {
                     before(grammarAccess.getUnaryExpressionAccess().getGroup_2()); 
                    // InternalDynamicGoalModel.g:626:3: ( rule__UnaryExpression__Group_2__0 )
                    // InternalDynamicGoalModel.g:626:4: rule__UnaryExpression__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__UnaryExpression__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getUnaryExpressionAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Alternatives"


    // $ANTLR start "rule__AtomicCondition__Alternatives"
    // InternalDynamicGoalModel.g:634:1: rule__AtomicCondition__Alternatives : ( ( ruleEvidenceRef ) | ( ruleTemporalCondition ) | ( ruleComparisonCondition ) );
    public final void rule__AtomicCondition__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:638:1: ( ( ruleEvidenceRef ) | ( ruleTemporalCondition ) | ( ruleComparisonCondition ) )
            int alt2=3;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_ID) ) {
                int LA2_1 = input.LA(2);

                if ( (LA2_1==EOF||(LA2_1>=53 && LA2_1<=54)||(LA2_1>=58 && LA2_1<=59)||LA2_1==64) ) {
                    alt2=1;
                }
                else if ( ((LA2_1>=22 && LA2_1<=25)) ) {
                    alt2=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA2_0>=18 && LA2_0<=21)) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalDynamicGoalModel.g:639:2: ( ruleEvidenceRef )
                    {
                    // InternalDynamicGoalModel.g:639:2: ( ruleEvidenceRef )
                    // InternalDynamicGoalModel.g:640:3: ruleEvidenceRef
                    {
                     before(grammarAccess.getAtomicConditionAccess().getEvidenceRefParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleEvidenceRef();

                    state._fsp--;

                     after(grammarAccess.getAtomicConditionAccess().getEvidenceRefParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:645:2: ( ruleTemporalCondition )
                    {
                    // InternalDynamicGoalModel.g:645:2: ( ruleTemporalCondition )
                    // InternalDynamicGoalModel.g:646:3: ruleTemporalCondition
                    {
                     before(grammarAccess.getAtomicConditionAccess().getTemporalConditionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTemporalCondition();

                    state._fsp--;

                     after(grammarAccess.getAtomicConditionAccess().getTemporalConditionParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:651:2: ( ruleComparisonCondition )
                    {
                    // InternalDynamicGoalModel.g:651:2: ( ruleComparisonCondition )
                    // InternalDynamicGoalModel.g:652:3: ruleComparisonCondition
                    {
                     before(grammarAccess.getAtomicConditionAccess().getComparisonConditionParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleComparisonCondition();

                    state._fsp--;

                     after(grammarAccess.getAtomicConditionAccess().getComparisonConditionParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AtomicCondition__Alternatives"


    // $ANTLR start "rule__EvidenceType__Alternatives"
    // InternalDynamicGoalModel.g:661:1: rule__EvidenceType__Alternatives : ( ( ( 'SENSOR' ) ) | ( ( 'TEMPORAL' ) ) | ( ( 'IDENTITY' ) ) | ( ( 'SPATIAL' ) ) | ( ( 'DERIVED' ) ) | ( ( 'ROLE' ) ) | ( ( 'CATALOG' ) ) );
    public final void rule__EvidenceType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:665:1: ( ( ( 'SENSOR' ) ) | ( ( 'TEMPORAL' ) ) | ( ( 'IDENTITY' ) ) | ( ( 'SPATIAL' ) ) | ( ( 'DERIVED' ) ) | ( ( 'ROLE' ) ) | ( ( 'CATALOG' ) ) )
            int alt3=7;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt3=1;
                }
                break;
            case 12:
                {
                alt3=2;
                }
                break;
            case 13:
                {
                alt3=3;
                }
                break;
            case 14:
                {
                alt3=4;
                }
                break;
            case 15:
                {
                alt3=5;
                }
                break;
            case 16:
                {
                alt3=6;
                }
                break;
            case 17:
                {
                alt3=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalDynamicGoalModel.g:666:2: ( ( 'SENSOR' ) )
                    {
                    // InternalDynamicGoalModel.g:666:2: ( ( 'SENSOR' ) )
                    // InternalDynamicGoalModel.g:667:3: ( 'SENSOR' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getSENSOREnumLiteralDeclaration_0()); 
                    // InternalDynamicGoalModel.g:668:3: ( 'SENSOR' )
                    // InternalDynamicGoalModel.g:668:4: 'SENSOR'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getSENSOREnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:672:2: ( ( 'TEMPORAL' ) )
                    {
                    // InternalDynamicGoalModel.g:672:2: ( ( 'TEMPORAL' ) )
                    // InternalDynamicGoalModel.g:673:3: ( 'TEMPORAL' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getTEMPORALEnumLiteralDeclaration_1()); 
                    // InternalDynamicGoalModel.g:674:3: ( 'TEMPORAL' )
                    // InternalDynamicGoalModel.g:674:4: 'TEMPORAL'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getTEMPORALEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:678:2: ( ( 'IDENTITY' ) )
                    {
                    // InternalDynamicGoalModel.g:678:2: ( ( 'IDENTITY' ) )
                    // InternalDynamicGoalModel.g:679:3: ( 'IDENTITY' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getIDENTITYEnumLiteralDeclaration_2()); 
                    // InternalDynamicGoalModel.g:680:3: ( 'IDENTITY' )
                    // InternalDynamicGoalModel.g:680:4: 'IDENTITY'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getIDENTITYEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:684:2: ( ( 'SPATIAL' ) )
                    {
                    // InternalDynamicGoalModel.g:684:2: ( ( 'SPATIAL' ) )
                    // InternalDynamicGoalModel.g:685:3: ( 'SPATIAL' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getSPATIALEnumLiteralDeclaration_3()); 
                    // InternalDynamicGoalModel.g:686:3: ( 'SPATIAL' )
                    // InternalDynamicGoalModel.g:686:4: 'SPATIAL'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getSPATIALEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalDynamicGoalModel.g:690:2: ( ( 'DERIVED' ) )
                    {
                    // InternalDynamicGoalModel.g:690:2: ( ( 'DERIVED' ) )
                    // InternalDynamicGoalModel.g:691:3: ( 'DERIVED' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getDERIVEDEnumLiteralDeclaration_4()); 
                    // InternalDynamicGoalModel.g:692:3: ( 'DERIVED' )
                    // InternalDynamicGoalModel.g:692:4: 'DERIVED'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getDERIVEDEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalDynamicGoalModel.g:696:2: ( ( 'ROLE' ) )
                    {
                    // InternalDynamicGoalModel.g:696:2: ( ( 'ROLE' ) )
                    // InternalDynamicGoalModel.g:697:3: ( 'ROLE' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getROLEEnumLiteralDeclaration_5()); 
                    // InternalDynamicGoalModel.g:698:3: ( 'ROLE' )
                    // InternalDynamicGoalModel.g:698:4: 'ROLE'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getROLEEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalDynamicGoalModel.g:702:2: ( ( 'CATALOG' ) )
                    {
                    // InternalDynamicGoalModel.g:702:2: ( ( 'CATALOG' ) )
                    // InternalDynamicGoalModel.g:703:3: ( 'CATALOG' )
                    {
                     before(grammarAccess.getEvidenceTypeAccess().getCATALOGEnumLiteralDeclaration_6()); 
                    // InternalDynamicGoalModel.g:704:3: ( 'CATALOG' )
                    // InternalDynamicGoalModel.g:704:4: 'CATALOG'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getEvidenceTypeAccess().getCATALOGEnumLiteralDeclaration_6()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceType__Alternatives"


    // $ANTLR start "rule__TemporalOperator__Alternatives"
    // InternalDynamicGoalModel.g:712:1: rule__TemporalOperator__Alternatives : ( ( ( 'WITHIN' ) ) | ( ( 'NOT_WITHIN' ) ) | ( ( 'HELD_FOR' ) ) | ( ( 'REPEATED_WITHIN' ) ) );
    public final void rule__TemporalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:716:1: ( ( ( 'WITHIN' ) ) | ( ( 'NOT_WITHIN' ) ) | ( ( 'HELD_FOR' ) ) | ( ( 'REPEATED_WITHIN' ) ) )
            int alt4=4;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt4=1;
                }
                break;
            case 19:
                {
                alt4=2;
                }
                break;
            case 20:
                {
                alt4=3;
                }
                break;
            case 21:
                {
                alt4=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalDynamicGoalModel.g:717:2: ( ( 'WITHIN' ) )
                    {
                    // InternalDynamicGoalModel.g:717:2: ( ( 'WITHIN' ) )
                    // InternalDynamicGoalModel.g:718:3: ( 'WITHIN' )
                    {
                     before(grammarAccess.getTemporalOperatorAccess().getWITHINEnumLiteralDeclaration_0()); 
                    // InternalDynamicGoalModel.g:719:3: ( 'WITHIN' )
                    // InternalDynamicGoalModel.g:719:4: 'WITHIN'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getTemporalOperatorAccess().getWITHINEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:723:2: ( ( 'NOT_WITHIN' ) )
                    {
                    // InternalDynamicGoalModel.g:723:2: ( ( 'NOT_WITHIN' ) )
                    // InternalDynamicGoalModel.g:724:3: ( 'NOT_WITHIN' )
                    {
                     before(grammarAccess.getTemporalOperatorAccess().getNOT_WITHINEnumLiteralDeclaration_1()); 
                    // InternalDynamicGoalModel.g:725:3: ( 'NOT_WITHIN' )
                    // InternalDynamicGoalModel.g:725:4: 'NOT_WITHIN'
                    {
                    match(input,19,FOLLOW_2); 

                    }

                     after(grammarAccess.getTemporalOperatorAccess().getNOT_WITHINEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:729:2: ( ( 'HELD_FOR' ) )
                    {
                    // InternalDynamicGoalModel.g:729:2: ( ( 'HELD_FOR' ) )
                    // InternalDynamicGoalModel.g:730:3: ( 'HELD_FOR' )
                    {
                     before(grammarAccess.getTemporalOperatorAccess().getHELD_FOREnumLiteralDeclaration_2()); 
                    // InternalDynamicGoalModel.g:731:3: ( 'HELD_FOR' )
                    // InternalDynamicGoalModel.g:731:4: 'HELD_FOR'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getTemporalOperatorAccess().getHELD_FOREnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:735:2: ( ( 'REPEATED_WITHIN' ) )
                    {
                    // InternalDynamicGoalModel.g:735:2: ( ( 'REPEATED_WITHIN' ) )
                    // InternalDynamicGoalModel.g:736:3: ( 'REPEATED_WITHIN' )
                    {
                     before(grammarAccess.getTemporalOperatorAccess().getREPEATED_WITHINEnumLiteralDeclaration_3()); 
                    // InternalDynamicGoalModel.g:737:3: ( 'REPEATED_WITHIN' )
                    // InternalDynamicGoalModel.g:737:4: 'REPEATED_WITHIN'
                    {
                    match(input,21,FOLLOW_2); 

                    }

                     after(grammarAccess.getTemporalOperatorAccess().getREPEATED_WITHINEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalOperator__Alternatives"


    // $ANTLR start "rule__Comparator__Alternatives"
    // InternalDynamicGoalModel.g:745:1: rule__Comparator__Alternatives : ( ( ( '=' ) ) | ( ( '!=' ) ) | ( ( '>' ) ) | ( ( '<' ) ) );
    public final void rule__Comparator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:749:1: ( ( ( '=' ) ) | ( ( '!=' ) ) | ( ( '>' ) ) | ( ( '<' ) ) )
            int alt5=4;
            switch ( input.LA(1) ) {
            case 22:
                {
                alt5=1;
                }
                break;
            case 23:
                {
                alt5=2;
                }
                break;
            case 24:
                {
                alt5=3;
                }
                break;
            case 25:
                {
                alt5=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalDynamicGoalModel.g:750:2: ( ( '=' ) )
                    {
                    // InternalDynamicGoalModel.g:750:2: ( ( '=' ) )
                    // InternalDynamicGoalModel.g:751:3: ( '=' )
                    {
                     before(grammarAccess.getComparatorAccess().getEQUALSEnumLiteralDeclaration_0()); 
                    // InternalDynamicGoalModel.g:752:3: ( '=' )
                    // InternalDynamicGoalModel.g:752:4: '='
                    {
                    match(input,22,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparatorAccess().getEQUALSEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:756:2: ( ( '!=' ) )
                    {
                    // InternalDynamicGoalModel.g:756:2: ( ( '!=' ) )
                    // InternalDynamicGoalModel.g:757:3: ( '!=' )
                    {
                     before(grammarAccess.getComparatorAccess().getNOT_EQUALSEnumLiteralDeclaration_1()); 
                    // InternalDynamicGoalModel.g:758:3: ( '!=' )
                    // InternalDynamicGoalModel.g:758:4: '!='
                    {
                    match(input,23,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparatorAccess().getNOT_EQUALSEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:762:2: ( ( '>' ) )
                    {
                    // InternalDynamicGoalModel.g:762:2: ( ( '>' ) )
                    // InternalDynamicGoalModel.g:763:3: ( '>' )
                    {
                     before(grammarAccess.getComparatorAccess().getGREATEREnumLiteralDeclaration_2()); 
                    // InternalDynamicGoalModel.g:764:3: ( '>' )
                    // InternalDynamicGoalModel.g:764:4: '>'
                    {
                    match(input,24,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparatorAccess().getGREATEREnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:768:2: ( ( '<' ) )
                    {
                    // InternalDynamicGoalModel.g:768:2: ( ( '<' ) )
                    // InternalDynamicGoalModel.g:769:3: ( '<' )
                    {
                     before(grammarAccess.getComparatorAccess().getLESSEnumLiteralDeclaration_3()); 
                    // InternalDynamicGoalModel.g:770:3: ( '<' )
                    // InternalDynamicGoalModel.g:770:4: '<'
                    {
                    match(input,25,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparatorAccess().getLESSEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comparator__Alternatives"


    // $ANTLR start "rule__EscalationStrategyType__Alternatives"
    // InternalDynamicGoalModel.g:778:1: rule__EscalationStrategyType__Alternatives : ( ( ( 'REQUEST_MORE_EVIDENCE' ) ) | ( ( 'DEFAULT_NO_COMMIT' ) ) | ( ( 'NOTIFY_OPERATOR' ) ) );
    public final void rule__EscalationStrategyType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:782:1: ( ( ( 'REQUEST_MORE_EVIDENCE' ) ) | ( ( 'DEFAULT_NO_COMMIT' ) ) | ( ( 'NOTIFY_OPERATOR' ) ) )
            int alt6=3;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt6=1;
                }
                break;
            case 27:
                {
                alt6=2;
                }
                break;
            case 28:
                {
                alt6=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalDynamicGoalModel.g:783:2: ( ( 'REQUEST_MORE_EVIDENCE' ) )
                    {
                    // InternalDynamicGoalModel.g:783:2: ( ( 'REQUEST_MORE_EVIDENCE' ) )
                    // InternalDynamicGoalModel.g:784:3: ( 'REQUEST_MORE_EVIDENCE' )
                    {
                     before(grammarAccess.getEscalationStrategyTypeAccess().getREQUEST_MORE_EVIDENCEEnumLiteralDeclaration_0()); 
                    // InternalDynamicGoalModel.g:785:3: ( 'REQUEST_MORE_EVIDENCE' )
                    // InternalDynamicGoalModel.g:785:4: 'REQUEST_MORE_EVIDENCE'
                    {
                    match(input,26,FOLLOW_2); 

                    }

                     after(grammarAccess.getEscalationStrategyTypeAccess().getREQUEST_MORE_EVIDENCEEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:789:2: ( ( 'DEFAULT_NO_COMMIT' ) )
                    {
                    // InternalDynamicGoalModel.g:789:2: ( ( 'DEFAULT_NO_COMMIT' ) )
                    // InternalDynamicGoalModel.g:790:3: ( 'DEFAULT_NO_COMMIT' )
                    {
                     before(grammarAccess.getEscalationStrategyTypeAccess().getDEFAULT_NO_COMMITEnumLiteralDeclaration_1()); 
                    // InternalDynamicGoalModel.g:791:3: ( 'DEFAULT_NO_COMMIT' )
                    // InternalDynamicGoalModel.g:791:4: 'DEFAULT_NO_COMMIT'
                    {
                    match(input,27,FOLLOW_2); 

                    }

                     after(grammarAccess.getEscalationStrategyTypeAccess().getDEFAULT_NO_COMMITEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:795:2: ( ( 'NOTIFY_OPERATOR' ) )
                    {
                    // InternalDynamicGoalModel.g:795:2: ( ( 'NOTIFY_OPERATOR' ) )
                    // InternalDynamicGoalModel.g:796:3: ( 'NOTIFY_OPERATOR' )
                    {
                     before(grammarAccess.getEscalationStrategyTypeAccess().getNOTIFY_OPERATOREnumLiteralDeclaration_2()); 
                    // InternalDynamicGoalModel.g:797:3: ( 'NOTIFY_OPERATOR' )
                    // InternalDynamicGoalModel.g:797:4: 'NOTIFY_OPERATOR'
                    {
                    match(input,28,FOLLOW_2); 

                    }

                     after(grammarAccess.getEscalationStrategyTypeAccess().getNOTIFY_OPERATOREnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategyType__Alternatives"


    // $ANTLR start "rule__OperationalMode__Alternatives"
    // InternalDynamicGoalModel.g:805:1: rule__OperationalMode__Alternatives : ( ( ( 'NORMAL' ) ) | ( ( 'EMERGENCY' ) ) | ( ( 'MAINTENANCE' ) ) | ( ( 'ENERGY_SAVING' ) ) );
    public final void rule__OperationalMode__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:809:1: ( ( ( 'NORMAL' ) ) | ( ( 'EMERGENCY' ) ) | ( ( 'MAINTENANCE' ) ) | ( ( 'ENERGY_SAVING' ) ) )
            int alt7=4;
            switch ( input.LA(1) ) {
            case 29:
                {
                alt7=1;
                }
                break;
            case 30:
                {
                alt7=2;
                }
                break;
            case 31:
                {
                alt7=3;
                }
                break;
            case 32:
                {
                alt7=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalDynamicGoalModel.g:810:2: ( ( 'NORMAL' ) )
                    {
                    // InternalDynamicGoalModel.g:810:2: ( ( 'NORMAL' ) )
                    // InternalDynamicGoalModel.g:811:3: ( 'NORMAL' )
                    {
                     before(grammarAccess.getOperationalModeAccess().getNORMALEnumLiteralDeclaration_0()); 
                    // InternalDynamicGoalModel.g:812:3: ( 'NORMAL' )
                    // InternalDynamicGoalModel.g:812:4: 'NORMAL'
                    {
                    match(input,29,FOLLOW_2); 

                    }

                     after(grammarAccess.getOperationalModeAccess().getNORMALEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:816:2: ( ( 'EMERGENCY' ) )
                    {
                    // InternalDynamicGoalModel.g:816:2: ( ( 'EMERGENCY' ) )
                    // InternalDynamicGoalModel.g:817:3: ( 'EMERGENCY' )
                    {
                     before(grammarAccess.getOperationalModeAccess().getEMERGENCYEnumLiteralDeclaration_1()); 
                    // InternalDynamicGoalModel.g:818:3: ( 'EMERGENCY' )
                    // InternalDynamicGoalModel.g:818:4: 'EMERGENCY'
                    {
                    match(input,30,FOLLOW_2); 

                    }

                     after(grammarAccess.getOperationalModeAccess().getEMERGENCYEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:822:2: ( ( 'MAINTENANCE' ) )
                    {
                    // InternalDynamicGoalModel.g:822:2: ( ( 'MAINTENANCE' ) )
                    // InternalDynamicGoalModel.g:823:3: ( 'MAINTENANCE' )
                    {
                     before(grammarAccess.getOperationalModeAccess().getMAINTENANCEEnumLiteralDeclaration_2()); 
                    // InternalDynamicGoalModel.g:824:3: ( 'MAINTENANCE' )
                    // InternalDynamicGoalModel.g:824:4: 'MAINTENANCE'
                    {
                    match(input,31,FOLLOW_2); 

                    }

                     after(grammarAccess.getOperationalModeAccess().getMAINTENANCEEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:828:2: ( ( 'ENERGY_SAVING' ) )
                    {
                    // InternalDynamicGoalModel.g:828:2: ( ( 'ENERGY_SAVING' ) )
                    // InternalDynamicGoalModel.g:829:3: ( 'ENERGY_SAVING' )
                    {
                     before(grammarAccess.getOperationalModeAccess().getENERGY_SAVINGEnumLiteralDeclaration_3()); 
                    // InternalDynamicGoalModel.g:830:3: ( 'ENERGY_SAVING' )
                    // InternalDynamicGoalModel.g:830:4: 'ENERGY_SAVING'
                    {
                    match(input,32,FOLLOW_2); 

                    }

                     after(grammarAccess.getOperationalModeAccess().getENERGY_SAVINGEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OperationalMode__Alternatives"


    // $ANTLR start "rule__DGMSpecification__Group__0"
    // InternalDynamicGoalModel.g:838:1: rule__DGMSpecification__Group__0 : rule__DGMSpecification__Group__0__Impl rule__DGMSpecification__Group__1 ;
    public final void rule__DGMSpecification__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:842:1: ( rule__DGMSpecification__Group__0__Impl rule__DGMSpecification__Group__1 )
            // InternalDynamicGoalModel.g:843:2: rule__DGMSpecification__Group__0__Impl rule__DGMSpecification__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__DGMSpecification__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__0"


    // $ANTLR start "rule__DGMSpecification__Group__0__Impl"
    // InternalDynamicGoalModel.g:850:1: rule__DGMSpecification__Group__0__Impl : ( 'DGMSpecification' ) ;
    public final void rule__DGMSpecification__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:854:1: ( ( 'DGMSpecification' ) )
            // InternalDynamicGoalModel.g:855:1: ( 'DGMSpecification' )
            {
            // InternalDynamicGoalModel.g:855:1: ( 'DGMSpecification' )
            // InternalDynamicGoalModel.g:856:2: 'DGMSpecification'
            {
             before(grammarAccess.getDGMSpecificationAccess().getDGMSpecificationKeyword_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getDGMSpecificationKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__0__Impl"


    // $ANTLR start "rule__DGMSpecification__Group__1"
    // InternalDynamicGoalModel.g:865:1: rule__DGMSpecification__Group__1 : rule__DGMSpecification__Group__1__Impl rule__DGMSpecification__Group__2 ;
    public final void rule__DGMSpecification__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:869:1: ( rule__DGMSpecification__Group__1__Impl rule__DGMSpecification__Group__2 )
            // InternalDynamicGoalModel.g:870:2: rule__DGMSpecification__Group__1__Impl rule__DGMSpecification__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__DGMSpecification__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__1"


    // $ANTLR start "rule__DGMSpecification__Group__1__Impl"
    // InternalDynamicGoalModel.g:877:1: rule__DGMSpecification__Group__1__Impl : ( ( rule__DGMSpecification__NameAssignment_1 ) ) ;
    public final void rule__DGMSpecification__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:881:1: ( ( ( rule__DGMSpecification__NameAssignment_1 ) ) )
            // InternalDynamicGoalModel.g:882:1: ( ( rule__DGMSpecification__NameAssignment_1 ) )
            {
            // InternalDynamicGoalModel.g:882:1: ( ( rule__DGMSpecification__NameAssignment_1 ) )
            // InternalDynamicGoalModel.g:883:2: ( rule__DGMSpecification__NameAssignment_1 )
            {
             before(grammarAccess.getDGMSpecificationAccess().getNameAssignment_1()); 
            // InternalDynamicGoalModel.g:884:2: ( rule__DGMSpecification__NameAssignment_1 )
            // InternalDynamicGoalModel.g:884:3: rule__DGMSpecification__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDGMSpecificationAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__1__Impl"


    // $ANTLR start "rule__DGMSpecification__Group__2"
    // InternalDynamicGoalModel.g:892:1: rule__DGMSpecification__Group__2 : rule__DGMSpecification__Group__2__Impl rule__DGMSpecification__Group__3 ;
    public final void rule__DGMSpecification__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:896:1: ( rule__DGMSpecification__Group__2__Impl rule__DGMSpecification__Group__3 )
            // InternalDynamicGoalModel.g:897:2: rule__DGMSpecification__Group__2__Impl rule__DGMSpecification__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__DGMSpecification__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__2"


    // $ANTLR start "rule__DGMSpecification__Group__2__Impl"
    // InternalDynamicGoalModel.g:904:1: rule__DGMSpecification__Group__2__Impl : ( '{' ) ;
    public final void rule__DGMSpecification__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:908:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:909:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:909:1: ( '{' )
            // InternalDynamicGoalModel.g:910:2: '{'
            {
             before(grammarAccess.getDGMSpecificationAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__2__Impl"


    // $ANTLR start "rule__DGMSpecification__Group__3"
    // InternalDynamicGoalModel.g:919:1: rule__DGMSpecification__Group__3 : rule__DGMSpecification__Group__3__Impl rule__DGMSpecification__Group__4 ;
    public final void rule__DGMSpecification__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:923:1: ( rule__DGMSpecification__Group__3__Impl rule__DGMSpecification__Group__4 )
            // InternalDynamicGoalModel.g:924:2: rule__DGMSpecification__Group__3__Impl rule__DGMSpecification__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__DGMSpecification__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__3"


    // $ANTLR start "rule__DGMSpecification__Group__3__Impl"
    // InternalDynamicGoalModel.g:931:1: rule__DGMSpecification__Group__3__Impl : ( ( rule__DGMSpecification__Group_3__0 )? ) ;
    public final void rule__DGMSpecification__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:935:1: ( ( ( rule__DGMSpecification__Group_3__0 )? ) )
            // InternalDynamicGoalModel.g:936:1: ( ( rule__DGMSpecification__Group_3__0 )? )
            {
            // InternalDynamicGoalModel.g:936:1: ( ( rule__DGMSpecification__Group_3__0 )? )
            // InternalDynamicGoalModel.g:937:2: ( rule__DGMSpecification__Group_3__0 )?
            {
             before(grammarAccess.getDGMSpecificationAccess().getGroup_3()); 
            // InternalDynamicGoalModel.g:938:2: ( rule__DGMSpecification__Group_3__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==36) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalDynamicGoalModel.g:938:3: rule__DGMSpecification__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DGMSpecification__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDGMSpecificationAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__3__Impl"


    // $ANTLR start "rule__DGMSpecification__Group__4"
    // InternalDynamicGoalModel.g:946:1: rule__DGMSpecification__Group__4 : rule__DGMSpecification__Group__4__Impl rule__DGMSpecification__Group__5 ;
    public final void rule__DGMSpecification__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:950:1: ( rule__DGMSpecification__Group__4__Impl rule__DGMSpecification__Group__5 )
            // InternalDynamicGoalModel.g:951:2: rule__DGMSpecification__Group__4__Impl rule__DGMSpecification__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__DGMSpecification__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__4"


    // $ANTLR start "rule__DGMSpecification__Group__4__Impl"
    // InternalDynamicGoalModel.g:958:1: rule__DGMSpecification__Group__4__Impl : ( ( rule__DGMSpecification__Group_4__0 )? ) ;
    public final void rule__DGMSpecification__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:962:1: ( ( ( rule__DGMSpecification__Group_4__0 )? ) )
            // InternalDynamicGoalModel.g:963:1: ( ( rule__DGMSpecification__Group_4__0 )? )
            {
            // InternalDynamicGoalModel.g:963:1: ( ( rule__DGMSpecification__Group_4__0 )? )
            // InternalDynamicGoalModel.g:964:2: ( rule__DGMSpecification__Group_4__0 )?
            {
             before(grammarAccess.getDGMSpecificationAccess().getGroup_4()); 
            // InternalDynamicGoalModel.g:965:2: ( rule__DGMSpecification__Group_4__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==37) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalDynamicGoalModel.g:965:3: rule__DGMSpecification__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DGMSpecification__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDGMSpecificationAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__4__Impl"


    // $ANTLR start "rule__DGMSpecification__Group__5"
    // InternalDynamicGoalModel.g:973:1: rule__DGMSpecification__Group__5 : rule__DGMSpecification__Group__5__Impl rule__DGMSpecification__Group__6 ;
    public final void rule__DGMSpecification__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:977:1: ( rule__DGMSpecification__Group__5__Impl rule__DGMSpecification__Group__6 )
            // InternalDynamicGoalModel.g:978:2: rule__DGMSpecification__Group__5__Impl rule__DGMSpecification__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__DGMSpecification__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__5"


    // $ANTLR start "rule__DGMSpecification__Group__5__Impl"
    // InternalDynamicGoalModel.g:985:1: rule__DGMSpecification__Group__5__Impl : ( ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 ) ) ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 )* ) ) ;
    public final void rule__DGMSpecification__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:989:1: ( ( ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 ) ) ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 )* ) ) )
            // InternalDynamicGoalModel.g:990:1: ( ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 ) ) ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 )* ) )
            {
            // InternalDynamicGoalModel.g:990:1: ( ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 ) ) ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 )* ) )
            // InternalDynamicGoalModel.g:991:2: ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 ) ) ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 )* )
            {
            // InternalDynamicGoalModel.g:991:2: ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 ) )
            // InternalDynamicGoalModel.g:992:3: ( rule__DGMSpecification__DynamicGoalsAssignment_5 )
            {
             before(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsAssignment_5()); 
            // InternalDynamicGoalModel.g:993:3: ( rule__DGMSpecification__DynamicGoalsAssignment_5 )
            // InternalDynamicGoalModel.g:993:4: rule__DGMSpecification__DynamicGoalsAssignment_5
            {
            pushFollow(FOLLOW_7);
            rule__DGMSpecification__DynamicGoalsAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsAssignment_5()); 

            }

            // InternalDynamicGoalModel.g:996:2: ( ( rule__DGMSpecification__DynamicGoalsAssignment_5 )* )
            // InternalDynamicGoalModel.g:997:3: ( rule__DGMSpecification__DynamicGoalsAssignment_5 )*
            {
             before(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsAssignment_5()); 
            // InternalDynamicGoalModel.g:998:3: ( rule__DGMSpecification__DynamicGoalsAssignment_5 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==38) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:998:4: rule__DGMSpecification__DynamicGoalsAssignment_5
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__DGMSpecification__DynamicGoalsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsAssignment_5()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__5__Impl"


    // $ANTLR start "rule__DGMSpecification__Group__6"
    // InternalDynamicGoalModel.g:1007:1: rule__DGMSpecification__Group__6 : rule__DGMSpecification__Group__6__Impl ;
    public final void rule__DGMSpecification__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1011:1: ( rule__DGMSpecification__Group__6__Impl )
            // InternalDynamicGoalModel.g:1012:2: rule__DGMSpecification__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__6"


    // $ANTLR start "rule__DGMSpecification__Group__6__Impl"
    // InternalDynamicGoalModel.g:1018:1: rule__DGMSpecification__Group__6__Impl : ( '}' ) ;
    public final void rule__DGMSpecification__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1022:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:1023:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:1023:1: ( '}' )
            // InternalDynamicGoalModel.g:1024:2: '}'
            {
             before(grammarAccess.getDGMSpecificationAccess().getRightCurlyBracketKeyword_6()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group__6__Impl"


    // $ANTLR start "rule__DGMSpecification__Group_3__0"
    // InternalDynamicGoalModel.g:1034:1: rule__DGMSpecification__Group_3__0 : rule__DGMSpecification__Group_3__0__Impl rule__DGMSpecification__Group_3__1 ;
    public final void rule__DGMSpecification__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1038:1: ( rule__DGMSpecification__Group_3__0__Impl rule__DGMSpecification__Group_3__1 )
            // InternalDynamicGoalModel.g:1039:2: rule__DGMSpecification__Group_3__0__Impl rule__DGMSpecification__Group_3__1
            {
            pushFollow(FOLLOW_8);
            rule__DGMSpecification__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_3__0"


    // $ANTLR start "rule__DGMSpecification__Group_3__0__Impl"
    // InternalDynamicGoalModel.g:1046:1: rule__DGMSpecification__Group_3__0__Impl : ( 'description' ) ;
    public final void rule__DGMSpecification__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1050:1: ( ( 'description' ) )
            // InternalDynamicGoalModel.g:1051:1: ( 'description' )
            {
            // InternalDynamicGoalModel.g:1051:1: ( 'description' )
            // InternalDynamicGoalModel.g:1052:2: 'description'
            {
             before(grammarAccess.getDGMSpecificationAccess().getDescriptionKeyword_3_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getDescriptionKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_3__0__Impl"


    // $ANTLR start "rule__DGMSpecification__Group_3__1"
    // InternalDynamicGoalModel.g:1061:1: rule__DGMSpecification__Group_3__1 : rule__DGMSpecification__Group_3__1__Impl ;
    public final void rule__DGMSpecification__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1065:1: ( rule__DGMSpecification__Group_3__1__Impl )
            // InternalDynamicGoalModel.g:1066:2: rule__DGMSpecification__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_3__1"


    // $ANTLR start "rule__DGMSpecification__Group_3__1__Impl"
    // InternalDynamicGoalModel.g:1072:1: rule__DGMSpecification__Group_3__1__Impl : ( ( rule__DGMSpecification__DescriptionAssignment_3_1 ) ) ;
    public final void rule__DGMSpecification__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1076:1: ( ( ( rule__DGMSpecification__DescriptionAssignment_3_1 ) ) )
            // InternalDynamicGoalModel.g:1077:1: ( ( rule__DGMSpecification__DescriptionAssignment_3_1 ) )
            {
            // InternalDynamicGoalModel.g:1077:1: ( ( rule__DGMSpecification__DescriptionAssignment_3_1 ) )
            // InternalDynamicGoalModel.g:1078:2: ( rule__DGMSpecification__DescriptionAssignment_3_1 )
            {
             before(grammarAccess.getDGMSpecificationAccess().getDescriptionAssignment_3_1()); 
            // InternalDynamicGoalModel.g:1079:2: ( rule__DGMSpecification__DescriptionAssignment_3_1 )
            // InternalDynamicGoalModel.g:1079:3: rule__DGMSpecification__DescriptionAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__DescriptionAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getDGMSpecificationAccess().getDescriptionAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_3__1__Impl"


    // $ANTLR start "rule__DGMSpecification__Group_4__0"
    // InternalDynamicGoalModel.g:1088:1: rule__DGMSpecification__Group_4__0 : rule__DGMSpecification__Group_4__0__Impl rule__DGMSpecification__Group_4__1 ;
    public final void rule__DGMSpecification__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1092:1: ( rule__DGMSpecification__Group_4__0__Impl rule__DGMSpecification__Group_4__1 )
            // InternalDynamicGoalModel.g:1093:2: rule__DGMSpecification__Group_4__0__Impl rule__DGMSpecification__Group_4__1
            {
            pushFollow(FOLLOW_9);
            rule__DGMSpecification__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_4__0"


    // $ANTLR start "rule__DGMSpecification__Group_4__0__Impl"
    // InternalDynamicGoalModel.g:1100:1: rule__DGMSpecification__Group_4__0__Impl : ( 'operationalMode' ) ;
    public final void rule__DGMSpecification__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1104:1: ( ( 'operationalMode' ) )
            // InternalDynamicGoalModel.g:1105:1: ( 'operationalMode' )
            {
            // InternalDynamicGoalModel.g:1105:1: ( 'operationalMode' )
            // InternalDynamicGoalModel.g:1106:2: 'operationalMode'
            {
             before(grammarAccess.getDGMSpecificationAccess().getOperationalModeKeyword_4_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getOperationalModeKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_4__0__Impl"


    // $ANTLR start "rule__DGMSpecification__Group_4__1"
    // InternalDynamicGoalModel.g:1115:1: rule__DGMSpecification__Group_4__1 : rule__DGMSpecification__Group_4__1__Impl ;
    public final void rule__DGMSpecification__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1119:1: ( rule__DGMSpecification__Group_4__1__Impl )
            // InternalDynamicGoalModel.g:1120:2: rule__DGMSpecification__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_4__1"


    // $ANTLR start "rule__DGMSpecification__Group_4__1__Impl"
    // InternalDynamicGoalModel.g:1126:1: rule__DGMSpecification__Group_4__1__Impl : ( ( rule__DGMSpecification__OperationalModeAssignment_4_1 ) ) ;
    public final void rule__DGMSpecification__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1130:1: ( ( ( rule__DGMSpecification__OperationalModeAssignment_4_1 ) ) )
            // InternalDynamicGoalModel.g:1131:1: ( ( rule__DGMSpecification__OperationalModeAssignment_4_1 ) )
            {
            // InternalDynamicGoalModel.g:1131:1: ( ( rule__DGMSpecification__OperationalModeAssignment_4_1 ) )
            // InternalDynamicGoalModel.g:1132:2: ( rule__DGMSpecification__OperationalModeAssignment_4_1 )
            {
             before(grammarAccess.getDGMSpecificationAccess().getOperationalModeAssignment_4_1()); 
            // InternalDynamicGoalModel.g:1133:2: ( rule__DGMSpecification__OperationalModeAssignment_4_1 )
            // InternalDynamicGoalModel.g:1133:3: rule__DGMSpecification__OperationalModeAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__DGMSpecification__OperationalModeAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getDGMSpecificationAccess().getOperationalModeAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__Group_4__1__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__0"
    // InternalDynamicGoalModel.g:1142:1: rule__DynamicGoal__Group__0 : rule__DynamicGoal__Group__0__Impl rule__DynamicGoal__Group__1 ;
    public final void rule__DynamicGoal__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1146:1: ( rule__DynamicGoal__Group__0__Impl rule__DynamicGoal__Group__1 )
            // InternalDynamicGoalModel.g:1147:2: rule__DynamicGoal__Group__0__Impl rule__DynamicGoal__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__DynamicGoal__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__0"


    // $ANTLR start "rule__DynamicGoal__Group__0__Impl"
    // InternalDynamicGoalModel.g:1154:1: rule__DynamicGoal__Group__0__Impl : ( 'DynamicGoal' ) ;
    public final void rule__DynamicGoal__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1158:1: ( ( 'DynamicGoal' ) )
            // InternalDynamicGoalModel.g:1159:1: ( 'DynamicGoal' )
            {
            // InternalDynamicGoalModel.g:1159:1: ( 'DynamicGoal' )
            // InternalDynamicGoalModel.g:1160:2: 'DynamicGoal'
            {
             before(grammarAccess.getDynamicGoalAccess().getDynamicGoalKeyword_0()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getDynamicGoalKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__0__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__1"
    // InternalDynamicGoalModel.g:1169:1: rule__DynamicGoal__Group__1 : rule__DynamicGoal__Group__1__Impl rule__DynamicGoal__Group__2 ;
    public final void rule__DynamicGoal__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1173:1: ( rule__DynamicGoal__Group__1__Impl rule__DynamicGoal__Group__2 )
            // InternalDynamicGoalModel.g:1174:2: rule__DynamicGoal__Group__1__Impl rule__DynamicGoal__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__DynamicGoal__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__1"


    // $ANTLR start "rule__DynamicGoal__Group__1__Impl"
    // InternalDynamicGoalModel.g:1181:1: rule__DynamicGoal__Group__1__Impl : ( ( rule__DynamicGoal__NameAssignment_1 ) ) ;
    public final void rule__DynamicGoal__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1185:1: ( ( ( rule__DynamicGoal__NameAssignment_1 ) ) )
            // InternalDynamicGoalModel.g:1186:1: ( ( rule__DynamicGoal__NameAssignment_1 ) )
            {
            // InternalDynamicGoalModel.g:1186:1: ( ( rule__DynamicGoal__NameAssignment_1 ) )
            // InternalDynamicGoalModel.g:1187:2: ( rule__DynamicGoal__NameAssignment_1 )
            {
             before(grammarAccess.getDynamicGoalAccess().getNameAssignment_1()); 
            // InternalDynamicGoalModel.g:1188:2: ( rule__DynamicGoal__NameAssignment_1 )
            // InternalDynamicGoalModel.g:1188:3: rule__DynamicGoal__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__1__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__2"
    // InternalDynamicGoalModel.g:1196:1: rule__DynamicGoal__Group__2 : rule__DynamicGoal__Group__2__Impl rule__DynamicGoal__Group__3 ;
    public final void rule__DynamicGoal__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1200:1: ( rule__DynamicGoal__Group__2__Impl rule__DynamicGoal__Group__3 )
            // InternalDynamicGoalModel.g:1201:2: rule__DynamicGoal__Group__2__Impl rule__DynamicGoal__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__DynamicGoal__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__2"


    // $ANTLR start "rule__DynamicGoal__Group__2__Impl"
    // InternalDynamicGoalModel.g:1208:1: rule__DynamicGoal__Group__2__Impl : ( '{' ) ;
    public final void rule__DynamicGoal__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1212:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:1213:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:1213:1: ( '{' )
            // InternalDynamicGoalModel.g:1214:2: '{'
            {
             before(grammarAccess.getDynamicGoalAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__2__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__3"
    // InternalDynamicGoalModel.g:1223:1: rule__DynamicGoal__Group__3 : rule__DynamicGoal__Group__3__Impl rule__DynamicGoal__Group__4 ;
    public final void rule__DynamicGoal__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1227:1: ( rule__DynamicGoal__Group__3__Impl rule__DynamicGoal__Group__4 )
            // InternalDynamicGoalModel.g:1228:2: rule__DynamicGoal__Group__3__Impl rule__DynamicGoal__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__DynamicGoal__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__3"


    // $ANTLR start "rule__DynamicGoal__Group__3__Impl"
    // InternalDynamicGoalModel.g:1235:1: rule__DynamicGoal__Group__3__Impl : ( 'title' ) ;
    public final void rule__DynamicGoal__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1239:1: ( ( 'title' ) )
            // InternalDynamicGoalModel.g:1240:1: ( 'title' )
            {
            // InternalDynamicGoalModel.g:1240:1: ( 'title' )
            // InternalDynamicGoalModel.g:1241:2: 'title'
            {
             before(grammarAccess.getDynamicGoalAccess().getTitleKeyword_3()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getTitleKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__3__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__4"
    // InternalDynamicGoalModel.g:1250:1: rule__DynamicGoal__Group__4 : rule__DynamicGoal__Group__4__Impl rule__DynamicGoal__Group__5 ;
    public final void rule__DynamicGoal__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1254:1: ( rule__DynamicGoal__Group__4__Impl rule__DynamicGoal__Group__5 )
            // InternalDynamicGoalModel.g:1255:2: rule__DynamicGoal__Group__4__Impl rule__DynamicGoal__Group__5
            {
            pushFollow(FOLLOW_11);
            rule__DynamicGoal__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__4"


    // $ANTLR start "rule__DynamicGoal__Group__4__Impl"
    // InternalDynamicGoalModel.g:1262:1: rule__DynamicGoal__Group__4__Impl : ( ( rule__DynamicGoal__TitleAssignment_4 ) ) ;
    public final void rule__DynamicGoal__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1266:1: ( ( ( rule__DynamicGoal__TitleAssignment_4 ) ) )
            // InternalDynamicGoalModel.g:1267:1: ( ( rule__DynamicGoal__TitleAssignment_4 ) )
            {
            // InternalDynamicGoalModel.g:1267:1: ( ( rule__DynamicGoal__TitleAssignment_4 ) )
            // InternalDynamicGoalModel.g:1268:2: ( rule__DynamicGoal__TitleAssignment_4 )
            {
             before(grammarAccess.getDynamicGoalAccess().getTitleAssignment_4()); 
            // InternalDynamicGoalModel.g:1269:2: ( rule__DynamicGoal__TitleAssignment_4 )
            // InternalDynamicGoalModel.g:1269:3: rule__DynamicGoal__TitleAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__TitleAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getTitleAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__4__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__5"
    // InternalDynamicGoalModel.g:1277:1: rule__DynamicGoal__Group__5 : rule__DynamicGoal__Group__5__Impl rule__DynamicGoal__Group__6 ;
    public final void rule__DynamicGoal__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1281:1: ( rule__DynamicGoal__Group__5__Impl rule__DynamicGoal__Group__6 )
            // InternalDynamicGoalModel.g:1282:2: rule__DynamicGoal__Group__5__Impl rule__DynamicGoal__Group__6
            {
            pushFollow(FOLLOW_11);
            rule__DynamicGoal__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__5"


    // $ANTLR start "rule__DynamicGoal__Group__5__Impl"
    // InternalDynamicGoalModel.g:1289:1: rule__DynamicGoal__Group__5__Impl : ( ( rule__DynamicGoal__Group_5__0 )? ) ;
    public final void rule__DynamicGoal__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1293:1: ( ( ( rule__DynamicGoal__Group_5__0 )? ) )
            // InternalDynamicGoalModel.g:1294:1: ( ( rule__DynamicGoal__Group_5__0 )? )
            {
            // InternalDynamicGoalModel.g:1294:1: ( ( rule__DynamicGoal__Group_5__0 )? )
            // InternalDynamicGoalModel.g:1295:2: ( rule__DynamicGoal__Group_5__0 )?
            {
             before(grammarAccess.getDynamicGoalAccess().getGroup_5()); 
            // InternalDynamicGoalModel.g:1296:2: ( rule__DynamicGoal__Group_5__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==40) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalDynamicGoalModel.g:1296:3: rule__DynamicGoal__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DynamicGoal__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDynamicGoalAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__5__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__6"
    // InternalDynamicGoalModel.g:1304:1: rule__DynamicGoal__Group__6 : rule__DynamicGoal__Group__6__Impl rule__DynamicGoal__Group__7 ;
    public final void rule__DynamicGoal__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1308:1: ( rule__DynamicGoal__Group__6__Impl rule__DynamicGoal__Group__7 )
            // InternalDynamicGoalModel.g:1309:2: rule__DynamicGoal__Group__6__Impl rule__DynamicGoal__Group__7
            {
            pushFollow(FOLLOW_12);
            rule__DynamicGoal__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__6"


    // $ANTLR start "rule__DynamicGoal__Group__6__Impl"
    // InternalDynamicGoalModel.g:1316:1: rule__DynamicGoal__Group__6__Impl : ( ( rule__DynamicGoal__ObservableActionAssignment_6 ) ) ;
    public final void rule__DynamicGoal__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1320:1: ( ( ( rule__DynamicGoal__ObservableActionAssignment_6 ) ) )
            // InternalDynamicGoalModel.g:1321:1: ( ( rule__DynamicGoal__ObservableActionAssignment_6 ) )
            {
            // InternalDynamicGoalModel.g:1321:1: ( ( rule__DynamicGoal__ObservableActionAssignment_6 ) )
            // InternalDynamicGoalModel.g:1322:2: ( rule__DynamicGoal__ObservableActionAssignment_6 )
            {
             before(grammarAccess.getDynamicGoalAccess().getObservableActionAssignment_6()); 
            // InternalDynamicGoalModel.g:1323:2: ( rule__DynamicGoal__ObservableActionAssignment_6 )
            // InternalDynamicGoalModel.g:1323:3: rule__DynamicGoal__ObservableActionAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__ObservableActionAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getObservableActionAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__6__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__7"
    // InternalDynamicGoalModel.g:1331:1: rule__DynamicGoal__Group__7 : rule__DynamicGoal__Group__7__Impl rule__DynamicGoal__Group__8 ;
    public final void rule__DynamicGoal__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1335:1: ( rule__DynamicGoal__Group__7__Impl rule__DynamicGoal__Group__8 )
            // InternalDynamicGoalModel.g:1336:2: rule__DynamicGoal__Group__7__Impl rule__DynamicGoal__Group__8
            {
            pushFollow(FOLLOW_13);
            rule__DynamicGoal__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__7"


    // $ANTLR start "rule__DynamicGoal__Group__7__Impl"
    // InternalDynamicGoalModel.g:1343:1: rule__DynamicGoal__Group__7__Impl : ( ( ( rule__DynamicGoal__EvidenceAssignment_7 ) ) ( ( rule__DynamicGoal__EvidenceAssignment_7 )* ) ) ;
    public final void rule__DynamicGoal__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1347:1: ( ( ( ( rule__DynamicGoal__EvidenceAssignment_7 ) ) ( ( rule__DynamicGoal__EvidenceAssignment_7 )* ) ) )
            // InternalDynamicGoalModel.g:1348:1: ( ( ( rule__DynamicGoal__EvidenceAssignment_7 ) ) ( ( rule__DynamicGoal__EvidenceAssignment_7 )* ) )
            {
            // InternalDynamicGoalModel.g:1348:1: ( ( ( rule__DynamicGoal__EvidenceAssignment_7 ) ) ( ( rule__DynamicGoal__EvidenceAssignment_7 )* ) )
            // InternalDynamicGoalModel.g:1349:2: ( ( rule__DynamicGoal__EvidenceAssignment_7 ) ) ( ( rule__DynamicGoal__EvidenceAssignment_7 )* )
            {
            // InternalDynamicGoalModel.g:1349:2: ( ( rule__DynamicGoal__EvidenceAssignment_7 ) )
            // InternalDynamicGoalModel.g:1350:3: ( rule__DynamicGoal__EvidenceAssignment_7 )
            {
             before(grammarAccess.getDynamicGoalAccess().getEvidenceAssignment_7()); 
            // InternalDynamicGoalModel.g:1351:3: ( rule__DynamicGoal__EvidenceAssignment_7 )
            // InternalDynamicGoalModel.g:1351:4: rule__DynamicGoal__EvidenceAssignment_7
            {
            pushFollow(FOLLOW_14);
            rule__DynamicGoal__EvidenceAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getEvidenceAssignment_7()); 

            }

            // InternalDynamicGoalModel.g:1354:2: ( ( rule__DynamicGoal__EvidenceAssignment_7 )* )
            // InternalDynamicGoalModel.g:1355:3: ( rule__DynamicGoal__EvidenceAssignment_7 )*
            {
             before(grammarAccess.getDynamicGoalAccess().getEvidenceAssignment_7()); 
            // InternalDynamicGoalModel.g:1356:3: ( rule__DynamicGoal__EvidenceAssignment_7 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==48) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:1356:4: rule__DynamicGoal__EvidenceAssignment_7
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__DynamicGoal__EvidenceAssignment_7();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getDynamicGoalAccess().getEvidenceAssignment_7()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__7__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__8"
    // InternalDynamicGoalModel.g:1365:1: rule__DynamicGoal__Group__8 : rule__DynamicGoal__Group__8__Impl rule__DynamicGoal__Group__9 ;
    public final void rule__DynamicGoal__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1369:1: ( rule__DynamicGoal__Group__8__Impl rule__DynamicGoal__Group__9 )
            // InternalDynamicGoalModel.g:1370:2: rule__DynamicGoal__Group__8__Impl rule__DynamicGoal__Group__9
            {
            pushFollow(FOLLOW_15);
            rule__DynamicGoal__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__8"


    // $ANTLR start "rule__DynamicGoal__Group__8__Impl"
    // InternalDynamicGoalModel.g:1377:1: rule__DynamicGoal__Group__8__Impl : ( ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 ) ) ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 )* ) ) ;
    public final void rule__DynamicGoal__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1381:1: ( ( ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 ) ) ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 )* ) ) )
            // InternalDynamicGoalModel.g:1382:1: ( ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 ) ) ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 )* ) )
            {
            // InternalDynamicGoalModel.g:1382:1: ( ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 ) ) ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 )* ) )
            // InternalDynamicGoalModel.g:1383:2: ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 ) ) ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 )* )
            {
            // InternalDynamicGoalModel.g:1383:2: ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 ) )
            // InternalDynamicGoalModel.g:1384:3: ( rule__DynamicGoal__GoalHypothesesAssignment_8 )
            {
             before(grammarAccess.getDynamicGoalAccess().getGoalHypothesesAssignment_8()); 
            // InternalDynamicGoalModel.g:1385:3: ( rule__DynamicGoal__GoalHypothesesAssignment_8 )
            // InternalDynamicGoalModel.g:1385:4: rule__DynamicGoal__GoalHypothesesAssignment_8
            {
            pushFollow(FOLLOW_16);
            rule__DynamicGoal__GoalHypothesesAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getGoalHypothesesAssignment_8()); 

            }

            // InternalDynamicGoalModel.g:1388:2: ( ( rule__DynamicGoal__GoalHypothesesAssignment_8 )* )
            // InternalDynamicGoalModel.g:1389:3: ( rule__DynamicGoal__GoalHypothesesAssignment_8 )*
            {
             before(grammarAccess.getDynamicGoalAccess().getGoalHypothesesAssignment_8()); 
            // InternalDynamicGoalModel.g:1390:3: ( rule__DynamicGoal__GoalHypothesesAssignment_8 )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==55) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:1390:4: rule__DynamicGoal__GoalHypothesesAssignment_8
            	    {
            	    pushFollow(FOLLOW_16);
            	    rule__DynamicGoal__GoalHypothesesAssignment_8();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

             after(grammarAccess.getDynamicGoalAccess().getGoalHypothesesAssignment_8()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__8__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__9"
    // InternalDynamicGoalModel.g:1399:1: rule__DynamicGoal__Group__9 : rule__DynamicGoal__Group__9__Impl rule__DynamicGoal__Group__10 ;
    public final void rule__DynamicGoal__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1403:1: ( rule__DynamicGoal__Group__9__Impl rule__DynamicGoal__Group__10 )
            // InternalDynamicGoalModel.g:1404:2: rule__DynamicGoal__Group__9__Impl rule__DynamicGoal__Group__10
            {
            pushFollow(FOLLOW_15);
            rule__DynamicGoal__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__9"


    // $ANTLR start "rule__DynamicGoal__Group__9__Impl"
    // InternalDynamicGoalModel.g:1411:1: rule__DynamicGoal__Group__9__Impl : ( ( rule__DynamicGoal__Group_9__0 )? ) ;
    public final void rule__DynamicGoal__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1415:1: ( ( ( rule__DynamicGoal__Group_9__0 )? ) )
            // InternalDynamicGoalModel.g:1416:1: ( ( rule__DynamicGoal__Group_9__0 )? )
            {
            // InternalDynamicGoalModel.g:1416:1: ( ( rule__DynamicGoal__Group_9__0 )? )
            // InternalDynamicGoalModel.g:1417:2: ( rule__DynamicGoal__Group_9__0 )?
            {
             before(grammarAccess.getDynamicGoalAccess().getGroup_9()); 
            // InternalDynamicGoalModel.g:1418:2: ( rule__DynamicGoal__Group_9__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==41) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalDynamicGoalModel.g:1418:3: rule__DynamicGoal__Group_9__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DynamicGoal__Group_9__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDynamicGoalAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__9__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__10"
    // InternalDynamicGoalModel.g:1426:1: rule__DynamicGoal__Group__10 : rule__DynamicGoal__Group__10__Impl rule__DynamicGoal__Group__11 ;
    public final void rule__DynamicGoal__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1430:1: ( rule__DynamicGoal__Group__10__Impl rule__DynamicGoal__Group__11 )
            // InternalDynamicGoalModel.g:1431:2: rule__DynamicGoal__Group__10__Impl rule__DynamicGoal__Group__11
            {
            pushFollow(FOLLOW_15);
            rule__DynamicGoal__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__10"


    // $ANTLR start "rule__DynamicGoal__Group__10__Impl"
    // InternalDynamicGoalModel.g:1438:1: rule__DynamicGoal__Group__10__Impl : ( ( rule__DynamicGoal__Group_10__0 )? ) ;
    public final void rule__DynamicGoal__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1442:1: ( ( ( rule__DynamicGoal__Group_10__0 )? ) )
            // InternalDynamicGoalModel.g:1443:1: ( ( rule__DynamicGoal__Group_10__0 )? )
            {
            // InternalDynamicGoalModel.g:1443:1: ( ( rule__DynamicGoal__Group_10__0 )? )
            // InternalDynamicGoalModel.g:1444:2: ( rule__DynamicGoal__Group_10__0 )?
            {
             before(grammarAccess.getDynamicGoalAccess().getGroup_10()); 
            // InternalDynamicGoalModel.g:1445:2: ( rule__DynamicGoal__Group_10__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==42) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalDynamicGoalModel.g:1445:3: rule__DynamicGoal__Group_10__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DynamicGoal__Group_10__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDynamicGoalAccess().getGroup_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__10__Impl"


    // $ANTLR start "rule__DynamicGoal__Group__11"
    // InternalDynamicGoalModel.g:1453:1: rule__DynamicGoal__Group__11 : rule__DynamicGoal__Group__11__Impl ;
    public final void rule__DynamicGoal__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1457:1: ( rule__DynamicGoal__Group__11__Impl )
            // InternalDynamicGoalModel.g:1458:2: rule__DynamicGoal__Group__11__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group__11__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__11"


    // $ANTLR start "rule__DynamicGoal__Group__11__Impl"
    // InternalDynamicGoalModel.g:1464:1: rule__DynamicGoal__Group__11__Impl : ( '}' ) ;
    public final void rule__DynamicGoal__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1468:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:1469:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:1469:1: ( '}' )
            // InternalDynamicGoalModel.g:1470:2: '}'
            {
             before(grammarAccess.getDynamicGoalAccess().getRightCurlyBracketKeyword_11()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getRightCurlyBracketKeyword_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group__11__Impl"


    // $ANTLR start "rule__DynamicGoal__Group_5__0"
    // InternalDynamicGoalModel.g:1480:1: rule__DynamicGoal__Group_5__0 : rule__DynamicGoal__Group_5__0__Impl rule__DynamicGoal__Group_5__1 ;
    public final void rule__DynamicGoal__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1484:1: ( rule__DynamicGoal__Group_5__0__Impl rule__DynamicGoal__Group_5__1 )
            // InternalDynamicGoalModel.g:1485:2: rule__DynamicGoal__Group_5__0__Impl rule__DynamicGoal__Group_5__1
            {
            pushFollow(FOLLOW_8);
            rule__DynamicGoal__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_5__0"


    // $ANTLR start "rule__DynamicGoal__Group_5__0__Impl"
    // InternalDynamicGoalModel.g:1492:1: rule__DynamicGoal__Group_5__0__Impl : ( 'useCaseRef' ) ;
    public final void rule__DynamicGoal__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1496:1: ( ( 'useCaseRef' ) )
            // InternalDynamicGoalModel.g:1497:1: ( 'useCaseRef' )
            {
            // InternalDynamicGoalModel.g:1497:1: ( 'useCaseRef' )
            // InternalDynamicGoalModel.g:1498:2: 'useCaseRef'
            {
             before(grammarAccess.getDynamicGoalAccess().getUseCaseRefKeyword_5_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getUseCaseRefKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_5__0__Impl"


    // $ANTLR start "rule__DynamicGoal__Group_5__1"
    // InternalDynamicGoalModel.g:1507:1: rule__DynamicGoal__Group_5__1 : rule__DynamicGoal__Group_5__1__Impl ;
    public final void rule__DynamicGoal__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1511:1: ( rule__DynamicGoal__Group_5__1__Impl )
            // InternalDynamicGoalModel.g:1512:2: rule__DynamicGoal__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_5__1"


    // $ANTLR start "rule__DynamicGoal__Group_5__1__Impl"
    // InternalDynamicGoalModel.g:1518:1: rule__DynamicGoal__Group_5__1__Impl : ( ( rule__DynamicGoal__UseCaseRefAssignment_5_1 ) ) ;
    public final void rule__DynamicGoal__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1522:1: ( ( ( rule__DynamicGoal__UseCaseRefAssignment_5_1 ) ) )
            // InternalDynamicGoalModel.g:1523:1: ( ( rule__DynamicGoal__UseCaseRefAssignment_5_1 ) )
            {
            // InternalDynamicGoalModel.g:1523:1: ( ( rule__DynamicGoal__UseCaseRefAssignment_5_1 ) )
            // InternalDynamicGoalModel.g:1524:2: ( rule__DynamicGoal__UseCaseRefAssignment_5_1 )
            {
             before(grammarAccess.getDynamicGoalAccess().getUseCaseRefAssignment_5_1()); 
            // InternalDynamicGoalModel.g:1525:2: ( rule__DynamicGoal__UseCaseRefAssignment_5_1 )
            // InternalDynamicGoalModel.g:1525:3: rule__DynamicGoal__UseCaseRefAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__UseCaseRefAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getUseCaseRefAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_5__1__Impl"


    // $ANTLR start "rule__DynamicGoal__Group_9__0"
    // InternalDynamicGoalModel.g:1534:1: rule__DynamicGoal__Group_9__0 : rule__DynamicGoal__Group_9__0__Impl rule__DynamicGoal__Group_9__1 ;
    public final void rule__DynamicGoal__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1538:1: ( rule__DynamicGoal__Group_9__0__Impl rule__DynamicGoal__Group_9__1 )
            // InternalDynamicGoalModel.g:1539:2: rule__DynamicGoal__Group_9__0__Impl rule__DynamicGoal__Group_9__1
            {
            pushFollow(FOLLOW_17);
            rule__DynamicGoal__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_9__0"


    // $ANTLR start "rule__DynamicGoal__Group_9__0__Impl"
    // InternalDynamicGoalModel.g:1546:1: rule__DynamicGoal__Group_9__0__Impl : ( 'precedence' ) ;
    public final void rule__DynamicGoal__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1550:1: ( ( 'precedence' ) )
            // InternalDynamicGoalModel.g:1551:1: ( 'precedence' )
            {
            // InternalDynamicGoalModel.g:1551:1: ( 'precedence' )
            // InternalDynamicGoalModel.g:1552:2: 'precedence'
            {
             before(grammarAccess.getDynamicGoalAccess().getPrecedenceKeyword_9_0()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getPrecedenceKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_9__0__Impl"


    // $ANTLR start "rule__DynamicGoal__Group_9__1"
    // InternalDynamicGoalModel.g:1561:1: rule__DynamicGoal__Group_9__1 : rule__DynamicGoal__Group_9__1__Impl ;
    public final void rule__DynamicGoal__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1565:1: ( rule__DynamicGoal__Group_9__1__Impl )
            // InternalDynamicGoalModel.g:1566:2: rule__DynamicGoal__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group_9__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_9__1"


    // $ANTLR start "rule__DynamicGoal__Group_9__1__Impl"
    // InternalDynamicGoalModel.g:1572:1: rule__DynamicGoal__Group_9__1__Impl : ( ( rule__DynamicGoal__PrecedenceAssignment_9_1 ) ) ;
    public final void rule__DynamicGoal__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1576:1: ( ( ( rule__DynamicGoal__PrecedenceAssignment_9_1 ) ) )
            // InternalDynamicGoalModel.g:1577:1: ( ( rule__DynamicGoal__PrecedenceAssignment_9_1 ) )
            {
            // InternalDynamicGoalModel.g:1577:1: ( ( rule__DynamicGoal__PrecedenceAssignment_9_1 ) )
            // InternalDynamicGoalModel.g:1578:2: ( rule__DynamicGoal__PrecedenceAssignment_9_1 )
            {
             before(grammarAccess.getDynamicGoalAccess().getPrecedenceAssignment_9_1()); 
            // InternalDynamicGoalModel.g:1579:2: ( rule__DynamicGoal__PrecedenceAssignment_9_1 )
            // InternalDynamicGoalModel.g:1579:3: rule__DynamicGoal__PrecedenceAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__PrecedenceAssignment_9_1();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getPrecedenceAssignment_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_9__1__Impl"


    // $ANTLR start "rule__DynamicGoal__Group_10__0"
    // InternalDynamicGoalModel.g:1588:1: rule__DynamicGoal__Group_10__0 : rule__DynamicGoal__Group_10__0__Impl rule__DynamicGoal__Group_10__1 ;
    public final void rule__DynamicGoal__Group_10__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1592:1: ( rule__DynamicGoal__Group_10__0__Impl rule__DynamicGoal__Group_10__1 )
            // InternalDynamicGoalModel.g:1593:2: rule__DynamicGoal__Group_10__0__Impl rule__DynamicGoal__Group_10__1
            {
            pushFollow(FOLLOW_18);
            rule__DynamicGoal__Group_10__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group_10__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_10__0"


    // $ANTLR start "rule__DynamicGoal__Group_10__0__Impl"
    // InternalDynamicGoalModel.g:1600:1: rule__DynamicGoal__Group_10__0__Impl : ( 'escalation' ) ;
    public final void rule__DynamicGoal__Group_10__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1604:1: ( ( 'escalation' ) )
            // InternalDynamicGoalModel.g:1605:1: ( 'escalation' )
            {
            // InternalDynamicGoalModel.g:1605:1: ( 'escalation' )
            // InternalDynamicGoalModel.g:1606:2: 'escalation'
            {
             before(grammarAccess.getDynamicGoalAccess().getEscalationKeyword_10_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getEscalationKeyword_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_10__0__Impl"


    // $ANTLR start "rule__DynamicGoal__Group_10__1"
    // InternalDynamicGoalModel.g:1615:1: rule__DynamicGoal__Group_10__1 : rule__DynamicGoal__Group_10__1__Impl ;
    public final void rule__DynamicGoal__Group_10__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1619:1: ( rule__DynamicGoal__Group_10__1__Impl )
            // InternalDynamicGoalModel.g:1620:2: rule__DynamicGoal__Group_10__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__Group_10__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_10__1"


    // $ANTLR start "rule__DynamicGoal__Group_10__1__Impl"
    // InternalDynamicGoalModel.g:1626:1: rule__DynamicGoal__Group_10__1__Impl : ( ( rule__DynamicGoal__EscalationAssignment_10_1 ) ) ;
    public final void rule__DynamicGoal__Group_10__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1630:1: ( ( ( rule__DynamicGoal__EscalationAssignment_10_1 ) ) )
            // InternalDynamicGoalModel.g:1631:1: ( ( rule__DynamicGoal__EscalationAssignment_10_1 ) )
            {
            // InternalDynamicGoalModel.g:1631:1: ( ( rule__DynamicGoal__EscalationAssignment_10_1 ) )
            // InternalDynamicGoalModel.g:1632:2: ( rule__DynamicGoal__EscalationAssignment_10_1 )
            {
             before(grammarAccess.getDynamicGoalAccess().getEscalationAssignment_10_1()); 
            // InternalDynamicGoalModel.g:1633:2: ( rule__DynamicGoal__EscalationAssignment_10_1 )
            // InternalDynamicGoalModel.g:1633:3: rule__DynamicGoal__EscalationAssignment_10_1
            {
            pushFollow(FOLLOW_2);
            rule__DynamicGoal__EscalationAssignment_10_1();

            state._fsp--;


            }

             after(grammarAccess.getDynamicGoalAccess().getEscalationAssignment_10_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__Group_10__1__Impl"


    // $ANTLR start "rule__ObservableAction__Group__0"
    // InternalDynamicGoalModel.g:1642:1: rule__ObservableAction__Group__0 : rule__ObservableAction__Group__0__Impl rule__ObservableAction__Group__1 ;
    public final void rule__ObservableAction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1646:1: ( rule__ObservableAction__Group__0__Impl rule__ObservableAction__Group__1 )
            // InternalDynamicGoalModel.g:1647:2: rule__ObservableAction__Group__0__Impl rule__ObservableAction__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__ObservableAction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__0"


    // $ANTLR start "rule__ObservableAction__Group__0__Impl"
    // InternalDynamicGoalModel.g:1654:1: rule__ObservableAction__Group__0__Impl : ( 'ObservableAction' ) ;
    public final void rule__ObservableAction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1658:1: ( ( 'ObservableAction' ) )
            // InternalDynamicGoalModel.g:1659:1: ( 'ObservableAction' )
            {
            // InternalDynamicGoalModel.g:1659:1: ( 'ObservableAction' )
            // InternalDynamicGoalModel.g:1660:2: 'ObservableAction'
            {
             before(grammarAccess.getObservableActionAccess().getObservableActionKeyword_0()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getObservableActionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__0__Impl"


    // $ANTLR start "rule__ObservableAction__Group__1"
    // InternalDynamicGoalModel.g:1669:1: rule__ObservableAction__Group__1 : rule__ObservableAction__Group__1__Impl rule__ObservableAction__Group__2 ;
    public final void rule__ObservableAction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1673:1: ( rule__ObservableAction__Group__1__Impl rule__ObservableAction__Group__2 )
            // InternalDynamicGoalModel.g:1674:2: rule__ObservableAction__Group__1__Impl rule__ObservableAction__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__ObservableAction__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__1"


    // $ANTLR start "rule__ObservableAction__Group__1__Impl"
    // InternalDynamicGoalModel.g:1681:1: rule__ObservableAction__Group__1__Impl : ( '{' ) ;
    public final void rule__ObservableAction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1685:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:1686:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:1686:1: ( '{' )
            // InternalDynamicGoalModel.g:1687:2: '{'
            {
             before(grammarAccess.getObservableActionAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__1__Impl"


    // $ANTLR start "rule__ObservableAction__Group__2"
    // InternalDynamicGoalModel.g:1696:1: rule__ObservableAction__Group__2 : rule__ObservableAction__Group__2__Impl rule__ObservableAction__Group__3 ;
    public final void rule__ObservableAction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1700:1: ( rule__ObservableAction__Group__2__Impl rule__ObservableAction__Group__3 )
            // InternalDynamicGoalModel.g:1701:2: rule__ObservableAction__Group__2__Impl rule__ObservableAction__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__ObservableAction__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__2"


    // $ANTLR start "rule__ObservableAction__Group__2__Impl"
    // InternalDynamicGoalModel.g:1708:1: rule__ObservableAction__Group__2__Impl : ( 'signature' ) ;
    public final void rule__ObservableAction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1712:1: ( ( 'signature' ) )
            // InternalDynamicGoalModel.g:1713:1: ( 'signature' )
            {
            // InternalDynamicGoalModel.g:1713:1: ( 'signature' )
            // InternalDynamicGoalModel.g:1714:2: 'signature'
            {
             before(grammarAccess.getObservableActionAccess().getSignatureKeyword_2()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getSignatureKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__2__Impl"


    // $ANTLR start "rule__ObservableAction__Group__3"
    // InternalDynamicGoalModel.g:1723:1: rule__ObservableAction__Group__3 : rule__ObservableAction__Group__3__Impl rule__ObservableAction__Group__4 ;
    public final void rule__ObservableAction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1727:1: ( rule__ObservableAction__Group__3__Impl rule__ObservableAction__Group__4 )
            // InternalDynamicGoalModel.g:1728:2: rule__ObservableAction__Group__3__Impl rule__ObservableAction__Group__4
            {
            pushFollow(FOLLOW_20);
            rule__ObservableAction__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__3"


    // $ANTLR start "rule__ObservableAction__Group__3__Impl"
    // InternalDynamicGoalModel.g:1735:1: rule__ObservableAction__Group__3__Impl : ( ( rule__ObservableAction__SignatureAssignment_3 ) ) ;
    public final void rule__ObservableAction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1739:1: ( ( ( rule__ObservableAction__SignatureAssignment_3 ) ) )
            // InternalDynamicGoalModel.g:1740:1: ( ( rule__ObservableAction__SignatureAssignment_3 ) )
            {
            // InternalDynamicGoalModel.g:1740:1: ( ( rule__ObservableAction__SignatureAssignment_3 ) )
            // InternalDynamicGoalModel.g:1741:2: ( rule__ObservableAction__SignatureAssignment_3 )
            {
             before(grammarAccess.getObservableActionAccess().getSignatureAssignment_3()); 
            // InternalDynamicGoalModel.g:1742:2: ( rule__ObservableAction__SignatureAssignment_3 )
            // InternalDynamicGoalModel.g:1742:3: rule__ObservableAction__SignatureAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__SignatureAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getObservableActionAccess().getSignatureAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__3__Impl"


    // $ANTLR start "rule__ObservableAction__Group__4"
    // InternalDynamicGoalModel.g:1750:1: rule__ObservableAction__Group__4 : rule__ObservableAction__Group__4__Impl rule__ObservableAction__Group__5 ;
    public final void rule__ObservableAction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1754:1: ( rule__ObservableAction__Group__4__Impl rule__ObservableAction__Group__5 )
            // InternalDynamicGoalModel.g:1755:2: rule__ObservableAction__Group__4__Impl rule__ObservableAction__Group__5
            {
            pushFollow(FOLLOW_8);
            rule__ObservableAction__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__4"


    // $ANTLR start "rule__ObservableAction__Group__4__Impl"
    // InternalDynamicGoalModel.g:1762:1: rule__ObservableAction__Group__4__Impl : ( 'trigger' ) ;
    public final void rule__ObservableAction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1766:1: ( ( 'trigger' ) )
            // InternalDynamicGoalModel.g:1767:1: ( 'trigger' )
            {
            // InternalDynamicGoalModel.g:1767:1: ( 'trigger' )
            // InternalDynamicGoalModel.g:1768:2: 'trigger'
            {
             before(grammarAccess.getObservableActionAccess().getTriggerKeyword_4()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getTriggerKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__4__Impl"


    // $ANTLR start "rule__ObservableAction__Group__5"
    // InternalDynamicGoalModel.g:1777:1: rule__ObservableAction__Group__5 : rule__ObservableAction__Group__5__Impl rule__ObservableAction__Group__6 ;
    public final void rule__ObservableAction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1781:1: ( rule__ObservableAction__Group__5__Impl rule__ObservableAction__Group__6 )
            // InternalDynamicGoalModel.g:1782:2: rule__ObservableAction__Group__5__Impl rule__ObservableAction__Group__6
            {
            pushFollow(FOLLOW_21);
            rule__ObservableAction__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__5"


    // $ANTLR start "rule__ObservableAction__Group__5__Impl"
    // InternalDynamicGoalModel.g:1789:1: rule__ObservableAction__Group__5__Impl : ( ( rule__ObservableAction__TriggerAssignment_5 ) ) ;
    public final void rule__ObservableAction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1793:1: ( ( ( rule__ObservableAction__TriggerAssignment_5 ) ) )
            // InternalDynamicGoalModel.g:1794:1: ( ( rule__ObservableAction__TriggerAssignment_5 ) )
            {
            // InternalDynamicGoalModel.g:1794:1: ( ( rule__ObservableAction__TriggerAssignment_5 ) )
            // InternalDynamicGoalModel.g:1795:2: ( rule__ObservableAction__TriggerAssignment_5 )
            {
             before(grammarAccess.getObservableActionAccess().getTriggerAssignment_5()); 
            // InternalDynamicGoalModel.g:1796:2: ( rule__ObservableAction__TriggerAssignment_5 )
            // InternalDynamicGoalModel.g:1796:3: rule__ObservableAction__TriggerAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__TriggerAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getObservableActionAccess().getTriggerAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__5__Impl"


    // $ANTLR start "rule__ObservableAction__Group__6"
    // InternalDynamicGoalModel.g:1804:1: rule__ObservableAction__Group__6 : rule__ObservableAction__Group__6__Impl rule__ObservableAction__Group__7 ;
    public final void rule__ObservableAction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1808:1: ( rule__ObservableAction__Group__6__Impl rule__ObservableAction__Group__7 )
            // InternalDynamicGoalModel.g:1809:2: rule__ObservableAction__Group__6__Impl rule__ObservableAction__Group__7
            {
            pushFollow(FOLLOW_21);
            rule__ObservableAction__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__6"


    // $ANTLR start "rule__ObservableAction__Group__6__Impl"
    // InternalDynamicGoalModel.g:1816:1: rule__ObservableAction__Group__6__Impl : ( ( rule__ObservableAction__Group_6__0 )? ) ;
    public final void rule__ObservableAction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1820:1: ( ( ( rule__ObservableAction__Group_6__0 )? ) )
            // InternalDynamicGoalModel.g:1821:1: ( ( rule__ObservableAction__Group_6__0 )? )
            {
            // InternalDynamicGoalModel.g:1821:1: ( ( rule__ObservableAction__Group_6__0 )? )
            // InternalDynamicGoalModel.g:1822:2: ( rule__ObservableAction__Group_6__0 )?
            {
             before(grammarAccess.getObservableActionAccess().getGroup_6()); 
            // InternalDynamicGoalModel.g:1823:2: ( rule__ObservableAction__Group_6__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==46) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalDynamicGoalModel.g:1823:3: rule__ObservableAction__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ObservableAction__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getObservableActionAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__6__Impl"


    // $ANTLR start "rule__ObservableAction__Group__7"
    // InternalDynamicGoalModel.g:1831:1: rule__ObservableAction__Group__7 : rule__ObservableAction__Group__7__Impl rule__ObservableAction__Group__8 ;
    public final void rule__ObservableAction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1835:1: ( rule__ObservableAction__Group__7__Impl rule__ObservableAction__Group__8 )
            // InternalDynamicGoalModel.g:1836:2: rule__ObservableAction__Group__7__Impl rule__ObservableAction__Group__8
            {
            pushFollow(FOLLOW_21);
            rule__ObservableAction__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__7"


    // $ANTLR start "rule__ObservableAction__Group__7__Impl"
    // InternalDynamicGoalModel.g:1843:1: rule__ObservableAction__Group__7__Impl : ( ( rule__ObservableAction__Group_7__0 )? ) ;
    public final void rule__ObservableAction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1847:1: ( ( ( rule__ObservableAction__Group_7__0 )? ) )
            // InternalDynamicGoalModel.g:1848:1: ( ( rule__ObservableAction__Group_7__0 )? )
            {
            // InternalDynamicGoalModel.g:1848:1: ( ( rule__ObservableAction__Group_7__0 )? )
            // InternalDynamicGoalModel.g:1849:2: ( rule__ObservableAction__Group_7__0 )?
            {
             before(grammarAccess.getObservableActionAccess().getGroup_7()); 
            // InternalDynamicGoalModel.g:1850:2: ( rule__ObservableAction__Group_7__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==47) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalDynamicGoalModel.g:1850:3: rule__ObservableAction__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ObservableAction__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getObservableActionAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__7__Impl"


    // $ANTLR start "rule__ObservableAction__Group__8"
    // InternalDynamicGoalModel.g:1858:1: rule__ObservableAction__Group__8 : rule__ObservableAction__Group__8__Impl ;
    public final void rule__ObservableAction__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1862:1: ( rule__ObservableAction__Group__8__Impl )
            // InternalDynamicGoalModel.g:1863:2: rule__ObservableAction__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__8"


    // $ANTLR start "rule__ObservableAction__Group__8__Impl"
    // InternalDynamicGoalModel.g:1869:1: rule__ObservableAction__Group__8__Impl : ( '}' ) ;
    public final void rule__ObservableAction__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1873:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:1874:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:1874:1: ( '}' )
            // InternalDynamicGoalModel.g:1875:2: '}'
            {
             before(grammarAccess.getObservableActionAccess().getRightCurlyBracketKeyword_8()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group__8__Impl"


    // $ANTLR start "rule__ObservableAction__Group_6__0"
    // InternalDynamicGoalModel.g:1885:1: rule__ObservableAction__Group_6__0 : rule__ObservableAction__Group_6__0__Impl rule__ObservableAction__Group_6__1 ;
    public final void rule__ObservableAction__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1889:1: ( rule__ObservableAction__Group_6__0__Impl rule__ObservableAction__Group_6__1 )
            // InternalDynamicGoalModel.g:1890:2: rule__ObservableAction__Group_6__0__Impl rule__ObservableAction__Group_6__1
            {
            pushFollow(FOLLOW_8);
            rule__ObservableAction__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_6__0"


    // $ANTLR start "rule__ObservableAction__Group_6__0__Impl"
    // InternalDynamicGoalModel.g:1897:1: rule__ObservableAction__Group_6__0__Impl : ( 'scopeStart' ) ;
    public final void rule__ObservableAction__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1901:1: ( ( 'scopeStart' ) )
            // InternalDynamicGoalModel.g:1902:1: ( 'scopeStart' )
            {
            // InternalDynamicGoalModel.g:1902:1: ( 'scopeStart' )
            // InternalDynamicGoalModel.g:1903:2: 'scopeStart'
            {
             before(grammarAccess.getObservableActionAccess().getScopeStartKeyword_6_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getScopeStartKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_6__0__Impl"


    // $ANTLR start "rule__ObservableAction__Group_6__1"
    // InternalDynamicGoalModel.g:1912:1: rule__ObservableAction__Group_6__1 : rule__ObservableAction__Group_6__1__Impl ;
    public final void rule__ObservableAction__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1916:1: ( rule__ObservableAction__Group_6__1__Impl )
            // InternalDynamicGoalModel.g:1917:2: rule__ObservableAction__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_6__1"


    // $ANTLR start "rule__ObservableAction__Group_6__1__Impl"
    // InternalDynamicGoalModel.g:1923:1: rule__ObservableAction__Group_6__1__Impl : ( ( rule__ObservableAction__ScopeStartAssignment_6_1 ) ) ;
    public final void rule__ObservableAction__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1927:1: ( ( ( rule__ObservableAction__ScopeStartAssignment_6_1 ) ) )
            // InternalDynamicGoalModel.g:1928:1: ( ( rule__ObservableAction__ScopeStartAssignment_6_1 ) )
            {
            // InternalDynamicGoalModel.g:1928:1: ( ( rule__ObservableAction__ScopeStartAssignment_6_1 ) )
            // InternalDynamicGoalModel.g:1929:2: ( rule__ObservableAction__ScopeStartAssignment_6_1 )
            {
             before(grammarAccess.getObservableActionAccess().getScopeStartAssignment_6_1()); 
            // InternalDynamicGoalModel.g:1930:2: ( rule__ObservableAction__ScopeStartAssignment_6_1 )
            // InternalDynamicGoalModel.g:1930:3: rule__ObservableAction__ScopeStartAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__ScopeStartAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getObservableActionAccess().getScopeStartAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_6__1__Impl"


    // $ANTLR start "rule__ObservableAction__Group_7__0"
    // InternalDynamicGoalModel.g:1939:1: rule__ObservableAction__Group_7__0 : rule__ObservableAction__Group_7__0__Impl rule__ObservableAction__Group_7__1 ;
    public final void rule__ObservableAction__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1943:1: ( rule__ObservableAction__Group_7__0__Impl rule__ObservableAction__Group_7__1 )
            // InternalDynamicGoalModel.g:1944:2: rule__ObservableAction__Group_7__0__Impl rule__ObservableAction__Group_7__1
            {
            pushFollow(FOLLOW_8);
            rule__ObservableAction__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_7__0"


    // $ANTLR start "rule__ObservableAction__Group_7__0__Impl"
    // InternalDynamicGoalModel.g:1951:1: rule__ObservableAction__Group_7__0__Impl : ( 'scopeEnd' ) ;
    public final void rule__ObservableAction__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1955:1: ( ( 'scopeEnd' ) )
            // InternalDynamicGoalModel.g:1956:1: ( 'scopeEnd' )
            {
            // InternalDynamicGoalModel.g:1956:1: ( 'scopeEnd' )
            // InternalDynamicGoalModel.g:1957:2: 'scopeEnd'
            {
             before(grammarAccess.getObservableActionAccess().getScopeEndKeyword_7_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getScopeEndKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_7__0__Impl"


    // $ANTLR start "rule__ObservableAction__Group_7__1"
    // InternalDynamicGoalModel.g:1966:1: rule__ObservableAction__Group_7__1 : rule__ObservableAction__Group_7__1__Impl ;
    public final void rule__ObservableAction__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1970:1: ( rule__ObservableAction__Group_7__1__Impl )
            // InternalDynamicGoalModel.g:1971:2: rule__ObservableAction__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_7__1"


    // $ANTLR start "rule__ObservableAction__Group_7__1__Impl"
    // InternalDynamicGoalModel.g:1977:1: rule__ObservableAction__Group_7__1__Impl : ( ( rule__ObservableAction__ScopeEndAssignment_7_1 ) ) ;
    public final void rule__ObservableAction__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1981:1: ( ( ( rule__ObservableAction__ScopeEndAssignment_7_1 ) ) )
            // InternalDynamicGoalModel.g:1982:1: ( ( rule__ObservableAction__ScopeEndAssignment_7_1 ) )
            {
            // InternalDynamicGoalModel.g:1982:1: ( ( rule__ObservableAction__ScopeEndAssignment_7_1 ) )
            // InternalDynamicGoalModel.g:1983:2: ( rule__ObservableAction__ScopeEndAssignment_7_1 )
            {
             before(grammarAccess.getObservableActionAccess().getScopeEndAssignment_7_1()); 
            // InternalDynamicGoalModel.g:1984:2: ( rule__ObservableAction__ScopeEndAssignment_7_1 )
            // InternalDynamicGoalModel.g:1984:3: rule__ObservableAction__ScopeEndAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__ObservableAction__ScopeEndAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getObservableActionAccess().getScopeEndAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__Group_7__1__Impl"


    // $ANTLR start "rule__Evidence__Group__0"
    // InternalDynamicGoalModel.g:1993:1: rule__Evidence__Group__0 : rule__Evidence__Group__0__Impl rule__Evidence__Group__1 ;
    public final void rule__Evidence__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:1997:1: ( rule__Evidence__Group__0__Impl rule__Evidence__Group__1 )
            // InternalDynamicGoalModel.g:1998:2: rule__Evidence__Group__0__Impl rule__Evidence__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Evidence__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__0"


    // $ANTLR start "rule__Evidence__Group__0__Impl"
    // InternalDynamicGoalModel.g:2005:1: rule__Evidence__Group__0__Impl : ( 'Evidence' ) ;
    public final void rule__Evidence__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2009:1: ( ( 'Evidence' ) )
            // InternalDynamicGoalModel.g:2010:1: ( 'Evidence' )
            {
            // InternalDynamicGoalModel.g:2010:1: ( 'Evidence' )
            // InternalDynamicGoalModel.g:2011:2: 'Evidence'
            {
             before(grammarAccess.getEvidenceAccess().getEvidenceKeyword_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getEvidenceKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__0__Impl"


    // $ANTLR start "rule__Evidence__Group__1"
    // InternalDynamicGoalModel.g:2020:1: rule__Evidence__Group__1 : rule__Evidence__Group__1__Impl rule__Evidence__Group__2 ;
    public final void rule__Evidence__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2024:1: ( rule__Evidence__Group__1__Impl rule__Evidence__Group__2 )
            // InternalDynamicGoalModel.g:2025:2: rule__Evidence__Group__1__Impl rule__Evidence__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Evidence__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__1"


    // $ANTLR start "rule__Evidence__Group__1__Impl"
    // InternalDynamicGoalModel.g:2032:1: rule__Evidence__Group__1__Impl : ( ( rule__Evidence__NameAssignment_1 ) ) ;
    public final void rule__Evidence__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2036:1: ( ( ( rule__Evidence__NameAssignment_1 ) ) )
            // InternalDynamicGoalModel.g:2037:1: ( ( rule__Evidence__NameAssignment_1 ) )
            {
            // InternalDynamicGoalModel.g:2037:1: ( ( rule__Evidence__NameAssignment_1 ) )
            // InternalDynamicGoalModel.g:2038:2: ( rule__Evidence__NameAssignment_1 )
            {
             before(grammarAccess.getEvidenceAccess().getNameAssignment_1()); 
            // InternalDynamicGoalModel.g:2039:2: ( rule__Evidence__NameAssignment_1 )
            // InternalDynamicGoalModel.g:2039:3: rule__Evidence__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__1__Impl"


    // $ANTLR start "rule__Evidence__Group__2"
    // InternalDynamicGoalModel.g:2047:1: rule__Evidence__Group__2 : rule__Evidence__Group__2__Impl rule__Evidence__Group__3 ;
    public final void rule__Evidence__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2051:1: ( rule__Evidence__Group__2__Impl rule__Evidence__Group__3 )
            // InternalDynamicGoalModel.g:2052:2: rule__Evidence__Group__2__Impl rule__Evidence__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Evidence__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__2"


    // $ANTLR start "rule__Evidence__Group__2__Impl"
    // InternalDynamicGoalModel.g:2059:1: rule__Evidence__Group__2__Impl : ( '{' ) ;
    public final void rule__Evidence__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2063:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:2064:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:2064:1: ( '{' )
            // InternalDynamicGoalModel.g:2065:2: '{'
            {
             before(grammarAccess.getEvidenceAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__2__Impl"


    // $ANTLR start "rule__Evidence__Group__3"
    // InternalDynamicGoalModel.g:2074:1: rule__Evidence__Group__3 : rule__Evidence__Group__3__Impl rule__Evidence__Group__4 ;
    public final void rule__Evidence__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2078:1: ( rule__Evidence__Group__3__Impl rule__Evidence__Group__4 )
            // InternalDynamicGoalModel.g:2079:2: rule__Evidence__Group__3__Impl rule__Evidence__Group__4
            {
            pushFollow(FOLLOW_23);
            rule__Evidence__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__3"


    // $ANTLR start "rule__Evidence__Group__3__Impl"
    // InternalDynamicGoalModel.g:2086:1: rule__Evidence__Group__3__Impl : ( 'type' ) ;
    public final void rule__Evidence__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2090:1: ( ( 'type' ) )
            // InternalDynamicGoalModel.g:2091:1: ( 'type' )
            {
            // InternalDynamicGoalModel.g:2091:1: ( 'type' )
            // InternalDynamicGoalModel.g:2092:2: 'type'
            {
             before(grammarAccess.getEvidenceAccess().getTypeKeyword_3()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getTypeKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__3__Impl"


    // $ANTLR start "rule__Evidence__Group__4"
    // InternalDynamicGoalModel.g:2101:1: rule__Evidence__Group__4 : rule__Evidence__Group__4__Impl rule__Evidence__Group__5 ;
    public final void rule__Evidence__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2105:1: ( rule__Evidence__Group__4__Impl rule__Evidence__Group__5 )
            // InternalDynamicGoalModel.g:2106:2: rule__Evidence__Group__4__Impl rule__Evidence__Group__5
            {
            pushFollow(FOLLOW_24);
            rule__Evidence__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__4"


    // $ANTLR start "rule__Evidence__Group__4__Impl"
    // InternalDynamicGoalModel.g:2113:1: rule__Evidence__Group__4__Impl : ( ( rule__Evidence__TypeAssignment_4 ) ) ;
    public final void rule__Evidence__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2117:1: ( ( ( rule__Evidence__TypeAssignment_4 ) ) )
            // InternalDynamicGoalModel.g:2118:1: ( ( rule__Evidence__TypeAssignment_4 ) )
            {
            // InternalDynamicGoalModel.g:2118:1: ( ( rule__Evidence__TypeAssignment_4 ) )
            // InternalDynamicGoalModel.g:2119:2: ( rule__Evidence__TypeAssignment_4 )
            {
             before(grammarAccess.getEvidenceAccess().getTypeAssignment_4()); 
            // InternalDynamicGoalModel.g:2120:2: ( rule__Evidence__TypeAssignment_4 )
            // InternalDynamicGoalModel.g:2120:3: rule__Evidence__TypeAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__TypeAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceAccess().getTypeAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__4__Impl"


    // $ANTLR start "rule__Evidence__Group__5"
    // InternalDynamicGoalModel.g:2128:1: rule__Evidence__Group__5 : rule__Evidence__Group__5__Impl rule__Evidence__Group__6 ;
    public final void rule__Evidence__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2132:1: ( rule__Evidence__Group__5__Impl rule__Evidence__Group__6 )
            // InternalDynamicGoalModel.g:2133:2: rule__Evidence__Group__5__Impl rule__Evidence__Group__6
            {
            pushFollow(FOLLOW_8);
            rule__Evidence__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__5"


    // $ANTLR start "rule__Evidence__Group__5__Impl"
    // InternalDynamicGoalModel.g:2140:1: rule__Evidence__Group__5__Impl : ( 'source' ) ;
    public final void rule__Evidence__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2144:1: ( ( 'source' ) )
            // InternalDynamicGoalModel.g:2145:1: ( 'source' )
            {
            // InternalDynamicGoalModel.g:2145:1: ( 'source' )
            // InternalDynamicGoalModel.g:2146:2: 'source'
            {
             before(grammarAccess.getEvidenceAccess().getSourceKeyword_5()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getSourceKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__5__Impl"


    // $ANTLR start "rule__Evidence__Group__6"
    // InternalDynamicGoalModel.g:2155:1: rule__Evidence__Group__6 : rule__Evidence__Group__6__Impl rule__Evidence__Group__7 ;
    public final void rule__Evidence__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2159:1: ( rule__Evidence__Group__6__Impl rule__Evidence__Group__7 )
            // InternalDynamicGoalModel.g:2160:2: rule__Evidence__Group__6__Impl rule__Evidence__Group__7
            {
            pushFollow(FOLLOW_25);
            rule__Evidence__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__6"


    // $ANTLR start "rule__Evidence__Group__6__Impl"
    // InternalDynamicGoalModel.g:2167:1: rule__Evidence__Group__6__Impl : ( ( rule__Evidence__SourceAssignment_6 ) ) ;
    public final void rule__Evidence__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2171:1: ( ( ( rule__Evidence__SourceAssignment_6 ) ) )
            // InternalDynamicGoalModel.g:2172:1: ( ( rule__Evidence__SourceAssignment_6 ) )
            {
            // InternalDynamicGoalModel.g:2172:1: ( ( rule__Evidence__SourceAssignment_6 ) )
            // InternalDynamicGoalModel.g:2173:2: ( rule__Evidence__SourceAssignment_6 )
            {
             before(grammarAccess.getEvidenceAccess().getSourceAssignment_6()); 
            // InternalDynamicGoalModel.g:2174:2: ( rule__Evidence__SourceAssignment_6 )
            // InternalDynamicGoalModel.g:2174:3: rule__Evidence__SourceAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__SourceAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceAccess().getSourceAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__6__Impl"


    // $ANTLR start "rule__Evidence__Group__7"
    // InternalDynamicGoalModel.g:2182:1: rule__Evidence__Group__7 : rule__Evidence__Group__7__Impl rule__Evidence__Group__8 ;
    public final void rule__Evidence__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2186:1: ( rule__Evidence__Group__7__Impl rule__Evidence__Group__8 )
            // InternalDynamicGoalModel.g:2187:2: rule__Evidence__Group__7__Impl rule__Evidence__Group__8
            {
            pushFollow(FOLLOW_8);
            rule__Evidence__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__7"


    // $ANTLR start "rule__Evidence__Group__7__Impl"
    // InternalDynamicGoalModel.g:2194:1: rule__Evidence__Group__7__Impl : ( 'predicate' ) ;
    public final void rule__Evidence__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2198:1: ( ( 'predicate' ) )
            // InternalDynamicGoalModel.g:2199:1: ( 'predicate' )
            {
            // InternalDynamicGoalModel.g:2199:1: ( 'predicate' )
            // InternalDynamicGoalModel.g:2200:2: 'predicate'
            {
             before(grammarAccess.getEvidenceAccess().getPredicateKeyword_7()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getPredicateKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__7__Impl"


    // $ANTLR start "rule__Evidence__Group__8"
    // InternalDynamicGoalModel.g:2209:1: rule__Evidence__Group__8 : rule__Evidence__Group__8__Impl rule__Evidence__Group__9 ;
    public final void rule__Evidence__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2213:1: ( rule__Evidence__Group__8__Impl rule__Evidence__Group__9 )
            // InternalDynamicGoalModel.g:2214:2: rule__Evidence__Group__8__Impl rule__Evidence__Group__9
            {
            pushFollow(FOLLOW_26);
            rule__Evidence__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__8"


    // $ANTLR start "rule__Evidence__Group__8__Impl"
    // InternalDynamicGoalModel.g:2221:1: rule__Evidence__Group__8__Impl : ( ( rule__Evidence__PredicateAssignment_8 ) ) ;
    public final void rule__Evidence__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2225:1: ( ( ( rule__Evidence__PredicateAssignment_8 ) ) )
            // InternalDynamicGoalModel.g:2226:1: ( ( rule__Evidence__PredicateAssignment_8 ) )
            {
            // InternalDynamicGoalModel.g:2226:1: ( ( rule__Evidence__PredicateAssignment_8 ) )
            // InternalDynamicGoalModel.g:2227:2: ( rule__Evidence__PredicateAssignment_8 )
            {
             before(grammarAccess.getEvidenceAccess().getPredicateAssignment_8()); 
            // InternalDynamicGoalModel.g:2228:2: ( rule__Evidence__PredicateAssignment_8 )
            // InternalDynamicGoalModel.g:2228:3: rule__Evidence__PredicateAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__PredicateAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceAccess().getPredicateAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__8__Impl"


    // $ANTLR start "rule__Evidence__Group__9"
    // InternalDynamicGoalModel.g:2236:1: rule__Evidence__Group__9 : rule__Evidence__Group__9__Impl rule__Evidence__Group__10 ;
    public final void rule__Evidence__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2240:1: ( rule__Evidence__Group__9__Impl rule__Evidence__Group__10 )
            // InternalDynamicGoalModel.g:2241:2: rule__Evidence__Group__9__Impl rule__Evidence__Group__10
            {
            pushFollow(FOLLOW_26);
            rule__Evidence__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__9"


    // $ANTLR start "rule__Evidence__Group__9__Impl"
    // InternalDynamicGoalModel.g:2248:1: rule__Evidence__Group__9__Impl : ( ( rule__Evidence__Group_9__0 )? ) ;
    public final void rule__Evidence__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2252:1: ( ( ( rule__Evidence__Group_9__0 )? ) )
            // InternalDynamicGoalModel.g:2253:1: ( ( rule__Evidence__Group_9__0 )? )
            {
            // InternalDynamicGoalModel.g:2253:1: ( ( rule__Evidence__Group_9__0 )? )
            // InternalDynamicGoalModel.g:2254:2: ( rule__Evidence__Group_9__0 )?
            {
             before(grammarAccess.getEvidenceAccess().getGroup_9()); 
            // InternalDynamicGoalModel.g:2255:2: ( rule__Evidence__Group_9__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==52) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalDynamicGoalModel.g:2255:3: rule__Evidence__Group_9__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Evidence__Group_9__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEvidenceAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__9__Impl"


    // $ANTLR start "rule__Evidence__Group__10"
    // InternalDynamicGoalModel.g:2263:1: rule__Evidence__Group__10 : rule__Evidence__Group__10__Impl ;
    public final void rule__Evidence__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2267:1: ( rule__Evidence__Group__10__Impl )
            // InternalDynamicGoalModel.g:2268:2: rule__Evidence__Group__10__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__10"


    // $ANTLR start "rule__Evidence__Group__10__Impl"
    // InternalDynamicGoalModel.g:2274:1: rule__Evidence__Group__10__Impl : ( '}' ) ;
    public final void rule__Evidence__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2278:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:2279:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:2279:1: ( '}' )
            // InternalDynamicGoalModel.g:2280:2: '}'
            {
             before(grammarAccess.getEvidenceAccess().getRightCurlyBracketKeyword_10()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getRightCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group__10__Impl"


    // $ANTLR start "rule__Evidence__Group_9__0"
    // InternalDynamicGoalModel.g:2290:1: rule__Evidence__Group_9__0 : rule__Evidence__Group_9__0__Impl rule__Evidence__Group_9__1 ;
    public final void rule__Evidence__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2294:1: ( rule__Evidence__Group_9__0__Impl rule__Evidence__Group_9__1 )
            // InternalDynamicGoalModel.g:2295:2: rule__Evidence__Group_9__0__Impl rule__Evidence__Group_9__1
            {
            pushFollow(FOLLOW_27);
            rule__Evidence__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Evidence__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group_9__0"


    // $ANTLR start "rule__Evidence__Group_9__0__Impl"
    // InternalDynamicGoalModel.g:2302:1: rule__Evidence__Group_9__0__Impl : ( 'derivedFrom' ) ;
    public final void rule__Evidence__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2306:1: ( ( 'derivedFrom' ) )
            // InternalDynamicGoalModel.g:2307:1: ( 'derivedFrom' )
            {
            // InternalDynamicGoalModel.g:2307:1: ( 'derivedFrom' )
            // InternalDynamicGoalModel.g:2308:2: 'derivedFrom'
            {
             before(grammarAccess.getEvidenceAccess().getDerivedFromKeyword_9_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getDerivedFromKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group_9__0__Impl"


    // $ANTLR start "rule__Evidence__Group_9__1"
    // InternalDynamicGoalModel.g:2317:1: rule__Evidence__Group_9__1 : rule__Evidence__Group_9__1__Impl ;
    public final void rule__Evidence__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2321:1: ( rule__Evidence__Group_9__1__Impl )
            // InternalDynamicGoalModel.g:2322:2: rule__Evidence__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__Group_9__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group_9__1"


    // $ANTLR start "rule__Evidence__Group_9__1__Impl"
    // InternalDynamicGoalModel.g:2328:1: rule__Evidence__Group_9__1__Impl : ( ( rule__Evidence__DerivedFromAssignment_9_1 ) ) ;
    public final void rule__Evidence__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2332:1: ( ( ( rule__Evidence__DerivedFromAssignment_9_1 ) ) )
            // InternalDynamicGoalModel.g:2333:1: ( ( rule__Evidence__DerivedFromAssignment_9_1 ) )
            {
            // InternalDynamicGoalModel.g:2333:1: ( ( rule__Evidence__DerivedFromAssignment_9_1 ) )
            // InternalDynamicGoalModel.g:2334:2: ( rule__Evidence__DerivedFromAssignment_9_1 )
            {
             before(grammarAccess.getEvidenceAccess().getDerivedFromAssignment_9_1()); 
            // InternalDynamicGoalModel.g:2335:2: ( rule__Evidence__DerivedFromAssignment_9_1 )
            // InternalDynamicGoalModel.g:2335:3: rule__Evidence__DerivedFromAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__Evidence__DerivedFromAssignment_9_1();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceAccess().getDerivedFromAssignment_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__Group_9__1__Impl"


    // $ANTLR start "rule__DerivedExpression__Group__0"
    // InternalDynamicGoalModel.g:2344:1: rule__DerivedExpression__Group__0 : rule__DerivedExpression__Group__0__Impl rule__DerivedExpression__Group__1 ;
    public final void rule__DerivedExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2348:1: ( rule__DerivedExpression__Group__0__Impl rule__DerivedExpression__Group__1 )
            // InternalDynamicGoalModel.g:2349:2: rule__DerivedExpression__Group__0__Impl rule__DerivedExpression__Group__1
            {
            pushFollow(FOLLOW_28);
            rule__DerivedExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DerivedExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__0"


    // $ANTLR start "rule__DerivedExpression__Group__0__Impl"
    // InternalDynamicGoalModel.g:2356:1: rule__DerivedExpression__Group__0__Impl : ( 'derivedFrom' ) ;
    public final void rule__DerivedExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2360:1: ( ( 'derivedFrom' ) )
            // InternalDynamicGoalModel.g:2361:1: ( 'derivedFrom' )
            {
            // InternalDynamicGoalModel.g:2361:1: ( 'derivedFrom' )
            // InternalDynamicGoalModel.g:2362:2: 'derivedFrom'
            {
             before(grammarAccess.getDerivedExpressionAccess().getDerivedFromKeyword_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getDerivedExpressionAccess().getDerivedFromKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__0__Impl"


    // $ANTLR start "rule__DerivedExpression__Group__1"
    // InternalDynamicGoalModel.g:2371:1: rule__DerivedExpression__Group__1 : rule__DerivedExpression__Group__1__Impl rule__DerivedExpression__Group__2 ;
    public final void rule__DerivedExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2375:1: ( rule__DerivedExpression__Group__1__Impl rule__DerivedExpression__Group__2 )
            // InternalDynamicGoalModel.g:2376:2: rule__DerivedExpression__Group__1__Impl rule__DerivedExpression__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__DerivedExpression__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DerivedExpression__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__1"


    // $ANTLR start "rule__DerivedExpression__Group__1__Impl"
    // InternalDynamicGoalModel.g:2383:1: rule__DerivedExpression__Group__1__Impl : ( '(' ) ;
    public final void rule__DerivedExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2387:1: ( ( '(' ) )
            // InternalDynamicGoalModel.g:2388:1: ( '(' )
            {
            // InternalDynamicGoalModel.g:2388:1: ( '(' )
            // InternalDynamicGoalModel.g:2389:2: '('
            {
             before(grammarAccess.getDerivedExpressionAccess().getLeftParenthesisKeyword_1()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getDerivedExpressionAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__1__Impl"


    // $ANTLR start "rule__DerivedExpression__Group__2"
    // InternalDynamicGoalModel.g:2398:1: rule__DerivedExpression__Group__2 : rule__DerivedExpression__Group__2__Impl rule__DerivedExpression__Group__3 ;
    public final void rule__DerivedExpression__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2402:1: ( rule__DerivedExpression__Group__2__Impl rule__DerivedExpression__Group__3 )
            // InternalDynamicGoalModel.g:2403:2: rule__DerivedExpression__Group__2__Impl rule__DerivedExpression__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__DerivedExpression__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DerivedExpression__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__2"


    // $ANTLR start "rule__DerivedExpression__Group__2__Impl"
    // InternalDynamicGoalModel.g:2410:1: rule__DerivedExpression__Group__2__Impl : ( ( rule__DerivedExpression__ExpressionAssignment_2 ) ) ;
    public final void rule__DerivedExpression__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2414:1: ( ( ( rule__DerivedExpression__ExpressionAssignment_2 ) ) )
            // InternalDynamicGoalModel.g:2415:1: ( ( rule__DerivedExpression__ExpressionAssignment_2 ) )
            {
            // InternalDynamicGoalModel.g:2415:1: ( ( rule__DerivedExpression__ExpressionAssignment_2 ) )
            // InternalDynamicGoalModel.g:2416:2: ( rule__DerivedExpression__ExpressionAssignment_2 )
            {
             before(grammarAccess.getDerivedExpressionAccess().getExpressionAssignment_2()); 
            // InternalDynamicGoalModel.g:2417:2: ( rule__DerivedExpression__ExpressionAssignment_2 )
            // InternalDynamicGoalModel.g:2417:3: rule__DerivedExpression__ExpressionAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__DerivedExpression__ExpressionAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getDerivedExpressionAccess().getExpressionAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__2__Impl"


    // $ANTLR start "rule__DerivedExpression__Group__3"
    // InternalDynamicGoalModel.g:2425:1: rule__DerivedExpression__Group__3 : rule__DerivedExpression__Group__3__Impl ;
    public final void rule__DerivedExpression__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2429:1: ( rule__DerivedExpression__Group__3__Impl )
            // InternalDynamicGoalModel.g:2430:2: rule__DerivedExpression__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DerivedExpression__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__3"


    // $ANTLR start "rule__DerivedExpression__Group__3__Impl"
    // InternalDynamicGoalModel.g:2436:1: rule__DerivedExpression__Group__3__Impl : ( ')' ) ;
    public final void rule__DerivedExpression__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2440:1: ( ( ')' ) )
            // InternalDynamicGoalModel.g:2441:1: ( ')' )
            {
            // InternalDynamicGoalModel.g:2441:1: ( ')' )
            // InternalDynamicGoalModel.g:2442:2: ')'
            {
             before(grammarAccess.getDerivedExpressionAccess().getRightParenthesisKeyword_3()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getDerivedExpressionAccess().getRightParenthesisKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__Group__3__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__0"
    // InternalDynamicGoalModel.g:2452:1: rule__GoalHypothesis__Group__0 : rule__GoalHypothesis__Group__0__Impl rule__GoalHypothesis__Group__1 ;
    public final void rule__GoalHypothesis__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2456:1: ( rule__GoalHypothesis__Group__0__Impl rule__GoalHypothesis__Group__1 )
            // InternalDynamicGoalModel.g:2457:2: rule__GoalHypothesis__Group__0__Impl rule__GoalHypothesis__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__GoalHypothesis__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__0"


    // $ANTLR start "rule__GoalHypothesis__Group__0__Impl"
    // InternalDynamicGoalModel.g:2464:1: rule__GoalHypothesis__Group__0__Impl : ( 'GoalHypothesis' ) ;
    public final void rule__GoalHypothesis__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2468:1: ( ( 'GoalHypothesis' ) )
            // InternalDynamicGoalModel.g:2469:1: ( 'GoalHypothesis' )
            {
            // InternalDynamicGoalModel.g:2469:1: ( 'GoalHypothesis' )
            // InternalDynamicGoalModel.g:2470:2: 'GoalHypothesis'
            {
             before(grammarAccess.getGoalHypothesisAccess().getGoalHypothesisKeyword_0()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getGoalHypothesisKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__0__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__1"
    // InternalDynamicGoalModel.g:2479:1: rule__GoalHypothesis__Group__1 : rule__GoalHypothesis__Group__1__Impl rule__GoalHypothesis__Group__2 ;
    public final void rule__GoalHypothesis__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2483:1: ( rule__GoalHypothesis__Group__1__Impl rule__GoalHypothesis__Group__2 )
            // InternalDynamicGoalModel.g:2484:2: rule__GoalHypothesis__Group__1__Impl rule__GoalHypothesis__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__GoalHypothesis__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__1"


    // $ANTLR start "rule__GoalHypothesis__Group__1__Impl"
    // InternalDynamicGoalModel.g:2491:1: rule__GoalHypothesis__Group__1__Impl : ( ( rule__GoalHypothesis__NameAssignment_1 ) ) ;
    public final void rule__GoalHypothesis__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2495:1: ( ( ( rule__GoalHypothesis__NameAssignment_1 ) ) )
            // InternalDynamicGoalModel.g:2496:1: ( ( rule__GoalHypothesis__NameAssignment_1 ) )
            {
            // InternalDynamicGoalModel.g:2496:1: ( ( rule__GoalHypothesis__NameAssignment_1 ) )
            // InternalDynamicGoalModel.g:2497:2: ( rule__GoalHypothesis__NameAssignment_1 )
            {
             before(grammarAccess.getGoalHypothesisAccess().getNameAssignment_1()); 
            // InternalDynamicGoalModel.g:2498:2: ( rule__GoalHypothesis__NameAssignment_1 )
            // InternalDynamicGoalModel.g:2498:3: rule__GoalHypothesis__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGoalHypothesisAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__1__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__2"
    // InternalDynamicGoalModel.g:2506:1: rule__GoalHypothesis__Group__2 : rule__GoalHypothesis__Group__2__Impl rule__GoalHypothesis__Group__3 ;
    public final void rule__GoalHypothesis__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2510:1: ( rule__GoalHypothesis__Group__2__Impl rule__GoalHypothesis__Group__3 )
            // InternalDynamicGoalModel.g:2511:2: rule__GoalHypothesis__Group__2__Impl rule__GoalHypothesis__Group__3
            {
            pushFollow(FOLLOW_31);
            rule__GoalHypothesis__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__2"


    // $ANTLR start "rule__GoalHypothesis__Group__2__Impl"
    // InternalDynamicGoalModel.g:2518:1: rule__GoalHypothesis__Group__2__Impl : ( '{' ) ;
    public final void rule__GoalHypothesis__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2522:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:2523:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:2523:1: ( '{' )
            // InternalDynamicGoalModel.g:2524:2: '{'
            {
             before(grammarAccess.getGoalHypothesisAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__2__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__3"
    // InternalDynamicGoalModel.g:2533:1: rule__GoalHypothesis__Group__3 : rule__GoalHypothesis__Group__3__Impl rule__GoalHypothesis__Group__4 ;
    public final void rule__GoalHypothesis__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2537:1: ( rule__GoalHypothesis__Group__3__Impl rule__GoalHypothesis__Group__4 )
            // InternalDynamicGoalModel.g:2538:2: rule__GoalHypothesis__Group__3__Impl rule__GoalHypothesis__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__GoalHypothesis__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__3"


    // $ANTLR start "rule__GoalHypothesis__Group__3__Impl"
    // InternalDynamicGoalModel.g:2545:1: rule__GoalHypothesis__Group__3__Impl : ( 'intention' ) ;
    public final void rule__GoalHypothesis__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2549:1: ( ( 'intention' ) )
            // InternalDynamicGoalModel.g:2550:1: ( 'intention' )
            {
            // InternalDynamicGoalModel.g:2550:1: ( 'intention' )
            // InternalDynamicGoalModel.g:2551:2: 'intention'
            {
             before(grammarAccess.getGoalHypothesisAccess().getIntentionKeyword_3()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getIntentionKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__3__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__4"
    // InternalDynamicGoalModel.g:2560:1: rule__GoalHypothesis__Group__4 : rule__GoalHypothesis__Group__4__Impl rule__GoalHypothesis__Group__5 ;
    public final void rule__GoalHypothesis__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2564:1: ( rule__GoalHypothesis__Group__4__Impl rule__GoalHypothesis__Group__5 )
            // InternalDynamicGoalModel.g:2565:2: rule__GoalHypothesis__Group__4__Impl rule__GoalHypothesis__Group__5
            {
            pushFollow(FOLLOW_32);
            rule__GoalHypothesis__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__4"


    // $ANTLR start "rule__GoalHypothesis__Group__4__Impl"
    // InternalDynamicGoalModel.g:2572:1: rule__GoalHypothesis__Group__4__Impl : ( ( rule__GoalHypothesis__IntentionAssignment_4 ) ) ;
    public final void rule__GoalHypothesis__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2576:1: ( ( ( rule__GoalHypothesis__IntentionAssignment_4 ) ) )
            // InternalDynamicGoalModel.g:2577:1: ( ( rule__GoalHypothesis__IntentionAssignment_4 ) )
            {
            // InternalDynamicGoalModel.g:2577:1: ( ( rule__GoalHypothesis__IntentionAssignment_4 ) )
            // InternalDynamicGoalModel.g:2578:2: ( rule__GoalHypothesis__IntentionAssignment_4 )
            {
             before(grammarAccess.getGoalHypothesisAccess().getIntentionAssignment_4()); 
            // InternalDynamicGoalModel.g:2579:2: ( rule__GoalHypothesis__IntentionAssignment_4 )
            // InternalDynamicGoalModel.g:2579:3: rule__GoalHypothesis__IntentionAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__IntentionAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getGoalHypothesisAccess().getIntentionAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__4__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__5"
    // InternalDynamicGoalModel.g:2587:1: rule__GoalHypothesis__Group__5 : rule__GoalHypothesis__Group__5__Impl rule__GoalHypothesis__Group__6 ;
    public final void rule__GoalHypothesis__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2591:1: ( rule__GoalHypothesis__Group__5__Impl rule__GoalHypothesis__Group__6 )
            // InternalDynamicGoalModel.g:2592:2: rule__GoalHypothesis__Group__5__Impl rule__GoalHypothesis__Group__6
            {
            pushFollow(FOLLOW_29);
            rule__GoalHypothesis__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__5"


    // $ANTLR start "rule__GoalHypothesis__Group__5__Impl"
    // InternalDynamicGoalModel.g:2599:1: rule__GoalHypothesis__Group__5__Impl : ( 'condition' ) ;
    public final void rule__GoalHypothesis__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2603:1: ( ( 'condition' ) )
            // InternalDynamicGoalModel.g:2604:1: ( 'condition' )
            {
            // InternalDynamicGoalModel.g:2604:1: ( 'condition' )
            // InternalDynamicGoalModel.g:2605:2: 'condition'
            {
             before(grammarAccess.getGoalHypothesisAccess().getConditionKeyword_5()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getConditionKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__5__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__6"
    // InternalDynamicGoalModel.g:2614:1: rule__GoalHypothesis__Group__6 : rule__GoalHypothesis__Group__6__Impl rule__GoalHypothesis__Group__7 ;
    public final void rule__GoalHypothesis__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2618:1: ( rule__GoalHypothesis__Group__6__Impl rule__GoalHypothesis__Group__7 )
            // InternalDynamicGoalModel.g:2619:2: rule__GoalHypothesis__Group__6__Impl rule__GoalHypothesis__Group__7
            {
            pushFollow(FOLLOW_33);
            rule__GoalHypothesis__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__6"


    // $ANTLR start "rule__GoalHypothesis__Group__6__Impl"
    // InternalDynamicGoalModel.g:2626:1: rule__GoalHypothesis__Group__6__Impl : ( ( rule__GoalHypothesis__ConditionAssignment_6 ) ) ;
    public final void rule__GoalHypothesis__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2630:1: ( ( ( rule__GoalHypothesis__ConditionAssignment_6 ) ) )
            // InternalDynamicGoalModel.g:2631:1: ( ( rule__GoalHypothesis__ConditionAssignment_6 ) )
            {
            // InternalDynamicGoalModel.g:2631:1: ( ( rule__GoalHypothesis__ConditionAssignment_6 ) )
            // InternalDynamicGoalModel.g:2632:2: ( rule__GoalHypothesis__ConditionAssignment_6 )
            {
             before(grammarAccess.getGoalHypothesisAccess().getConditionAssignment_6()); 
            // InternalDynamicGoalModel.g:2633:2: ( rule__GoalHypothesis__ConditionAssignment_6 )
            // InternalDynamicGoalModel.g:2633:3: rule__GoalHypothesis__ConditionAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__ConditionAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getGoalHypothesisAccess().getConditionAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__6__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__7"
    // InternalDynamicGoalModel.g:2641:1: rule__GoalHypothesis__Group__7 : rule__GoalHypothesis__Group__7__Impl rule__GoalHypothesis__Group__8 ;
    public final void rule__GoalHypothesis__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2645:1: ( rule__GoalHypothesis__Group__7__Impl rule__GoalHypothesis__Group__8 )
            // InternalDynamicGoalModel.g:2646:2: rule__GoalHypothesis__Group__7__Impl rule__GoalHypothesis__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__GoalHypothesis__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__7"


    // $ANTLR start "rule__GoalHypothesis__Group__7__Impl"
    // InternalDynamicGoalModel.g:2653:1: rule__GoalHypothesis__Group__7__Impl : ( ( rule__GoalHypothesis__ResponseBindingAssignment_7 ) ) ;
    public final void rule__GoalHypothesis__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2657:1: ( ( ( rule__GoalHypothesis__ResponseBindingAssignment_7 ) ) )
            // InternalDynamicGoalModel.g:2658:1: ( ( rule__GoalHypothesis__ResponseBindingAssignment_7 ) )
            {
            // InternalDynamicGoalModel.g:2658:1: ( ( rule__GoalHypothesis__ResponseBindingAssignment_7 ) )
            // InternalDynamicGoalModel.g:2659:2: ( rule__GoalHypothesis__ResponseBindingAssignment_7 )
            {
             before(grammarAccess.getGoalHypothesisAccess().getResponseBindingAssignment_7()); 
            // InternalDynamicGoalModel.g:2660:2: ( rule__GoalHypothesis__ResponseBindingAssignment_7 )
            // InternalDynamicGoalModel.g:2660:3: rule__GoalHypothesis__ResponseBindingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__ResponseBindingAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getGoalHypothesisAccess().getResponseBindingAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__7__Impl"


    // $ANTLR start "rule__GoalHypothesis__Group__8"
    // InternalDynamicGoalModel.g:2668:1: rule__GoalHypothesis__Group__8 : rule__GoalHypothesis__Group__8__Impl ;
    public final void rule__GoalHypothesis__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2672:1: ( rule__GoalHypothesis__Group__8__Impl )
            // InternalDynamicGoalModel.g:2673:2: rule__GoalHypothesis__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GoalHypothesis__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__8"


    // $ANTLR start "rule__GoalHypothesis__Group__8__Impl"
    // InternalDynamicGoalModel.g:2679:1: rule__GoalHypothesis__Group__8__Impl : ( '}' ) ;
    public final void rule__GoalHypothesis__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2683:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:2684:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:2684:1: ( '}' )
            // InternalDynamicGoalModel.g:2685:2: '}'
            {
             before(grammarAccess.getGoalHypothesisAccess().getRightCurlyBracketKeyword_8()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__Group__8__Impl"


    // $ANTLR start "rule__OrExpression__Group__0"
    // InternalDynamicGoalModel.g:2695:1: rule__OrExpression__Group__0 : rule__OrExpression__Group__0__Impl rule__OrExpression__Group__1 ;
    public final void rule__OrExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2699:1: ( rule__OrExpression__Group__0__Impl rule__OrExpression__Group__1 )
            // InternalDynamicGoalModel.g:2700:2: rule__OrExpression__Group__0__Impl rule__OrExpression__Group__1
            {
            pushFollow(FOLLOW_34);
            rule__OrExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__OrExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group__0"


    // $ANTLR start "rule__OrExpression__Group__0__Impl"
    // InternalDynamicGoalModel.g:2707:1: rule__OrExpression__Group__0__Impl : ( ruleAndExpression ) ;
    public final void rule__OrExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2711:1: ( ( ruleAndExpression ) )
            // InternalDynamicGoalModel.g:2712:1: ( ruleAndExpression )
            {
            // InternalDynamicGoalModel.g:2712:1: ( ruleAndExpression )
            // InternalDynamicGoalModel.g:2713:2: ruleAndExpression
            {
             before(grammarAccess.getOrExpressionAccess().getAndExpressionParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleAndExpression();

            state._fsp--;

             after(grammarAccess.getOrExpressionAccess().getAndExpressionParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group__0__Impl"


    // $ANTLR start "rule__OrExpression__Group__1"
    // InternalDynamicGoalModel.g:2722:1: rule__OrExpression__Group__1 : rule__OrExpression__Group__1__Impl ;
    public final void rule__OrExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2726:1: ( rule__OrExpression__Group__1__Impl )
            // InternalDynamicGoalModel.g:2727:2: rule__OrExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__OrExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group__1"


    // $ANTLR start "rule__OrExpression__Group__1__Impl"
    // InternalDynamicGoalModel.g:2733:1: rule__OrExpression__Group__1__Impl : ( ( rule__OrExpression__Group_1__0 )* ) ;
    public final void rule__OrExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2737:1: ( ( ( rule__OrExpression__Group_1__0 )* ) )
            // InternalDynamicGoalModel.g:2738:1: ( ( rule__OrExpression__Group_1__0 )* )
            {
            // InternalDynamicGoalModel.g:2738:1: ( ( rule__OrExpression__Group_1__0 )* )
            // InternalDynamicGoalModel.g:2739:2: ( rule__OrExpression__Group_1__0 )*
            {
             before(grammarAccess.getOrExpressionAccess().getGroup_1()); 
            // InternalDynamicGoalModel.g:2740:2: ( rule__OrExpression__Group_1__0 )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==58) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:2740:3: rule__OrExpression__Group_1__0
            	    {
            	    pushFollow(FOLLOW_35);
            	    rule__OrExpression__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

             after(grammarAccess.getOrExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group__1__Impl"


    // $ANTLR start "rule__OrExpression__Group_1__0"
    // InternalDynamicGoalModel.g:2749:1: rule__OrExpression__Group_1__0 : rule__OrExpression__Group_1__0__Impl rule__OrExpression__Group_1__1 ;
    public final void rule__OrExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2753:1: ( rule__OrExpression__Group_1__0__Impl rule__OrExpression__Group_1__1 )
            // InternalDynamicGoalModel.g:2754:2: rule__OrExpression__Group_1__0__Impl rule__OrExpression__Group_1__1
            {
            pushFollow(FOLLOW_34);
            rule__OrExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__OrExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group_1__0"


    // $ANTLR start "rule__OrExpression__Group_1__0__Impl"
    // InternalDynamicGoalModel.g:2761:1: rule__OrExpression__Group_1__0__Impl : ( () ) ;
    public final void rule__OrExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2765:1: ( ( () ) )
            // InternalDynamicGoalModel.g:2766:1: ( () )
            {
            // InternalDynamicGoalModel.g:2766:1: ( () )
            // InternalDynamicGoalModel.g:2767:2: ()
            {
             before(grammarAccess.getOrExpressionAccess().getOrExpressionLeftAction_1_0()); 
            // InternalDynamicGoalModel.g:2768:2: ()
            // InternalDynamicGoalModel.g:2768:3: 
            {
            }

             after(grammarAccess.getOrExpressionAccess().getOrExpressionLeftAction_1_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group_1__0__Impl"


    // $ANTLR start "rule__OrExpression__Group_1__1"
    // InternalDynamicGoalModel.g:2776:1: rule__OrExpression__Group_1__1 : rule__OrExpression__Group_1__1__Impl rule__OrExpression__Group_1__2 ;
    public final void rule__OrExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2780:1: ( rule__OrExpression__Group_1__1__Impl rule__OrExpression__Group_1__2 )
            // InternalDynamicGoalModel.g:2781:2: rule__OrExpression__Group_1__1__Impl rule__OrExpression__Group_1__2
            {
            pushFollow(FOLLOW_29);
            rule__OrExpression__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__OrExpression__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group_1__1"


    // $ANTLR start "rule__OrExpression__Group_1__1__Impl"
    // InternalDynamicGoalModel.g:2788:1: rule__OrExpression__Group_1__1__Impl : ( '||' ) ;
    public final void rule__OrExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2792:1: ( ( '||' ) )
            // InternalDynamicGoalModel.g:2793:1: ( '||' )
            {
            // InternalDynamicGoalModel.g:2793:1: ( '||' )
            // InternalDynamicGoalModel.g:2794:2: '||'
            {
             before(grammarAccess.getOrExpressionAccess().getVerticalLineVerticalLineKeyword_1_1()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getOrExpressionAccess().getVerticalLineVerticalLineKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group_1__1__Impl"


    // $ANTLR start "rule__OrExpression__Group_1__2"
    // InternalDynamicGoalModel.g:2803:1: rule__OrExpression__Group_1__2 : rule__OrExpression__Group_1__2__Impl ;
    public final void rule__OrExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2807:1: ( rule__OrExpression__Group_1__2__Impl )
            // InternalDynamicGoalModel.g:2808:2: rule__OrExpression__Group_1__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__OrExpression__Group_1__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group_1__2"


    // $ANTLR start "rule__OrExpression__Group_1__2__Impl"
    // InternalDynamicGoalModel.g:2814:1: rule__OrExpression__Group_1__2__Impl : ( ( rule__OrExpression__RightAssignment_1_2 ) ) ;
    public final void rule__OrExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2818:1: ( ( ( rule__OrExpression__RightAssignment_1_2 ) ) )
            // InternalDynamicGoalModel.g:2819:1: ( ( rule__OrExpression__RightAssignment_1_2 ) )
            {
            // InternalDynamicGoalModel.g:2819:1: ( ( rule__OrExpression__RightAssignment_1_2 ) )
            // InternalDynamicGoalModel.g:2820:2: ( rule__OrExpression__RightAssignment_1_2 )
            {
             before(grammarAccess.getOrExpressionAccess().getRightAssignment_1_2()); 
            // InternalDynamicGoalModel.g:2821:2: ( rule__OrExpression__RightAssignment_1_2 )
            // InternalDynamicGoalModel.g:2821:3: rule__OrExpression__RightAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__OrExpression__RightAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getOrExpressionAccess().getRightAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__Group_1__2__Impl"


    // $ANTLR start "rule__AndExpression__Group__0"
    // InternalDynamicGoalModel.g:2830:1: rule__AndExpression__Group__0 : rule__AndExpression__Group__0__Impl rule__AndExpression__Group__1 ;
    public final void rule__AndExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2834:1: ( rule__AndExpression__Group__0__Impl rule__AndExpression__Group__1 )
            // InternalDynamicGoalModel.g:2835:2: rule__AndExpression__Group__0__Impl rule__AndExpression__Group__1
            {
            pushFollow(FOLLOW_36);
            rule__AndExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AndExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group__0"


    // $ANTLR start "rule__AndExpression__Group__0__Impl"
    // InternalDynamicGoalModel.g:2842:1: rule__AndExpression__Group__0__Impl : ( ruleUnaryExpression ) ;
    public final void rule__AndExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2846:1: ( ( ruleUnaryExpression ) )
            // InternalDynamicGoalModel.g:2847:1: ( ruleUnaryExpression )
            {
            // InternalDynamicGoalModel.g:2847:1: ( ruleUnaryExpression )
            // InternalDynamicGoalModel.g:2848:2: ruleUnaryExpression
            {
             before(grammarAccess.getAndExpressionAccess().getUnaryExpressionParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleUnaryExpression();

            state._fsp--;

             after(grammarAccess.getAndExpressionAccess().getUnaryExpressionParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group__0__Impl"


    // $ANTLR start "rule__AndExpression__Group__1"
    // InternalDynamicGoalModel.g:2857:1: rule__AndExpression__Group__1 : rule__AndExpression__Group__1__Impl ;
    public final void rule__AndExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2861:1: ( rule__AndExpression__Group__1__Impl )
            // InternalDynamicGoalModel.g:2862:2: rule__AndExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AndExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group__1"


    // $ANTLR start "rule__AndExpression__Group__1__Impl"
    // InternalDynamicGoalModel.g:2868:1: rule__AndExpression__Group__1__Impl : ( ( rule__AndExpression__Group_1__0 )* ) ;
    public final void rule__AndExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2872:1: ( ( ( rule__AndExpression__Group_1__0 )* ) )
            // InternalDynamicGoalModel.g:2873:1: ( ( rule__AndExpression__Group_1__0 )* )
            {
            // InternalDynamicGoalModel.g:2873:1: ( ( rule__AndExpression__Group_1__0 )* )
            // InternalDynamicGoalModel.g:2874:2: ( rule__AndExpression__Group_1__0 )*
            {
             before(grammarAccess.getAndExpressionAccess().getGroup_1()); 
            // InternalDynamicGoalModel.g:2875:2: ( rule__AndExpression__Group_1__0 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==59) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:2875:3: rule__AndExpression__Group_1__0
            	    {
            	    pushFollow(FOLLOW_37);
            	    rule__AndExpression__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getAndExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group__1__Impl"


    // $ANTLR start "rule__AndExpression__Group_1__0"
    // InternalDynamicGoalModel.g:2884:1: rule__AndExpression__Group_1__0 : rule__AndExpression__Group_1__0__Impl rule__AndExpression__Group_1__1 ;
    public final void rule__AndExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2888:1: ( rule__AndExpression__Group_1__0__Impl rule__AndExpression__Group_1__1 )
            // InternalDynamicGoalModel.g:2889:2: rule__AndExpression__Group_1__0__Impl rule__AndExpression__Group_1__1
            {
            pushFollow(FOLLOW_36);
            rule__AndExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AndExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group_1__0"


    // $ANTLR start "rule__AndExpression__Group_1__0__Impl"
    // InternalDynamicGoalModel.g:2896:1: rule__AndExpression__Group_1__0__Impl : ( () ) ;
    public final void rule__AndExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2900:1: ( ( () ) )
            // InternalDynamicGoalModel.g:2901:1: ( () )
            {
            // InternalDynamicGoalModel.g:2901:1: ( () )
            // InternalDynamicGoalModel.g:2902:2: ()
            {
             before(grammarAccess.getAndExpressionAccess().getAndExpressionLeftAction_1_0()); 
            // InternalDynamicGoalModel.g:2903:2: ()
            // InternalDynamicGoalModel.g:2903:3: 
            {
            }

             after(grammarAccess.getAndExpressionAccess().getAndExpressionLeftAction_1_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group_1__0__Impl"


    // $ANTLR start "rule__AndExpression__Group_1__1"
    // InternalDynamicGoalModel.g:2911:1: rule__AndExpression__Group_1__1 : rule__AndExpression__Group_1__1__Impl rule__AndExpression__Group_1__2 ;
    public final void rule__AndExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2915:1: ( rule__AndExpression__Group_1__1__Impl rule__AndExpression__Group_1__2 )
            // InternalDynamicGoalModel.g:2916:2: rule__AndExpression__Group_1__1__Impl rule__AndExpression__Group_1__2
            {
            pushFollow(FOLLOW_29);
            rule__AndExpression__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AndExpression__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group_1__1"


    // $ANTLR start "rule__AndExpression__Group_1__1__Impl"
    // InternalDynamicGoalModel.g:2923:1: rule__AndExpression__Group_1__1__Impl : ( '&&' ) ;
    public final void rule__AndExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2927:1: ( ( '&&' ) )
            // InternalDynamicGoalModel.g:2928:1: ( '&&' )
            {
            // InternalDynamicGoalModel.g:2928:1: ( '&&' )
            // InternalDynamicGoalModel.g:2929:2: '&&'
            {
             before(grammarAccess.getAndExpressionAccess().getAmpersandAmpersandKeyword_1_1()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getAndExpressionAccess().getAmpersandAmpersandKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group_1__1__Impl"


    // $ANTLR start "rule__AndExpression__Group_1__2"
    // InternalDynamicGoalModel.g:2938:1: rule__AndExpression__Group_1__2 : rule__AndExpression__Group_1__2__Impl ;
    public final void rule__AndExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2942:1: ( rule__AndExpression__Group_1__2__Impl )
            // InternalDynamicGoalModel.g:2943:2: rule__AndExpression__Group_1__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AndExpression__Group_1__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group_1__2"


    // $ANTLR start "rule__AndExpression__Group_1__2__Impl"
    // InternalDynamicGoalModel.g:2949:1: rule__AndExpression__Group_1__2__Impl : ( ( rule__AndExpression__RightAssignment_1_2 ) ) ;
    public final void rule__AndExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2953:1: ( ( ( rule__AndExpression__RightAssignment_1_2 ) ) )
            // InternalDynamicGoalModel.g:2954:1: ( ( rule__AndExpression__RightAssignment_1_2 ) )
            {
            // InternalDynamicGoalModel.g:2954:1: ( ( rule__AndExpression__RightAssignment_1_2 ) )
            // InternalDynamicGoalModel.g:2955:2: ( rule__AndExpression__RightAssignment_1_2 )
            {
             before(grammarAccess.getAndExpressionAccess().getRightAssignment_1_2()); 
            // InternalDynamicGoalModel.g:2956:2: ( rule__AndExpression__RightAssignment_1_2 )
            // InternalDynamicGoalModel.g:2956:3: rule__AndExpression__RightAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__AndExpression__RightAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getAndExpressionAccess().getRightAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__Group_1__2__Impl"


    // $ANTLR start "rule__UnaryExpression__Group_2__0"
    // InternalDynamicGoalModel.g:2965:1: rule__UnaryExpression__Group_2__0 : rule__UnaryExpression__Group_2__0__Impl rule__UnaryExpression__Group_2__1 ;
    public final void rule__UnaryExpression__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2969:1: ( rule__UnaryExpression__Group_2__0__Impl rule__UnaryExpression__Group_2__1 )
            // InternalDynamicGoalModel.g:2970:2: rule__UnaryExpression__Group_2__0__Impl rule__UnaryExpression__Group_2__1
            {
            pushFollow(FOLLOW_29);
            rule__UnaryExpression__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UnaryExpression__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Group_2__0"


    // $ANTLR start "rule__UnaryExpression__Group_2__0__Impl"
    // InternalDynamicGoalModel.g:2977:1: rule__UnaryExpression__Group_2__0__Impl : ( '(' ) ;
    public final void rule__UnaryExpression__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2981:1: ( ( '(' ) )
            // InternalDynamicGoalModel.g:2982:1: ( '(' )
            {
            // InternalDynamicGoalModel.g:2982:1: ( '(' )
            // InternalDynamicGoalModel.g:2983:2: '('
            {
             before(grammarAccess.getUnaryExpressionAccess().getLeftParenthesisKeyword_2_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getUnaryExpressionAccess().getLeftParenthesisKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Group_2__0__Impl"


    // $ANTLR start "rule__UnaryExpression__Group_2__1"
    // InternalDynamicGoalModel.g:2992:1: rule__UnaryExpression__Group_2__1 : rule__UnaryExpression__Group_2__1__Impl rule__UnaryExpression__Group_2__2 ;
    public final void rule__UnaryExpression__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:2996:1: ( rule__UnaryExpression__Group_2__1__Impl rule__UnaryExpression__Group_2__2 )
            // InternalDynamicGoalModel.g:2997:2: rule__UnaryExpression__Group_2__1__Impl rule__UnaryExpression__Group_2__2
            {
            pushFollow(FOLLOW_30);
            rule__UnaryExpression__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UnaryExpression__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Group_2__1"


    // $ANTLR start "rule__UnaryExpression__Group_2__1__Impl"
    // InternalDynamicGoalModel.g:3004:1: rule__UnaryExpression__Group_2__1__Impl : ( ruleConditionExpression ) ;
    public final void rule__UnaryExpression__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3008:1: ( ( ruleConditionExpression ) )
            // InternalDynamicGoalModel.g:3009:1: ( ruleConditionExpression )
            {
            // InternalDynamicGoalModel.g:3009:1: ( ruleConditionExpression )
            // InternalDynamicGoalModel.g:3010:2: ruleConditionExpression
            {
             before(grammarAccess.getUnaryExpressionAccess().getConditionExpressionParserRuleCall_2_1()); 
            pushFollow(FOLLOW_2);
            ruleConditionExpression();

            state._fsp--;

             after(grammarAccess.getUnaryExpressionAccess().getConditionExpressionParserRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Group_2__1__Impl"


    // $ANTLR start "rule__UnaryExpression__Group_2__2"
    // InternalDynamicGoalModel.g:3019:1: rule__UnaryExpression__Group_2__2 : rule__UnaryExpression__Group_2__2__Impl ;
    public final void rule__UnaryExpression__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3023:1: ( rule__UnaryExpression__Group_2__2__Impl )
            // InternalDynamicGoalModel.g:3024:2: rule__UnaryExpression__Group_2__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__UnaryExpression__Group_2__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Group_2__2"


    // $ANTLR start "rule__UnaryExpression__Group_2__2__Impl"
    // InternalDynamicGoalModel.g:3030:1: rule__UnaryExpression__Group_2__2__Impl : ( ')' ) ;
    public final void rule__UnaryExpression__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3034:1: ( ( ')' ) )
            // InternalDynamicGoalModel.g:3035:1: ( ')' )
            {
            // InternalDynamicGoalModel.g:3035:1: ( ')' )
            // InternalDynamicGoalModel.g:3036:2: ')'
            {
             before(grammarAccess.getUnaryExpressionAccess().getRightParenthesisKeyword_2_2()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getUnaryExpressionAccess().getRightParenthesisKeyword_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnaryExpression__Group_2__2__Impl"


    // $ANTLR start "rule__NegationExpression__Group__0"
    // InternalDynamicGoalModel.g:3046:1: rule__NegationExpression__Group__0 : rule__NegationExpression__Group__0__Impl rule__NegationExpression__Group__1 ;
    public final void rule__NegationExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3050:1: ( rule__NegationExpression__Group__0__Impl rule__NegationExpression__Group__1 )
            // InternalDynamicGoalModel.g:3051:2: rule__NegationExpression__Group__0__Impl rule__NegationExpression__Group__1
            {
            pushFollow(FOLLOW_38);
            rule__NegationExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NegationExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__0"


    // $ANTLR start "rule__NegationExpression__Group__0__Impl"
    // InternalDynamicGoalModel.g:3058:1: rule__NegationExpression__Group__0__Impl : ( 'NOT' ) ;
    public final void rule__NegationExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3062:1: ( ( 'NOT' ) )
            // InternalDynamicGoalModel.g:3063:1: ( 'NOT' )
            {
            // InternalDynamicGoalModel.g:3063:1: ( 'NOT' )
            // InternalDynamicGoalModel.g:3064:2: 'NOT'
            {
             before(grammarAccess.getNegationExpressionAccess().getNOTKeyword_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getNegationExpressionAccess().getNOTKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__0__Impl"


    // $ANTLR start "rule__NegationExpression__Group__1"
    // InternalDynamicGoalModel.g:3073:1: rule__NegationExpression__Group__1 : rule__NegationExpression__Group__1__Impl ;
    public final void rule__NegationExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3077:1: ( rule__NegationExpression__Group__1__Impl )
            // InternalDynamicGoalModel.g:3078:2: rule__NegationExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__NegationExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__1"


    // $ANTLR start "rule__NegationExpression__Group__1__Impl"
    // InternalDynamicGoalModel.g:3084:1: rule__NegationExpression__Group__1__Impl : ( ( rule__NegationExpression__OperandAssignment_1 ) ) ;
    public final void rule__NegationExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3088:1: ( ( ( rule__NegationExpression__OperandAssignment_1 ) ) )
            // InternalDynamicGoalModel.g:3089:1: ( ( rule__NegationExpression__OperandAssignment_1 ) )
            {
            // InternalDynamicGoalModel.g:3089:1: ( ( rule__NegationExpression__OperandAssignment_1 ) )
            // InternalDynamicGoalModel.g:3090:2: ( rule__NegationExpression__OperandAssignment_1 )
            {
             before(grammarAccess.getNegationExpressionAccess().getOperandAssignment_1()); 
            // InternalDynamicGoalModel.g:3091:2: ( rule__NegationExpression__OperandAssignment_1 )
            // InternalDynamicGoalModel.g:3091:3: rule__NegationExpression__OperandAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__NegationExpression__OperandAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getNegationExpressionAccess().getOperandAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__1__Impl"


    // $ANTLR start "rule__EvidenceRef__Group__0"
    // InternalDynamicGoalModel.g:3100:1: rule__EvidenceRef__Group__0 : rule__EvidenceRef__Group__0__Impl rule__EvidenceRef__Group__1 ;
    public final void rule__EvidenceRef__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3104:1: ( rule__EvidenceRef__Group__0__Impl rule__EvidenceRef__Group__1 )
            // InternalDynamicGoalModel.g:3105:2: rule__EvidenceRef__Group__0__Impl rule__EvidenceRef__Group__1
            {
            pushFollow(FOLLOW_28);
            rule__EvidenceRef__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group__0"


    // $ANTLR start "rule__EvidenceRef__Group__0__Impl"
    // InternalDynamicGoalModel.g:3112:1: rule__EvidenceRef__Group__0__Impl : ( ( rule__EvidenceRef__EvidenceAssignment_0 ) ) ;
    public final void rule__EvidenceRef__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3116:1: ( ( ( rule__EvidenceRef__EvidenceAssignment_0 ) ) )
            // InternalDynamicGoalModel.g:3117:1: ( ( rule__EvidenceRef__EvidenceAssignment_0 ) )
            {
            // InternalDynamicGoalModel.g:3117:1: ( ( rule__EvidenceRef__EvidenceAssignment_0 ) )
            // InternalDynamicGoalModel.g:3118:2: ( rule__EvidenceRef__EvidenceAssignment_0 )
            {
             before(grammarAccess.getEvidenceRefAccess().getEvidenceAssignment_0()); 
            // InternalDynamicGoalModel.g:3119:2: ( rule__EvidenceRef__EvidenceAssignment_0 )
            // InternalDynamicGoalModel.g:3119:3: rule__EvidenceRef__EvidenceAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__EvidenceAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceRefAccess().getEvidenceAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group__0__Impl"


    // $ANTLR start "rule__EvidenceRef__Group__1"
    // InternalDynamicGoalModel.g:3127:1: rule__EvidenceRef__Group__1 : rule__EvidenceRef__Group__1__Impl ;
    public final void rule__EvidenceRef__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3131:1: ( rule__EvidenceRef__Group__1__Impl )
            // InternalDynamicGoalModel.g:3132:2: rule__EvidenceRef__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group__1"


    // $ANTLR start "rule__EvidenceRef__Group__1__Impl"
    // InternalDynamicGoalModel.g:3138:1: rule__EvidenceRef__Group__1__Impl : ( ( rule__EvidenceRef__Group_1__0 )? ) ;
    public final void rule__EvidenceRef__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3142:1: ( ( ( rule__EvidenceRef__Group_1__0 )? ) )
            // InternalDynamicGoalModel.g:3143:1: ( ( rule__EvidenceRef__Group_1__0 )? )
            {
            // InternalDynamicGoalModel.g:3143:1: ( ( rule__EvidenceRef__Group_1__0 )? )
            // InternalDynamicGoalModel.g:3144:2: ( rule__EvidenceRef__Group_1__0 )?
            {
             before(grammarAccess.getEvidenceRefAccess().getGroup_1()); 
            // InternalDynamicGoalModel.g:3145:2: ( rule__EvidenceRef__Group_1__0 )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==53) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalDynamicGoalModel.g:3145:3: rule__EvidenceRef__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EvidenceRef__Group_1__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEvidenceRefAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group__1__Impl"


    // $ANTLR start "rule__EvidenceRef__Group_1__0"
    // InternalDynamicGoalModel.g:3154:1: rule__EvidenceRef__Group_1__0 : rule__EvidenceRef__Group_1__0__Impl rule__EvidenceRef__Group_1__1 ;
    public final void rule__EvidenceRef__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3158:1: ( rule__EvidenceRef__Group_1__0__Impl rule__EvidenceRef__Group_1__1 )
            // InternalDynamicGoalModel.g:3159:2: rule__EvidenceRef__Group_1__0__Impl rule__EvidenceRef__Group_1__1
            {
            pushFollow(FOLLOW_8);
            rule__EvidenceRef__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__0"


    // $ANTLR start "rule__EvidenceRef__Group_1__0__Impl"
    // InternalDynamicGoalModel.g:3166:1: rule__EvidenceRef__Group_1__0__Impl : ( '(' ) ;
    public final void rule__EvidenceRef__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3170:1: ( ( '(' ) )
            // InternalDynamicGoalModel.g:3171:1: ( '(' )
            {
            // InternalDynamicGoalModel.g:3171:1: ( '(' )
            // InternalDynamicGoalModel.g:3172:2: '('
            {
             before(grammarAccess.getEvidenceRefAccess().getLeftParenthesisKeyword_1_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getEvidenceRefAccess().getLeftParenthesisKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__0__Impl"


    // $ANTLR start "rule__EvidenceRef__Group_1__1"
    // InternalDynamicGoalModel.g:3181:1: rule__EvidenceRef__Group_1__1 : rule__EvidenceRef__Group_1__1__Impl rule__EvidenceRef__Group_1__2 ;
    public final void rule__EvidenceRef__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3185:1: ( rule__EvidenceRef__Group_1__1__Impl rule__EvidenceRef__Group_1__2 )
            // InternalDynamicGoalModel.g:3186:2: rule__EvidenceRef__Group_1__1__Impl rule__EvidenceRef__Group_1__2
            {
            pushFollow(FOLLOW_39);
            rule__EvidenceRef__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__1"


    // $ANTLR start "rule__EvidenceRef__Group_1__1__Impl"
    // InternalDynamicGoalModel.g:3193:1: rule__EvidenceRef__Group_1__1__Impl : ( ( rule__EvidenceRef__ParamsAssignment_1_1 ) ) ;
    public final void rule__EvidenceRef__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3197:1: ( ( ( rule__EvidenceRef__ParamsAssignment_1_1 ) ) )
            // InternalDynamicGoalModel.g:3198:1: ( ( rule__EvidenceRef__ParamsAssignment_1_1 ) )
            {
            // InternalDynamicGoalModel.g:3198:1: ( ( rule__EvidenceRef__ParamsAssignment_1_1 ) )
            // InternalDynamicGoalModel.g:3199:2: ( rule__EvidenceRef__ParamsAssignment_1_1 )
            {
             before(grammarAccess.getEvidenceRefAccess().getParamsAssignment_1_1()); 
            // InternalDynamicGoalModel.g:3200:2: ( rule__EvidenceRef__ParamsAssignment_1_1 )
            // InternalDynamicGoalModel.g:3200:3: rule__EvidenceRef__ParamsAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__ParamsAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceRefAccess().getParamsAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__1__Impl"


    // $ANTLR start "rule__EvidenceRef__Group_1__2"
    // InternalDynamicGoalModel.g:3208:1: rule__EvidenceRef__Group_1__2 : rule__EvidenceRef__Group_1__2__Impl rule__EvidenceRef__Group_1__3 ;
    public final void rule__EvidenceRef__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3212:1: ( rule__EvidenceRef__Group_1__2__Impl rule__EvidenceRef__Group_1__3 )
            // InternalDynamicGoalModel.g:3213:2: rule__EvidenceRef__Group_1__2__Impl rule__EvidenceRef__Group_1__3
            {
            pushFollow(FOLLOW_39);
            rule__EvidenceRef__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__2"


    // $ANTLR start "rule__EvidenceRef__Group_1__2__Impl"
    // InternalDynamicGoalModel.g:3220:1: rule__EvidenceRef__Group_1__2__Impl : ( ( rule__EvidenceRef__Group_1_2__0 )* ) ;
    public final void rule__EvidenceRef__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3224:1: ( ( ( rule__EvidenceRef__Group_1_2__0 )* ) )
            // InternalDynamicGoalModel.g:3225:1: ( ( rule__EvidenceRef__Group_1_2__0 )* )
            {
            // InternalDynamicGoalModel.g:3225:1: ( ( rule__EvidenceRef__Group_1_2__0 )* )
            // InternalDynamicGoalModel.g:3226:2: ( rule__EvidenceRef__Group_1_2__0 )*
            {
             before(grammarAccess.getEvidenceRefAccess().getGroup_1_2()); 
            // InternalDynamicGoalModel.g:3227:2: ( rule__EvidenceRef__Group_1_2__0 )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==61) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:3227:3: rule__EvidenceRef__Group_1_2__0
            	    {
            	    pushFollow(FOLLOW_40);
            	    rule__EvidenceRef__Group_1_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

             after(grammarAccess.getEvidenceRefAccess().getGroup_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__2__Impl"


    // $ANTLR start "rule__EvidenceRef__Group_1__3"
    // InternalDynamicGoalModel.g:3235:1: rule__EvidenceRef__Group_1__3 : rule__EvidenceRef__Group_1__3__Impl ;
    public final void rule__EvidenceRef__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3239:1: ( rule__EvidenceRef__Group_1__3__Impl )
            // InternalDynamicGoalModel.g:3240:2: rule__EvidenceRef__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__3"


    // $ANTLR start "rule__EvidenceRef__Group_1__3__Impl"
    // InternalDynamicGoalModel.g:3246:1: rule__EvidenceRef__Group_1__3__Impl : ( ')' ) ;
    public final void rule__EvidenceRef__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3250:1: ( ( ')' ) )
            // InternalDynamicGoalModel.g:3251:1: ( ')' )
            {
            // InternalDynamicGoalModel.g:3251:1: ( ')' )
            // InternalDynamicGoalModel.g:3252:2: ')'
            {
             before(grammarAccess.getEvidenceRefAccess().getRightParenthesisKeyword_1_3()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getEvidenceRefAccess().getRightParenthesisKeyword_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1__3__Impl"


    // $ANTLR start "rule__EvidenceRef__Group_1_2__0"
    // InternalDynamicGoalModel.g:3262:1: rule__EvidenceRef__Group_1_2__0 : rule__EvidenceRef__Group_1_2__0__Impl rule__EvidenceRef__Group_1_2__1 ;
    public final void rule__EvidenceRef__Group_1_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3266:1: ( rule__EvidenceRef__Group_1_2__0__Impl rule__EvidenceRef__Group_1_2__1 )
            // InternalDynamicGoalModel.g:3267:2: rule__EvidenceRef__Group_1_2__0__Impl rule__EvidenceRef__Group_1_2__1
            {
            pushFollow(FOLLOW_8);
            rule__EvidenceRef__Group_1_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group_1_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1_2__0"


    // $ANTLR start "rule__EvidenceRef__Group_1_2__0__Impl"
    // InternalDynamicGoalModel.g:3274:1: rule__EvidenceRef__Group_1_2__0__Impl : ( ',' ) ;
    public final void rule__EvidenceRef__Group_1_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3278:1: ( ( ',' ) )
            // InternalDynamicGoalModel.g:3279:1: ( ',' )
            {
            // InternalDynamicGoalModel.g:3279:1: ( ',' )
            // InternalDynamicGoalModel.g:3280:2: ','
            {
             before(grammarAccess.getEvidenceRefAccess().getCommaKeyword_1_2_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getEvidenceRefAccess().getCommaKeyword_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1_2__0__Impl"


    // $ANTLR start "rule__EvidenceRef__Group_1_2__1"
    // InternalDynamicGoalModel.g:3289:1: rule__EvidenceRef__Group_1_2__1 : rule__EvidenceRef__Group_1_2__1__Impl ;
    public final void rule__EvidenceRef__Group_1_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3293:1: ( rule__EvidenceRef__Group_1_2__1__Impl )
            // InternalDynamicGoalModel.g:3294:2: rule__EvidenceRef__Group_1_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__Group_1_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1_2__1"


    // $ANTLR start "rule__EvidenceRef__Group_1_2__1__Impl"
    // InternalDynamicGoalModel.g:3300:1: rule__EvidenceRef__Group_1_2__1__Impl : ( ( rule__EvidenceRef__ParamsAssignment_1_2_1 ) ) ;
    public final void rule__EvidenceRef__Group_1_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3304:1: ( ( ( rule__EvidenceRef__ParamsAssignment_1_2_1 ) ) )
            // InternalDynamicGoalModel.g:3305:1: ( ( rule__EvidenceRef__ParamsAssignment_1_2_1 ) )
            {
            // InternalDynamicGoalModel.g:3305:1: ( ( rule__EvidenceRef__ParamsAssignment_1_2_1 ) )
            // InternalDynamicGoalModel.g:3306:2: ( rule__EvidenceRef__ParamsAssignment_1_2_1 )
            {
             before(grammarAccess.getEvidenceRefAccess().getParamsAssignment_1_2_1()); 
            // InternalDynamicGoalModel.g:3307:2: ( rule__EvidenceRef__ParamsAssignment_1_2_1 )
            // InternalDynamicGoalModel.g:3307:3: rule__EvidenceRef__ParamsAssignment_1_2_1
            {
            pushFollow(FOLLOW_2);
            rule__EvidenceRef__ParamsAssignment_1_2_1();

            state._fsp--;


            }

             after(grammarAccess.getEvidenceRefAccess().getParamsAssignment_1_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__Group_1_2__1__Impl"


    // $ANTLR start "rule__TemporalCondition__Group__0"
    // InternalDynamicGoalModel.g:3316:1: rule__TemporalCondition__Group__0 : rule__TemporalCondition__Group__0__Impl rule__TemporalCondition__Group__1 ;
    public final void rule__TemporalCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3320:1: ( rule__TemporalCondition__Group__0__Impl rule__TemporalCondition__Group__1 )
            // InternalDynamicGoalModel.g:3321:2: rule__TemporalCondition__Group__0__Impl rule__TemporalCondition__Group__1
            {
            pushFollow(FOLLOW_28);
            rule__TemporalCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__0"


    // $ANTLR start "rule__TemporalCondition__Group__0__Impl"
    // InternalDynamicGoalModel.g:3328:1: rule__TemporalCondition__Group__0__Impl : ( ( rule__TemporalCondition__TemporalOpAssignment_0 ) ) ;
    public final void rule__TemporalCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3332:1: ( ( ( rule__TemporalCondition__TemporalOpAssignment_0 ) ) )
            // InternalDynamicGoalModel.g:3333:1: ( ( rule__TemporalCondition__TemporalOpAssignment_0 ) )
            {
            // InternalDynamicGoalModel.g:3333:1: ( ( rule__TemporalCondition__TemporalOpAssignment_0 ) )
            // InternalDynamicGoalModel.g:3334:2: ( rule__TemporalCondition__TemporalOpAssignment_0 )
            {
             before(grammarAccess.getTemporalConditionAccess().getTemporalOpAssignment_0()); 
            // InternalDynamicGoalModel.g:3335:2: ( rule__TemporalCondition__TemporalOpAssignment_0 )
            // InternalDynamicGoalModel.g:3335:3: rule__TemporalCondition__TemporalOpAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__TemporalCondition__TemporalOpAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTemporalConditionAccess().getTemporalOpAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__0__Impl"


    // $ANTLR start "rule__TemporalCondition__Group__1"
    // InternalDynamicGoalModel.g:3343:1: rule__TemporalCondition__Group__1 : rule__TemporalCondition__Group__1__Impl rule__TemporalCondition__Group__2 ;
    public final void rule__TemporalCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3347:1: ( rule__TemporalCondition__Group__1__Impl rule__TemporalCondition__Group__2 )
            // InternalDynamicGoalModel.g:3348:2: rule__TemporalCondition__Group__1__Impl rule__TemporalCondition__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__TemporalCondition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__1"


    // $ANTLR start "rule__TemporalCondition__Group__1__Impl"
    // InternalDynamicGoalModel.g:3355:1: rule__TemporalCondition__Group__1__Impl : ( '(' ) ;
    public final void rule__TemporalCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3359:1: ( ( '(' ) )
            // InternalDynamicGoalModel.g:3360:1: ( '(' )
            {
            // InternalDynamicGoalModel.g:3360:1: ( '(' )
            // InternalDynamicGoalModel.g:3361:2: '('
            {
             before(grammarAccess.getTemporalConditionAccess().getLeftParenthesisKeyword_1()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getTemporalConditionAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__1__Impl"


    // $ANTLR start "rule__TemporalCondition__Group__2"
    // InternalDynamicGoalModel.g:3370:1: rule__TemporalCondition__Group__2 : rule__TemporalCondition__Group__2__Impl rule__TemporalCondition__Group__3 ;
    public final void rule__TemporalCondition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3374:1: ( rule__TemporalCondition__Group__2__Impl rule__TemporalCondition__Group__3 )
            // InternalDynamicGoalModel.g:3375:2: rule__TemporalCondition__Group__2__Impl rule__TemporalCondition__Group__3
            {
            pushFollow(FOLLOW_41);
            rule__TemporalCondition__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__2"


    // $ANTLR start "rule__TemporalCondition__Group__2__Impl"
    // InternalDynamicGoalModel.g:3382:1: rule__TemporalCondition__Group__2__Impl : ( ( rule__TemporalCondition__EvidenceRefAssignment_2 ) ) ;
    public final void rule__TemporalCondition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3386:1: ( ( ( rule__TemporalCondition__EvidenceRefAssignment_2 ) ) )
            // InternalDynamicGoalModel.g:3387:1: ( ( rule__TemporalCondition__EvidenceRefAssignment_2 ) )
            {
            // InternalDynamicGoalModel.g:3387:1: ( ( rule__TemporalCondition__EvidenceRefAssignment_2 ) )
            // InternalDynamicGoalModel.g:3388:2: ( rule__TemporalCondition__EvidenceRefAssignment_2 )
            {
             before(grammarAccess.getTemporalConditionAccess().getEvidenceRefAssignment_2()); 
            // InternalDynamicGoalModel.g:3389:2: ( rule__TemporalCondition__EvidenceRefAssignment_2 )
            // InternalDynamicGoalModel.g:3389:3: rule__TemporalCondition__EvidenceRefAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TemporalCondition__EvidenceRefAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTemporalConditionAccess().getEvidenceRefAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__2__Impl"


    // $ANTLR start "rule__TemporalCondition__Group__3"
    // InternalDynamicGoalModel.g:3397:1: rule__TemporalCondition__Group__3 : rule__TemporalCondition__Group__3__Impl rule__TemporalCondition__Group__4 ;
    public final void rule__TemporalCondition__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3401:1: ( rule__TemporalCondition__Group__3__Impl rule__TemporalCondition__Group__4 )
            // InternalDynamicGoalModel.g:3402:2: rule__TemporalCondition__Group__3__Impl rule__TemporalCondition__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__TemporalCondition__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__3"


    // $ANTLR start "rule__TemporalCondition__Group__3__Impl"
    // InternalDynamicGoalModel.g:3409:1: rule__TemporalCondition__Group__3__Impl : ( ',' ) ;
    public final void rule__TemporalCondition__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3413:1: ( ( ',' ) )
            // InternalDynamicGoalModel.g:3414:1: ( ',' )
            {
            // InternalDynamicGoalModel.g:3414:1: ( ',' )
            // InternalDynamicGoalModel.g:3415:2: ','
            {
             before(grammarAccess.getTemporalConditionAccess().getCommaKeyword_3()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getTemporalConditionAccess().getCommaKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__3__Impl"


    // $ANTLR start "rule__TemporalCondition__Group__4"
    // InternalDynamicGoalModel.g:3424:1: rule__TemporalCondition__Group__4 : rule__TemporalCondition__Group__4__Impl rule__TemporalCondition__Group__5 ;
    public final void rule__TemporalCondition__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3428:1: ( rule__TemporalCondition__Group__4__Impl rule__TemporalCondition__Group__5 )
            // InternalDynamicGoalModel.g:3429:2: rule__TemporalCondition__Group__4__Impl rule__TemporalCondition__Group__5
            {
            pushFollow(FOLLOW_30);
            rule__TemporalCondition__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__4"


    // $ANTLR start "rule__TemporalCondition__Group__4__Impl"
    // InternalDynamicGoalModel.g:3436:1: rule__TemporalCondition__Group__4__Impl : ( ( rule__TemporalCondition__DurationAssignment_4 ) ) ;
    public final void rule__TemporalCondition__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3440:1: ( ( ( rule__TemporalCondition__DurationAssignment_4 ) ) )
            // InternalDynamicGoalModel.g:3441:1: ( ( rule__TemporalCondition__DurationAssignment_4 ) )
            {
            // InternalDynamicGoalModel.g:3441:1: ( ( rule__TemporalCondition__DurationAssignment_4 ) )
            // InternalDynamicGoalModel.g:3442:2: ( rule__TemporalCondition__DurationAssignment_4 )
            {
             before(grammarAccess.getTemporalConditionAccess().getDurationAssignment_4()); 
            // InternalDynamicGoalModel.g:3443:2: ( rule__TemporalCondition__DurationAssignment_4 )
            // InternalDynamicGoalModel.g:3443:3: rule__TemporalCondition__DurationAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TemporalCondition__DurationAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTemporalConditionAccess().getDurationAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__4__Impl"


    // $ANTLR start "rule__TemporalCondition__Group__5"
    // InternalDynamicGoalModel.g:3451:1: rule__TemporalCondition__Group__5 : rule__TemporalCondition__Group__5__Impl ;
    public final void rule__TemporalCondition__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3455:1: ( rule__TemporalCondition__Group__5__Impl )
            // InternalDynamicGoalModel.g:3456:2: rule__TemporalCondition__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TemporalCondition__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__5"


    // $ANTLR start "rule__TemporalCondition__Group__5__Impl"
    // InternalDynamicGoalModel.g:3462:1: rule__TemporalCondition__Group__5__Impl : ( ')' ) ;
    public final void rule__TemporalCondition__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3466:1: ( ( ')' ) )
            // InternalDynamicGoalModel.g:3467:1: ( ')' )
            {
            // InternalDynamicGoalModel.g:3467:1: ( ')' )
            // InternalDynamicGoalModel.g:3468:2: ')'
            {
             before(grammarAccess.getTemporalConditionAccess().getRightParenthesisKeyword_5()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getTemporalConditionAccess().getRightParenthesisKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__Group__5__Impl"


    // $ANTLR start "rule__ComparisonCondition__Group__0"
    // InternalDynamicGoalModel.g:3478:1: rule__ComparisonCondition__Group__0 : rule__ComparisonCondition__Group__0__Impl rule__ComparisonCondition__Group__1 ;
    public final void rule__ComparisonCondition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3482:1: ( rule__ComparisonCondition__Group__0__Impl rule__ComparisonCondition__Group__1 )
            // InternalDynamicGoalModel.g:3483:2: rule__ComparisonCondition__Group__0__Impl rule__ComparisonCondition__Group__1
            {
            pushFollow(FOLLOW_42);
            rule__ComparisonCondition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__Group__0"


    // $ANTLR start "rule__ComparisonCondition__Group__0__Impl"
    // InternalDynamicGoalModel.g:3490:1: rule__ComparisonCondition__Group__0__Impl : ( ( rule__ComparisonCondition__LeftAssignment_0 ) ) ;
    public final void rule__ComparisonCondition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3494:1: ( ( ( rule__ComparisonCondition__LeftAssignment_0 ) ) )
            // InternalDynamicGoalModel.g:3495:1: ( ( rule__ComparisonCondition__LeftAssignment_0 ) )
            {
            // InternalDynamicGoalModel.g:3495:1: ( ( rule__ComparisonCondition__LeftAssignment_0 ) )
            // InternalDynamicGoalModel.g:3496:2: ( rule__ComparisonCondition__LeftAssignment_0 )
            {
             before(grammarAccess.getComparisonConditionAccess().getLeftAssignment_0()); 
            // InternalDynamicGoalModel.g:3497:2: ( rule__ComparisonCondition__LeftAssignment_0 )
            // InternalDynamicGoalModel.g:3497:3: rule__ComparisonCondition__LeftAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__LeftAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getComparisonConditionAccess().getLeftAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__Group__0__Impl"


    // $ANTLR start "rule__ComparisonCondition__Group__1"
    // InternalDynamicGoalModel.g:3505:1: rule__ComparisonCondition__Group__1 : rule__ComparisonCondition__Group__1__Impl rule__ComparisonCondition__Group__2 ;
    public final void rule__ComparisonCondition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3509:1: ( rule__ComparisonCondition__Group__1__Impl rule__ComparisonCondition__Group__2 )
            // InternalDynamicGoalModel.g:3510:2: rule__ComparisonCondition__Group__1__Impl rule__ComparisonCondition__Group__2
            {
            pushFollow(FOLLOW_8);
            rule__ComparisonCondition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__Group__1"


    // $ANTLR start "rule__ComparisonCondition__Group__1__Impl"
    // InternalDynamicGoalModel.g:3517:1: rule__ComparisonCondition__Group__1__Impl : ( ( rule__ComparisonCondition__ComparatorAssignment_1 ) ) ;
    public final void rule__ComparisonCondition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3521:1: ( ( ( rule__ComparisonCondition__ComparatorAssignment_1 ) ) )
            // InternalDynamicGoalModel.g:3522:1: ( ( rule__ComparisonCondition__ComparatorAssignment_1 ) )
            {
            // InternalDynamicGoalModel.g:3522:1: ( ( rule__ComparisonCondition__ComparatorAssignment_1 ) )
            // InternalDynamicGoalModel.g:3523:2: ( rule__ComparisonCondition__ComparatorAssignment_1 )
            {
             before(grammarAccess.getComparisonConditionAccess().getComparatorAssignment_1()); 
            // InternalDynamicGoalModel.g:3524:2: ( rule__ComparisonCondition__ComparatorAssignment_1 )
            // InternalDynamicGoalModel.g:3524:3: rule__ComparisonCondition__ComparatorAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__ComparatorAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getComparisonConditionAccess().getComparatorAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__Group__1__Impl"


    // $ANTLR start "rule__ComparisonCondition__Group__2"
    // InternalDynamicGoalModel.g:3532:1: rule__ComparisonCondition__Group__2 : rule__ComparisonCondition__Group__2__Impl ;
    public final void rule__ComparisonCondition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3536:1: ( rule__ComparisonCondition__Group__2__Impl )
            // InternalDynamicGoalModel.g:3537:2: rule__ComparisonCondition__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__Group__2"


    // $ANTLR start "rule__ComparisonCondition__Group__2__Impl"
    // InternalDynamicGoalModel.g:3543:1: rule__ComparisonCondition__Group__2__Impl : ( ( rule__ComparisonCondition__RightAssignment_2 ) ) ;
    public final void rule__ComparisonCondition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3547:1: ( ( ( rule__ComparisonCondition__RightAssignment_2 ) ) )
            // InternalDynamicGoalModel.g:3548:1: ( ( rule__ComparisonCondition__RightAssignment_2 ) )
            {
            // InternalDynamicGoalModel.g:3548:1: ( ( rule__ComparisonCondition__RightAssignment_2 ) )
            // InternalDynamicGoalModel.g:3549:2: ( rule__ComparisonCondition__RightAssignment_2 )
            {
             before(grammarAccess.getComparisonConditionAccess().getRightAssignment_2()); 
            // InternalDynamicGoalModel.g:3550:2: ( rule__ComparisonCondition__RightAssignment_2 )
            // InternalDynamicGoalModel.g:3550:3: rule__ComparisonCondition__RightAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ComparisonCondition__RightAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getComparisonConditionAccess().getRightAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__Group__2__Impl"


    // $ANTLR start "rule__Precedence__Group__0"
    // InternalDynamicGoalModel.g:3559:1: rule__Precedence__Group__0 : rule__Precedence__Group__0__Impl rule__Precedence__Group__1 ;
    public final void rule__Precedence__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3563:1: ( rule__Precedence__Group__0__Impl rule__Precedence__Group__1 )
            // InternalDynamicGoalModel.g:3564:2: rule__Precedence__Group__0__Impl rule__Precedence__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Precedence__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__0"


    // $ANTLR start "rule__Precedence__Group__0__Impl"
    // InternalDynamicGoalModel.g:3571:1: rule__Precedence__Group__0__Impl : ( 'Precedence' ) ;
    public final void rule__Precedence__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3575:1: ( ( 'Precedence' ) )
            // InternalDynamicGoalModel.g:3576:1: ( 'Precedence' )
            {
            // InternalDynamicGoalModel.g:3576:1: ( 'Precedence' )
            // InternalDynamicGoalModel.g:3577:2: 'Precedence'
            {
             before(grammarAccess.getPrecedenceAccess().getPrecedenceKeyword_0()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getPrecedenceAccess().getPrecedenceKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__0__Impl"


    // $ANTLR start "rule__Precedence__Group__1"
    // InternalDynamicGoalModel.g:3586:1: rule__Precedence__Group__1 : rule__Precedence__Group__1__Impl rule__Precedence__Group__2 ;
    public final void rule__Precedence__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3590:1: ( rule__Precedence__Group__1__Impl rule__Precedence__Group__2 )
            // InternalDynamicGoalModel.g:3591:2: rule__Precedence__Group__1__Impl rule__Precedence__Group__2
            {
            pushFollow(FOLLOW_43);
            rule__Precedence__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__1"


    // $ANTLR start "rule__Precedence__Group__1__Impl"
    // InternalDynamicGoalModel.g:3598:1: rule__Precedence__Group__1__Impl : ( '{' ) ;
    public final void rule__Precedence__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3602:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:3603:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:3603:1: ( '{' )
            // InternalDynamicGoalModel.g:3604:2: '{'
            {
             before(grammarAccess.getPrecedenceAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getPrecedenceAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__1__Impl"


    // $ANTLR start "rule__Precedence__Group__2"
    // InternalDynamicGoalModel.g:3613:1: rule__Precedence__Group__2 : rule__Precedence__Group__2__Impl rule__Precedence__Group__3 ;
    public final void rule__Precedence__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3617:1: ( rule__Precedence__Group__2__Impl rule__Precedence__Group__3 )
            // InternalDynamicGoalModel.g:3618:2: rule__Precedence__Group__2__Impl rule__Precedence__Group__3
            {
            pushFollow(FOLLOW_43);
            rule__Precedence__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__2"


    // $ANTLR start "rule__Precedence__Group__2__Impl"
    // InternalDynamicGoalModel.g:3625:1: rule__Precedence__Group__2__Impl : ( ( rule__Precedence__Group_2__0 )? ) ;
    public final void rule__Precedence__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3629:1: ( ( ( rule__Precedence__Group_2__0 )? ) )
            // InternalDynamicGoalModel.g:3630:1: ( ( rule__Precedence__Group_2__0 )? )
            {
            // InternalDynamicGoalModel.g:3630:1: ( ( rule__Precedence__Group_2__0 )? )
            // InternalDynamicGoalModel.g:3631:2: ( rule__Precedence__Group_2__0 )?
            {
             before(grammarAccess.getPrecedenceAccess().getGroup_2()); 
            // InternalDynamicGoalModel.g:3632:2: ( rule__Precedence__Group_2__0 )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==63) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalDynamicGoalModel.g:3632:3: rule__Precedence__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Precedence__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPrecedenceAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__2__Impl"


    // $ANTLR start "rule__Precedence__Group__3"
    // InternalDynamicGoalModel.g:3640:1: rule__Precedence__Group__3 : rule__Precedence__Group__3__Impl rule__Precedence__Group__4 ;
    public final void rule__Precedence__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3644:1: ( rule__Precedence__Group__3__Impl rule__Precedence__Group__4 )
            // InternalDynamicGoalModel.g:3645:2: rule__Precedence__Group__3__Impl rule__Precedence__Group__4
            {
            pushFollow(FOLLOW_44);
            rule__Precedence__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__3"


    // $ANTLR start "rule__Precedence__Group__3__Impl"
    // InternalDynamicGoalModel.g:3652:1: rule__Precedence__Group__3__Impl : ( ( rule__Precedence__OrderingAssignment_3 ) ) ;
    public final void rule__Precedence__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3656:1: ( ( ( rule__Precedence__OrderingAssignment_3 ) ) )
            // InternalDynamicGoalModel.g:3657:1: ( ( rule__Precedence__OrderingAssignment_3 ) )
            {
            // InternalDynamicGoalModel.g:3657:1: ( ( rule__Precedence__OrderingAssignment_3 ) )
            // InternalDynamicGoalModel.g:3658:2: ( rule__Precedence__OrderingAssignment_3 )
            {
             before(grammarAccess.getPrecedenceAccess().getOrderingAssignment_3()); 
            // InternalDynamicGoalModel.g:3659:2: ( rule__Precedence__OrderingAssignment_3 )
            // InternalDynamicGoalModel.g:3659:3: rule__Precedence__OrderingAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__OrderingAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getPrecedenceAccess().getOrderingAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__3__Impl"


    // $ANTLR start "rule__Precedence__Group__4"
    // InternalDynamicGoalModel.g:3667:1: rule__Precedence__Group__4 : rule__Precedence__Group__4__Impl rule__Precedence__Group__5 ;
    public final void rule__Precedence__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3671:1: ( rule__Precedence__Group__4__Impl rule__Precedence__Group__5 )
            // InternalDynamicGoalModel.g:3672:2: rule__Precedence__Group__4__Impl rule__Precedence__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__Precedence__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__4"


    // $ANTLR start "rule__Precedence__Group__4__Impl"
    // InternalDynamicGoalModel.g:3679:1: rule__Precedence__Group__4__Impl : ( ( ( rule__Precedence__Group_4__0 ) ) ( ( rule__Precedence__Group_4__0 )* ) ) ;
    public final void rule__Precedence__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3683:1: ( ( ( ( rule__Precedence__Group_4__0 ) ) ( ( rule__Precedence__Group_4__0 )* ) ) )
            // InternalDynamicGoalModel.g:3684:1: ( ( ( rule__Precedence__Group_4__0 ) ) ( ( rule__Precedence__Group_4__0 )* ) )
            {
            // InternalDynamicGoalModel.g:3684:1: ( ( ( rule__Precedence__Group_4__0 ) ) ( ( rule__Precedence__Group_4__0 )* ) )
            // InternalDynamicGoalModel.g:3685:2: ( ( rule__Precedence__Group_4__0 ) ) ( ( rule__Precedence__Group_4__0 )* )
            {
            // InternalDynamicGoalModel.g:3685:2: ( ( rule__Precedence__Group_4__0 ) )
            // InternalDynamicGoalModel.g:3686:3: ( rule__Precedence__Group_4__0 )
            {
             before(grammarAccess.getPrecedenceAccess().getGroup_4()); 
            // InternalDynamicGoalModel.g:3687:3: ( rule__Precedence__Group_4__0 )
            // InternalDynamicGoalModel.g:3687:4: rule__Precedence__Group_4__0
            {
            pushFollow(FOLLOW_45);
            rule__Precedence__Group_4__0();

            state._fsp--;


            }

             after(grammarAccess.getPrecedenceAccess().getGroup_4()); 

            }

            // InternalDynamicGoalModel.g:3690:2: ( ( rule__Precedence__Group_4__0 )* )
            // InternalDynamicGoalModel.g:3691:3: ( rule__Precedence__Group_4__0 )*
            {
             before(grammarAccess.getPrecedenceAccess().getGroup_4()); 
            // InternalDynamicGoalModel.g:3692:3: ( rule__Precedence__Group_4__0 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==24) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:3692:4: rule__Precedence__Group_4__0
            	    {
            	    pushFollow(FOLLOW_45);
            	    rule__Precedence__Group_4__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

             after(grammarAccess.getPrecedenceAccess().getGroup_4()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__4__Impl"


    // $ANTLR start "rule__Precedence__Group__5"
    // InternalDynamicGoalModel.g:3701:1: rule__Precedence__Group__5 : rule__Precedence__Group__5__Impl ;
    public final void rule__Precedence__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3705:1: ( rule__Precedence__Group__5__Impl )
            // InternalDynamicGoalModel.g:3706:2: rule__Precedence__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__5"


    // $ANTLR start "rule__Precedence__Group__5__Impl"
    // InternalDynamicGoalModel.g:3712:1: rule__Precedence__Group__5__Impl : ( '}' ) ;
    public final void rule__Precedence__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3716:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:3717:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:3717:1: ( '}' )
            // InternalDynamicGoalModel.g:3718:2: '}'
            {
             before(grammarAccess.getPrecedenceAccess().getRightCurlyBracketKeyword_5()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getPrecedenceAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group__5__Impl"


    // $ANTLR start "rule__Precedence__Group_2__0"
    // InternalDynamicGoalModel.g:3728:1: rule__Precedence__Group_2__0 : rule__Precedence__Group_2__0__Impl rule__Precedence__Group_2__1 ;
    public final void rule__Precedence__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3732:1: ( rule__Precedence__Group_2__0__Impl rule__Precedence__Group_2__1 )
            // InternalDynamicGoalModel.g:3733:2: rule__Precedence__Group_2__0__Impl rule__Precedence__Group_2__1
            {
            pushFollow(FOLLOW_8);
            rule__Precedence__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_2__0"


    // $ANTLR start "rule__Precedence__Group_2__0__Impl"
    // InternalDynamicGoalModel.g:3740:1: rule__Precedence__Group_2__0__Impl : ( 'justification' ) ;
    public final void rule__Precedence__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3744:1: ( ( 'justification' ) )
            // InternalDynamicGoalModel.g:3745:1: ( 'justification' )
            {
            // InternalDynamicGoalModel.g:3745:1: ( 'justification' )
            // InternalDynamicGoalModel.g:3746:2: 'justification'
            {
             before(grammarAccess.getPrecedenceAccess().getJustificationKeyword_2_0()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getPrecedenceAccess().getJustificationKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_2__0__Impl"


    // $ANTLR start "rule__Precedence__Group_2__1"
    // InternalDynamicGoalModel.g:3755:1: rule__Precedence__Group_2__1 : rule__Precedence__Group_2__1__Impl ;
    public final void rule__Precedence__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3759:1: ( rule__Precedence__Group_2__1__Impl )
            // InternalDynamicGoalModel.g:3760:2: rule__Precedence__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_2__1"


    // $ANTLR start "rule__Precedence__Group_2__1__Impl"
    // InternalDynamicGoalModel.g:3766:1: rule__Precedence__Group_2__1__Impl : ( ( rule__Precedence__JustificationAssignment_2_1 ) ) ;
    public final void rule__Precedence__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3770:1: ( ( ( rule__Precedence__JustificationAssignment_2_1 ) ) )
            // InternalDynamicGoalModel.g:3771:1: ( ( rule__Precedence__JustificationAssignment_2_1 ) )
            {
            // InternalDynamicGoalModel.g:3771:1: ( ( rule__Precedence__JustificationAssignment_2_1 ) )
            // InternalDynamicGoalModel.g:3772:2: ( rule__Precedence__JustificationAssignment_2_1 )
            {
             before(grammarAccess.getPrecedenceAccess().getJustificationAssignment_2_1()); 
            // InternalDynamicGoalModel.g:3773:2: ( rule__Precedence__JustificationAssignment_2_1 )
            // InternalDynamicGoalModel.g:3773:3: rule__Precedence__JustificationAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__JustificationAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getPrecedenceAccess().getJustificationAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_2__1__Impl"


    // $ANTLR start "rule__Precedence__Group_4__0"
    // InternalDynamicGoalModel.g:3782:1: rule__Precedence__Group_4__0 : rule__Precedence__Group_4__0__Impl rule__Precedence__Group_4__1 ;
    public final void rule__Precedence__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3786:1: ( rule__Precedence__Group_4__0__Impl rule__Precedence__Group_4__1 )
            // InternalDynamicGoalModel.g:3787:2: rule__Precedence__Group_4__0__Impl rule__Precedence__Group_4__1
            {
            pushFollow(FOLLOW_43);
            rule__Precedence__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Precedence__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_4__0"


    // $ANTLR start "rule__Precedence__Group_4__0__Impl"
    // InternalDynamicGoalModel.g:3794:1: rule__Precedence__Group_4__0__Impl : ( '>' ) ;
    public final void rule__Precedence__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3798:1: ( ( '>' ) )
            // InternalDynamicGoalModel.g:3799:1: ( '>' )
            {
            // InternalDynamicGoalModel.g:3799:1: ( '>' )
            // InternalDynamicGoalModel.g:3800:2: '>'
            {
             before(grammarAccess.getPrecedenceAccess().getGreaterThanSignKeyword_4_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getPrecedenceAccess().getGreaterThanSignKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_4__0__Impl"


    // $ANTLR start "rule__Precedence__Group_4__1"
    // InternalDynamicGoalModel.g:3809:1: rule__Precedence__Group_4__1 : rule__Precedence__Group_4__1__Impl ;
    public final void rule__Precedence__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3813:1: ( rule__Precedence__Group_4__1__Impl )
            // InternalDynamicGoalModel.g:3814:2: rule__Precedence__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_4__1"


    // $ANTLR start "rule__Precedence__Group_4__1__Impl"
    // InternalDynamicGoalModel.g:3820:1: rule__Precedence__Group_4__1__Impl : ( ( rule__Precedence__OrderingAssignment_4_1 ) ) ;
    public final void rule__Precedence__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3824:1: ( ( ( rule__Precedence__OrderingAssignment_4_1 ) ) )
            // InternalDynamicGoalModel.g:3825:1: ( ( rule__Precedence__OrderingAssignment_4_1 ) )
            {
            // InternalDynamicGoalModel.g:3825:1: ( ( rule__Precedence__OrderingAssignment_4_1 ) )
            // InternalDynamicGoalModel.g:3826:2: ( rule__Precedence__OrderingAssignment_4_1 )
            {
             before(grammarAccess.getPrecedenceAccess().getOrderingAssignment_4_1()); 
            // InternalDynamicGoalModel.g:3827:2: ( rule__Precedence__OrderingAssignment_4_1 )
            // InternalDynamicGoalModel.g:3827:3: rule__Precedence__OrderingAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Precedence__OrderingAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getPrecedenceAccess().getOrderingAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__Group_4__1__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__0"
    // InternalDynamicGoalModel.g:3836:1: rule__ResponseBinding__Group__0 : rule__ResponseBinding__Group__0__Impl rule__ResponseBinding__Group__1 ;
    public final void rule__ResponseBinding__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3840:1: ( rule__ResponseBinding__Group__0__Impl rule__ResponseBinding__Group__1 )
            // InternalDynamicGoalModel.g:3841:2: rule__ResponseBinding__Group__0__Impl rule__ResponseBinding__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__ResponseBinding__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__0"


    // $ANTLR start "rule__ResponseBinding__Group__0__Impl"
    // InternalDynamicGoalModel.g:3848:1: rule__ResponseBinding__Group__0__Impl : ( 'ResponseBinding' ) ;
    public final void rule__ResponseBinding__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3852:1: ( ( 'ResponseBinding' ) )
            // InternalDynamicGoalModel.g:3853:1: ( 'ResponseBinding' )
            {
            // InternalDynamicGoalModel.g:3853:1: ( 'ResponseBinding' )
            // InternalDynamicGoalModel.g:3854:2: 'ResponseBinding'
            {
             before(grammarAccess.getResponseBindingAccess().getResponseBindingKeyword_0()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getResponseBindingKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__0__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__1"
    // InternalDynamicGoalModel.g:3863:1: rule__ResponseBinding__Group__1 : rule__ResponseBinding__Group__1__Impl rule__ResponseBinding__Group__2 ;
    public final void rule__ResponseBinding__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3867:1: ( rule__ResponseBinding__Group__1__Impl rule__ResponseBinding__Group__2 )
            // InternalDynamicGoalModel.g:3868:2: rule__ResponseBinding__Group__1__Impl rule__ResponseBinding__Group__2
            {
            pushFollow(FOLLOW_46);
            rule__ResponseBinding__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__1"


    // $ANTLR start "rule__ResponseBinding__Group__1__Impl"
    // InternalDynamicGoalModel.g:3875:1: rule__ResponseBinding__Group__1__Impl : ( '{' ) ;
    public final void rule__ResponseBinding__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3879:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:3880:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:3880:1: ( '{' )
            // InternalDynamicGoalModel.g:3881:2: '{'
            {
             before(grammarAccess.getResponseBindingAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__1__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__2"
    // InternalDynamicGoalModel.g:3890:1: rule__ResponseBinding__Group__2 : rule__ResponseBinding__Group__2__Impl rule__ResponseBinding__Group__3 ;
    public final void rule__ResponseBinding__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3894:1: ( rule__ResponseBinding__Group__2__Impl rule__ResponseBinding__Group__3 )
            // InternalDynamicGoalModel.g:3895:2: rule__ResponseBinding__Group__2__Impl rule__ResponseBinding__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__ResponseBinding__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__2"


    // $ANTLR start "rule__ResponseBinding__Group__2__Impl"
    // InternalDynamicGoalModel.g:3902:1: rule__ResponseBinding__Group__2__Impl : ( 'action' ) ;
    public final void rule__ResponseBinding__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3906:1: ( ( 'action' ) )
            // InternalDynamicGoalModel.g:3907:1: ( 'action' )
            {
            // InternalDynamicGoalModel.g:3907:1: ( 'action' )
            // InternalDynamicGoalModel.g:3908:2: 'action'
            {
             before(grammarAccess.getResponseBindingAccess().getActionKeyword_2()); 
            match(input,65,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getActionKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__2__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__3"
    // InternalDynamicGoalModel.g:3917:1: rule__ResponseBinding__Group__3 : rule__ResponseBinding__Group__3__Impl rule__ResponseBinding__Group__4 ;
    public final void rule__ResponseBinding__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3921:1: ( rule__ResponseBinding__Group__3__Impl rule__ResponseBinding__Group__4 )
            // InternalDynamicGoalModel.g:3922:2: rule__ResponseBinding__Group__3__Impl rule__ResponseBinding__Group__4
            {
            pushFollow(FOLLOW_47);
            rule__ResponseBinding__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__3"


    // $ANTLR start "rule__ResponseBinding__Group__3__Impl"
    // InternalDynamicGoalModel.g:3929:1: rule__ResponseBinding__Group__3__Impl : ( ( rule__ResponseBinding__ActionAssignment_3 ) ) ;
    public final void rule__ResponseBinding__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3933:1: ( ( ( rule__ResponseBinding__ActionAssignment_3 ) ) )
            // InternalDynamicGoalModel.g:3934:1: ( ( rule__ResponseBinding__ActionAssignment_3 ) )
            {
            // InternalDynamicGoalModel.g:3934:1: ( ( rule__ResponseBinding__ActionAssignment_3 ) )
            // InternalDynamicGoalModel.g:3935:2: ( rule__ResponseBinding__ActionAssignment_3 )
            {
             before(grammarAccess.getResponseBindingAccess().getActionAssignment_3()); 
            // InternalDynamicGoalModel.g:3936:2: ( rule__ResponseBinding__ActionAssignment_3 )
            // InternalDynamicGoalModel.g:3936:3: rule__ResponseBinding__ActionAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__ActionAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getResponseBindingAccess().getActionAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__3__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__4"
    // InternalDynamicGoalModel.g:3944:1: rule__ResponseBinding__Group__4 : rule__ResponseBinding__Group__4__Impl rule__ResponseBinding__Group__5 ;
    public final void rule__ResponseBinding__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3948:1: ( rule__ResponseBinding__Group__4__Impl rule__ResponseBinding__Group__5 )
            // InternalDynamicGoalModel.g:3949:2: rule__ResponseBinding__Group__4__Impl rule__ResponseBinding__Group__5
            {
            pushFollow(FOLLOW_47);
            rule__ResponseBinding__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__4"


    // $ANTLR start "rule__ResponseBinding__Group__4__Impl"
    // InternalDynamicGoalModel.g:3956:1: rule__ResponseBinding__Group__4__Impl : ( ( rule__ResponseBinding__Group_4__0 )? ) ;
    public final void rule__ResponseBinding__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3960:1: ( ( ( rule__ResponseBinding__Group_4__0 )? ) )
            // InternalDynamicGoalModel.g:3961:1: ( ( rule__ResponseBinding__Group_4__0 )? )
            {
            // InternalDynamicGoalModel.g:3961:1: ( ( rule__ResponseBinding__Group_4__0 )? )
            // InternalDynamicGoalModel.g:3962:2: ( rule__ResponseBinding__Group_4__0 )?
            {
             before(grammarAccess.getResponseBindingAccess().getGroup_4()); 
            // InternalDynamicGoalModel.g:3963:2: ( rule__ResponseBinding__Group_4__0 )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==66) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalDynamicGoalModel.g:3963:3: rule__ResponseBinding__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ResponseBinding__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getResponseBindingAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__4__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__5"
    // InternalDynamicGoalModel.g:3971:1: rule__ResponseBinding__Group__5 : rule__ResponseBinding__Group__5__Impl rule__ResponseBinding__Group__6 ;
    public final void rule__ResponseBinding__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3975:1: ( rule__ResponseBinding__Group__5__Impl rule__ResponseBinding__Group__6 )
            // InternalDynamicGoalModel.g:3976:2: rule__ResponseBinding__Group__5__Impl rule__ResponseBinding__Group__6
            {
            pushFollow(FOLLOW_47);
            rule__ResponseBinding__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__5"


    // $ANTLR start "rule__ResponseBinding__Group__5__Impl"
    // InternalDynamicGoalModel.g:3983:1: rule__ResponseBinding__Group__5__Impl : ( ( rule__ResponseBinding__Group_5__0 )? ) ;
    public final void rule__ResponseBinding__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:3987:1: ( ( ( rule__ResponseBinding__Group_5__0 )? ) )
            // InternalDynamicGoalModel.g:3988:1: ( ( rule__ResponseBinding__Group_5__0 )? )
            {
            // InternalDynamicGoalModel.g:3988:1: ( ( rule__ResponseBinding__Group_5__0 )? )
            // InternalDynamicGoalModel.g:3989:2: ( rule__ResponseBinding__Group_5__0 )?
            {
             before(grammarAccess.getResponseBindingAccess().getGroup_5()); 
            // InternalDynamicGoalModel.g:3990:2: ( rule__ResponseBinding__Group_5__0 )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==67) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalDynamicGoalModel.g:3990:3: rule__ResponseBinding__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ResponseBinding__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getResponseBindingAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__5__Impl"


    // $ANTLR start "rule__ResponseBinding__Group__6"
    // InternalDynamicGoalModel.g:3998:1: rule__ResponseBinding__Group__6 : rule__ResponseBinding__Group__6__Impl ;
    public final void rule__ResponseBinding__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4002:1: ( rule__ResponseBinding__Group__6__Impl )
            // InternalDynamicGoalModel.g:4003:2: rule__ResponseBinding__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__6"


    // $ANTLR start "rule__ResponseBinding__Group__6__Impl"
    // InternalDynamicGoalModel.g:4009:1: rule__ResponseBinding__Group__6__Impl : ( '}' ) ;
    public final void rule__ResponseBinding__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4013:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:4014:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:4014:1: ( '}' )
            // InternalDynamicGoalModel.g:4015:2: '}'
            {
             before(grammarAccess.getResponseBindingAccess().getRightCurlyBracketKeyword_6()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group__6__Impl"


    // $ANTLR start "rule__ResponseBinding__Group_4__0"
    // InternalDynamicGoalModel.g:4025:1: rule__ResponseBinding__Group_4__0 : rule__ResponseBinding__Group_4__0__Impl rule__ResponseBinding__Group_4__1 ;
    public final void rule__ResponseBinding__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4029:1: ( rule__ResponseBinding__Group_4__0__Impl rule__ResponseBinding__Group_4__1 )
            // InternalDynamicGoalModel.g:4030:2: rule__ResponseBinding__Group_4__0__Impl rule__ResponseBinding__Group_4__1
            {
            pushFollow(FOLLOW_8);
            rule__ResponseBinding__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_4__0"


    // $ANTLR start "rule__ResponseBinding__Group_4__0__Impl"
    // InternalDynamicGoalModel.g:4037:1: rule__ResponseBinding__Group_4__0__Impl : ( 'ucmStep' ) ;
    public final void rule__ResponseBinding__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4041:1: ( ( 'ucmStep' ) )
            // InternalDynamicGoalModel.g:4042:1: ( 'ucmStep' )
            {
            // InternalDynamicGoalModel.g:4042:1: ( 'ucmStep' )
            // InternalDynamicGoalModel.g:4043:2: 'ucmStep'
            {
             before(grammarAccess.getResponseBindingAccess().getUcmStepKeyword_4_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getUcmStepKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_4__0__Impl"


    // $ANTLR start "rule__ResponseBinding__Group_4__1"
    // InternalDynamicGoalModel.g:4052:1: rule__ResponseBinding__Group_4__1 : rule__ResponseBinding__Group_4__1__Impl ;
    public final void rule__ResponseBinding__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4056:1: ( rule__ResponseBinding__Group_4__1__Impl )
            // InternalDynamicGoalModel.g:4057:2: rule__ResponseBinding__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_4__1"


    // $ANTLR start "rule__ResponseBinding__Group_4__1__Impl"
    // InternalDynamicGoalModel.g:4063:1: rule__ResponseBinding__Group_4__1__Impl : ( ( rule__ResponseBinding__UcmStepAssignment_4_1 ) ) ;
    public final void rule__ResponseBinding__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4067:1: ( ( ( rule__ResponseBinding__UcmStepAssignment_4_1 ) ) )
            // InternalDynamicGoalModel.g:4068:1: ( ( rule__ResponseBinding__UcmStepAssignment_4_1 ) )
            {
            // InternalDynamicGoalModel.g:4068:1: ( ( rule__ResponseBinding__UcmStepAssignment_4_1 ) )
            // InternalDynamicGoalModel.g:4069:2: ( rule__ResponseBinding__UcmStepAssignment_4_1 )
            {
             before(grammarAccess.getResponseBindingAccess().getUcmStepAssignment_4_1()); 
            // InternalDynamicGoalModel.g:4070:2: ( rule__ResponseBinding__UcmStepAssignment_4_1 )
            // InternalDynamicGoalModel.g:4070:3: rule__ResponseBinding__UcmStepAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__UcmStepAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getResponseBindingAccess().getUcmStepAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_4__1__Impl"


    // $ANTLR start "rule__ResponseBinding__Group_5__0"
    // InternalDynamicGoalModel.g:4079:1: rule__ResponseBinding__Group_5__0 : rule__ResponseBinding__Group_5__0__Impl rule__ResponseBinding__Group_5__1 ;
    public final void rule__ResponseBinding__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4083:1: ( rule__ResponseBinding__Group_5__0__Impl rule__ResponseBinding__Group_5__1 )
            // InternalDynamicGoalModel.g:4084:2: rule__ResponseBinding__Group_5__0__Impl rule__ResponseBinding__Group_5__1
            {
            pushFollow(FOLLOW_48);
            rule__ResponseBinding__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_5__0"


    // $ANTLR start "rule__ResponseBinding__Group_5__0__Impl"
    // InternalDynamicGoalModel.g:4091:1: rule__ResponseBinding__Group_5__0__Impl : ( 'noCartWrite' ) ;
    public final void rule__ResponseBinding__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4095:1: ( ( 'noCartWrite' ) )
            // InternalDynamicGoalModel.g:4096:1: ( 'noCartWrite' )
            {
            // InternalDynamicGoalModel.g:4096:1: ( 'noCartWrite' )
            // InternalDynamicGoalModel.g:4097:2: 'noCartWrite'
            {
             before(grammarAccess.getResponseBindingAccess().getNoCartWriteKeyword_5_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getNoCartWriteKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_5__0__Impl"


    // $ANTLR start "rule__ResponseBinding__Group_5__1"
    // InternalDynamicGoalModel.g:4106:1: rule__ResponseBinding__Group_5__1 : rule__ResponseBinding__Group_5__1__Impl ;
    public final void rule__ResponseBinding__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4110:1: ( rule__ResponseBinding__Group_5__1__Impl )
            // InternalDynamicGoalModel.g:4111:2: rule__ResponseBinding__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_5__1"


    // $ANTLR start "rule__ResponseBinding__Group_5__1__Impl"
    // InternalDynamicGoalModel.g:4117:1: rule__ResponseBinding__Group_5__1__Impl : ( ( rule__ResponseBinding__NoCartWriteAssignment_5_1 ) ) ;
    public final void rule__ResponseBinding__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4121:1: ( ( ( rule__ResponseBinding__NoCartWriteAssignment_5_1 ) ) )
            // InternalDynamicGoalModel.g:4122:1: ( ( rule__ResponseBinding__NoCartWriteAssignment_5_1 ) )
            {
            // InternalDynamicGoalModel.g:4122:1: ( ( rule__ResponseBinding__NoCartWriteAssignment_5_1 ) )
            // InternalDynamicGoalModel.g:4123:2: ( rule__ResponseBinding__NoCartWriteAssignment_5_1 )
            {
             before(grammarAccess.getResponseBindingAccess().getNoCartWriteAssignment_5_1()); 
            // InternalDynamicGoalModel.g:4124:2: ( rule__ResponseBinding__NoCartWriteAssignment_5_1 )
            // InternalDynamicGoalModel.g:4124:3: rule__ResponseBinding__NoCartWriteAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__ResponseBinding__NoCartWriteAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getResponseBindingAccess().getNoCartWriteAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__Group_5__1__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__0"
    // InternalDynamicGoalModel.g:4133:1: rule__EscalationStrategy__Group__0 : rule__EscalationStrategy__Group__0__Impl rule__EscalationStrategy__Group__1 ;
    public final void rule__EscalationStrategy__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4137:1: ( rule__EscalationStrategy__Group__0__Impl rule__EscalationStrategy__Group__1 )
            // InternalDynamicGoalModel.g:4138:2: rule__EscalationStrategy__Group__0__Impl rule__EscalationStrategy__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__EscalationStrategy__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__0"


    // $ANTLR start "rule__EscalationStrategy__Group__0__Impl"
    // InternalDynamicGoalModel.g:4145:1: rule__EscalationStrategy__Group__0__Impl : ( 'Escalation' ) ;
    public final void rule__EscalationStrategy__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4149:1: ( ( 'Escalation' ) )
            // InternalDynamicGoalModel.g:4150:1: ( 'Escalation' )
            {
            // InternalDynamicGoalModel.g:4150:1: ( 'Escalation' )
            // InternalDynamicGoalModel.g:4151:2: 'Escalation'
            {
             before(grammarAccess.getEscalationStrategyAccess().getEscalationKeyword_0()); 
            match(input,68,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getEscalationKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__0__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__1"
    // InternalDynamicGoalModel.g:4160:1: rule__EscalationStrategy__Group__1 : rule__EscalationStrategy__Group__1__Impl rule__EscalationStrategy__Group__2 ;
    public final void rule__EscalationStrategy__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4164:1: ( rule__EscalationStrategy__Group__1__Impl rule__EscalationStrategy__Group__2 )
            // InternalDynamicGoalModel.g:4165:2: rule__EscalationStrategy__Group__1__Impl rule__EscalationStrategy__Group__2
            {
            pushFollow(FOLLOW_49);
            rule__EscalationStrategy__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__1"


    // $ANTLR start "rule__EscalationStrategy__Group__1__Impl"
    // InternalDynamicGoalModel.g:4172:1: rule__EscalationStrategy__Group__1__Impl : ( '{' ) ;
    public final void rule__EscalationStrategy__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4176:1: ( ( '{' ) )
            // InternalDynamicGoalModel.g:4177:1: ( '{' )
            {
            // InternalDynamicGoalModel.g:4177:1: ( '{' )
            // InternalDynamicGoalModel.g:4178:2: '{'
            {
             before(grammarAccess.getEscalationStrategyAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__1__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__2"
    // InternalDynamicGoalModel.g:4187:1: rule__EscalationStrategy__Group__2 : rule__EscalationStrategy__Group__2__Impl rule__EscalationStrategy__Group__3 ;
    public final void rule__EscalationStrategy__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4191:1: ( rule__EscalationStrategy__Group__2__Impl rule__EscalationStrategy__Group__3 )
            // InternalDynamicGoalModel.g:4192:2: rule__EscalationStrategy__Group__2__Impl rule__EscalationStrategy__Group__3
            {
            pushFollow(FOLLOW_50);
            rule__EscalationStrategy__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__2"


    // $ANTLR start "rule__EscalationStrategy__Group__2__Impl"
    // InternalDynamicGoalModel.g:4199:1: rule__EscalationStrategy__Group__2__Impl : ( 'strategy' ) ;
    public final void rule__EscalationStrategy__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4203:1: ( ( 'strategy' ) )
            // InternalDynamicGoalModel.g:4204:1: ( 'strategy' )
            {
            // InternalDynamicGoalModel.g:4204:1: ( 'strategy' )
            // InternalDynamicGoalModel.g:4205:2: 'strategy'
            {
             before(grammarAccess.getEscalationStrategyAccess().getStrategyKeyword_2()); 
            match(input,69,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getStrategyKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__2__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__3"
    // InternalDynamicGoalModel.g:4214:1: rule__EscalationStrategy__Group__3 : rule__EscalationStrategy__Group__3__Impl rule__EscalationStrategy__Group__4 ;
    public final void rule__EscalationStrategy__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4218:1: ( rule__EscalationStrategy__Group__3__Impl rule__EscalationStrategy__Group__4 )
            // InternalDynamicGoalModel.g:4219:2: rule__EscalationStrategy__Group__3__Impl rule__EscalationStrategy__Group__4
            {
            pushFollow(FOLLOW_51);
            rule__EscalationStrategy__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__3"


    // $ANTLR start "rule__EscalationStrategy__Group__3__Impl"
    // InternalDynamicGoalModel.g:4226:1: rule__EscalationStrategy__Group__3__Impl : ( ( rule__EscalationStrategy__StrategyAssignment_3 ) ) ;
    public final void rule__EscalationStrategy__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4230:1: ( ( ( rule__EscalationStrategy__StrategyAssignment_3 ) ) )
            // InternalDynamicGoalModel.g:4231:1: ( ( rule__EscalationStrategy__StrategyAssignment_3 ) )
            {
            // InternalDynamicGoalModel.g:4231:1: ( ( rule__EscalationStrategy__StrategyAssignment_3 ) )
            // InternalDynamicGoalModel.g:4232:2: ( rule__EscalationStrategy__StrategyAssignment_3 )
            {
             before(grammarAccess.getEscalationStrategyAccess().getStrategyAssignment_3()); 
            // InternalDynamicGoalModel.g:4233:2: ( rule__EscalationStrategy__StrategyAssignment_3 )
            // InternalDynamicGoalModel.g:4233:3: rule__EscalationStrategy__StrategyAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__StrategyAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyAccess().getStrategyAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__3__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__4"
    // InternalDynamicGoalModel.g:4241:1: rule__EscalationStrategy__Group__4 : rule__EscalationStrategy__Group__4__Impl rule__EscalationStrategy__Group__5 ;
    public final void rule__EscalationStrategy__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4245:1: ( rule__EscalationStrategy__Group__4__Impl rule__EscalationStrategy__Group__5 )
            // InternalDynamicGoalModel.g:4246:2: rule__EscalationStrategy__Group__4__Impl rule__EscalationStrategy__Group__5
            {
            pushFollow(FOLLOW_51);
            rule__EscalationStrategy__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__4"


    // $ANTLR start "rule__EscalationStrategy__Group__4__Impl"
    // InternalDynamicGoalModel.g:4253:1: rule__EscalationStrategy__Group__4__Impl : ( ( rule__EscalationStrategy__Group_4__0 )? ) ;
    public final void rule__EscalationStrategy__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4257:1: ( ( ( rule__EscalationStrategy__Group_4__0 )? ) )
            // InternalDynamicGoalModel.g:4258:1: ( ( rule__EscalationStrategy__Group_4__0 )? )
            {
            // InternalDynamicGoalModel.g:4258:1: ( ( rule__EscalationStrategy__Group_4__0 )? )
            // InternalDynamicGoalModel.g:4259:2: ( rule__EscalationStrategy__Group_4__0 )?
            {
             before(grammarAccess.getEscalationStrategyAccess().getGroup_4()); 
            // InternalDynamicGoalModel.g:4260:2: ( rule__EscalationStrategy__Group_4__0 )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==70) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalDynamicGoalModel.g:4260:3: rule__EscalationStrategy__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EscalationStrategy__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEscalationStrategyAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__4__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__5"
    // InternalDynamicGoalModel.g:4268:1: rule__EscalationStrategy__Group__5 : rule__EscalationStrategy__Group__5__Impl rule__EscalationStrategy__Group__6 ;
    public final void rule__EscalationStrategy__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4272:1: ( rule__EscalationStrategy__Group__5__Impl rule__EscalationStrategy__Group__6 )
            // InternalDynamicGoalModel.g:4273:2: rule__EscalationStrategy__Group__5__Impl rule__EscalationStrategy__Group__6
            {
            pushFollow(FOLLOW_51);
            rule__EscalationStrategy__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__5"


    // $ANTLR start "rule__EscalationStrategy__Group__5__Impl"
    // InternalDynamicGoalModel.g:4280:1: rule__EscalationStrategy__Group__5__Impl : ( ( rule__EscalationStrategy__Group_5__0 )? ) ;
    public final void rule__EscalationStrategy__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4284:1: ( ( ( rule__EscalationStrategy__Group_5__0 )? ) )
            // InternalDynamicGoalModel.g:4285:1: ( ( rule__EscalationStrategy__Group_5__0 )? )
            {
            // InternalDynamicGoalModel.g:4285:1: ( ( rule__EscalationStrategy__Group_5__0 )? )
            // InternalDynamicGoalModel.g:4286:2: ( rule__EscalationStrategy__Group_5__0 )?
            {
             before(grammarAccess.getEscalationStrategyAccess().getGroup_5()); 
            // InternalDynamicGoalModel.g:4287:2: ( rule__EscalationStrategy__Group_5__0 )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==71) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalDynamicGoalModel.g:4287:3: rule__EscalationStrategy__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EscalationStrategy__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEscalationStrategyAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__5__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__6"
    // InternalDynamicGoalModel.g:4295:1: rule__EscalationStrategy__Group__6 : rule__EscalationStrategy__Group__6__Impl rule__EscalationStrategy__Group__7 ;
    public final void rule__EscalationStrategy__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4299:1: ( rule__EscalationStrategy__Group__6__Impl rule__EscalationStrategy__Group__7 )
            // InternalDynamicGoalModel.g:4300:2: rule__EscalationStrategy__Group__6__Impl rule__EscalationStrategy__Group__7
            {
            pushFollow(FOLLOW_51);
            rule__EscalationStrategy__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__6"


    // $ANTLR start "rule__EscalationStrategy__Group__6__Impl"
    // InternalDynamicGoalModel.g:4307:1: rule__EscalationStrategy__Group__6__Impl : ( ( rule__EscalationStrategy__Group_6__0 )? ) ;
    public final void rule__EscalationStrategy__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4311:1: ( ( ( rule__EscalationStrategy__Group_6__0 )? ) )
            // InternalDynamicGoalModel.g:4312:1: ( ( rule__EscalationStrategy__Group_6__0 )? )
            {
            // InternalDynamicGoalModel.g:4312:1: ( ( rule__EscalationStrategy__Group_6__0 )? )
            // InternalDynamicGoalModel.g:4313:2: ( rule__EscalationStrategy__Group_6__0 )?
            {
             before(grammarAccess.getEscalationStrategyAccess().getGroup_6()); 
            // InternalDynamicGoalModel.g:4314:2: ( rule__EscalationStrategy__Group_6__0 )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==72) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalDynamicGoalModel.g:4314:3: rule__EscalationStrategy__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EscalationStrategy__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEscalationStrategyAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__6__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group__7"
    // InternalDynamicGoalModel.g:4322:1: rule__EscalationStrategy__Group__7 : rule__EscalationStrategy__Group__7__Impl ;
    public final void rule__EscalationStrategy__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4326:1: ( rule__EscalationStrategy__Group__7__Impl )
            // InternalDynamicGoalModel.g:4327:2: rule__EscalationStrategy__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__7"


    // $ANTLR start "rule__EscalationStrategy__Group__7__Impl"
    // InternalDynamicGoalModel.g:4333:1: rule__EscalationStrategy__Group__7__Impl : ( '}' ) ;
    public final void rule__EscalationStrategy__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4337:1: ( ( '}' ) )
            // InternalDynamicGoalModel.g:4338:1: ( '}' )
            {
            // InternalDynamicGoalModel.g:4338:1: ( '}' )
            // InternalDynamicGoalModel.g:4339:2: '}'
            {
             before(grammarAccess.getEscalationStrategyAccess().getRightCurlyBracketKeyword_7()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group__7__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_4__0"
    // InternalDynamicGoalModel.g:4349:1: rule__EscalationStrategy__Group_4__0 : rule__EscalationStrategy__Group_4__0__Impl rule__EscalationStrategy__Group_4__1 ;
    public final void rule__EscalationStrategy__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4353:1: ( rule__EscalationStrategy__Group_4__0__Impl rule__EscalationStrategy__Group_4__1 )
            // InternalDynamicGoalModel.g:4354:2: rule__EscalationStrategy__Group_4__0__Impl rule__EscalationStrategy__Group_4__1
            {
            pushFollow(FOLLOW_3);
            rule__EscalationStrategy__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4__0"


    // $ANTLR start "rule__EscalationStrategy__Group_4__0__Impl"
    // InternalDynamicGoalModel.g:4361:1: rule__EscalationStrategy__Group_4__0__Impl : ( 'additionalEvidence' ) ;
    public final void rule__EscalationStrategy__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4365:1: ( ( 'additionalEvidence' ) )
            // InternalDynamicGoalModel.g:4366:1: ( 'additionalEvidence' )
            {
            // InternalDynamicGoalModel.g:4366:1: ( 'additionalEvidence' )
            // InternalDynamicGoalModel.g:4367:2: 'additionalEvidence'
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceKeyword_4_0()); 
            match(input,70,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4__0__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_4__1"
    // InternalDynamicGoalModel.g:4376:1: rule__EscalationStrategy__Group_4__1 : rule__EscalationStrategy__Group_4__1__Impl rule__EscalationStrategy__Group_4__2 ;
    public final void rule__EscalationStrategy__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4380:1: ( rule__EscalationStrategy__Group_4__1__Impl rule__EscalationStrategy__Group_4__2 )
            // InternalDynamicGoalModel.g:4381:2: rule__EscalationStrategy__Group_4__1__Impl rule__EscalationStrategy__Group_4__2
            {
            pushFollow(FOLLOW_41);
            rule__EscalationStrategy__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4__1"


    // $ANTLR start "rule__EscalationStrategy__Group_4__1__Impl"
    // InternalDynamicGoalModel.g:4388:1: rule__EscalationStrategy__Group_4__1__Impl : ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 ) ) ;
    public final void rule__EscalationStrategy__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4392:1: ( ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 ) ) )
            // InternalDynamicGoalModel.g:4393:1: ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 ) )
            {
            // InternalDynamicGoalModel.g:4393:1: ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 ) )
            // InternalDynamicGoalModel.g:4394:2: ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 )
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceAssignment_4_1()); 
            // InternalDynamicGoalModel.g:4395:2: ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 )
            // InternalDynamicGoalModel.g:4395:3: rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4__1__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_4__2"
    // InternalDynamicGoalModel.g:4403:1: rule__EscalationStrategy__Group_4__2 : rule__EscalationStrategy__Group_4__2__Impl ;
    public final void rule__EscalationStrategy__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4407:1: ( rule__EscalationStrategy__Group_4__2__Impl )
            // InternalDynamicGoalModel.g:4408:2: rule__EscalationStrategy__Group_4__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_4__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4__2"


    // $ANTLR start "rule__EscalationStrategy__Group_4__2__Impl"
    // InternalDynamicGoalModel.g:4414:1: rule__EscalationStrategy__Group_4__2__Impl : ( ( rule__EscalationStrategy__Group_4_2__0 )* ) ;
    public final void rule__EscalationStrategy__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4418:1: ( ( ( rule__EscalationStrategy__Group_4_2__0 )* ) )
            // InternalDynamicGoalModel.g:4419:1: ( ( rule__EscalationStrategy__Group_4_2__0 )* )
            {
            // InternalDynamicGoalModel.g:4419:1: ( ( rule__EscalationStrategy__Group_4_2__0 )* )
            // InternalDynamicGoalModel.g:4420:2: ( rule__EscalationStrategy__Group_4_2__0 )*
            {
             before(grammarAccess.getEscalationStrategyAccess().getGroup_4_2()); 
            // InternalDynamicGoalModel.g:4421:2: ( rule__EscalationStrategy__Group_4_2__0 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==61) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:4421:3: rule__EscalationStrategy__Group_4_2__0
            	    {
            	    pushFollow(FOLLOW_40);
            	    rule__EscalationStrategy__Group_4_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getEscalationStrategyAccess().getGroup_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4__2__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_4_2__0"
    // InternalDynamicGoalModel.g:4430:1: rule__EscalationStrategy__Group_4_2__0 : rule__EscalationStrategy__Group_4_2__0__Impl rule__EscalationStrategy__Group_4_2__1 ;
    public final void rule__EscalationStrategy__Group_4_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4434:1: ( rule__EscalationStrategy__Group_4_2__0__Impl rule__EscalationStrategy__Group_4_2__1 )
            // InternalDynamicGoalModel.g:4435:2: rule__EscalationStrategy__Group_4_2__0__Impl rule__EscalationStrategy__Group_4_2__1
            {
            pushFollow(FOLLOW_3);
            rule__EscalationStrategy__Group_4_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_4_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4_2__0"


    // $ANTLR start "rule__EscalationStrategy__Group_4_2__0__Impl"
    // InternalDynamicGoalModel.g:4442:1: rule__EscalationStrategy__Group_4_2__0__Impl : ( ',' ) ;
    public final void rule__EscalationStrategy__Group_4_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4446:1: ( ( ',' ) )
            // InternalDynamicGoalModel.g:4447:1: ( ',' )
            {
            // InternalDynamicGoalModel.g:4447:1: ( ',' )
            // InternalDynamicGoalModel.g:4448:2: ','
            {
             before(grammarAccess.getEscalationStrategyAccess().getCommaKeyword_4_2_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getCommaKeyword_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4_2__0__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_4_2__1"
    // InternalDynamicGoalModel.g:4457:1: rule__EscalationStrategy__Group_4_2__1 : rule__EscalationStrategy__Group_4_2__1__Impl ;
    public final void rule__EscalationStrategy__Group_4_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4461:1: ( rule__EscalationStrategy__Group_4_2__1__Impl )
            // InternalDynamicGoalModel.g:4462:2: rule__EscalationStrategy__Group_4_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_4_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4_2__1"


    // $ANTLR start "rule__EscalationStrategy__Group_4_2__1__Impl"
    // InternalDynamicGoalModel.g:4468:1: rule__EscalationStrategy__Group_4_2__1__Impl : ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 ) ) ;
    public final void rule__EscalationStrategy__Group_4_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4472:1: ( ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 ) ) )
            // InternalDynamicGoalModel.g:4473:1: ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 ) )
            {
            // InternalDynamicGoalModel.g:4473:1: ( ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 ) )
            // InternalDynamicGoalModel.g:4474:2: ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 )
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceAssignment_4_2_1()); 
            // InternalDynamicGoalModel.g:4475:2: ( rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 )
            // InternalDynamicGoalModel.g:4475:3: rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceAssignment_4_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_4_2__1__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_5__0"
    // InternalDynamicGoalModel.g:4484:1: rule__EscalationStrategy__Group_5__0 : rule__EscalationStrategy__Group_5__0__Impl rule__EscalationStrategy__Group_5__1 ;
    public final void rule__EscalationStrategy__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4488:1: ( rule__EscalationStrategy__Group_5__0__Impl rule__EscalationStrategy__Group_5__1 )
            // InternalDynamicGoalModel.g:4489:2: rule__EscalationStrategy__Group_5__0__Impl rule__EscalationStrategy__Group_5__1
            {
            pushFollow(FOLLOW_8);
            rule__EscalationStrategy__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_5__0"


    // $ANTLR start "rule__EscalationStrategy__Group_5__0__Impl"
    // InternalDynamicGoalModel.g:4496:1: rule__EscalationStrategy__Group_5__0__Impl : ( 'defaultResponse' ) ;
    public final void rule__EscalationStrategy__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4500:1: ( ( 'defaultResponse' ) )
            // InternalDynamicGoalModel.g:4501:1: ( 'defaultResponse' )
            {
            // InternalDynamicGoalModel.g:4501:1: ( 'defaultResponse' )
            // InternalDynamicGoalModel.g:4502:2: 'defaultResponse'
            {
             before(grammarAccess.getEscalationStrategyAccess().getDefaultResponseKeyword_5_0()); 
            match(input,71,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getDefaultResponseKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_5__0__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_5__1"
    // InternalDynamicGoalModel.g:4511:1: rule__EscalationStrategy__Group_5__1 : rule__EscalationStrategy__Group_5__1__Impl ;
    public final void rule__EscalationStrategy__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4515:1: ( rule__EscalationStrategy__Group_5__1__Impl )
            // InternalDynamicGoalModel.g:4516:2: rule__EscalationStrategy__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_5__1"


    // $ANTLR start "rule__EscalationStrategy__Group_5__1__Impl"
    // InternalDynamicGoalModel.g:4522:1: rule__EscalationStrategy__Group_5__1__Impl : ( ( rule__EscalationStrategy__DefaultResponseAssignment_5_1 ) ) ;
    public final void rule__EscalationStrategy__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4526:1: ( ( ( rule__EscalationStrategy__DefaultResponseAssignment_5_1 ) ) )
            // InternalDynamicGoalModel.g:4527:1: ( ( rule__EscalationStrategy__DefaultResponseAssignment_5_1 ) )
            {
            // InternalDynamicGoalModel.g:4527:1: ( ( rule__EscalationStrategy__DefaultResponseAssignment_5_1 ) )
            // InternalDynamicGoalModel.g:4528:2: ( rule__EscalationStrategy__DefaultResponseAssignment_5_1 )
            {
             before(grammarAccess.getEscalationStrategyAccess().getDefaultResponseAssignment_5_1()); 
            // InternalDynamicGoalModel.g:4529:2: ( rule__EscalationStrategy__DefaultResponseAssignment_5_1 )
            // InternalDynamicGoalModel.g:4529:3: rule__EscalationStrategy__DefaultResponseAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__DefaultResponseAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyAccess().getDefaultResponseAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_5__1__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_6__0"
    // InternalDynamicGoalModel.g:4538:1: rule__EscalationStrategy__Group_6__0 : rule__EscalationStrategy__Group_6__0__Impl rule__EscalationStrategy__Group_6__1 ;
    public final void rule__EscalationStrategy__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4542:1: ( rule__EscalationStrategy__Group_6__0__Impl rule__EscalationStrategy__Group_6__1 )
            // InternalDynamicGoalModel.g:4543:2: rule__EscalationStrategy__Group_6__0__Impl rule__EscalationStrategy__Group_6__1
            {
            pushFollow(FOLLOW_8);
            rule__EscalationStrategy__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_6__0"


    // $ANTLR start "rule__EscalationStrategy__Group_6__0__Impl"
    // InternalDynamicGoalModel.g:4550:1: rule__EscalationStrategy__Group_6__0__Impl : ( 'timeout' ) ;
    public final void rule__EscalationStrategy__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4554:1: ( ( 'timeout' ) )
            // InternalDynamicGoalModel.g:4555:1: ( 'timeout' )
            {
            // InternalDynamicGoalModel.g:4555:1: ( 'timeout' )
            // InternalDynamicGoalModel.g:4556:2: 'timeout'
            {
             before(grammarAccess.getEscalationStrategyAccess().getTimeoutKeyword_6_0()); 
            match(input,72,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getTimeoutKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_6__0__Impl"


    // $ANTLR start "rule__EscalationStrategy__Group_6__1"
    // InternalDynamicGoalModel.g:4565:1: rule__EscalationStrategy__Group_6__1 : rule__EscalationStrategy__Group_6__1__Impl ;
    public final void rule__EscalationStrategy__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4569:1: ( rule__EscalationStrategy__Group_6__1__Impl )
            // InternalDynamicGoalModel.g:4570:2: rule__EscalationStrategy__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_6__1"


    // $ANTLR start "rule__EscalationStrategy__Group_6__1__Impl"
    // InternalDynamicGoalModel.g:4576:1: rule__EscalationStrategy__Group_6__1__Impl : ( ( rule__EscalationStrategy__TimeoutAssignment_6_1 ) ) ;
    public final void rule__EscalationStrategy__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4580:1: ( ( ( rule__EscalationStrategy__TimeoutAssignment_6_1 ) ) )
            // InternalDynamicGoalModel.g:4581:1: ( ( rule__EscalationStrategy__TimeoutAssignment_6_1 ) )
            {
            // InternalDynamicGoalModel.g:4581:1: ( ( rule__EscalationStrategy__TimeoutAssignment_6_1 ) )
            // InternalDynamicGoalModel.g:4582:2: ( rule__EscalationStrategy__TimeoutAssignment_6_1 )
            {
             before(grammarAccess.getEscalationStrategyAccess().getTimeoutAssignment_6_1()); 
            // InternalDynamicGoalModel.g:4583:2: ( rule__EscalationStrategy__TimeoutAssignment_6_1 )
            // InternalDynamicGoalModel.g:4583:3: rule__EscalationStrategy__TimeoutAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__EscalationStrategy__TimeoutAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getEscalationStrategyAccess().getTimeoutAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__Group_6__1__Impl"


    // $ANTLR start "rule__DGMSpecification__NameAssignment_1"
    // InternalDynamicGoalModel.g:4592:1: rule__DGMSpecification__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__DGMSpecification__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4596:1: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:4597:2: ( RULE_ID )
            {
            // InternalDynamicGoalModel.g:4597:2: ( RULE_ID )
            // InternalDynamicGoalModel.g:4598:3: RULE_ID
            {
             before(grammarAccess.getDGMSpecificationAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__NameAssignment_1"


    // $ANTLR start "rule__DGMSpecification__DescriptionAssignment_3_1"
    // InternalDynamicGoalModel.g:4607:1: rule__DGMSpecification__DescriptionAssignment_3_1 : ( RULE_STRING ) ;
    public final void rule__DGMSpecification__DescriptionAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4611:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4612:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4612:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4613:3: RULE_STRING
            {
             before(grammarAccess.getDGMSpecificationAccess().getDescriptionSTRINGTerminalRuleCall_3_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getDGMSpecificationAccess().getDescriptionSTRINGTerminalRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__DescriptionAssignment_3_1"


    // $ANTLR start "rule__DGMSpecification__OperationalModeAssignment_4_1"
    // InternalDynamicGoalModel.g:4622:1: rule__DGMSpecification__OperationalModeAssignment_4_1 : ( ruleOperationalMode ) ;
    public final void rule__DGMSpecification__OperationalModeAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4626:1: ( ( ruleOperationalMode ) )
            // InternalDynamicGoalModel.g:4627:2: ( ruleOperationalMode )
            {
            // InternalDynamicGoalModel.g:4627:2: ( ruleOperationalMode )
            // InternalDynamicGoalModel.g:4628:3: ruleOperationalMode
            {
             before(grammarAccess.getDGMSpecificationAccess().getOperationalModeOperationalModeEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleOperationalMode();

            state._fsp--;

             after(grammarAccess.getDGMSpecificationAccess().getOperationalModeOperationalModeEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__OperationalModeAssignment_4_1"


    // $ANTLR start "rule__DGMSpecification__DynamicGoalsAssignment_5"
    // InternalDynamicGoalModel.g:4637:1: rule__DGMSpecification__DynamicGoalsAssignment_5 : ( ruleDynamicGoal ) ;
    public final void rule__DGMSpecification__DynamicGoalsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4641:1: ( ( ruleDynamicGoal ) )
            // InternalDynamicGoalModel.g:4642:2: ( ruleDynamicGoal )
            {
            // InternalDynamicGoalModel.g:4642:2: ( ruleDynamicGoal )
            // InternalDynamicGoalModel.g:4643:3: ruleDynamicGoal
            {
             before(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsDynamicGoalParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleDynamicGoal();

            state._fsp--;

             after(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsDynamicGoalParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DGMSpecification__DynamicGoalsAssignment_5"


    // $ANTLR start "rule__DynamicGoal__NameAssignment_1"
    // InternalDynamicGoalModel.g:4652:1: rule__DynamicGoal__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__DynamicGoal__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4656:1: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:4657:2: ( RULE_ID )
            {
            // InternalDynamicGoalModel.g:4657:2: ( RULE_ID )
            // InternalDynamicGoalModel.g:4658:3: RULE_ID
            {
             before(grammarAccess.getDynamicGoalAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__NameAssignment_1"


    // $ANTLR start "rule__DynamicGoal__TitleAssignment_4"
    // InternalDynamicGoalModel.g:4667:1: rule__DynamicGoal__TitleAssignment_4 : ( RULE_STRING ) ;
    public final void rule__DynamicGoal__TitleAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4671:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4672:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4672:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4673:3: RULE_STRING
            {
             before(grammarAccess.getDynamicGoalAccess().getTitleSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getTitleSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__TitleAssignment_4"


    // $ANTLR start "rule__DynamicGoal__UseCaseRefAssignment_5_1"
    // InternalDynamicGoalModel.g:4682:1: rule__DynamicGoal__UseCaseRefAssignment_5_1 : ( RULE_STRING ) ;
    public final void rule__DynamicGoal__UseCaseRefAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4686:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4687:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4687:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4688:3: RULE_STRING
            {
             before(grammarAccess.getDynamicGoalAccess().getUseCaseRefSTRINGTerminalRuleCall_5_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getDynamicGoalAccess().getUseCaseRefSTRINGTerminalRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__UseCaseRefAssignment_5_1"


    // $ANTLR start "rule__DynamicGoal__ObservableActionAssignment_6"
    // InternalDynamicGoalModel.g:4697:1: rule__DynamicGoal__ObservableActionAssignment_6 : ( ruleObservableAction ) ;
    public final void rule__DynamicGoal__ObservableActionAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4701:1: ( ( ruleObservableAction ) )
            // InternalDynamicGoalModel.g:4702:2: ( ruleObservableAction )
            {
            // InternalDynamicGoalModel.g:4702:2: ( ruleObservableAction )
            // InternalDynamicGoalModel.g:4703:3: ruleObservableAction
            {
             before(grammarAccess.getDynamicGoalAccess().getObservableActionObservableActionParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleObservableAction();

            state._fsp--;

             after(grammarAccess.getDynamicGoalAccess().getObservableActionObservableActionParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__ObservableActionAssignment_6"


    // $ANTLR start "rule__DynamicGoal__EvidenceAssignment_7"
    // InternalDynamicGoalModel.g:4712:1: rule__DynamicGoal__EvidenceAssignment_7 : ( ruleEvidence ) ;
    public final void rule__DynamicGoal__EvidenceAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4716:1: ( ( ruleEvidence ) )
            // InternalDynamicGoalModel.g:4717:2: ( ruleEvidence )
            {
            // InternalDynamicGoalModel.g:4717:2: ( ruleEvidence )
            // InternalDynamicGoalModel.g:4718:3: ruleEvidence
            {
             before(grammarAccess.getDynamicGoalAccess().getEvidenceEvidenceParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleEvidence();

            state._fsp--;

             after(grammarAccess.getDynamicGoalAccess().getEvidenceEvidenceParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__EvidenceAssignment_7"


    // $ANTLR start "rule__DynamicGoal__GoalHypothesesAssignment_8"
    // InternalDynamicGoalModel.g:4727:1: rule__DynamicGoal__GoalHypothesesAssignment_8 : ( ruleGoalHypothesis ) ;
    public final void rule__DynamicGoal__GoalHypothesesAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4731:1: ( ( ruleGoalHypothesis ) )
            // InternalDynamicGoalModel.g:4732:2: ( ruleGoalHypothesis )
            {
            // InternalDynamicGoalModel.g:4732:2: ( ruleGoalHypothesis )
            // InternalDynamicGoalModel.g:4733:3: ruleGoalHypothesis
            {
             before(grammarAccess.getDynamicGoalAccess().getGoalHypothesesGoalHypothesisParserRuleCall_8_0()); 
            pushFollow(FOLLOW_2);
            ruleGoalHypothesis();

            state._fsp--;

             after(grammarAccess.getDynamicGoalAccess().getGoalHypothesesGoalHypothesisParserRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__GoalHypothesesAssignment_8"


    // $ANTLR start "rule__DynamicGoal__PrecedenceAssignment_9_1"
    // InternalDynamicGoalModel.g:4742:1: rule__DynamicGoal__PrecedenceAssignment_9_1 : ( rulePrecedence ) ;
    public final void rule__DynamicGoal__PrecedenceAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4746:1: ( ( rulePrecedence ) )
            // InternalDynamicGoalModel.g:4747:2: ( rulePrecedence )
            {
            // InternalDynamicGoalModel.g:4747:2: ( rulePrecedence )
            // InternalDynamicGoalModel.g:4748:3: rulePrecedence
            {
             before(grammarAccess.getDynamicGoalAccess().getPrecedencePrecedenceParserRuleCall_9_1_0()); 
            pushFollow(FOLLOW_2);
            rulePrecedence();

            state._fsp--;

             after(grammarAccess.getDynamicGoalAccess().getPrecedencePrecedenceParserRuleCall_9_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__PrecedenceAssignment_9_1"


    // $ANTLR start "rule__DynamicGoal__EscalationAssignment_10_1"
    // InternalDynamicGoalModel.g:4757:1: rule__DynamicGoal__EscalationAssignment_10_1 : ( ruleEscalationStrategy ) ;
    public final void rule__DynamicGoal__EscalationAssignment_10_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4761:1: ( ( ruleEscalationStrategy ) )
            // InternalDynamicGoalModel.g:4762:2: ( ruleEscalationStrategy )
            {
            // InternalDynamicGoalModel.g:4762:2: ( ruleEscalationStrategy )
            // InternalDynamicGoalModel.g:4763:3: ruleEscalationStrategy
            {
             before(grammarAccess.getDynamicGoalAccess().getEscalationEscalationStrategyParserRuleCall_10_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEscalationStrategy();

            state._fsp--;

             after(grammarAccess.getDynamicGoalAccess().getEscalationEscalationStrategyParserRuleCall_10_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DynamicGoal__EscalationAssignment_10_1"


    // $ANTLR start "rule__ObservableAction__SignatureAssignment_3"
    // InternalDynamicGoalModel.g:4772:1: rule__ObservableAction__SignatureAssignment_3 : ( RULE_STRING ) ;
    public final void rule__ObservableAction__SignatureAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4776:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4777:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4777:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4778:3: RULE_STRING
            {
             before(grammarAccess.getObservableActionAccess().getSignatureSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getSignatureSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__SignatureAssignment_3"


    // $ANTLR start "rule__ObservableAction__TriggerAssignment_5"
    // InternalDynamicGoalModel.g:4787:1: rule__ObservableAction__TriggerAssignment_5 : ( RULE_STRING ) ;
    public final void rule__ObservableAction__TriggerAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4791:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4792:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4792:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4793:3: RULE_STRING
            {
             before(grammarAccess.getObservableActionAccess().getTriggerSTRINGTerminalRuleCall_5_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getTriggerSTRINGTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__TriggerAssignment_5"


    // $ANTLR start "rule__ObservableAction__ScopeStartAssignment_6_1"
    // InternalDynamicGoalModel.g:4802:1: rule__ObservableAction__ScopeStartAssignment_6_1 : ( RULE_STRING ) ;
    public final void rule__ObservableAction__ScopeStartAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4806:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4807:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4807:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4808:3: RULE_STRING
            {
             before(grammarAccess.getObservableActionAccess().getScopeStartSTRINGTerminalRuleCall_6_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getScopeStartSTRINGTerminalRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__ScopeStartAssignment_6_1"


    // $ANTLR start "rule__ObservableAction__ScopeEndAssignment_7_1"
    // InternalDynamicGoalModel.g:4817:1: rule__ObservableAction__ScopeEndAssignment_7_1 : ( RULE_STRING ) ;
    public final void rule__ObservableAction__ScopeEndAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4821:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4822:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4822:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4823:3: RULE_STRING
            {
             before(grammarAccess.getObservableActionAccess().getScopeEndSTRINGTerminalRuleCall_7_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getObservableActionAccess().getScopeEndSTRINGTerminalRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObservableAction__ScopeEndAssignment_7_1"


    // $ANTLR start "rule__Evidence__NameAssignment_1"
    // InternalDynamicGoalModel.g:4832:1: rule__Evidence__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Evidence__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4836:1: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:4837:2: ( RULE_ID )
            {
            // InternalDynamicGoalModel.g:4837:2: ( RULE_ID )
            // InternalDynamicGoalModel.g:4838:3: RULE_ID
            {
             before(grammarAccess.getEvidenceAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__NameAssignment_1"


    // $ANTLR start "rule__Evidence__TypeAssignment_4"
    // InternalDynamicGoalModel.g:4847:1: rule__Evidence__TypeAssignment_4 : ( ruleEvidenceType ) ;
    public final void rule__Evidence__TypeAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4851:1: ( ( ruleEvidenceType ) )
            // InternalDynamicGoalModel.g:4852:2: ( ruleEvidenceType )
            {
            // InternalDynamicGoalModel.g:4852:2: ( ruleEvidenceType )
            // InternalDynamicGoalModel.g:4853:3: ruleEvidenceType
            {
             before(grammarAccess.getEvidenceAccess().getTypeEvidenceTypeEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEvidenceType();

            state._fsp--;

             after(grammarAccess.getEvidenceAccess().getTypeEvidenceTypeEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__TypeAssignment_4"


    // $ANTLR start "rule__Evidence__SourceAssignment_6"
    // InternalDynamicGoalModel.g:4862:1: rule__Evidence__SourceAssignment_6 : ( RULE_STRING ) ;
    public final void rule__Evidence__SourceAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4866:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4867:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4867:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4868:3: RULE_STRING
            {
             before(grammarAccess.getEvidenceAccess().getSourceSTRINGTerminalRuleCall_6_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getSourceSTRINGTerminalRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__SourceAssignment_6"


    // $ANTLR start "rule__Evidence__PredicateAssignment_8"
    // InternalDynamicGoalModel.g:4877:1: rule__Evidence__PredicateAssignment_8 : ( RULE_STRING ) ;
    public final void rule__Evidence__PredicateAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4881:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4882:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4882:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4883:3: RULE_STRING
            {
             before(grammarAccess.getEvidenceAccess().getPredicateSTRINGTerminalRuleCall_8_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEvidenceAccess().getPredicateSTRINGTerminalRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__PredicateAssignment_8"


    // $ANTLR start "rule__Evidence__DerivedFromAssignment_9_1"
    // InternalDynamicGoalModel.g:4892:1: rule__Evidence__DerivedFromAssignment_9_1 : ( ruleDerivedExpression ) ;
    public final void rule__Evidence__DerivedFromAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4896:1: ( ( ruleDerivedExpression ) )
            // InternalDynamicGoalModel.g:4897:2: ( ruleDerivedExpression )
            {
            // InternalDynamicGoalModel.g:4897:2: ( ruleDerivedExpression )
            // InternalDynamicGoalModel.g:4898:3: ruleDerivedExpression
            {
             before(grammarAccess.getEvidenceAccess().getDerivedFromDerivedExpressionParserRuleCall_9_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDerivedExpression();

            state._fsp--;

             after(grammarAccess.getEvidenceAccess().getDerivedFromDerivedExpressionParserRuleCall_9_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Evidence__DerivedFromAssignment_9_1"


    // $ANTLR start "rule__DerivedExpression__ExpressionAssignment_2"
    // InternalDynamicGoalModel.g:4907:1: rule__DerivedExpression__ExpressionAssignment_2 : ( ruleConditionExpression ) ;
    public final void rule__DerivedExpression__ExpressionAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4911:1: ( ( ruleConditionExpression ) )
            // InternalDynamicGoalModel.g:4912:2: ( ruleConditionExpression )
            {
            // InternalDynamicGoalModel.g:4912:2: ( ruleConditionExpression )
            // InternalDynamicGoalModel.g:4913:3: ruleConditionExpression
            {
             before(grammarAccess.getDerivedExpressionAccess().getExpressionConditionExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleConditionExpression();

            state._fsp--;

             after(grammarAccess.getDerivedExpressionAccess().getExpressionConditionExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DerivedExpression__ExpressionAssignment_2"


    // $ANTLR start "rule__GoalHypothesis__NameAssignment_1"
    // InternalDynamicGoalModel.g:4922:1: rule__GoalHypothesis__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__GoalHypothesis__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4926:1: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:4927:2: ( RULE_ID )
            {
            // InternalDynamicGoalModel.g:4927:2: ( RULE_ID )
            // InternalDynamicGoalModel.g:4928:3: RULE_ID
            {
             before(grammarAccess.getGoalHypothesisAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__NameAssignment_1"


    // $ANTLR start "rule__GoalHypothesis__IntentionAssignment_4"
    // InternalDynamicGoalModel.g:4937:1: rule__GoalHypothesis__IntentionAssignment_4 : ( RULE_STRING ) ;
    public final void rule__GoalHypothesis__IntentionAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4941:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:4942:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:4942:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:4943:3: RULE_STRING
            {
             before(grammarAccess.getGoalHypothesisAccess().getIntentionSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getGoalHypothesisAccess().getIntentionSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__IntentionAssignment_4"


    // $ANTLR start "rule__GoalHypothesis__ConditionAssignment_6"
    // InternalDynamicGoalModel.g:4952:1: rule__GoalHypothesis__ConditionAssignment_6 : ( ruleConditionExpression ) ;
    public final void rule__GoalHypothesis__ConditionAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4956:1: ( ( ruleConditionExpression ) )
            // InternalDynamicGoalModel.g:4957:2: ( ruleConditionExpression )
            {
            // InternalDynamicGoalModel.g:4957:2: ( ruleConditionExpression )
            // InternalDynamicGoalModel.g:4958:3: ruleConditionExpression
            {
             before(grammarAccess.getGoalHypothesisAccess().getConditionConditionExpressionParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleConditionExpression();

            state._fsp--;

             after(grammarAccess.getGoalHypothesisAccess().getConditionConditionExpressionParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__ConditionAssignment_6"


    // $ANTLR start "rule__GoalHypothesis__ResponseBindingAssignment_7"
    // InternalDynamicGoalModel.g:4967:1: rule__GoalHypothesis__ResponseBindingAssignment_7 : ( ruleResponseBinding ) ;
    public final void rule__GoalHypothesis__ResponseBindingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4971:1: ( ( ruleResponseBinding ) )
            // InternalDynamicGoalModel.g:4972:2: ( ruleResponseBinding )
            {
            // InternalDynamicGoalModel.g:4972:2: ( ruleResponseBinding )
            // InternalDynamicGoalModel.g:4973:3: ruleResponseBinding
            {
             before(grammarAccess.getGoalHypothesisAccess().getResponseBindingResponseBindingParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleResponseBinding();

            state._fsp--;

             after(grammarAccess.getGoalHypothesisAccess().getResponseBindingResponseBindingParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GoalHypothesis__ResponseBindingAssignment_7"


    // $ANTLR start "rule__OrExpression__RightAssignment_1_2"
    // InternalDynamicGoalModel.g:4982:1: rule__OrExpression__RightAssignment_1_2 : ( ruleAndExpression ) ;
    public final void rule__OrExpression__RightAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:4986:1: ( ( ruleAndExpression ) )
            // InternalDynamicGoalModel.g:4987:2: ( ruleAndExpression )
            {
            // InternalDynamicGoalModel.g:4987:2: ( ruleAndExpression )
            // InternalDynamicGoalModel.g:4988:3: ruleAndExpression
            {
             before(grammarAccess.getOrExpressionAccess().getRightAndExpressionParserRuleCall_1_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAndExpression();

            state._fsp--;

             after(grammarAccess.getOrExpressionAccess().getRightAndExpressionParserRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrExpression__RightAssignment_1_2"


    // $ANTLR start "rule__AndExpression__RightAssignment_1_2"
    // InternalDynamicGoalModel.g:4997:1: rule__AndExpression__RightAssignment_1_2 : ( ruleUnaryExpression ) ;
    public final void rule__AndExpression__RightAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5001:1: ( ( ruleUnaryExpression ) )
            // InternalDynamicGoalModel.g:5002:2: ( ruleUnaryExpression )
            {
            // InternalDynamicGoalModel.g:5002:2: ( ruleUnaryExpression )
            // InternalDynamicGoalModel.g:5003:3: ruleUnaryExpression
            {
             before(grammarAccess.getAndExpressionAccess().getRightUnaryExpressionParserRuleCall_1_2_0()); 
            pushFollow(FOLLOW_2);
            ruleUnaryExpression();

            state._fsp--;

             after(grammarAccess.getAndExpressionAccess().getRightUnaryExpressionParserRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndExpression__RightAssignment_1_2"


    // $ANTLR start "rule__NegationExpression__OperandAssignment_1"
    // InternalDynamicGoalModel.g:5012:1: rule__NegationExpression__OperandAssignment_1 : ( ruleAtomicCondition ) ;
    public final void rule__NegationExpression__OperandAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5016:1: ( ( ruleAtomicCondition ) )
            // InternalDynamicGoalModel.g:5017:2: ( ruleAtomicCondition )
            {
            // InternalDynamicGoalModel.g:5017:2: ( ruleAtomicCondition )
            // InternalDynamicGoalModel.g:5018:3: ruleAtomicCondition
            {
             before(grammarAccess.getNegationExpressionAccess().getOperandAtomicConditionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleAtomicCondition();

            state._fsp--;

             after(grammarAccess.getNegationExpressionAccess().getOperandAtomicConditionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__OperandAssignment_1"


    // $ANTLR start "rule__EvidenceRef__EvidenceAssignment_0"
    // InternalDynamicGoalModel.g:5027:1: rule__EvidenceRef__EvidenceAssignment_0 : ( ( RULE_ID ) ) ;
    public final void rule__EvidenceRef__EvidenceAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5031:1: ( ( ( RULE_ID ) ) )
            // InternalDynamicGoalModel.g:5032:2: ( ( RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:5032:2: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:5033:3: ( RULE_ID )
            {
             before(grammarAccess.getEvidenceRefAccess().getEvidenceEvidenceCrossReference_0_0()); 
            // InternalDynamicGoalModel.g:5034:3: ( RULE_ID )
            // InternalDynamicGoalModel.g:5035:4: RULE_ID
            {
             before(grammarAccess.getEvidenceRefAccess().getEvidenceEvidenceIDTerminalRuleCall_0_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEvidenceRefAccess().getEvidenceEvidenceIDTerminalRuleCall_0_0_1()); 

            }

             after(grammarAccess.getEvidenceRefAccess().getEvidenceEvidenceCrossReference_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__EvidenceAssignment_0"


    // $ANTLR start "rule__EvidenceRef__ParamsAssignment_1_1"
    // InternalDynamicGoalModel.g:5046:1: rule__EvidenceRef__ParamsAssignment_1_1 : ( RULE_STRING ) ;
    public final void rule__EvidenceRef__ParamsAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5050:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5051:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5051:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5052:3: RULE_STRING
            {
             before(grammarAccess.getEvidenceRefAccess().getParamsSTRINGTerminalRuleCall_1_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEvidenceRefAccess().getParamsSTRINGTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__ParamsAssignment_1_1"


    // $ANTLR start "rule__EvidenceRef__ParamsAssignment_1_2_1"
    // InternalDynamicGoalModel.g:5061:1: rule__EvidenceRef__ParamsAssignment_1_2_1 : ( RULE_STRING ) ;
    public final void rule__EvidenceRef__ParamsAssignment_1_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5065:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5066:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5066:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5067:3: RULE_STRING
            {
             before(grammarAccess.getEvidenceRefAccess().getParamsSTRINGTerminalRuleCall_1_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEvidenceRefAccess().getParamsSTRINGTerminalRuleCall_1_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EvidenceRef__ParamsAssignment_1_2_1"


    // $ANTLR start "rule__TemporalCondition__TemporalOpAssignment_0"
    // InternalDynamicGoalModel.g:5076:1: rule__TemporalCondition__TemporalOpAssignment_0 : ( ruleTemporalOperator ) ;
    public final void rule__TemporalCondition__TemporalOpAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5080:1: ( ( ruleTemporalOperator ) )
            // InternalDynamicGoalModel.g:5081:2: ( ruleTemporalOperator )
            {
            // InternalDynamicGoalModel.g:5081:2: ( ruleTemporalOperator )
            // InternalDynamicGoalModel.g:5082:3: ruleTemporalOperator
            {
             before(grammarAccess.getTemporalConditionAccess().getTemporalOpTemporalOperatorEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleTemporalOperator();

            state._fsp--;

             after(grammarAccess.getTemporalConditionAccess().getTemporalOpTemporalOperatorEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__TemporalOpAssignment_0"


    // $ANTLR start "rule__TemporalCondition__EvidenceRefAssignment_2"
    // InternalDynamicGoalModel.g:5091:1: rule__TemporalCondition__EvidenceRefAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__TemporalCondition__EvidenceRefAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5095:1: ( ( ( RULE_ID ) ) )
            // InternalDynamicGoalModel.g:5096:2: ( ( RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:5096:2: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:5097:3: ( RULE_ID )
            {
             before(grammarAccess.getTemporalConditionAccess().getEvidenceRefEvidenceCrossReference_2_0()); 
            // InternalDynamicGoalModel.g:5098:3: ( RULE_ID )
            // InternalDynamicGoalModel.g:5099:4: RULE_ID
            {
             before(grammarAccess.getTemporalConditionAccess().getEvidenceRefEvidenceIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTemporalConditionAccess().getEvidenceRefEvidenceIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getTemporalConditionAccess().getEvidenceRefEvidenceCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__EvidenceRefAssignment_2"


    // $ANTLR start "rule__TemporalCondition__DurationAssignment_4"
    // InternalDynamicGoalModel.g:5110:1: rule__TemporalCondition__DurationAssignment_4 : ( RULE_STRING ) ;
    public final void rule__TemporalCondition__DurationAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5114:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5115:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5115:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5116:3: RULE_STRING
            {
             before(grammarAccess.getTemporalConditionAccess().getDurationSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getTemporalConditionAccess().getDurationSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemporalCondition__DurationAssignment_4"


    // $ANTLR start "rule__ComparisonCondition__LeftAssignment_0"
    // InternalDynamicGoalModel.g:5125:1: rule__ComparisonCondition__LeftAssignment_0 : ( ( RULE_ID ) ) ;
    public final void rule__ComparisonCondition__LeftAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5129:1: ( ( ( RULE_ID ) ) )
            // InternalDynamicGoalModel.g:5130:2: ( ( RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:5130:2: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:5131:3: ( RULE_ID )
            {
             before(grammarAccess.getComparisonConditionAccess().getLeftEvidenceCrossReference_0_0()); 
            // InternalDynamicGoalModel.g:5132:3: ( RULE_ID )
            // InternalDynamicGoalModel.g:5133:4: RULE_ID
            {
             before(grammarAccess.getComparisonConditionAccess().getLeftEvidenceIDTerminalRuleCall_0_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getComparisonConditionAccess().getLeftEvidenceIDTerminalRuleCall_0_0_1()); 

            }

             after(grammarAccess.getComparisonConditionAccess().getLeftEvidenceCrossReference_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__LeftAssignment_0"


    // $ANTLR start "rule__ComparisonCondition__ComparatorAssignment_1"
    // InternalDynamicGoalModel.g:5144:1: rule__ComparisonCondition__ComparatorAssignment_1 : ( ruleComparator ) ;
    public final void rule__ComparisonCondition__ComparatorAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5148:1: ( ( ruleComparator ) )
            // InternalDynamicGoalModel.g:5149:2: ( ruleComparator )
            {
            // InternalDynamicGoalModel.g:5149:2: ( ruleComparator )
            // InternalDynamicGoalModel.g:5150:3: ruleComparator
            {
             before(grammarAccess.getComparisonConditionAccess().getComparatorComparatorEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleComparator();

            state._fsp--;

             after(grammarAccess.getComparisonConditionAccess().getComparatorComparatorEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__ComparatorAssignment_1"


    // $ANTLR start "rule__ComparisonCondition__RightAssignment_2"
    // InternalDynamicGoalModel.g:5159:1: rule__ComparisonCondition__RightAssignment_2 : ( RULE_STRING ) ;
    public final void rule__ComparisonCondition__RightAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5163:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5164:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5164:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5165:3: RULE_STRING
            {
             before(grammarAccess.getComparisonConditionAccess().getRightSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getComparisonConditionAccess().getRightSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparisonCondition__RightAssignment_2"


    // $ANTLR start "rule__Precedence__JustificationAssignment_2_1"
    // InternalDynamicGoalModel.g:5174:1: rule__Precedence__JustificationAssignment_2_1 : ( RULE_STRING ) ;
    public final void rule__Precedence__JustificationAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5178:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5179:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5179:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5180:3: RULE_STRING
            {
             before(grammarAccess.getPrecedenceAccess().getJustificationSTRINGTerminalRuleCall_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPrecedenceAccess().getJustificationSTRINGTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__JustificationAssignment_2_1"


    // $ANTLR start "rule__Precedence__OrderingAssignment_3"
    // InternalDynamicGoalModel.g:5189:1: rule__Precedence__OrderingAssignment_3 : ( rulePrecedenceEntry ) ;
    public final void rule__Precedence__OrderingAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5193:1: ( ( rulePrecedenceEntry ) )
            // InternalDynamicGoalModel.g:5194:2: ( rulePrecedenceEntry )
            {
            // InternalDynamicGoalModel.g:5194:2: ( rulePrecedenceEntry )
            // InternalDynamicGoalModel.g:5195:3: rulePrecedenceEntry
            {
             before(grammarAccess.getPrecedenceAccess().getOrderingPrecedenceEntryParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            rulePrecedenceEntry();

            state._fsp--;

             after(grammarAccess.getPrecedenceAccess().getOrderingPrecedenceEntryParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__OrderingAssignment_3"


    // $ANTLR start "rule__Precedence__OrderingAssignment_4_1"
    // InternalDynamicGoalModel.g:5204:1: rule__Precedence__OrderingAssignment_4_1 : ( rulePrecedenceEntry ) ;
    public final void rule__Precedence__OrderingAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5208:1: ( ( rulePrecedenceEntry ) )
            // InternalDynamicGoalModel.g:5209:2: ( rulePrecedenceEntry )
            {
            // InternalDynamicGoalModel.g:5209:2: ( rulePrecedenceEntry )
            // InternalDynamicGoalModel.g:5210:3: rulePrecedenceEntry
            {
             before(grammarAccess.getPrecedenceAccess().getOrderingPrecedenceEntryParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            rulePrecedenceEntry();

            state._fsp--;

             after(grammarAccess.getPrecedenceAccess().getOrderingPrecedenceEntryParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Precedence__OrderingAssignment_4_1"


    // $ANTLR start "rule__PrecedenceEntry__HypothesisAssignment"
    // InternalDynamicGoalModel.g:5219:1: rule__PrecedenceEntry__HypothesisAssignment : ( ( RULE_ID ) ) ;
    public final void rule__PrecedenceEntry__HypothesisAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5223:1: ( ( ( RULE_ID ) ) )
            // InternalDynamicGoalModel.g:5224:2: ( ( RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:5224:2: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:5225:3: ( RULE_ID )
            {
             before(grammarAccess.getPrecedenceEntryAccess().getHypothesisGoalHypothesisCrossReference_0()); 
            // InternalDynamicGoalModel.g:5226:3: ( RULE_ID )
            // InternalDynamicGoalModel.g:5227:4: RULE_ID
            {
             before(grammarAccess.getPrecedenceEntryAccess().getHypothesisGoalHypothesisIDTerminalRuleCall_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPrecedenceEntryAccess().getHypothesisGoalHypothesisIDTerminalRuleCall_0_1()); 

            }

             after(grammarAccess.getPrecedenceEntryAccess().getHypothesisGoalHypothesisCrossReference_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrecedenceEntry__HypothesisAssignment"


    // $ANTLR start "rule__ResponseBinding__ActionAssignment_3"
    // InternalDynamicGoalModel.g:5238:1: rule__ResponseBinding__ActionAssignment_3 : ( RULE_STRING ) ;
    public final void rule__ResponseBinding__ActionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5242:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5243:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5243:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5244:3: RULE_STRING
            {
             before(grammarAccess.getResponseBindingAccess().getActionSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getActionSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__ActionAssignment_3"


    // $ANTLR start "rule__ResponseBinding__UcmStepAssignment_4_1"
    // InternalDynamicGoalModel.g:5253:1: rule__ResponseBinding__UcmStepAssignment_4_1 : ( RULE_STRING ) ;
    public final void rule__ResponseBinding__UcmStepAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5257:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5258:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5258:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5259:3: RULE_STRING
            {
             before(grammarAccess.getResponseBindingAccess().getUcmStepSTRINGTerminalRuleCall_4_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getUcmStepSTRINGTerminalRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__UcmStepAssignment_4_1"


    // $ANTLR start "rule__ResponseBinding__NoCartWriteAssignment_5_1"
    // InternalDynamicGoalModel.g:5268:1: rule__ResponseBinding__NoCartWriteAssignment_5_1 : ( ( 'noSideEffect' ) ) ;
    public final void rule__ResponseBinding__NoCartWriteAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5272:1: ( ( ( 'noSideEffect' ) ) )
            // InternalDynamicGoalModel.g:5273:2: ( ( 'noSideEffect' ) )
            {
            // InternalDynamicGoalModel.g:5273:2: ( ( 'noSideEffect' ) )
            // InternalDynamicGoalModel.g:5274:3: ( 'noSideEffect' )
            {
             before(grammarAccess.getResponseBindingAccess().getNoCartWriteNoSideEffectKeyword_5_1_0()); 
            // InternalDynamicGoalModel.g:5275:3: ( 'noSideEffect' )
            // InternalDynamicGoalModel.g:5276:4: 'noSideEffect'
            {
             before(grammarAccess.getResponseBindingAccess().getNoCartWriteNoSideEffectKeyword_5_1_0()); 
            match(input,73,FOLLOW_2); 
             after(grammarAccess.getResponseBindingAccess().getNoCartWriteNoSideEffectKeyword_5_1_0()); 

            }

             after(grammarAccess.getResponseBindingAccess().getNoCartWriteNoSideEffectKeyword_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResponseBinding__NoCartWriteAssignment_5_1"


    // $ANTLR start "rule__EscalationStrategy__StrategyAssignment_3"
    // InternalDynamicGoalModel.g:5287:1: rule__EscalationStrategy__StrategyAssignment_3 : ( ruleEscalationStrategyType ) ;
    public final void rule__EscalationStrategy__StrategyAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5291:1: ( ( ruleEscalationStrategyType ) )
            // InternalDynamicGoalModel.g:5292:2: ( ruleEscalationStrategyType )
            {
            // InternalDynamicGoalModel.g:5292:2: ( ruleEscalationStrategyType )
            // InternalDynamicGoalModel.g:5293:3: ruleEscalationStrategyType
            {
             before(grammarAccess.getEscalationStrategyAccess().getStrategyEscalationStrategyTypeEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEscalationStrategyType();

            state._fsp--;

             after(grammarAccess.getEscalationStrategyAccess().getStrategyEscalationStrategyTypeEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__StrategyAssignment_3"


    // $ANTLR start "rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1"
    // InternalDynamicGoalModel.g:5302:1: rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1 : ( ( RULE_ID ) ) ;
    public final void rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5306:1: ( ( ( RULE_ID ) ) )
            // InternalDynamicGoalModel.g:5307:2: ( ( RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:5307:2: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:5308:3: ( RULE_ID )
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceCrossReference_4_1_0()); 
            // InternalDynamicGoalModel.g:5309:3: ( RULE_ID )
            // InternalDynamicGoalModel.g:5310:4: RULE_ID
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceIDTerminalRuleCall_4_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceIDTerminalRuleCall_4_1_0_1()); 

            }

             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceCrossReference_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__AdditionalEvidenceAssignment_4_1"


    // $ANTLR start "rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1"
    // InternalDynamicGoalModel.g:5321:1: rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5325:1: ( ( ( RULE_ID ) ) )
            // InternalDynamicGoalModel.g:5326:2: ( ( RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:5326:2: ( ( RULE_ID ) )
            // InternalDynamicGoalModel.g:5327:3: ( RULE_ID )
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceCrossReference_4_2_1_0()); 
            // InternalDynamicGoalModel.g:5328:3: ( RULE_ID )
            // InternalDynamicGoalModel.g:5329:4: RULE_ID
            {
             before(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceIDTerminalRuleCall_4_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceIDTerminalRuleCall_4_2_1_0_1()); 

            }

             after(grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceCrossReference_4_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__AdditionalEvidenceAssignment_4_2_1"


    // $ANTLR start "rule__EscalationStrategy__DefaultResponseAssignment_5_1"
    // InternalDynamicGoalModel.g:5340:1: rule__EscalationStrategy__DefaultResponseAssignment_5_1 : ( RULE_STRING ) ;
    public final void rule__EscalationStrategy__DefaultResponseAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5344:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5345:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5345:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5346:3: RULE_STRING
            {
             before(grammarAccess.getEscalationStrategyAccess().getDefaultResponseSTRINGTerminalRuleCall_5_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getDefaultResponseSTRINGTerminalRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__DefaultResponseAssignment_5_1"


    // $ANTLR start "rule__EscalationStrategy__TimeoutAssignment_6_1"
    // InternalDynamicGoalModel.g:5355:1: rule__EscalationStrategy__TimeoutAssignment_6_1 : ( RULE_STRING ) ;
    public final void rule__EscalationStrategy__TimeoutAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDynamicGoalModel.g:5359:1: ( ( RULE_STRING ) )
            // InternalDynamicGoalModel.g:5360:2: ( RULE_STRING )
            {
            // InternalDynamicGoalModel.g:5360:2: ( RULE_STRING )
            // InternalDynamicGoalModel.g:5361:3: RULE_STRING
            {
             before(grammarAccess.getEscalationStrategyAccess().getTimeoutSTRINGTerminalRuleCall_6_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEscalationStrategyAccess().getTimeoutSTRINGTerminalRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EscalationStrategy__TimeoutAssignment_6_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000007000000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000007000000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x00000001E0000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000090000000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0001000000000002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000060800000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0080000000000002L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000C00800000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x000000000003F800L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0010000800000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x10200000003C0010L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0400000000000002L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0800000000000002L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x00000000003C0010L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x2040000000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x2000000000000002L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000003C00000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x8000000000000010L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000800000000L,0x000000000000000CL});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x000000001C000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000800000000L,0x00000000000001C0L});

}