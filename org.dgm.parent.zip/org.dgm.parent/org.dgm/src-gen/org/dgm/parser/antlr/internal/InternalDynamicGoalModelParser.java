package org.dgm.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.dgm.services.DynamicGoalModelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDynamicGoalModelParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'DGMSpecification'", "'{'", "'description'", "'operationalMode'", "'}'", "'DynamicGoal'", "'title'", "'useCaseRef'", "'precedence'", "'escalation'", "'ObservableAction'", "'signature'", "'trigger'", "'scopeStart'", "'scopeEnd'", "'Evidence'", "'type'", "'source'", "'predicate'", "'derivedFrom'", "'('", "')'", "'GoalHypothesis'", "'intention'", "'condition'", "'||'", "'&&'", "'NOT'", "','", "'Precedence'", "'justification'", "'>'", "'ResponseBinding'", "'action'", "'ucmStep'", "'noCartWrite'", "'noSideEffect'", "'Escalation'", "'strategy'", "'additionalEvidence'", "'defaultResponse'", "'timeout'", "'SENSOR'", "'TEMPORAL'", "'IDENTITY'", "'SPATIAL'", "'DERIVED'", "'ROLE'", "'CATALOG'", "'WITHIN'", "'NOT_WITHIN'", "'HELD_FOR'", "'REPEATED_WITHIN'", "'='", "'!='", "'<'", "'REQUEST_MORE_EVIDENCE'", "'DEFAULT_NO_COMMIT'", "'NOTIFY_OPERATOR'", "'NORMAL'", "'EMERGENCY'", "'MAINTENANCE'", "'ENERGY_SAVING'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalDynamicGoalModelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDynamicGoalModelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDynamicGoalModelParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDynamicGoalModel.g"; }



     	private DynamicGoalModelGrammarAccess grammarAccess;

        public InternalDynamicGoalModelParser(TokenStream input, DynamicGoalModelGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "DGMSpecification";
       	}

       	@Override
       	protected DynamicGoalModelGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleDGMSpecification"
    // InternalDynamicGoalModel.g:65:1: entryRuleDGMSpecification returns [EObject current=null] : iv_ruleDGMSpecification= ruleDGMSpecification EOF ;
    public final EObject entryRuleDGMSpecification() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDGMSpecification = null;


        try {
            // InternalDynamicGoalModel.g:65:57: (iv_ruleDGMSpecification= ruleDGMSpecification EOF )
            // InternalDynamicGoalModel.g:66:2: iv_ruleDGMSpecification= ruleDGMSpecification EOF
            {
             newCompositeNode(grammarAccess.getDGMSpecificationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDGMSpecification=ruleDGMSpecification();

            state._fsp--;

             current =iv_ruleDGMSpecification; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDGMSpecification"


    // $ANTLR start "ruleDGMSpecification"
    // InternalDynamicGoalModel.g:72:1: ruleDGMSpecification returns [EObject current=null] : (otherlv_0= 'DGMSpecification' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) ) )? (otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) ) )? ( (lv_dynamicGoals_7_0= ruleDynamicGoal ) )+ otherlv_8= '}' ) ;
    public final EObject ruleDGMSpecification() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_description_4_0=null;
        Token otherlv_5=null;
        Token otherlv_8=null;
        Enumerator lv_operationalMode_6_0 = null;

        EObject lv_dynamicGoals_7_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:78:2: ( (otherlv_0= 'DGMSpecification' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) ) )? (otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) ) )? ( (lv_dynamicGoals_7_0= ruleDynamicGoal ) )+ otherlv_8= '}' ) )
            // InternalDynamicGoalModel.g:79:2: (otherlv_0= 'DGMSpecification' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) ) )? (otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) ) )? ( (lv_dynamicGoals_7_0= ruleDynamicGoal ) )+ otherlv_8= '}' )
            {
            // InternalDynamicGoalModel.g:79:2: (otherlv_0= 'DGMSpecification' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) ) )? (otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) ) )? ( (lv_dynamicGoals_7_0= ruleDynamicGoal ) )+ otherlv_8= '}' )
            // InternalDynamicGoalModel.g:80:3: otherlv_0= 'DGMSpecification' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) ) )? (otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) ) )? ( (lv_dynamicGoals_7_0= ruleDynamicGoal ) )+ otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getDGMSpecificationAccess().getDGMSpecificationKeyword_0());
            		
            // InternalDynamicGoalModel.g:84:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:85:4: (lv_name_1_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:85:4: (lv_name_1_0= RULE_ID )
            // InternalDynamicGoalModel.g:86:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDGMSpecificationAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDGMSpecificationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getDGMSpecificationAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDynamicGoalModel.g:106:3: (otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalDynamicGoalModel.g:107:4: otherlv_3= 'description' ( (lv_description_4_0= RULE_STRING ) )
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_6); 

                    				newLeafNode(otherlv_3, grammarAccess.getDGMSpecificationAccess().getDescriptionKeyword_3_0());
                    			
                    // InternalDynamicGoalModel.g:111:4: ( (lv_description_4_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:112:5: (lv_description_4_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:112:5: (lv_description_4_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:113:6: lv_description_4_0= RULE_STRING
                    {
                    lv_description_4_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

                    						newLeafNode(lv_description_4_0, grammarAccess.getDGMSpecificationAccess().getDescriptionSTRINGTerminalRuleCall_3_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDGMSpecificationRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_4_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:130:3: (otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalDynamicGoalModel.g:131:4: otherlv_5= 'operationalMode' ( (lv_operationalMode_6_0= ruleOperationalMode ) )
                    {
                    otherlv_5=(Token)match(input,14,FOLLOW_7); 

                    				newLeafNode(otherlv_5, grammarAccess.getDGMSpecificationAccess().getOperationalModeKeyword_4_0());
                    			
                    // InternalDynamicGoalModel.g:135:4: ( (lv_operationalMode_6_0= ruleOperationalMode ) )
                    // InternalDynamicGoalModel.g:136:5: (lv_operationalMode_6_0= ruleOperationalMode )
                    {
                    // InternalDynamicGoalModel.g:136:5: (lv_operationalMode_6_0= ruleOperationalMode )
                    // InternalDynamicGoalModel.g:137:6: lv_operationalMode_6_0= ruleOperationalMode
                    {

                    						newCompositeNode(grammarAccess.getDGMSpecificationAccess().getOperationalModeOperationalModeEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_5);
                    lv_operationalMode_6_0=ruleOperationalMode();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDGMSpecificationRule());
                    						}
                    						set(
                    							current,
                    							"operationalMode",
                    							lv_operationalMode_6_0,
                    							"org.dgm.DynamicGoalModel.OperationalMode");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:155:3: ( (lv_dynamicGoals_7_0= ruleDynamicGoal ) )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==16) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:156:4: (lv_dynamicGoals_7_0= ruleDynamicGoal )
            	    {
            	    // InternalDynamicGoalModel.g:156:4: (lv_dynamicGoals_7_0= ruleDynamicGoal )
            	    // InternalDynamicGoalModel.g:157:5: lv_dynamicGoals_7_0= ruleDynamicGoal
            	    {

            	    					newCompositeNode(grammarAccess.getDGMSpecificationAccess().getDynamicGoalsDynamicGoalParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_8);
            	    lv_dynamicGoals_7_0=ruleDynamicGoal();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDGMSpecificationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"dynamicGoals",
            	    						lv_dynamicGoals_7_0,
            	    						"org.dgm.DynamicGoalModel.DynamicGoal");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);

            otherlv_8=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getDGMSpecificationAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDGMSpecification"


    // $ANTLR start "entryRuleDynamicGoal"
    // InternalDynamicGoalModel.g:182:1: entryRuleDynamicGoal returns [EObject current=null] : iv_ruleDynamicGoal= ruleDynamicGoal EOF ;
    public final EObject entryRuleDynamicGoal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDynamicGoal = null;


        try {
            // InternalDynamicGoalModel.g:182:52: (iv_ruleDynamicGoal= ruleDynamicGoal EOF )
            // InternalDynamicGoalModel.g:183:2: iv_ruleDynamicGoal= ruleDynamicGoal EOF
            {
             newCompositeNode(grammarAccess.getDynamicGoalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDynamicGoal=ruleDynamicGoal();

            state._fsp--;

             current =iv_ruleDynamicGoal; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDynamicGoal"


    // $ANTLR start "ruleDynamicGoal"
    // InternalDynamicGoalModel.g:189:1: ruleDynamicGoal returns [EObject current=null] : (otherlv_0= 'DynamicGoal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'title' ( (lv_title_4_0= RULE_STRING ) ) (otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) ) )? ( (lv_observableAction_7_0= ruleObservableAction ) ) ( (lv_evidence_8_0= ruleEvidence ) )+ ( (lv_goalHypotheses_9_0= ruleGoalHypothesis ) )+ (otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) ) )? (otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) ) )? otherlv_14= '}' ) ;
    public final EObject ruleDynamicGoal() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_title_4_0=null;
        Token otherlv_5=null;
        Token lv_useCaseRef_6_0=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        EObject lv_observableAction_7_0 = null;

        EObject lv_evidence_8_0 = null;

        EObject lv_goalHypotheses_9_0 = null;

        EObject lv_precedence_11_0 = null;

        EObject lv_escalation_13_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:195:2: ( (otherlv_0= 'DynamicGoal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'title' ( (lv_title_4_0= RULE_STRING ) ) (otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) ) )? ( (lv_observableAction_7_0= ruleObservableAction ) ) ( (lv_evidence_8_0= ruleEvidence ) )+ ( (lv_goalHypotheses_9_0= ruleGoalHypothesis ) )+ (otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) ) )? (otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) ) )? otherlv_14= '}' ) )
            // InternalDynamicGoalModel.g:196:2: (otherlv_0= 'DynamicGoal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'title' ( (lv_title_4_0= RULE_STRING ) ) (otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) ) )? ( (lv_observableAction_7_0= ruleObservableAction ) ) ( (lv_evidence_8_0= ruleEvidence ) )+ ( (lv_goalHypotheses_9_0= ruleGoalHypothesis ) )+ (otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) ) )? (otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) ) )? otherlv_14= '}' )
            {
            // InternalDynamicGoalModel.g:196:2: (otherlv_0= 'DynamicGoal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'title' ( (lv_title_4_0= RULE_STRING ) ) (otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) ) )? ( (lv_observableAction_7_0= ruleObservableAction ) ) ( (lv_evidence_8_0= ruleEvidence ) )+ ( (lv_goalHypotheses_9_0= ruleGoalHypothesis ) )+ (otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) ) )? (otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) ) )? otherlv_14= '}' )
            // InternalDynamicGoalModel.g:197:3: otherlv_0= 'DynamicGoal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'title' ( (lv_title_4_0= RULE_STRING ) ) (otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) ) )? ( (lv_observableAction_7_0= ruleObservableAction ) ) ( (lv_evidence_8_0= ruleEvidence ) )+ ( (lv_goalHypotheses_9_0= ruleGoalHypothesis ) )+ (otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) ) )? (otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) ) )? otherlv_14= '}'
            {
            otherlv_0=(Token)match(input,16,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getDynamicGoalAccess().getDynamicGoalKeyword_0());
            		
            // InternalDynamicGoalModel.g:201:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:202:4: (lv_name_1_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:202:4: (lv_name_1_0= RULE_ID )
            // InternalDynamicGoalModel.g:203:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDynamicGoalAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDynamicGoalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_9); 

            			newLeafNode(otherlv_2, grammarAccess.getDynamicGoalAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,17,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getDynamicGoalAccess().getTitleKeyword_3());
            		
            // InternalDynamicGoalModel.g:227:3: ( (lv_title_4_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:228:4: (lv_title_4_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:228:4: (lv_title_4_0= RULE_STRING )
            // InternalDynamicGoalModel.g:229:5: lv_title_4_0= RULE_STRING
            {
            lv_title_4_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_title_4_0, grammarAccess.getDynamicGoalAccess().getTitleSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDynamicGoalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"title",
            						lv_title_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalDynamicGoalModel.g:245:3: (otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==18) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalDynamicGoalModel.g:246:4: otherlv_5= 'useCaseRef' ( (lv_useCaseRef_6_0= RULE_STRING ) )
                    {
                    otherlv_5=(Token)match(input,18,FOLLOW_6); 

                    				newLeafNode(otherlv_5, grammarAccess.getDynamicGoalAccess().getUseCaseRefKeyword_5_0());
                    			
                    // InternalDynamicGoalModel.g:250:4: ( (lv_useCaseRef_6_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:251:5: (lv_useCaseRef_6_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:251:5: (lv_useCaseRef_6_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:252:6: lv_useCaseRef_6_0= RULE_STRING
                    {
                    lv_useCaseRef_6_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    						newLeafNode(lv_useCaseRef_6_0, grammarAccess.getDynamicGoalAccess().getUseCaseRefSTRINGTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDynamicGoalRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"useCaseRef",
                    							lv_useCaseRef_6_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:269:3: ( (lv_observableAction_7_0= ruleObservableAction ) )
            // InternalDynamicGoalModel.g:270:4: (lv_observableAction_7_0= ruleObservableAction )
            {
            // InternalDynamicGoalModel.g:270:4: (lv_observableAction_7_0= ruleObservableAction )
            // InternalDynamicGoalModel.g:271:5: lv_observableAction_7_0= ruleObservableAction
            {

            					newCompositeNode(grammarAccess.getDynamicGoalAccess().getObservableActionObservableActionParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_11);
            lv_observableAction_7_0=ruleObservableAction();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDynamicGoalRule());
            					}
            					set(
            						current,
            						"observableAction",
            						lv_observableAction_7_0,
            						"org.dgm.DynamicGoalModel.ObservableAction");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDynamicGoalModel.g:288:3: ( (lv_evidence_8_0= ruleEvidence ) )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==26) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:289:4: (lv_evidence_8_0= ruleEvidence )
            	    {
            	    // InternalDynamicGoalModel.g:289:4: (lv_evidence_8_0= ruleEvidence )
            	    // InternalDynamicGoalModel.g:290:5: lv_evidence_8_0= ruleEvidence
            	    {

            	    					newCompositeNode(grammarAccess.getDynamicGoalAccess().getEvidenceEvidenceParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_12);
            	    lv_evidence_8_0=ruleEvidence();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDynamicGoalRule());
            	    					}
            	    					add(
            	    						current,
            	    						"evidence",
            	    						lv_evidence_8_0,
            	    						"org.dgm.DynamicGoalModel.Evidence");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

            // InternalDynamicGoalModel.g:307:3: ( (lv_goalHypotheses_9_0= ruleGoalHypothesis ) )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==33) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:308:4: (lv_goalHypotheses_9_0= ruleGoalHypothesis )
            	    {
            	    // InternalDynamicGoalModel.g:308:4: (lv_goalHypotheses_9_0= ruleGoalHypothesis )
            	    // InternalDynamicGoalModel.g:309:5: lv_goalHypotheses_9_0= ruleGoalHypothesis
            	    {

            	    					newCompositeNode(grammarAccess.getDynamicGoalAccess().getGoalHypothesesGoalHypothesisParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_13);
            	    lv_goalHypotheses_9_0=ruleGoalHypothesis();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDynamicGoalRule());
            	    					}
            	    					add(
            	    						current,
            	    						"goalHypotheses",
            	    						lv_goalHypotheses_9_0,
            	    						"org.dgm.DynamicGoalModel.GoalHypothesis");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            // InternalDynamicGoalModel.g:326:3: (otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalDynamicGoalModel.g:327:4: otherlv_10= 'precedence' ( (lv_precedence_11_0= rulePrecedence ) )
                    {
                    otherlv_10=(Token)match(input,19,FOLLOW_14); 

                    				newLeafNode(otherlv_10, grammarAccess.getDynamicGoalAccess().getPrecedenceKeyword_9_0());
                    			
                    // InternalDynamicGoalModel.g:331:4: ( (lv_precedence_11_0= rulePrecedence ) )
                    // InternalDynamicGoalModel.g:332:5: (lv_precedence_11_0= rulePrecedence )
                    {
                    // InternalDynamicGoalModel.g:332:5: (lv_precedence_11_0= rulePrecedence )
                    // InternalDynamicGoalModel.g:333:6: lv_precedence_11_0= rulePrecedence
                    {

                    						newCompositeNode(grammarAccess.getDynamicGoalAccess().getPrecedencePrecedenceParserRuleCall_9_1_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_precedence_11_0=rulePrecedence();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDynamicGoalRule());
                    						}
                    						set(
                    							current,
                    							"precedence",
                    							lv_precedence_11_0,
                    							"org.dgm.DynamicGoalModel.Precedence");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:351:3: (otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==20) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalDynamicGoalModel.g:352:4: otherlv_12= 'escalation' ( (lv_escalation_13_0= ruleEscalationStrategy ) )
                    {
                    otherlv_12=(Token)match(input,20,FOLLOW_16); 

                    				newLeafNode(otherlv_12, grammarAccess.getDynamicGoalAccess().getEscalationKeyword_10_0());
                    			
                    // InternalDynamicGoalModel.g:356:4: ( (lv_escalation_13_0= ruleEscalationStrategy ) )
                    // InternalDynamicGoalModel.g:357:5: (lv_escalation_13_0= ruleEscalationStrategy )
                    {
                    // InternalDynamicGoalModel.g:357:5: (lv_escalation_13_0= ruleEscalationStrategy )
                    // InternalDynamicGoalModel.g:358:6: lv_escalation_13_0= ruleEscalationStrategy
                    {

                    						newCompositeNode(grammarAccess.getDynamicGoalAccess().getEscalationEscalationStrategyParserRuleCall_10_1_0());
                    					
                    pushFollow(FOLLOW_17);
                    lv_escalation_13_0=ruleEscalationStrategy();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDynamicGoalRule());
                    						}
                    						set(
                    							current,
                    							"escalation",
                    							lv_escalation_13_0,
                    							"org.dgm.DynamicGoalModel.EscalationStrategy");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_14=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getDynamicGoalAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDynamicGoal"


    // $ANTLR start "entryRuleObservableAction"
    // InternalDynamicGoalModel.g:384:1: entryRuleObservableAction returns [EObject current=null] : iv_ruleObservableAction= ruleObservableAction EOF ;
    public final EObject entryRuleObservableAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObservableAction = null;


        try {
            // InternalDynamicGoalModel.g:384:57: (iv_ruleObservableAction= ruleObservableAction EOF )
            // InternalDynamicGoalModel.g:385:2: iv_ruleObservableAction= ruleObservableAction EOF
            {
             newCompositeNode(grammarAccess.getObservableActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObservableAction=ruleObservableAction();

            state._fsp--;

             current =iv_ruleObservableAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObservableAction"


    // $ANTLR start "ruleObservableAction"
    // InternalDynamicGoalModel.g:391:1: ruleObservableAction returns [EObject current=null] : (otherlv_0= 'ObservableAction' otherlv_1= '{' otherlv_2= 'signature' ( (lv_signature_3_0= RULE_STRING ) ) otherlv_4= 'trigger' ( (lv_trigger_5_0= RULE_STRING ) ) (otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) ) )? (otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) ) )? otherlv_10= '}' ) ;
    public final EObject ruleObservableAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_signature_3_0=null;
        Token otherlv_4=null;
        Token lv_trigger_5_0=null;
        Token otherlv_6=null;
        Token lv_scopeStart_7_0=null;
        Token otherlv_8=null;
        Token lv_scopeEnd_9_0=null;
        Token otherlv_10=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:397:2: ( (otherlv_0= 'ObservableAction' otherlv_1= '{' otherlv_2= 'signature' ( (lv_signature_3_0= RULE_STRING ) ) otherlv_4= 'trigger' ( (lv_trigger_5_0= RULE_STRING ) ) (otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) ) )? (otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) ) )? otherlv_10= '}' ) )
            // InternalDynamicGoalModel.g:398:2: (otherlv_0= 'ObservableAction' otherlv_1= '{' otherlv_2= 'signature' ( (lv_signature_3_0= RULE_STRING ) ) otherlv_4= 'trigger' ( (lv_trigger_5_0= RULE_STRING ) ) (otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) ) )? (otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) ) )? otherlv_10= '}' )
            {
            // InternalDynamicGoalModel.g:398:2: (otherlv_0= 'ObservableAction' otherlv_1= '{' otherlv_2= 'signature' ( (lv_signature_3_0= RULE_STRING ) ) otherlv_4= 'trigger' ( (lv_trigger_5_0= RULE_STRING ) ) (otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) ) )? (otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) ) )? otherlv_10= '}' )
            // InternalDynamicGoalModel.g:399:3: otherlv_0= 'ObservableAction' otherlv_1= '{' otherlv_2= 'signature' ( (lv_signature_3_0= RULE_STRING ) ) otherlv_4= 'trigger' ( (lv_trigger_5_0= RULE_STRING ) ) (otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) ) )? (otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) ) )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,21,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getObservableActionAccess().getObservableActionKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_18); 

            			newLeafNode(otherlv_1, grammarAccess.getObservableActionAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,22,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getObservableActionAccess().getSignatureKeyword_2());
            		
            // InternalDynamicGoalModel.g:411:3: ( (lv_signature_3_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:412:4: (lv_signature_3_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:412:4: (lv_signature_3_0= RULE_STRING )
            // InternalDynamicGoalModel.g:413:5: lv_signature_3_0= RULE_STRING
            {
            lv_signature_3_0=(Token)match(input,RULE_STRING,FOLLOW_19); 

            					newLeafNode(lv_signature_3_0, grammarAccess.getObservableActionAccess().getSignatureSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getObservableActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"signature",
            						lv_signature_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,23,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getObservableActionAccess().getTriggerKeyword_4());
            		
            // InternalDynamicGoalModel.g:433:3: ( (lv_trigger_5_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:434:4: (lv_trigger_5_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:434:4: (lv_trigger_5_0= RULE_STRING )
            // InternalDynamicGoalModel.g:435:5: lv_trigger_5_0= RULE_STRING
            {
            lv_trigger_5_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_trigger_5_0, grammarAccess.getObservableActionAccess().getTriggerSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getObservableActionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"trigger",
            						lv_trigger_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalDynamicGoalModel.g:451:3: (otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==24) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalDynamicGoalModel.g:452:4: otherlv_6= 'scopeStart' ( (lv_scopeStart_7_0= RULE_STRING ) )
                    {
                    otherlv_6=(Token)match(input,24,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getObservableActionAccess().getScopeStartKeyword_6_0());
                    			
                    // InternalDynamicGoalModel.g:456:4: ( (lv_scopeStart_7_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:457:5: (lv_scopeStart_7_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:457:5: (lv_scopeStart_7_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:458:6: lv_scopeStart_7_0= RULE_STRING
                    {
                    lv_scopeStart_7_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

                    						newLeafNode(lv_scopeStart_7_0, grammarAccess.getObservableActionAccess().getScopeStartSTRINGTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getObservableActionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"scopeStart",
                    							lv_scopeStart_7_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:475:3: (otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==25) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalDynamicGoalModel.g:476:4: otherlv_8= 'scopeEnd' ( (lv_scopeEnd_9_0= RULE_STRING ) )
                    {
                    otherlv_8=(Token)match(input,25,FOLLOW_6); 

                    				newLeafNode(otherlv_8, grammarAccess.getObservableActionAccess().getScopeEndKeyword_7_0());
                    			
                    // InternalDynamicGoalModel.g:480:4: ( (lv_scopeEnd_9_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:481:5: (lv_scopeEnd_9_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:481:5: (lv_scopeEnd_9_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:482:6: lv_scopeEnd_9_0= RULE_STRING
                    {
                    lv_scopeEnd_9_0=(Token)match(input,RULE_STRING,FOLLOW_17); 

                    						newLeafNode(lv_scopeEnd_9_0, grammarAccess.getObservableActionAccess().getScopeEndSTRINGTerminalRuleCall_7_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getObservableActionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"scopeEnd",
                    							lv_scopeEnd_9_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getObservableActionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObservableAction"


    // $ANTLR start "entryRuleEvidence"
    // InternalDynamicGoalModel.g:507:1: entryRuleEvidence returns [EObject current=null] : iv_ruleEvidence= ruleEvidence EOF ;
    public final EObject entryRuleEvidence() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvidence = null;


        try {
            // InternalDynamicGoalModel.g:507:49: (iv_ruleEvidence= ruleEvidence EOF )
            // InternalDynamicGoalModel.g:508:2: iv_ruleEvidence= ruleEvidence EOF
            {
             newCompositeNode(grammarAccess.getEvidenceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvidence=ruleEvidence();

            state._fsp--;

             current =iv_ruleEvidence; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvidence"


    // $ANTLR start "ruleEvidence"
    // InternalDynamicGoalModel.g:514:1: ruleEvidence returns [EObject current=null] : (otherlv_0= 'Evidence' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type' ( (lv_type_4_0= ruleEvidenceType ) ) otherlv_5= 'source' ( (lv_source_6_0= RULE_STRING ) ) otherlv_7= 'predicate' ( (lv_predicate_8_0= RULE_STRING ) ) (otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) ) )? otherlv_11= '}' ) ;
    public final EObject ruleEvidence() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token lv_source_6_0=null;
        Token otherlv_7=null;
        Token lv_predicate_8_0=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Enumerator lv_type_4_0 = null;

        EObject lv_derivedFrom_10_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:520:2: ( (otherlv_0= 'Evidence' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type' ( (lv_type_4_0= ruleEvidenceType ) ) otherlv_5= 'source' ( (lv_source_6_0= RULE_STRING ) ) otherlv_7= 'predicate' ( (lv_predicate_8_0= RULE_STRING ) ) (otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) ) )? otherlv_11= '}' ) )
            // InternalDynamicGoalModel.g:521:2: (otherlv_0= 'Evidence' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type' ( (lv_type_4_0= ruleEvidenceType ) ) otherlv_5= 'source' ( (lv_source_6_0= RULE_STRING ) ) otherlv_7= 'predicate' ( (lv_predicate_8_0= RULE_STRING ) ) (otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) ) )? otherlv_11= '}' )
            {
            // InternalDynamicGoalModel.g:521:2: (otherlv_0= 'Evidence' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type' ( (lv_type_4_0= ruleEvidenceType ) ) otherlv_5= 'source' ( (lv_source_6_0= RULE_STRING ) ) otherlv_7= 'predicate' ( (lv_predicate_8_0= RULE_STRING ) ) (otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) ) )? otherlv_11= '}' )
            // InternalDynamicGoalModel.g:522:3: otherlv_0= 'Evidence' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'type' ( (lv_type_4_0= ruleEvidenceType ) ) otherlv_5= 'source' ( (lv_source_6_0= RULE_STRING ) ) otherlv_7= 'predicate' ( (lv_predicate_8_0= RULE_STRING ) ) (otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) ) )? otherlv_11= '}'
            {
            otherlv_0=(Token)match(input,26,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getEvidenceAccess().getEvidenceKeyword_0());
            		
            // InternalDynamicGoalModel.g:526:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:527:4: (lv_name_1_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:527:4: (lv_name_1_0= RULE_ID )
            // InternalDynamicGoalModel.g:528:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEvidenceAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvidenceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_22); 

            			newLeafNode(otherlv_2, grammarAccess.getEvidenceAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,27,FOLLOW_23); 

            			newLeafNode(otherlv_3, grammarAccess.getEvidenceAccess().getTypeKeyword_3());
            		
            // InternalDynamicGoalModel.g:552:3: ( (lv_type_4_0= ruleEvidenceType ) )
            // InternalDynamicGoalModel.g:553:4: (lv_type_4_0= ruleEvidenceType )
            {
            // InternalDynamicGoalModel.g:553:4: (lv_type_4_0= ruleEvidenceType )
            // InternalDynamicGoalModel.g:554:5: lv_type_4_0= ruleEvidenceType
            {

            					newCompositeNode(grammarAccess.getEvidenceAccess().getTypeEvidenceTypeEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_24);
            lv_type_4_0=ruleEvidenceType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEvidenceRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_4_0,
            						"org.dgm.DynamicGoalModel.EvidenceType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,28,FOLLOW_6); 

            			newLeafNode(otherlv_5, grammarAccess.getEvidenceAccess().getSourceKeyword_5());
            		
            // InternalDynamicGoalModel.g:575:3: ( (lv_source_6_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:576:4: (lv_source_6_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:576:4: (lv_source_6_0= RULE_STRING )
            // InternalDynamicGoalModel.g:577:5: lv_source_6_0= RULE_STRING
            {
            lv_source_6_0=(Token)match(input,RULE_STRING,FOLLOW_25); 

            					newLeafNode(lv_source_6_0, grammarAccess.getEvidenceAccess().getSourceSTRINGTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvidenceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"source",
            						lv_source_6_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_7=(Token)match(input,29,FOLLOW_6); 

            			newLeafNode(otherlv_7, grammarAccess.getEvidenceAccess().getPredicateKeyword_7());
            		
            // InternalDynamicGoalModel.g:597:3: ( (lv_predicate_8_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:598:4: (lv_predicate_8_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:598:4: (lv_predicate_8_0= RULE_STRING )
            // InternalDynamicGoalModel.g:599:5: lv_predicate_8_0= RULE_STRING
            {
            lv_predicate_8_0=(Token)match(input,RULE_STRING,FOLLOW_26); 

            					newLeafNode(lv_predicate_8_0, grammarAccess.getEvidenceAccess().getPredicateSTRINGTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvidenceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"predicate",
            						lv_predicate_8_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalDynamicGoalModel.g:615:3: (otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==30) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalDynamicGoalModel.g:616:4: otherlv_9= 'derivedFrom' ( (lv_derivedFrom_10_0= ruleDerivedExpression ) )
                    {
                    otherlv_9=(Token)match(input,30,FOLLOW_27); 

                    				newLeafNode(otherlv_9, grammarAccess.getEvidenceAccess().getDerivedFromKeyword_9_0());
                    			
                    // InternalDynamicGoalModel.g:620:4: ( (lv_derivedFrom_10_0= ruleDerivedExpression ) )
                    // InternalDynamicGoalModel.g:621:5: (lv_derivedFrom_10_0= ruleDerivedExpression )
                    {
                    // InternalDynamicGoalModel.g:621:5: (lv_derivedFrom_10_0= ruleDerivedExpression )
                    // InternalDynamicGoalModel.g:622:6: lv_derivedFrom_10_0= ruleDerivedExpression
                    {

                    						newCompositeNode(grammarAccess.getEvidenceAccess().getDerivedFromDerivedExpressionParserRuleCall_9_1_0());
                    					
                    pushFollow(FOLLOW_17);
                    lv_derivedFrom_10_0=ruleDerivedExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEvidenceRule());
                    						}
                    						set(
                    							current,
                    							"derivedFrom",
                    							lv_derivedFrom_10_0,
                    							"org.dgm.DynamicGoalModel.DerivedExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_11=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getEvidenceAccess().getRightCurlyBracketKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvidence"


    // $ANTLR start "entryRuleDerivedExpression"
    // InternalDynamicGoalModel.g:648:1: entryRuleDerivedExpression returns [EObject current=null] : iv_ruleDerivedExpression= ruleDerivedExpression EOF ;
    public final EObject entryRuleDerivedExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDerivedExpression = null;


        try {
            // InternalDynamicGoalModel.g:648:58: (iv_ruleDerivedExpression= ruleDerivedExpression EOF )
            // InternalDynamicGoalModel.g:649:2: iv_ruleDerivedExpression= ruleDerivedExpression EOF
            {
             newCompositeNode(grammarAccess.getDerivedExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDerivedExpression=ruleDerivedExpression();

            state._fsp--;

             current =iv_ruleDerivedExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDerivedExpression"


    // $ANTLR start "ruleDerivedExpression"
    // InternalDynamicGoalModel.g:655:1: ruleDerivedExpression returns [EObject current=null] : (otherlv_0= 'derivedFrom' otherlv_1= '(' ( (lv_expression_2_0= ruleConditionExpression ) ) otherlv_3= ')' ) ;
    public final EObject ruleDerivedExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_expression_2_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:661:2: ( (otherlv_0= 'derivedFrom' otherlv_1= '(' ( (lv_expression_2_0= ruleConditionExpression ) ) otherlv_3= ')' ) )
            // InternalDynamicGoalModel.g:662:2: (otherlv_0= 'derivedFrom' otherlv_1= '(' ( (lv_expression_2_0= ruleConditionExpression ) ) otherlv_3= ')' )
            {
            // InternalDynamicGoalModel.g:662:2: (otherlv_0= 'derivedFrom' otherlv_1= '(' ( (lv_expression_2_0= ruleConditionExpression ) ) otherlv_3= ')' )
            // InternalDynamicGoalModel.g:663:3: otherlv_0= 'derivedFrom' otherlv_1= '(' ( (lv_expression_2_0= ruleConditionExpression ) ) otherlv_3= ')'
            {
            otherlv_0=(Token)match(input,30,FOLLOW_28); 

            			newLeafNode(otherlv_0, grammarAccess.getDerivedExpressionAccess().getDerivedFromKeyword_0());
            		
            otherlv_1=(Token)match(input,31,FOLLOW_29); 

            			newLeafNode(otherlv_1, grammarAccess.getDerivedExpressionAccess().getLeftParenthesisKeyword_1());
            		
            // InternalDynamicGoalModel.g:671:3: ( (lv_expression_2_0= ruleConditionExpression ) )
            // InternalDynamicGoalModel.g:672:4: (lv_expression_2_0= ruleConditionExpression )
            {
            // InternalDynamicGoalModel.g:672:4: (lv_expression_2_0= ruleConditionExpression )
            // InternalDynamicGoalModel.g:673:5: lv_expression_2_0= ruleConditionExpression
            {

            					newCompositeNode(grammarAccess.getDerivedExpressionAccess().getExpressionConditionExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_30);
            lv_expression_2_0=ruleConditionExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDerivedExpressionRule());
            					}
            					set(
            						current,
            						"expression",
            						lv_expression_2_0,
            						"org.dgm.DynamicGoalModel.ConditionExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,32,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getDerivedExpressionAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDerivedExpression"


    // $ANTLR start "entryRuleGoalHypothesis"
    // InternalDynamicGoalModel.g:698:1: entryRuleGoalHypothesis returns [EObject current=null] : iv_ruleGoalHypothesis= ruleGoalHypothesis EOF ;
    public final EObject entryRuleGoalHypothesis() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGoalHypothesis = null;


        try {
            // InternalDynamicGoalModel.g:698:55: (iv_ruleGoalHypothesis= ruleGoalHypothesis EOF )
            // InternalDynamicGoalModel.g:699:2: iv_ruleGoalHypothesis= ruleGoalHypothesis EOF
            {
             newCompositeNode(grammarAccess.getGoalHypothesisRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGoalHypothesis=ruleGoalHypothesis();

            state._fsp--;

             current =iv_ruleGoalHypothesis; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGoalHypothesis"


    // $ANTLR start "ruleGoalHypothesis"
    // InternalDynamicGoalModel.g:705:1: ruleGoalHypothesis returns [EObject current=null] : (otherlv_0= 'GoalHypothesis' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'intention' ( (lv_intention_4_0= RULE_STRING ) ) otherlv_5= 'condition' ( (lv_condition_6_0= ruleConditionExpression ) ) ( (lv_responseBinding_7_0= ruleResponseBinding ) ) otherlv_8= '}' ) ;
    public final EObject ruleGoalHypothesis() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_intention_4_0=null;
        Token otherlv_5=null;
        Token otherlv_8=null;
        EObject lv_condition_6_0 = null;

        EObject lv_responseBinding_7_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:711:2: ( (otherlv_0= 'GoalHypothesis' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'intention' ( (lv_intention_4_0= RULE_STRING ) ) otherlv_5= 'condition' ( (lv_condition_6_0= ruleConditionExpression ) ) ( (lv_responseBinding_7_0= ruleResponseBinding ) ) otherlv_8= '}' ) )
            // InternalDynamicGoalModel.g:712:2: (otherlv_0= 'GoalHypothesis' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'intention' ( (lv_intention_4_0= RULE_STRING ) ) otherlv_5= 'condition' ( (lv_condition_6_0= ruleConditionExpression ) ) ( (lv_responseBinding_7_0= ruleResponseBinding ) ) otherlv_8= '}' )
            {
            // InternalDynamicGoalModel.g:712:2: (otherlv_0= 'GoalHypothesis' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'intention' ( (lv_intention_4_0= RULE_STRING ) ) otherlv_5= 'condition' ( (lv_condition_6_0= ruleConditionExpression ) ) ( (lv_responseBinding_7_0= ruleResponseBinding ) ) otherlv_8= '}' )
            // InternalDynamicGoalModel.g:713:3: otherlv_0= 'GoalHypothesis' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'intention' ( (lv_intention_4_0= RULE_STRING ) ) otherlv_5= 'condition' ( (lv_condition_6_0= ruleConditionExpression ) ) ( (lv_responseBinding_7_0= ruleResponseBinding ) ) otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getGoalHypothesisAccess().getGoalHypothesisKeyword_0());
            		
            // InternalDynamicGoalModel.g:717:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:718:4: (lv_name_1_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:718:4: (lv_name_1_0= RULE_ID )
            // InternalDynamicGoalModel.g:719:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getGoalHypothesisAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGoalHypothesisRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_31); 

            			newLeafNode(otherlv_2, grammarAccess.getGoalHypothesisAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,34,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getGoalHypothesisAccess().getIntentionKeyword_3());
            		
            // InternalDynamicGoalModel.g:743:3: ( (lv_intention_4_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:744:4: (lv_intention_4_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:744:4: (lv_intention_4_0= RULE_STRING )
            // InternalDynamicGoalModel.g:745:5: lv_intention_4_0= RULE_STRING
            {
            lv_intention_4_0=(Token)match(input,RULE_STRING,FOLLOW_32); 

            					newLeafNode(lv_intention_4_0, grammarAccess.getGoalHypothesisAccess().getIntentionSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getGoalHypothesisRule());
            					}
            					setWithLastConsumed(
            						current,
            						"intention",
            						lv_intention_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_5=(Token)match(input,35,FOLLOW_29); 

            			newLeafNode(otherlv_5, grammarAccess.getGoalHypothesisAccess().getConditionKeyword_5());
            		
            // InternalDynamicGoalModel.g:765:3: ( (lv_condition_6_0= ruleConditionExpression ) )
            // InternalDynamicGoalModel.g:766:4: (lv_condition_6_0= ruleConditionExpression )
            {
            // InternalDynamicGoalModel.g:766:4: (lv_condition_6_0= ruleConditionExpression )
            // InternalDynamicGoalModel.g:767:5: lv_condition_6_0= ruleConditionExpression
            {

            					newCompositeNode(grammarAccess.getGoalHypothesisAccess().getConditionConditionExpressionParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_33);
            lv_condition_6_0=ruleConditionExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGoalHypothesisRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_6_0,
            						"org.dgm.DynamicGoalModel.ConditionExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDynamicGoalModel.g:784:3: ( (lv_responseBinding_7_0= ruleResponseBinding ) )
            // InternalDynamicGoalModel.g:785:4: (lv_responseBinding_7_0= ruleResponseBinding )
            {
            // InternalDynamicGoalModel.g:785:4: (lv_responseBinding_7_0= ruleResponseBinding )
            // InternalDynamicGoalModel.g:786:5: lv_responseBinding_7_0= ruleResponseBinding
            {

            					newCompositeNode(grammarAccess.getGoalHypothesisAccess().getResponseBindingResponseBindingParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_17);
            lv_responseBinding_7_0=ruleResponseBinding();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGoalHypothesisRule());
            					}
            					set(
            						current,
            						"responseBinding",
            						lv_responseBinding_7_0,
            						"org.dgm.DynamicGoalModel.ResponseBinding");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getGoalHypothesisAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGoalHypothesis"


    // $ANTLR start "entryRuleConditionExpression"
    // InternalDynamicGoalModel.g:811:1: entryRuleConditionExpression returns [EObject current=null] : iv_ruleConditionExpression= ruleConditionExpression EOF ;
    public final EObject entryRuleConditionExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditionExpression = null;


        try {
            // InternalDynamicGoalModel.g:811:60: (iv_ruleConditionExpression= ruleConditionExpression EOF )
            // InternalDynamicGoalModel.g:812:2: iv_ruleConditionExpression= ruleConditionExpression EOF
            {
             newCompositeNode(grammarAccess.getConditionExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConditionExpression=ruleConditionExpression();

            state._fsp--;

             current =iv_ruleConditionExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditionExpression"


    // $ANTLR start "ruleConditionExpression"
    // InternalDynamicGoalModel.g:818:1: ruleConditionExpression returns [EObject current=null] : this_OrExpression_0= ruleOrExpression ;
    public final EObject ruleConditionExpression() throws RecognitionException {
        EObject current = null;

        EObject this_OrExpression_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:824:2: (this_OrExpression_0= ruleOrExpression )
            // InternalDynamicGoalModel.g:825:2: this_OrExpression_0= ruleOrExpression
            {

            		newCompositeNode(grammarAccess.getConditionExpressionAccess().getOrExpressionParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_OrExpression_0=ruleOrExpression();

            state._fsp--;


            		current = this_OrExpression_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditionExpression"


    // $ANTLR start "entryRuleOrExpression"
    // InternalDynamicGoalModel.g:836:1: entryRuleOrExpression returns [EObject current=null] : iv_ruleOrExpression= ruleOrExpression EOF ;
    public final EObject entryRuleOrExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOrExpression = null;


        try {
            // InternalDynamicGoalModel.g:836:53: (iv_ruleOrExpression= ruleOrExpression EOF )
            // InternalDynamicGoalModel.g:837:2: iv_ruleOrExpression= ruleOrExpression EOF
            {
             newCompositeNode(grammarAccess.getOrExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOrExpression=ruleOrExpression();

            state._fsp--;

             current =iv_ruleOrExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOrExpression"


    // $ANTLR start "ruleOrExpression"
    // InternalDynamicGoalModel.g:843:1: ruleOrExpression returns [EObject current=null] : (this_AndExpression_0= ruleAndExpression ( () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) ) )* ) ;
    public final EObject ruleOrExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject this_AndExpression_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:849:2: ( (this_AndExpression_0= ruleAndExpression ( () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) ) )* ) )
            // InternalDynamicGoalModel.g:850:2: (this_AndExpression_0= ruleAndExpression ( () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) ) )* )
            {
            // InternalDynamicGoalModel.g:850:2: (this_AndExpression_0= ruleAndExpression ( () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) ) )* )
            // InternalDynamicGoalModel.g:851:3: this_AndExpression_0= ruleAndExpression ( () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getOrExpressionAccess().getAndExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_34);
            this_AndExpression_0=ruleAndExpression();

            state._fsp--;


            			current = this_AndExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalDynamicGoalModel.g:859:3: ( () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==36) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:860:4: () otherlv_2= '||' ( (lv_right_3_0= ruleAndExpression ) )
            	    {
            	    // InternalDynamicGoalModel.g:860:4: ()
            	    // InternalDynamicGoalModel.g:861:5: 
            	    {

            	    					current = forceCreateModelElementAndSet(
            	    						grammarAccess.getOrExpressionAccess().getOrExpressionLeftAction_1_0(),
            	    						current);
            	    				

            	    }

            	    otherlv_2=(Token)match(input,36,FOLLOW_29); 

            	    				newLeafNode(otherlv_2, grammarAccess.getOrExpressionAccess().getVerticalLineVerticalLineKeyword_1_1());
            	    			
            	    // InternalDynamicGoalModel.g:871:4: ( (lv_right_3_0= ruleAndExpression ) )
            	    // InternalDynamicGoalModel.g:872:5: (lv_right_3_0= ruleAndExpression )
            	    {
            	    // InternalDynamicGoalModel.g:872:5: (lv_right_3_0= ruleAndExpression )
            	    // InternalDynamicGoalModel.g:873:6: lv_right_3_0= ruleAndExpression
            	    {

            	    						newCompositeNode(grammarAccess.getOrExpressionAccess().getRightAndExpressionParserRuleCall_1_2_0());
            	    					
            	    pushFollow(FOLLOW_34);
            	    lv_right_3_0=ruleAndExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getOrExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_3_0,
            	    							"org.dgm.DynamicGoalModel.AndExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOrExpression"


    // $ANTLR start "entryRuleAndExpression"
    // InternalDynamicGoalModel.g:895:1: entryRuleAndExpression returns [EObject current=null] : iv_ruleAndExpression= ruleAndExpression EOF ;
    public final EObject entryRuleAndExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAndExpression = null;


        try {
            // InternalDynamicGoalModel.g:895:54: (iv_ruleAndExpression= ruleAndExpression EOF )
            // InternalDynamicGoalModel.g:896:2: iv_ruleAndExpression= ruleAndExpression EOF
            {
             newCompositeNode(grammarAccess.getAndExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAndExpression=ruleAndExpression();

            state._fsp--;

             current =iv_ruleAndExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAndExpression"


    // $ANTLR start "ruleAndExpression"
    // InternalDynamicGoalModel.g:902:1: ruleAndExpression returns [EObject current=null] : (this_UnaryExpression_0= ruleUnaryExpression ( () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) ) )* ) ;
    public final EObject ruleAndExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject this_UnaryExpression_0 = null;

        EObject lv_right_3_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:908:2: ( (this_UnaryExpression_0= ruleUnaryExpression ( () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) ) )* ) )
            // InternalDynamicGoalModel.g:909:2: (this_UnaryExpression_0= ruleUnaryExpression ( () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) ) )* )
            {
            // InternalDynamicGoalModel.g:909:2: (this_UnaryExpression_0= ruleUnaryExpression ( () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) ) )* )
            // InternalDynamicGoalModel.g:910:3: this_UnaryExpression_0= ruleUnaryExpression ( () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getAndExpressionAccess().getUnaryExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_35);
            this_UnaryExpression_0=ruleUnaryExpression();

            state._fsp--;


            			current = this_UnaryExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalDynamicGoalModel.g:918:3: ( () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==37) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:919:4: () otherlv_2= '&&' ( (lv_right_3_0= ruleUnaryExpression ) )
            	    {
            	    // InternalDynamicGoalModel.g:919:4: ()
            	    // InternalDynamicGoalModel.g:920:5: 
            	    {

            	    					current = forceCreateModelElementAndSet(
            	    						grammarAccess.getAndExpressionAccess().getAndExpressionLeftAction_1_0(),
            	    						current);
            	    				

            	    }

            	    otherlv_2=(Token)match(input,37,FOLLOW_29); 

            	    				newLeafNode(otherlv_2, grammarAccess.getAndExpressionAccess().getAmpersandAmpersandKeyword_1_1());
            	    			
            	    // InternalDynamicGoalModel.g:930:4: ( (lv_right_3_0= ruleUnaryExpression ) )
            	    // InternalDynamicGoalModel.g:931:5: (lv_right_3_0= ruleUnaryExpression )
            	    {
            	    // InternalDynamicGoalModel.g:931:5: (lv_right_3_0= ruleUnaryExpression )
            	    // InternalDynamicGoalModel.g:932:6: lv_right_3_0= ruleUnaryExpression
            	    {

            	    						newCompositeNode(grammarAccess.getAndExpressionAccess().getRightUnaryExpressionParserRuleCall_1_2_0());
            	    					
            	    pushFollow(FOLLOW_35);
            	    lv_right_3_0=ruleUnaryExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getAndExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_3_0,
            	    							"org.dgm.DynamicGoalModel.UnaryExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAndExpression"


    // $ANTLR start "entryRuleUnaryExpression"
    // InternalDynamicGoalModel.g:954:1: entryRuleUnaryExpression returns [EObject current=null] : iv_ruleUnaryExpression= ruleUnaryExpression EOF ;
    public final EObject entryRuleUnaryExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUnaryExpression = null;


        try {
            // InternalDynamicGoalModel.g:954:56: (iv_ruleUnaryExpression= ruleUnaryExpression EOF )
            // InternalDynamicGoalModel.g:955:2: iv_ruleUnaryExpression= ruleUnaryExpression EOF
            {
             newCompositeNode(grammarAccess.getUnaryExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUnaryExpression=ruleUnaryExpression();

            state._fsp--;

             current =iv_ruleUnaryExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUnaryExpression"


    // $ANTLR start "ruleUnaryExpression"
    // InternalDynamicGoalModel.g:961:1: ruleUnaryExpression returns [EObject current=null] : (this_NegationExpression_0= ruleNegationExpression | this_AtomicCondition_1= ruleAtomicCondition | (otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')' ) ) ;
    public final EObject ruleUnaryExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_NegationExpression_0 = null;

        EObject this_AtomicCondition_1 = null;

        EObject this_ConditionExpression_3 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:967:2: ( (this_NegationExpression_0= ruleNegationExpression | this_AtomicCondition_1= ruleAtomicCondition | (otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')' ) ) )
            // InternalDynamicGoalModel.g:968:2: (this_NegationExpression_0= ruleNegationExpression | this_AtomicCondition_1= ruleAtomicCondition | (otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')' ) )
            {
            // InternalDynamicGoalModel.g:968:2: (this_NegationExpression_0= ruleNegationExpression | this_AtomicCondition_1= ruleAtomicCondition | (otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')' ) )
            int alt14=3;
            switch ( input.LA(1) ) {
            case 38:
                {
                alt14=1;
                }
                break;
            case RULE_ID:
            case 60:
            case 61:
            case 62:
            case 63:
                {
                alt14=2;
                }
                break;
            case 31:
                {
                alt14=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalDynamicGoalModel.g:969:3: this_NegationExpression_0= ruleNegationExpression
                    {

                    			newCompositeNode(grammarAccess.getUnaryExpressionAccess().getNegationExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    			current = this_NegationExpression_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:978:3: this_AtomicCondition_1= ruleAtomicCondition
                    {

                    			newCompositeNode(grammarAccess.getUnaryExpressionAccess().getAtomicConditionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_AtomicCondition_1=ruleAtomicCondition();

                    state._fsp--;


                    			current = this_AtomicCondition_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:987:3: (otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')' )
                    {
                    // InternalDynamicGoalModel.g:987:3: (otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')' )
                    // InternalDynamicGoalModel.g:988:4: otherlv_2= '(' this_ConditionExpression_3= ruleConditionExpression otherlv_4= ')'
                    {
                    otherlv_2=(Token)match(input,31,FOLLOW_29); 

                    				newLeafNode(otherlv_2, grammarAccess.getUnaryExpressionAccess().getLeftParenthesisKeyword_2_0());
                    			

                    				newCompositeNode(grammarAccess.getUnaryExpressionAccess().getConditionExpressionParserRuleCall_2_1());
                    			
                    pushFollow(FOLLOW_30);
                    this_ConditionExpression_3=ruleConditionExpression();

                    state._fsp--;


                    				current = this_ConditionExpression_3;
                    				afterParserOrEnumRuleCall();
                    			
                    otherlv_4=(Token)match(input,32,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getUnaryExpressionAccess().getRightParenthesisKeyword_2_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUnaryExpression"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalDynamicGoalModel.g:1009:1: entryRuleNegationExpression returns [EObject current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final EObject entryRuleNegationExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNegationExpression = null;


        try {
            // InternalDynamicGoalModel.g:1009:59: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalDynamicGoalModel.g:1010:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalDynamicGoalModel.g:1016:1: ruleNegationExpression returns [EObject current=null] : (otherlv_0= 'NOT' ( (lv_operand_1_0= ruleAtomicCondition ) ) ) ;
    public final EObject ruleNegationExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_operand_1_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1022:2: ( (otherlv_0= 'NOT' ( (lv_operand_1_0= ruleAtomicCondition ) ) ) )
            // InternalDynamicGoalModel.g:1023:2: (otherlv_0= 'NOT' ( (lv_operand_1_0= ruleAtomicCondition ) ) )
            {
            // InternalDynamicGoalModel.g:1023:2: (otherlv_0= 'NOT' ( (lv_operand_1_0= ruleAtomicCondition ) ) )
            // InternalDynamicGoalModel.g:1024:3: otherlv_0= 'NOT' ( (lv_operand_1_0= ruleAtomicCondition ) )
            {
            otherlv_0=(Token)match(input,38,FOLLOW_36); 

            			newLeafNode(otherlv_0, grammarAccess.getNegationExpressionAccess().getNOTKeyword_0());
            		
            // InternalDynamicGoalModel.g:1028:3: ( (lv_operand_1_0= ruleAtomicCondition ) )
            // InternalDynamicGoalModel.g:1029:4: (lv_operand_1_0= ruleAtomicCondition )
            {
            // InternalDynamicGoalModel.g:1029:4: (lv_operand_1_0= ruleAtomicCondition )
            // InternalDynamicGoalModel.g:1030:5: lv_operand_1_0= ruleAtomicCondition
            {

            					newCompositeNode(grammarAccess.getNegationExpressionAccess().getOperandAtomicConditionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_operand_1_0=ruleAtomicCondition();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getNegationExpressionRule());
            					}
            					set(
            						current,
            						"operand",
            						lv_operand_1_0,
            						"org.dgm.DynamicGoalModel.AtomicCondition");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleAtomicCondition"
    // InternalDynamicGoalModel.g:1051:1: entryRuleAtomicCondition returns [EObject current=null] : iv_ruleAtomicCondition= ruleAtomicCondition EOF ;
    public final EObject entryRuleAtomicCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAtomicCondition = null;


        try {
            // InternalDynamicGoalModel.g:1051:56: (iv_ruleAtomicCondition= ruleAtomicCondition EOF )
            // InternalDynamicGoalModel.g:1052:2: iv_ruleAtomicCondition= ruleAtomicCondition EOF
            {
             newCompositeNode(grammarAccess.getAtomicConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAtomicCondition=ruleAtomicCondition();

            state._fsp--;

             current =iv_ruleAtomicCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAtomicCondition"


    // $ANTLR start "ruleAtomicCondition"
    // InternalDynamicGoalModel.g:1058:1: ruleAtomicCondition returns [EObject current=null] : (this_EvidenceRef_0= ruleEvidenceRef | this_TemporalCondition_1= ruleTemporalCondition | this_ComparisonCondition_2= ruleComparisonCondition ) ;
    public final EObject ruleAtomicCondition() throws RecognitionException {
        EObject current = null;

        EObject this_EvidenceRef_0 = null;

        EObject this_TemporalCondition_1 = null;

        EObject this_ComparisonCondition_2 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1064:2: ( (this_EvidenceRef_0= ruleEvidenceRef | this_TemporalCondition_1= ruleTemporalCondition | this_ComparisonCondition_2= ruleComparisonCondition ) )
            // InternalDynamicGoalModel.g:1065:2: (this_EvidenceRef_0= ruleEvidenceRef | this_TemporalCondition_1= ruleTemporalCondition | this_ComparisonCondition_2= ruleComparisonCondition )
            {
            // InternalDynamicGoalModel.g:1065:2: (this_EvidenceRef_0= ruleEvidenceRef | this_TemporalCondition_1= ruleTemporalCondition | this_ComparisonCondition_2= ruleComparisonCondition )
            int alt15=3;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==RULE_ID) ) {
                int LA15_1 = input.LA(2);

                if ( (LA15_1==EOF||(LA15_1>=31 && LA15_1<=32)||(LA15_1>=36 && LA15_1<=37)||LA15_1==43) ) {
                    alt15=1;
                }
                else if ( (LA15_1==42||(LA15_1>=64 && LA15_1<=66)) ) {
                    alt15=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 15, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA15_0>=60 && LA15_0<=63)) ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // InternalDynamicGoalModel.g:1066:3: this_EvidenceRef_0= ruleEvidenceRef
                    {

                    			newCompositeNode(grammarAccess.getAtomicConditionAccess().getEvidenceRefParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_EvidenceRef_0=ruleEvidenceRef();

                    state._fsp--;


                    			current = this_EvidenceRef_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:1075:3: this_TemporalCondition_1= ruleTemporalCondition
                    {

                    			newCompositeNode(grammarAccess.getAtomicConditionAccess().getTemporalConditionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TemporalCondition_1=ruleTemporalCondition();

                    state._fsp--;


                    			current = this_TemporalCondition_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:1084:3: this_ComparisonCondition_2= ruleComparisonCondition
                    {

                    			newCompositeNode(grammarAccess.getAtomicConditionAccess().getComparisonConditionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ComparisonCondition_2=ruleComparisonCondition();

                    state._fsp--;


                    			current = this_ComparisonCondition_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAtomicCondition"


    // $ANTLR start "entryRuleEvidenceRef"
    // InternalDynamicGoalModel.g:1096:1: entryRuleEvidenceRef returns [EObject current=null] : iv_ruleEvidenceRef= ruleEvidenceRef EOF ;
    public final EObject entryRuleEvidenceRef() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvidenceRef = null;


        try {
            // InternalDynamicGoalModel.g:1096:52: (iv_ruleEvidenceRef= ruleEvidenceRef EOF )
            // InternalDynamicGoalModel.g:1097:2: iv_ruleEvidenceRef= ruleEvidenceRef EOF
            {
             newCompositeNode(grammarAccess.getEvidenceRefRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvidenceRef=ruleEvidenceRef();

            state._fsp--;

             current =iv_ruleEvidenceRef; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvidenceRef"


    // $ANTLR start "ruleEvidenceRef"
    // InternalDynamicGoalModel.g:1103:1: ruleEvidenceRef returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) (otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')' )? ) ;
    public final EObject ruleEvidenceRef() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_params_2_0=null;
        Token otherlv_3=null;
        Token lv_params_4_0=null;
        Token otherlv_5=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1109:2: ( ( ( (otherlv_0= RULE_ID ) ) (otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')' )? ) )
            // InternalDynamicGoalModel.g:1110:2: ( ( (otherlv_0= RULE_ID ) ) (otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')' )? )
            {
            // InternalDynamicGoalModel.g:1110:2: ( ( (otherlv_0= RULE_ID ) ) (otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')' )? )
            // InternalDynamicGoalModel.g:1111:3: ( (otherlv_0= RULE_ID ) ) (otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')' )?
            {
            // InternalDynamicGoalModel.g:1111:3: ( (otherlv_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:1112:4: (otherlv_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:1112:4: (otherlv_0= RULE_ID )
            // InternalDynamicGoalModel.g:1113:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvidenceRefRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_37); 

            					newLeafNode(otherlv_0, grammarAccess.getEvidenceRefAccess().getEvidenceEvidenceCrossReference_0_0());
            				

            }


            }

            // InternalDynamicGoalModel.g:1124:3: (otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')' )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==31) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalDynamicGoalModel.g:1125:4: otherlv_1= '(' ( (lv_params_2_0= RULE_STRING ) ) (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )* otherlv_5= ')'
                    {
                    otherlv_1=(Token)match(input,31,FOLLOW_6); 

                    				newLeafNode(otherlv_1, grammarAccess.getEvidenceRefAccess().getLeftParenthesisKeyword_1_0());
                    			
                    // InternalDynamicGoalModel.g:1129:4: ( (lv_params_2_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:1130:5: (lv_params_2_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:1130:5: (lv_params_2_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:1131:6: lv_params_2_0= RULE_STRING
                    {
                    lv_params_2_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

                    						newLeafNode(lv_params_2_0, grammarAccess.getEvidenceRefAccess().getParamsSTRINGTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEvidenceRefRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"params",
                    							lv_params_2_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    // InternalDynamicGoalModel.g:1147:4: (otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) ) )*
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( (LA16_0==39) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // InternalDynamicGoalModel.g:1148:5: otherlv_3= ',' ( (lv_params_4_0= RULE_STRING ) )
                    	    {
                    	    otherlv_3=(Token)match(input,39,FOLLOW_6); 

                    	    					newLeafNode(otherlv_3, grammarAccess.getEvidenceRefAccess().getCommaKeyword_1_2_0());
                    	    				
                    	    // InternalDynamicGoalModel.g:1152:5: ( (lv_params_4_0= RULE_STRING ) )
                    	    // InternalDynamicGoalModel.g:1153:6: (lv_params_4_0= RULE_STRING )
                    	    {
                    	    // InternalDynamicGoalModel.g:1153:6: (lv_params_4_0= RULE_STRING )
                    	    // InternalDynamicGoalModel.g:1154:7: lv_params_4_0= RULE_STRING
                    	    {
                    	    lv_params_4_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

                    	    							newLeafNode(lv_params_4_0, grammarAccess.getEvidenceRefAccess().getParamsSTRINGTerminalRuleCall_1_2_1_0());
                    	    						

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getEvidenceRefRule());
                    	    							}
                    	    							addWithLastConsumed(
                    	    								current,
                    	    								"params",
                    	    								lv_params_4_0,
                    	    								"org.eclipse.xtext.common.Terminals.STRING");
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop16;
                        }
                    } while (true);

                    otherlv_5=(Token)match(input,32,FOLLOW_2); 

                    				newLeafNode(otherlv_5, grammarAccess.getEvidenceRefAccess().getRightParenthesisKeyword_1_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvidenceRef"


    // $ANTLR start "entryRuleTemporalCondition"
    // InternalDynamicGoalModel.g:1180:1: entryRuleTemporalCondition returns [EObject current=null] : iv_ruleTemporalCondition= ruleTemporalCondition EOF ;
    public final EObject entryRuleTemporalCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTemporalCondition = null;


        try {
            // InternalDynamicGoalModel.g:1180:58: (iv_ruleTemporalCondition= ruleTemporalCondition EOF )
            // InternalDynamicGoalModel.g:1181:2: iv_ruleTemporalCondition= ruleTemporalCondition EOF
            {
             newCompositeNode(grammarAccess.getTemporalConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTemporalCondition=ruleTemporalCondition();

            state._fsp--;

             current =iv_ruleTemporalCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTemporalCondition"


    // $ANTLR start "ruleTemporalCondition"
    // InternalDynamicGoalModel.g:1187:1: ruleTemporalCondition returns [EObject current=null] : ( ( (lv_temporalOp_0_0= ruleTemporalOperator ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (lv_duration_4_0= RULE_STRING ) ) otherlv_5= ')' ) ;
    public final EObject ruleTemporalCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_duration_4_0=null;
        Token otherlv_5=null;
        Enumerator lv_temporalOp_0_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1193:2: ( ( ( (lv_temporalOp_0_0= ruleTemporalOperator ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (lv_duration_4_0= RULE_STRING ) ) otherlv_5= ')' ) )
            // InternalDynamicGoalModel.g:1194:2: ( ( (lv_temporalOp_0_0= ruleTemporalOperator ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (lv_duration_4_0= RULE_STRING ) ) otherlv_5= ')' )
            {
            // InternalDynamicGoalModel.g:1194:2: ( ( (lv_temporalOp_0_0= ruleTemporalOperator ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (lv_duration_4_0= RULE_STRING ) ) otherlv_5= ')' )
            // InternalDynamicGoalModel.g:1195:3: ( (lv_temporalOp_0_0= ruleTemporalOperator ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (lv_duration_4_0= RULE_STRING ) ) otherlv_5= ')'
            {
            // InternalDynamicGoalModel.g:1195:3: ( (lv_temporalOp_0_0= ruleTemporalOperator ) )
            // InternalDynamicGoalModel.g:1196:4: (lv_temporalOp_0_0= ruleTemporalOperator )
            {
            // InternalDynamicGoalModel.g:1196:4: (lv_temporalOp_0_0= ruleTemporalOperator )
            // InternalDynamicGoalModel.g:1197:5: lv_temporalOp_0_0= ruleTemporalOperator
            {

            					newCompositeNode(grammarAccess.getTemporalConditionAccess().getTemporalOpTemporalOperatorEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_28);
            lv_temporalOp_0_0=ruleTemporalOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTemporalConditionRule());
            					}
            					set(
            						current,
            						"temporalOp",
            						lv_temporalOp_0_0,
            						"org.dgm.DynamicGoalModel.TemporalOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_1=(Token)match(input,31,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getTemporalConditionAccess().getLeftParenthesisKeyword_1());
            		
            // InternalDynamicGoalModel.g:1218:3: ( (otherlv_2= RULE_ID ) )
            // InternalDynamicGoalModel.g:1219:4: (otherlv_2= RULE_ID )
            {
            // InternalDynamicGoalModel.g:1219:4: (otherlv_2= RULE_ID )
            // InternalDynamicGoalModel.g:1220:5: otherlv_2= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTemporalConditionRule());
            					}
            				
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_39); 

            					newLeafNode(otherlv_2, grammarAccess.getTemporalConditionAccess().getEvidenceRefEvidenceCrossReference_2_0());
            				

            }


            }

            otherlv_3=(Token)match(input,39,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getTemporalConditionAccess().getCommaKeyword_3());
            		
            // InternalDynamicGoalModel.g:1235:3: ( (lv_duration_4_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:1236:4: (lv_duration_4_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:1236:4: (lv_duration_4_0= RULE_STRING )
            // InternalDynamicGoalModel.g:1237:5: lv_duration_4_0= RULE_STRING
            {
            lv_duration_4_0=(Token)match(input,RULE_STRING,FOLLOW_30); 

            					newLeafNode(lv_duration_4_0, grammarAccess.getTemporalConditionAccess().getDurationSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTemporalConditionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"duration",
            						lv_duration_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_5=(Token)match(input,32,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getTemporalConditionAccess().getRightParenthesisKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTemporalCondition"


    // $ANTLR start "entryRuleComparisonCondition"
    // InternalDynamicGoalModel.g:1261:1: entryRuleComparisonCondition returns [EObject current=null] : iv_ruleComparisonCondition= ruleComparisonCondition EOF ;
    public final EObject entryRuleComparisonCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComparisonCondition = null;


        try {
            // InternalDynamicGoalModel.g:1261:60: (iv_ruleComparisonCondition= ruleComparisonCondition EOF )
            // InternalDynamicGoalModel.g:1262:2: iv_ruleComparisonCondition= ruleComparisonCondition EOF
            {
             newCompositeNode(grammarAccess.getComparisonConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComparisonCondition=ruleComparisonCondition();

            state._fsp--;

             current =iv_ruleComparisonCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComparisonCondition"


    // $ANTLR start "ruleComparisonCondition"
    // InternalDynamicGoalModel.g:1268:1: ruleComparisonCondition returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_right_2_0= RULE_STRING ) ) ) ;
    public final EObject ruleComparisonCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_right_2_0=null;
        Enumerator lv_comparator_1_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1274:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_right_2_0= RULE_STRING ) ) ) )
            // InternalDynamicGoalModel.g:1275:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_right_2_0= RULE_STRING ) ) )
            {
            // InternalDynamicGoalModel.g:1275:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_right_2_0= RULE_STRING ) ) )
            // InternalDynamicGoalModel.g:1276:3: ( (otherlv_0= RULE_ID ) ) ( (lv_comparator_1_0= ruleComparator ) ) ( (lv_right_2_0= RULE_STRING ) )
            {
            // InternalDynamicGoalModel.g:1276:3: ( (otherlv_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:1277:4: (otherlv_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:1277:4: (otherlv_0= RULE_ID )
            // InternalDynamicGoalModel.g:1278:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getComparisonConditionRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_40); 

            					newLeafNode(otherlv_0, grammarAccess.getComparisonConditionAccess().getLeftEvidenceCrossReference_0_0());
            				

            }


            }

            // InternalDynamicGoalModel.g:1289:3: ( (lv_comparator_1_0= ruleComparator ) )
            // InternalDynamicGoalModel.g:1290:4: (lv_comparator_1_0= ruleComparator )
            {
            // InternalDynamicGoalModel.g:1290:4: (lv_comparator_1_0= ruleComparator )
            // InternalDynamicGoalModel.g:1291:5: lv_comparator_1_0= ruleComparator
            {

            					newCompositeNode(grammarAccess.getComparisonConditionAccess().getComparatorComparatorEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_6);
            lv_comparator_1_0=ruleComparator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getComparisonConditionRule());
            					}
            					set(
            						current,
            						"comparator",
            						lv_comparator_1_0,
            						"org.dgm.DynamicGoalModel.Comparator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDynamicGoalModel.g:1308:3: ( (lv_right_2_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:1309:4: (lv_right_2_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:1309:4: (lv_right_2_0= RULE_STRING )
            // InternalDynamicGoalModel.g:1310:5: lv_right_2_0= RULE_STRING
            {
            lv_right_2_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_right_2_0, grammarAccess.getComparisonConditionAccess().getRightSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getComparisonConditionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"right",
            						lv_right_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparisonCondition"


    // $ANTLR start "entryRulePrecedence"
    // InternalDynamicGoalModel.g:1330:1: entryRulePrecedence returns [EObject current=null] : iv_rulePrecedence= rulePrecedence EOF ;
    public final EObject entryRulePrecedence() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrecedence = null;


        try {
            // InternalDynamicGoalModel.g:1330:51: (iv_rulePrecedence= rulePrecedence EOF )
            // InternalDynamicGoalModel.g:1331:2: iv_rulePrecedence= rulePrecedence EOF
            {
             newCompositeNode(grammarAccess.getPrecedenceRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrecedence=rulePrecedence();

            state._fsp--;

             current =iv_rulePrecedence; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrecedence"


    // $ANTLR start "rulePrecedence"
    // InternalDynamicGoalModel.g:1337:1: rulePrecedence returns [EObject current=null] : (otherlv_0= 'Precedence' otherlv_1= '{' (otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) ) )? ( (lv_ordering_4_0= rulePrecedenceEntry ) ) (otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) ) )+ otherlv_7= '}' ) ;
    public final EObject rulePrecedence() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_justification_3_0=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_ordering_4_0 = null;

        EObject lv_ordering_6_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1343:2: ( (otherlv_0= 'Precedence' otherlv_1= '{' (otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) ) )? ( (lv_ordering_4_0= rulePrecedenceEntry ) ) (otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) ) )+ otherlv_7= '}' ) )
            // InternalDynamicGoalModel.g:1344:2: (otherlv_0= 'Precedence' otherlv_1= '{' (otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) ) )? ( (lv_ordering_4_0= rulePrecedenceEntry ) ) (otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) ) )+ otherlv_7= '}' )
            {
            // InternalDynamicGoalModel.g:1344:2: (otherlv_0= 'Precedence' otherlv_1= '{' (otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) ) )? ( (lv_ordering_4_0= rulePrecedenceEntry ) ) (otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) ) )+ otherlv_7= '}' )
            // InternalDynamicGoalModel.g:1345:3: otherlv_0= 'Precedence' otherlv_1= '{' (otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) ) )? ( (lv_ordering_4_0= rulePrecedenceEntry ) ) (otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) ) )+ otherlv_7= '}'
            {
            otherlv_0=(Token)match(input,40,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getPrecedenceAccess().getPrecedenceKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_41); 

            			newLeafNode(otherlv_1, grammarAccess.getPrecedenceAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalDynamicGoalModel.g:1353:3: (otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==41) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalDynamicGoalModel.g:1354:4: otherlv_2= 'justification' ( (lv_justification_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getPrecedenceAccess().getJustificationKeyword_2_0());
                    			
                    // InternalDynamicGoalModel.g:1358:4: ( (lv_justification_3_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:1359:5: (lv_justification_3_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:1359:5: (lv_justification_3_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:1360:6: lv_justification_3_0= RULE_STRING
                    {
                    lv_justification_3_0=(Token)match(input,RULE_STRING,FOLLOW_41); 

                    						newLeafNode(lv_justification_3_0, grammarAccess.getPrecedenceAccess().getJustificationSTRINGTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrecedenceRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"justification",
                    							lv_justification_3_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:1377:3: ( (lv_ordering_4_0= rulePrecedenceEntry ) )
            // InternalDynamicGoalModel.g:1378:4: (lv_ordering_4_0= rulePrecedenceEntry )
            {
            // InternalDynamicGoalModel.g:1378:4: (lv_ordering_4_0= rulePrecedenceEntry )
            // InternalDynamicGoalModel.g:1379:5: lv_ordering_4_0= rulePrecedenceEntry
            {

            					newCompositeNode(grammarAccess.getPrecedenceAccess().getOrderingPrecedenceEntryParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_42);
            lv_ordering_4_0=rulePrecedenceEntry();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPrecedenceRule());
            					}
            					add(
            						current,
            						"ordering",
            						lv_ordering_4_0,
            						"org.dgm.DynamicGoalModel.PrecedenceEntry");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDynamicGoalModel.g:1396:3: (otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) ) )+
            int cnt19=0;
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==42) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalDynamicGoalModel.g:1397:4: otherlv_5= '>' ( (lv_ordering_6_0= rulePrecedenceEntry ) )
            	    {
            	    otherlv_5=(Token)match(input,42,FOLLOW_41); 

            	    				newLeafNode(otherlv_5, grammarAccess.getPrecedenceAccess().getGreaterThanSignKeyword_4_0());
            	    			
            	    // InternalDynamicGoalModel.g:1401:4: ( (lv_ordering_6_0= rulePrecedenceEntry ) )
            	    // InternalDynamicGoalModel.g:1402:5: (lv_ordering_6_0= rulePrecedenceEntry )
            	    {
            	    // InternalDynamicGoalModel.g:1402:5: (lv_ordering_6_0= rulePrecedenceEntry )
            	    // InternalDynamicGoalModel.g:1403:6: lv_ordering_6_0= rulePrecedenceEntry
            	    {

            	    						newCompositeNode(grammarAccess.getPrecedenceAccess().getOrderingPrecedenceEntryParserRuleCall_4_1_0());
            	    					
            	    pushFollow(FOLLOW_43);
            	    lv_ordering_6_0=rulePrecedenceEntry();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getPrecedenceRule());
            	    						}
            	    						add(
            	    							current,
            	    							"ordering",
            	    							lv_ordering_6_0,
            	    							"org.dgm.DynamicGoalModel.PrecedenceEntry");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt19 >= 1 ) break loop19;
                        EarlyExitException eee =
                            new EarlyExitException(19, input);
                        throw eee;
                }
                cnt19++;
            } while (true);

            otherlv_7=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getPrecedenceAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrecedence"


    // $ANTLR start "entryRulePrecedenceEntry"
    // InternalDynamicGoalModel.g:1429:1: entryRulePrecedenceEntry returns [EObject current=null] : iv_rulePrecedenceEntry= rulePrecedenceEntry EOF ;
    public final EObject entryRulePrecedenceEntry() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrecedenceEntry = null;


        try {
            // InternalDynamicGoalModel.g:1429:56: (iv_rulePrecedenceEntry= rulePrecedenceEntry EOF )
            // InternalDynamicGoalModel.g:1430:2: iv_rulePrecedenceEntry= rulePrecedenceEntry EOF
            {
             newCompositeNode(grammarAccess.getPrecedenceEntryRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrecedenceEntry=rulePrecedenceEntry();

            state._fsp--;

             current =iv_rulePrecedenceEntry; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrecedenceEntry"


    // $ANTLR start "rulePrecedenceEntry"
    // InternalDynamicGoalModel.g:1436:1: rulePrecedenceEntry returns [EObject current=null] : ( (otherlv_0= RULE_ID ) ) ;
    public final EObject rulePrecedenceEntry() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1442:2: ( ( (otherlv_0= RULE_ID ) ) )
            // InternalDynamicGoalModel.g:1443:2: ( (otherlv_0= RULE_ID ) )
            {
            // InternalDynamicGoalModel.g:1443:2: ( (otherlv_0= RULE_ID ) )
            // InternalDynamicGoalModel.g:1444:3: (otherlv_0= RULE_ID )
            {
            // InternalDynamicGoalModel.g:1444:3: (otherlv_0= RULE_ID )
            // InternalDynamicGoalModel.g:1445:4: otherlv_0= RULE_ID
            {

            				if (current==null) {
            					current = createModelElement(grammarAccess.getPrecedenceEntryRule());
            				}
            			
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            				newLeafNode(otherlv_0, grammarAccess.getPrecedenceEntryAccess().getHypothesisGoalHypothesisCrossReference_0());
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrecedenceEntry"


    // $ANTLR start "entryRuleResponseBinding"
    // InternalDynamicGoalModel.g:1459:1: entryRuleResponseBinding returns [EObject current=null] : iv_ruleResponseBinding= ruleResponseBinding EOF ;
    public final EObject entryRuleResponseBinding() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleResponseBinding = null;


        try {
            // InternalDynamicGoalModel.g:1459:56: (iv_ruleResponseBinding= ruleResponseBinding EOF )
            // InternalDynamicGoalModel.g:1460:2: iv_ruleResponseBinding= ruleResponseBinding EOF
            {
             newCompositeNode(grammarAccess.getResponseBindingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleResponseBinding=ruleResponseBinding();

            state._fsp--;

             current =iv_ruleResponseBinding; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleResponseBinding"


    // $ANTLR start "ruleResponseBinding"
    // InternalDynamicGoalModel.g:1466:1: ruleResponseBinding returns [EObject current=null] : (otherlv_0= 'ResponseBinding' otherlv_1= '{' otherlv_2= 'action' ( (lv_action_3_0= RULE_STRING ) ) (otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) ) )? (otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) ) )? otherlv_8= '}' ) ;
    public final EObject ruleResponseBinding() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_action_3_0=null;
        Token otherlv_4=null;
        Token lv_ucmStep_5_0=null;
        Token otherlv_6=null;
        Token lv_noCartWrite_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1472:2: ( (otherlv_0= 'ResponseBinding' otherlv_1= '{' otherlv_2= 'action' ( (lv_action_3_0= RULE_STRING ) ) (otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) ) )? (otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) ) )? otherlv_8= '}' ) )
            // InternalDynamicGoalModel.g:1473:2: (otherlv_0= 'ResponseBinding' otherlv_1= '{' otherlv_2= 'action' ( (lv_action_3_0= RULE_STRING ) ) (otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) ) )? (otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) ) )? otherlv_8= '}' )
            {
            // InternalDynamicGoalModel.g:1473:2: (otherlv_0= 'ResponseBinding' otherlv_1= '{' otherlv_2= 'action' ( (lv_action_3_0= RULE_STRING ) ) (otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) ) )? (otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) ) )? otherlv_8= '}' )
            // InternalDynamicGoalModel.g:1474:3: otherlv_0= 'ResponseBinding' otherlv_1= '{' otherlv_2= 'action' ( (lv_action_3_0= RULE_STRING ) ) (otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) ) )? (otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) ) )? otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,43,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getResponseBindingAccess().getResponseBindingKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_44); 

            			newLeafNode(otherlv_1, grammarAccess.getResponseBindingAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,44,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getResponseBindingAccess().getActionKeyword_2());
            		
            // InternalDynamicGoalModel.g:1486:3: ( (lv_action_3_0= RULE_STRING ) )
            // InternalDynamicGoalModel.g:1487:4: (lv_action_3_0= RULE_STRING )
            {
            // InternalDynamicGoalModel.g:1487:4: (lv_action_3_0= RULE_STRING )
            // InternalDynamicGoalModel.g:1488:5: lv_action_3_0= RULE_STRING
            {
            lv_action_3_0=(Token)match(input,RULE_STRING,FOLLOW_45); 

            					newLeafNode(lv_action_3_0, grammarAccess.getResponseBindingAccess().getActionSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getResponseBindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"action",
            						lv_action_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalDynamicGoalModel.g:1504:3: (otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==45) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalDynamicGoalModel.g:1505:4: otherlv_4= 'ucmStep' ( (lv_ucmStep_5_0= RULE_STRING ) )
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_6); 

                    				newLeafNode(otherlv_4, grammarAccess.getResponseBindingAccess().getUcmStepKeyword_4_0());
                    			
                    // InternalDynamicGoalModel.g:1509:4: ( (lv_ucmStep_5_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:1510:5: (lv_ucmStep_5_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:1510:5: (lv_ucmStep_5_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:1511:6: lv_ucmStep_5_0= RULE_STRING
                    {
                    lv_ucmStep_5_0=(Token)match(input,RULE_STRING,FOLLOW_46); 

                    						newLeafNode(lv_ucmStep_5_0, grammarAccess.getResponseBindingAccess().getUcmStepSTRINGTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getResponseBindingRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"ucmStep",
                    							lv_ucmStep_5_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:1528:3: (otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) ) )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==46) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalDynamicGoalModel.g:1529:4: otherlv_6= 'noCartWrite' ( (lv_noCartWrite_7_0= 'noSideEffect' ) )
                    {
                    otherlv_6=(Token)match(input,46,FOLLOW_47); 

                    				newLeafNode(otherlv_6, grammarAccess.getResponseBindingAccess().getNoCartWriteKeyword_5_0());
                    			
                    // InternalDynamicGoalModel.g:1533:4: ( (lv_noCartWrite_7_0= 'noSideEffect' ) )
                    // InternalDynamicGoalModel.g:1534:5: (lv_noCartWrite_7_0= 'noSideEffect' )
                    {
                    // InternalDynamicGoalModel.g:1534:5: (lv_noCartWrite_7_0= 'noSideEffect' )
                    // InternalDynamicGoalModel.g:1535:6: lv_noCartWrite_7_0= 'noSideEffect'
                    {
                    lv_noCartWrite_7_0=(Token)match(input,47,FOLLOW_17); 

                    						newLeafNode(lv_noCartWrite_7_0, grammarAccess.getResponseBindingAccess().getNoCartWriteNoSideEffectKeyword_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getResponseBindingRule());
                    						}
                    						setWithLastConsumed(current, "noCartWrite", lv_noCartWrite_7_0 != null, "noSideEffect");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getResponseBindingAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleResponseBinding"


    // $ANTLR start "entryRuleEscalationStrategy"
    // InternalDynamicGoalModel.g:1556:1: entryRuleEscalationStrategy returns [EObject current=null] : iv_ruleEscalationStrategy= ruleEscalationStrategy EOF ;
    public final EObject entryRuleEscalationStrategy() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEscalationStrategy = null;


        try {
            // InternalDynamicGoalModel.g:1556:59: (iv_ruleEscalationStrategy= ruleEscalationStrategy EOF )
            // InternalDynamicGoalModel.g:1557:2: iv_ruleEscalationStrategy= ruleEscalationStrategy EOF
            {
             newCompositeNode(grammarAccess.getEscalationStrategyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEscalationStrategy=ruleEscalationStrategy();

            state._fsp--;

             current =iv_ruleEscalationStrategy; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEscalationStrategy"


    // $ANTLR start "ruleEscalationStrategy"
    // InternalDynamicGoalModel.g:1563:1: ruleEscalationStrategy returns [EObject current=null] : (otherlv_0= 'Escalation' otherlv_1= '{' otherlv_2= 'strategy' ( (lv_strategy_3_0= ruleEscalationStrategyType ) ) (otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )? (otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) ) )? (otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) ) )? otherlv_12= '}' ) ;
    public final EObject ruleEscalationStrategy() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token lv_defaultResponse_9_0=null;
        Token otherlv_10=null;
        Token lv_timeout_11_0=null;
        Token otherlv_12=null;
        Enumerator lv_strategy_3_0 = null;



        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1569:2: ( (otherlv_0= 'Escalation' otherlv_1= '{' otherlv_2= 'strategy' ( (lv_strategy_3_0= ruleEscalationStrategyType ) ) (otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )? (otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) ) )? (otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) ) )? otherlv_12= '}' ) )
            // InternalDynamicGoalModel.g:1570:2: (otherlv_0= 'Escalation' otherlv_1= '{' otherlv_2= 'strategy' ( (lv_strategy_3_0= ruleEscalationStrategyType ) ) (otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )? (otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) ) )? (otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) ) )? otherlv_12= '}' )
            {
            // InternalDynamicGoalModel.g:1570:2: (otherlv_0= 'Escalation' otherlv_1= '{' otherlv_2= 'strategy' ( (lv_strategy_3_0= ruleEscalationStrategyType ) ) (otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )? (otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) ) )? (otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) ) )? otherlv_12= '}' )
            // InternalDynamicGoalModel.g:1571:3: otherlv_0= 'Escalation' otherlv_1= '{' otherlv_2= 'strategy' ( (lv_strategy_3_0= ruleEscalationStrategyType ) ) (otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )? (otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) ) )? (otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) ) )? otherlv_12= '}'
            {
            otherlv_0=(Token)match(input,48,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getEscalationStrategyAccess().getEscalationKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_48); 

            			newLeafNode(otherlv_1, grammarAccess.getEscalationStrategyAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,49,FOLLOW_49); 

            			newLeafNode(otherlv_2, grammarAccess.getEscalationStrategyAccess().getStrategyKeyword_2());
            		
            // InternalDynamicGoalModel.g:1583:3: ( (lv_strategy_3_0= ruleEscalationStrategyType ) )
            // InternalDynamicGoalModel.g:1584:4: (lv_strategy_3_0= ruleEscalationStrategyType )
            {
            // InternalDynamicGoalModel.g:1584:4: (lv_strategy_3_0= ruleEscalationStrategyType )
            // InternalDynamicGoalModel.g:1585:5: lv_strategy_3_0= ruleEscalationStrategyType
            {

            					newCompositeNode(grammarAccess.getEscalationStrategyAccess().getStrategyEscalationStrategyTypeEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_50);
            lv_strategy_3_0=ruleEscalationStrategyType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEscalationStrategyRule());
            					}
            					set(
            						current,
            						"strategy",
            						lv_strategy_3_0,
            						"org.dgm.DynamicGoalModel.EscalationStrategyType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDynamicGoalModel.g:1602:3: (otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==50) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalDynamicGoalModel.g:1603:4: otherlv_4= 'additionalEvidence' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
                    {
                    otherlv_4=(Token)match(input,50,FOLLOW_3); 

                    				newLeafNode(otherlv_4, grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceKeyword_4_0());
                    			
                    // InternalDynamicGoalModel.g:1607:4: ( (otherlv_5= RULE_ID ) )
                    // InternalDynamicGoalModel.g:1608:5: (otherlv_5= RULE_ID )
                    {
                    // InternalDynamicGoalModel.g:1608:5: (otherlv_5= RULE_ID )
                    // InternalDynamicGoalModel.g:1609:6: otherlv_5= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEscalationStrategyRule());
                    						}
                    					
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_51); 

                    						newLeafNode(otherlv_5, grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceCrossReference_4_1_0());
                    					

                    }


                    }

                    // InternalDynamicGoalModel.g:1620:4: (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
                    loop22:
                    do {
                        int alt22=2;
                        int LA22_0 = input.LA(1);

                        if ( (LA22_0==39) ) {
                            alt22=1;
                        }


                        switch (alt22) {
                    	case 1 :
                    	    // InternalDynamicGoalModel.g:1621:5: otherlv_6= ',' ( (otherlv_7= RULE_ID ) )
                    	    {
                    	    otherlv_6=(Token)match(input,39,FOLLOW_3); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getEscalationStrategyAccess().getCommaKeyword_4_2_0());
                    	    				
                    	    // InternalDynamicGoalModel.g:1625:5: ( (otherlv_7= RULE_ID ) )
                    	    // InternalDynamicGoalModel.g:1626:6: (otherlv_7= RULE_ID )
                    	    {
                    	    // InternalDynamicGoalModel.g:1626:6: (otherlv_7= RULE_ID )
                    	    // InternalDynamicGoalModel.g:1627:7: otherlv_7= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getEscalationStrategyRule());
                    	    							}
                    	    						
                    	    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_51); 

                    	    							newLeafNode(otherlv_7, grammarAccess.getEscalationStrategyAccess().getAdditionalEvidenceEvidenceCrossReference_4_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop22;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:1640:3: (otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==51) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalDynamicGoalModel.g:1641:4: otherlv_8= 'defaultResponse' ( (lv_defaultResponse_9_0= RULE_STRING ) )
                    {
                    otherlv_8=(Token)match(input,51,FOLLOW_6); 

                    				newLeafNode(otherlv_8, grammarAccess.getEscalationStrategyAccess().getDefaultResponseKeyword_5_0());
                    			
                    // InternalDynamicGoalModel.g:1645:4: ( (lv_defaultResponse_9_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:1646:5: (lv_defaultResponse_9_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:1646:5: (lv_defaultResponse_9_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:1647:6: lv_defaultResponse_9_0= RULE_STRING
                    {
                    lv_defaultResponse_9_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

                    						newLeafNode(lv_defaultResponse_9_0, grammarAccess.getEscalationStrategyAccess().getDefaultResponseSTRINGTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEscalationStrategyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"defaultResponse",
                    							lv_defaultResponse_9_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDynamicGoalModel.g:1664:3: (otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==52) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalDynamicGoalModel.g:1665:4: otherlv_10= 'timeout' ( (lv_timeout_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,52,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getEscalationStrategyAccess().getTimeoutKeyword_6_0());
                    			
                    // InternalDynamicGoalModel.g:1669:4: ( (lv_timeout_11_0= RULE_STRING ) )
                    // InternalDynamicGoalModel.g:1670:5: (lv_timeout_11_0= RULE_STRING )
                    {
                    // InternalDynamicGoalModel.g:1670:5: (lv_timeout_11_0= RULE_STRING )
                    // InternalDynamicGoalModel.g:1671:6: lv_timeout_11_0= RULE_STRING
                    {
                    lv_timeout_11_0=(Token)match(input,RULE_STRING,FOLLOW_17); 

                    						newLeafNode(lv_timeout_11_0, grammarAccess.getEscalationStrategyAccess().getTimeoutSTRINGTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEscalationStrategyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"timeout",
                    							lv_timeout_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_12=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getEscalationStrategyAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEscalationStrategy"


    // $ANTLR start "ruleEvidenceType"
    // InternalDynamicGoalModel.g:1696:1: ruleEvidenceType returns [Enumerator current=null] : ( (enumLiteral_0= 'SENSOR' ) | (enumLiteral_1= 'TEMPORAL' ) | (enumLiteral_2= 'IDENTITY' ) | (enumLiteral_3= 'SPATIAL' ) | (enumLiteral_4= 'DERIVED' ) | (enumLiteral_5= 'ROLE' ) | (enumLiteral_6= 'CATALOG' ) ) ;
    public final Enumerator ruleEvidenceType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1702:2: ( ( (enumLiteral_0= 'SENSOR' ) | (enumLiteral_1= 'TEMPORAL' ) | (enumLiteral_2= 'IDENTITY' ) | (enumLiteral_3= 'SPATIAL' ) | (enumLiteral_4= 'DERIVED' ) | (enumLiteral_5= 'ROLE' ) | (enumLiteral_6= 'CATALOG' ) ) )
            // InternalDynamicGoalModel.g:1703:2: ( (enumLiteral_0= 'SENSOR' ) | (enumLiteral_1= 'TEMPORAL' ) | (enumLiteral_2= 'IDENTITY' ) | (enumLiteral_3= 'SPATIAL' ) | (enumLiteral_4= 'DERIVED' ) | (enumLiteral_5= 'ROLE' ) | (enumLiteral_6= 'CATALOG' ) )
            {
            // InternalDynamicGoalModel.g:1703:2: ( (enumLiteral_0= 'SENSOR' ) | (enumLiteral_1= 'TEMPORAL' ) | (enumLiteral_2= 'IDENTITY' ) | (enumLiteral_3= 'SPATIAL' ) | (enumLiteral_4= 'DERIVED' ) | (enumLiteral_5= 'ROLE' ) | (enumLiteral_6= 'CATALOG' ) )
            int alt26=7;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt26=1;
                }
                break;
            case 54:
                {
                alt26=2;
                }
                break;
            case 55:
                {
                alt26=3;
                }
                break;
            case 56:
                {
                alt26=4;
                }
                break;
            case 57:
                {
                alt26=5;
                }
                break;
            case 58:
                {
                alt26=6;
                }
                break;
            case 59:
                {
                alt26=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }

            switch (alt26) {
                case 1 :
                    // InternalDynamicGoalModel.g:1704:3: (enumLiteral_0= 'SENSOR' )
                    {
                    // InternalDynamicGoalModel.g:1704:3: (enumLiteral_0= 'SENSOR' )
                    // InternalDynamicGoalModel.g:1705:4: enumLiteral_0= 'SENSOR'
                    {
                    enumLiteral_0=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getSENSOREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getEvidenceTypeAccess().getSENSOREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:1712:3: (enumLiteral_1= 'TEMPORAL' )
                    {
                    // InternalDynamicGoalModel.g:1712:3: (enumLiteral_1= 'TEMPORAL' )
                    // InternalDynamicGoalModel.g:1713:4: enumLiteral_1= 'TEMPORAL'
                    {
                    enumLiteral_1=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getTEMPORALEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getEvidenceTypeAccess().getTEMPORALEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:1720:3: (enumLiteral_2= 'IDENTITY' )
                    {
                    // InternalDynamicGoalModel.g:1720:3: (enumLiteral_2= 'IDENTITY' )
                    // InternalDynamicGoalModel.g:1721:4: enumLiteral_2= 'IDENTITY'
                    {
                    enumLiteral_2=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getIDENTITYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getEvidenceTypeAccess().getIDENTITYEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:1728:3: (enumLiteral_3= 'SPATIAL' )
                    {
                    // InternalDynamicGoalModel.g:1728:3: (enumLiteral_3= 'SPATIAL' )
                    // InternalDynamicGoalModel.g:1729:4: enumLiteral_3= 'SPATIAL'
                    {
                    enumLiteral_3=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getSPATIALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getEvidenceTypeAccess().getSPATIALEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalDynamicGoalModel.g:1736:3: (enumLiteral_4= 'DERIVED' )
                    {
                    // InternalDynamicGoalModel.g:1736:3: (enumLiteral_4= 'DERIVED' )
                    // InternalDynamicGoalModel.g:1737:4: enumLiteral_4= 'DERIVED'
                    {
                    enumLiteral_4=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getDERIVEDEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getEvidenceTypeAccess().getDERIVEDEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalDynamicGoalModel.g:1744:3: (enumLiteral_5= 'ROLE' )
                    {
                    // InternalDynamicGoalModel.g:1744:3: (enumLiteral_5= 'ROLE' )
                    // InternalDynamicGoalModel.g:1745:4: enumLiteral_5= 'ROLE'
                    {
                    enumLiteral_5=(Token)match(input,58,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getROLEEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getEvidenceTypeAccess().getROLEEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalDynamicGoalModel.g:1752:3: (enumLiteral_6= 'CATALOG' )
                    {
                    // InternalDynamicGoalModel.g:1752:3: (enumLiteral_6= 'CATALOG' )
                    // InternalDynamicGoalModel.g:1753:4: enumLiteral_6= 'CATALOG'
                    {
                    enumLiteral_6=(Token)match(input,59,FOLLOW_2); 

                    				current = grammarAccess.getEvidenceTypeAccess().getCATALOGEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getEvidenceTypeAccess().getCATALOGEnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvidenceType"


    // $ANTLR start "ruleTemporalOperator"
    // InternalDynamicGoalModel.g:1763:1: ruleTemporalOperator returns [Enumerator current=null] : ( (enumLiteral_0= 'WITHIN' ) | (enumLiteral_1= 'NOT_WITHIN' ) | (enumLiteral_2= 'HELD_FOR' ) | (enumLiteral_3= 'REPEATED_WITHIN' ) ) ;
    public final Enumerator ruleTemporalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1769:2: ( ( (enumLiteral_0= 'WITHIN' ) | (enumLiteral_1= 'NOT_WITHIN' ) | (enumLiteral_2= 'HELD_FOR' ) | (enumLiteral_3= 'REPEATED_WITHIN' ) ) )
            // InternalDynamicGoalModel.g:1770:2: ( (enumLiteral_0= 'WITHIN' ) | (enumLiteral_1= 'NOT_WITHIN' ) | (enumLiteral_2= 'HELD_FOR' ) | (enumLiteral_3= 'REPEATED_WITHIN' ) )
            {
            // InternalDynamicGoalModel.g:1770:2: ( (enumLiteral_0= 'WITHIN' ) | (enumLiteral_1= 'NOT_WITHIN' ) | (enumLiteral_2= 'HELD_FOR' ) | (enumLiteral_3= 'REPEATED_WITHIN' ) )
            int alt27=4;
            switch ( input.LA(1) ) {
            case 60:
                {
                alt27=1;
                }
                break;
            case 61:
                {
                alt27=2;
                }
                break;
            case 62:
                {
                alt27=3;
                }
                break;
            case 63:
                {
                alt27=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 27, 0, input);

                throw nvae;
            }

            switch (alt27) {
                case 1 :
                    // InternalDynamicGoalModel.g:1771:3: (enumLiteral_0= 'WITHIN' )
                    {
                    // InternalDynamicGoalModel.g:1771:3: (enumLiteral_0= 'WITHIN' )
                    // InternalDynamicGoalModel.g:1772:4: enumLiteral_0= 'WITHIN'
                    {
                    enumLiteral_0=(Token)match(input,60,FOLLOW_2); 

                    				current = grammarAccess.getTemporalOperatorAccess().getWITHINEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTemporalOperatorAccess().getWITHINEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:1779:3: (enumLiteral_1= 'NOT_WITHIN' )
                    {
                    // InternalDynamicGoalModel.g:1779:3: (enumLiteral_1= 'NOT_WITHIN' )
                    // InternalDynamicGoalModel.g:1780:4: enumLiteral_1= 'NOT_WITHIN'
                    {
                    enumLiteral_1=(Token)match(input,61,FOLLOW_2); 

                    				current = grammarAccess.getTemporalOperatorAccess().getNOT_WITHINEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTemporalOperatorAccess().getNOT_WITHINEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:1787:3: (enumLiteral_2= 'HELD_FOR' )
                    {
                    // InternalDynamicGoalModel.g:1787:3: (enumLiteral_2= 'HELD_FOR' )
                    // InternalDynamicGoalModel.g:1788:4: enumLiteral_2= 'HELD_FOR'
                    {
                    enumLiteral_2=(Token)match(input,62,FOLLOW_2); 

                    				current = grammarAccess.getTemporalOperatorAccess().getHELD_FOREnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTemporalOperatorAccess().getHELD_FOREnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:1795:3: (enumLiteral_3= 'REPEATED_WITHIN' )
                    {
                    // InternalDynamicGoalModel.g:1795:3: (enumLiteral_3= 'REPEATED_WITHIN' )
                    // InternalDynamicGoalModel.g:1796:4: enumLiteral_3= 'REPEATED_WITHIN'
                    {
                    enumLiteral_3=(Token)match(input,63,FOLLOW_2); 

                    				current = grammarAccess.getTemporalOperatorAccess().getREPEATED_WITHINEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getTemporalOperatorAccess().getREPEATED_WITHINEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTemporalOperator"


    // $ANTLR start "ruleComparator"
    // InternalDynamicGoalModel.g:1806:1: ruleComparator returns [Enumerator current=null] : ( (enumLiteral_0= '=' ) | (enumLiteral_1= '!=' ) | (enumLiteral_2= '>' ) | (enumLiteral_3= '<' ) ) ;
    public final Enumerator ruleComparator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1812:2: ( ( (enumLiteral_0= '=' ) | (enumLiteral_1= '!=' ) | (enumLiteral_2= '>' ) | (enumLiteral_3= '<' ) ) )
            // InternalDynamicGoalModel.g:1813:2: ( (enumLiteral_0= '=' ) | (enumLiteral_1= '!=' ) | (enumLiteral_2= '>' ) | (enumLiteral_3= '<' ) )
            {
            // InternalDynamicGoalModel.g:1813:2: ( (enumLiteral_0= '=' ) | (enumLiteral_1= '!=' ) | (enumLiteral_2= '>' ) | (enumLiteral_3= '<' ) )
            int alt28=4;
            switch ( input.LA(1) ) {
            case 64:
                {
                alt28=1;
                }
                break;
            case 65:
                {
                alt28=2;
                }
                break;
            case 42:
                {
                alt28=3;
                }
                break;
            case 66:
                {
                alt28=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // InternalDynamicGoalModel.g:1814:3: (enumLiteral_0= '=' )
                    {
                    // InternalDynamicGoalModel.g:1814:3: (enumLiteral_0= '=' )
                    // InternalDynamicGoalModel.g:1815:4: enumLiteral_0= '='
                    {
                    enumLiteral_0=(Token)match(input,64,FOLLOW_2); 

                    				current = grammarAccess.getComparatorAccess().getEQUALSEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparatorAccess().getEQUALSEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:1822:3: (enumLiteral_1= '!=' )
                    {
                    // InternalDynamicGoalModel.g:1822:3: (enumLiteral_1= '!=' )
                    // InternalDynamicGoalModel.g:1823:4: enumLiteral_1= '!='
                    {
                    enumLiteral_1=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getComparatorAccess().getNOT_EQUALSEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparatorAccess().getNOT_EQUALSEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:1830:3: (enumLiteral_2= '>' )
                    {
                    // InternalDynamicGoalModel.g:1830:3: (enumLiteral_2= '>' )
                    // InternalDynamicGoalModel.g:1831:4: enumLiteral_2= '>'
                    {
                    enumLiteral_2=(Token)match(input,42,FOLLOW_2); 

                    				current = grammarAccess.getComparatorAccess().getGREATEREnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparatorAccess().getGREATEREnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:1838:3: (enumLiteral_3= '<' )
                    {
                    // InternalDynamicGoalModel.g:1838:3: (enumLiteral_3= '<' )
                    // InternalDynamicGoalModel.g:1839:4: enumLiteral_3= '<'
                    {
                    enumLiteral_3=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getComparatorAccess().getLESSEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparatorAccess().getLESSEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparator"


    // $ANTLR start "ruleEscalationStrategyType"
    // InternalDynamicGoalModel.g:1849:1: ruleEscalationStrategyType returns [Enumerator current=null] : ( (enumLiteral_0= 'REQUEST_MORE_EVIDENCE' ) | (enumLiteral_1= 'DEFAULT_NO_COMMIT' ) | (enumLiteral_2= 'NOTIFY_OPERATOR' ) ) ;
    public final Enumerator ruleEscalationStrategyType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1855:2: ( ( (enumLiteral_0= 'REQUEST_MORE_EVIDENCE' ) | (enumLiteral_1= 'DEFAULT_NO_COMMIT' ) | (enumLiteral_2= 'NOTIFY_OPERATOR' ) ) )
            // InternalDynamicGoalModel.g:1856:2: ( (enumLiteral_0= 'REQUEST_MORE_EVIDENCE' ) | (enumLiteral_1= 'DEFAULT_NO_COMMIT' ) | (enumLiteral_2= 'NOTIFY_OPERATOR' ) )
            {
            // InternalDynamicGoalModel.g:1856:2: ( (enumLiteral_0= 'REQUEST_MORE_EVIDENCE' ) | (enumLiteral_1= 'DEFAULT_NO_COMMIT' ) | (enumLiteral_2= 'NOTIFY_OPERATOR' ) )
            int alt29=3;
            switch ( input.LA(1) ) {
            case 67:
                {
                alt29=1;
                }
                break;
            case 68:
                {
                alt29=2;
                }
                break;
            case 69:
                {
                alt29=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }

            switch (alt29) {
                case 1 :
                    // InternalDynamicGoalModel.g:1857:3: (enumLiteral_0= 'REQUEST_MORE_EVIDENCE' )
                    {
                    // InternalDynamicGoalModel.g:1857:3: (enumLiteral_0= 'REQUEST_MORE_EVIDENCE' )
                    // InternalDynamicGoalModel.g:1858:4: enumLiteral_0= 'REQUEST_MORE_EVIDENCE'
                    {
                    enumLiteral_0=(Token)match(input,67,FOLLOW_2); 

                    				current = grammarAccess.getEscalationStrategyTypeAccess().getREQUEST_MORE_EVIDENCEEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getEscalationStrategyTypeAccess().getREQUEST_MORE_EVIDENCEEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:1865:3: (enumLiteral_1= 'DEFAULT_NO_COMMIT' )
                    {
                    // InternalDynamicGoalModel.g:1865:3: (enumLiteral_1= 'DEFAULT_NO_COMMIT' )
                    // InternalDynamicGoalModel.g:1866:4: enumLiteral_1= 'DEFAULT_NO_COMMIT'
                    {
                    enumLiteral_1=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getEscalationStrategyTypeAccess().getDEFAULT_NO_COMMITEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getEscalationStrategyTypeAccess().getDEFAULT_NO_COMMITEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:1873:3: (enumLiteral_2= 'NOTIFY_OPERATOR' )
                    {
                    // InternalDynamicGoalModel.g:1873:3: (enumLiteral_2= 'NOTIFY_OPERATOR' )
                    // InternalDynamicGoalModel.g:1874:4: enumLiteral_2= 'NOTIFY_OPERATOR'
                    {
                    enumLiteral_2=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getEscalationStrategyTypeAccess().getNOTIFY_OPERATOREnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getEscalationStrategyTypeAccess().getNOTIFY_OPERATOREnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEscalationStrategyType"


    // $ANTLR start "ruleOperationalMode"
    // InternalDynamicGoalModel.g:1884:1: ruleOperationalMode returns [Enumerator current=null] : ( (enumLiteral_0= 'NORMAL' ) | (enumLiteral_1= 'EMERGENCY' ) | (enumLiteral_2= 'MAINTENANCE' ) | (enumLiteral_3= 'ENERGY_SAVING' ) ) ;
    public final Enumerator ruleOperationalMode() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalDynamicGoalModel.g:1890:2: ( ( (enumLiteral_0= 'NORMAL' ) | (enumLiteral_1= 'EMERGENCY' ) | (enumLiteral_2= 'MAINTENANCE' ) | (enumLiteral_3= 'ENERGY_SAVING' ) ) )
            // InternalDynamicGoalModel.g:1891:2: ( (enumLiteral_0= 'NORMAL' ) | (enumLiteral_1= 'EMERGENCY' ) | (enumLiteral_2= 'MAINTENANCE' ) | (enumLiteral_3= 'ENERGY_SAVING' ) )
            {
            // InternalDynamicGoalModel.g:1891:2: ( (enumLiteral_0= 'NORMAL' ) | (enumLiteral_1= 'EMERGENCY' ) | (enumLiteral_2= 'MAINTENANCE' ) | (enumLiteral_3= 'ENERGY_SAVING' ) )
            int alt30=4;
            switch ( input.LA(1) ) {
            case 70:
                {
                alt30=1;
                }
                break;
            case 71:
                {
                alt30=2;
                }
                break;
            case 72:
                {
                alt30=3;
                }
                break;
            case 73:
                {
                alt30=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // InternalDynamicGoalModel.g:1892:3: (enumLiteral_0= 'NORMAL' )
                    {
                    // InternalDynamicGoalModel.g:1892:3: (enumLiteral_0= 'NORMAL' )
                    // InternalDynamicGoalModel.g:1893:4: enumLiteral_0= 'NORMAL'
                    {
                    enumLiteral_0=(Token)match(input,70,FOLLOW_2); 

                    				current = grammarAccess.getOperationalModeAccess().getNORMALEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getOperationalModeAccess().getNORMALEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDynamicGoalModel.g:1900:3: (enumLiteral_1= 'EMERGENCY' )
                    {
                    // InternalDynamicGoalModel.g:1900:3: (enumLiteral_1= 'EMERGENCY' )
                    // InternalDynamicGoalModel.g:1901:4: enumLiteral_1= 'EMERGENCY'
                    {
                    enumLiteral_1=(Token)match(input,71,FOLLOW_2); 

                    				current = grammarAccess.getOperationalModeAccess().getEMERGENCYEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getOperationalModeAccess().getEMERGENCYEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDynamicGoalModel.g:1908:3: (enumLiteral_2= 'MAINTENANCE' )
                    {
                    // InternalDynamicGoalModel.g:1908:3: (enumLiteral_2= 'MAINTENANCE' )
                    // InternalDynamicGoalModel.g:1909:4: enumLiteral_2= 'MAINTENANCE'
                    {
                    enumLiteral_2=(Token)match(input,72,FOLLOW_2); 

                    				current = grammarAccess.getOperationalModeAccess().getMAINTENANCEEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getOperationalModeAccess().getMAINTENANCEEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalDynamicGoalModel.g:1916:3: (enumLiteral_3= 'ENERGY_SAVING' )
                    {
                    // InternalDynamicGoalModel.g:1916:3: (enumLiteral_3= 'ENERGY_SAVING' )
                    // InternalDynamicGoalModel.g:1917:4: enumLiteral_3= 'ENERGY_SAVING'
                    {
                    enumLiteral_3=(Token)match(input,73,FOLLOW_2); 

                    				current = grammarAccess.getOperationalModeAccess().getENERGY_SAVINGEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getOperationalModeAccess().getENERGY_SAVINGEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperationalMode"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000016000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000000L,0x00000000000003C0L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x000000000001E000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000240000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000204000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000200188000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000108000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000003008000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000002008000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0FE0000000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000040008000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0xF000004080000010L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000002000000002L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0xF000000000000010L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000080000002L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000008100000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000040000000000L,0x0000000000000007L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000020000000010L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000040000008000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000600000008000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000400000008000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000038L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x001C000000008000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0018008000008000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0010000000008000L});

}