package org.dgm.tests;

public class DGMSpec {

}
